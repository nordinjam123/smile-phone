-- Agregar campo tipo a la tabla facturas
ALTER TABLE public.facturas 
ADD COLUMN tipo TEXT NOT NULL DEFAULT 'servicio';

-- Crear índice para mejorar performance en consultas por tipo
CREATE INDEX idx_facturas_tipo ON public.facturas(tipo);

-- Agregar constraint para validar tipos permitidos
ALTER TABLE public.facturas 
ADD CONSTRAINT facturas_tipo_check 
CHECK (tipo IN ('servicio', 'venta_moviles', 'inventario'));