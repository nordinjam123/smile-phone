-- Crear tabla de órdenes de trabajo
CREATE TABLE public.ordenes_trabajo (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  numero_orden TEXT NOT NULL,
  cliente_nombre TEXT NOT NULL,
  cliente_telefono TEXT,
  cliente_email TEXT,
  dispositivo TEXT NOT NULL,
  problema TEXT NOT NULL,
  solucion TEXT,
  estado TEXT NOT NULL DEFAULT 'pendiente' CHECK (estado IN ('pendiente', 'en_proceso', 'completado', 'entregado')),
  prioridad TEXT NOT NULL DEFAULT 'media' CHECK (prioridad IN ('baja', 'media', 'alta', 'urgente')),
  precio NUMERIC(10,2) DEFAULT 0,
  fecha_ingreso DATE NOT NULL DEFAULT CURRENT_DATE,
  fecha_estimada DATE,
  fecha_completado DATE,
  notas TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Crear tabla de citas
CREATE TABLE public.citas (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  cliente_nombre TEXT NOT NULL,
  cliente_telefono TEXT,
  cliente_email TEXT,
  fecha DATE NOT NULL,
  hora TIME NOT NULL,
  servicio TEXT NOT NULL,
  notas TEXT,
  estado TEXT NOT NULL DEFAULT 'programada' CHECK (estado IN ('programada', 'confirmada', 'completada', 'cancelada')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Crear tabla de clientes
CREATE TABLE public.clientes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  nombre TEXT NOT NULL,
  telefono TEXT,
  email TEXT,
  direccion TEXT,
  notas TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Crear tabla de inventario
CREATE TABLE public.inventario (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  nombre TEXT NOT NULL,
  descripcion TEXT,
  categoria TEXT,
  precio NUMERIC(10,2) NOT NULL DEFAULT 0,
  stock INTEGER NOT NULL DEFAULT 0,
  stock_minimo INTEGER NOT NULL DEFAULT 1,
  proveedor TEXT,
  codigo_barras TEXT,
  ubicacion TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Habilitar RLS en todas las tablas
ALTER TABLE public.ordenes_trabajo ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.citas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.clientes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.inventario ENABLE ROW LEVEL SECURITY;

-- Políticas RLS para ordenes_trabajo
CREATE POLICY "Users can view their own work orders" 
ON public.ordenes_trabajo 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own work orders" 
ON public.ordenes_trabajo 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own work orders" 
ON public.ordenes_trabajo 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own work orders" 
ON public.ordenes_trabajo 
FOR DELETE 
USING (auth.uid() = user_id);

-- Políticas RLS para citas
CREATE POLICY "Users can view their own appointments" 
ON public.citas 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own appointments" 
ON public.citas 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own appointments" 
ON public.citas 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own appointments" 
ON public.citas 
FOR DELETE 
USING (auth.uid() = user_id);

-- Políticas RLS para clientes
CREATE POLICY "Users can view their own clients" 
ON public.clientes 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own clients" 
ON public.clientes 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own clients" 
ON public.clientes 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own clients" 
ON public.clientes 
FOR DELETE 
USING (auth.uid() = user_id);

-- Políticas RLS para inventario
CREATE POLICY "Users can view their own inventory" 
ON public.inventario 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own inventory" 
ON public.inventario 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own inventory" 
ON public.inventario 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own inventory" 
ON public.inventario 
FOR DELETE 
USING (auth.uid() = user_id);

-- Crear triggers para actualizar updated_at
CREATE TRIGGER update_ordenes_trabajo_updated_at
BEFORE UPDATE ON public.ordenes_trabajo
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_citas_updated_at
BEFORE UPDATE ON public.citas
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_clientes_updated_at
BEFORE UPDATE ON public.clientes
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_inventario_updated_at
BEFORE UPDATE ON public.inventario
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Crear índices para mejorar rendimiento
CREATE INDEX idx_ordenes_trabajo_user_id ON public.ordenes_trabajo(user_id);
CREATE INDEX idx_ordenes_trabajo_estado ON public.ordenes_trabajo(estado);
CREATE INDEX idx_ordenes_trabajo_fecha_ingreso ON public.ordenes_trabajo(fecha_ingreso);

CREATE INDEX idx_citas_user_id ON public.citas(user_id);
CREATE INDEX idx_citas_fecha ON public.citas(fecha);
CREATE INDEX idx_citas_estado ON public.citas(estado);

CREATE INDEX idx_clientes_user_id ON public.clientes(user_id);
CREATE INDEX idx_inventario_user_id ON public.inventario(user_id);
CREATE INDEX idx_inventario_stock ON public.inventario(stock);