import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { useTranslation } from '@/lib/i18n/useTranslation';
import { 
  FileDown,
  FileUp,
  HardDrive,
  Shield,
  Monitor
} from 'lucide-react';

const LocalBackupManager: React.FC = () => {
  const { toast } = useToast();
  const { t } = useTranslation();

  // Función para exportar todos los datos
  const handleExportData = () => {
    try {
      const data = {
        ordenes: JSON.parse(localStorage.getItem('ordenes') || '[]'),
        clientes: JSON.parse(localStorage.getItem('clientes') || '[]'),
        inventario: JSON.parse(localStorage.getItem('inventario') || '[]'),
        inventario_piezas: JSON.parse(localStorage.getItem('inventario_piezas') || '[]'),
        moviles: JSON.parse(localStorage.getItem('moviles') || '[]'),
        facturas: JSON.parse(localStorage.getItem('facturas') || '[]'),
        gastos_mercancia: JSON.parse(localStorage.getItem('gastos_mercancia') || '[]'),
        citas: JSON.parse(localStorage.getItem('citas') || '[]'),
        configuracion: JSON.parse(localStorage.getItem('configuracion') || '{}'),
        exportDate: new Date().toISOString(),
        version: '1.0'
      };

      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `techrepair-backup-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      toast({
        title: t.backup.backupCreated,
        description: t.backup.backupSuccess,
      });
    } catch (error) {
      toast({
        title: t.common.error,
        description: t.backup.exportError,
        variant: "destructive",
      });
    }
  };

  // Función para importar datos
  const handleImportData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const data = JSON.parse(content);

        // Verificar estructura del archivo
        if (!data.version || !data.exportDate) {
          throw new Error('Archivo de copia de seguridad no válido');
        }

        // Confirmar importación
        if (confirm(t.backup.confirmImport)) {
          // Importar cada sección
          Object.keys(data).forEach(key => {
            if (key !== 'exportDate' && key !== 'version') {
              localStorage.setItem(key, JSON.stringify(data[key]));
            }
          });

          toast({
            title: t.backup.dataImported,
            description: t.backup.importSuccess,
          });

          // Recargar página después de 2 segundos
          setTimeout(() => {
            window.location.reload();
          }, 2000);
        }
      } catch (error) {
        toast({
          title: t.common.error,
          description: t.backup.importError,
          variant: "destructive",
        });
      }
    };
    reader.readAsText(file);
    
    // Limpiar input
    event.target.value = '';
  };

  return (
    <Card className="border-blue-200 bg-gradient-to-r from-blue-50 to-indigo-50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-blue-800">
          <Shield className="h-5 w-5" />
          {t.backup.title}
        </CardTitle>
        <CardDescription className="text-blue-600">
          {t.backup.description}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
          <div className="flex items-start gap-2">
            <Monitor className="h-4 w-4 text-yellow-600 mt-0.5" />
            <div>
              <p className="font-medium text-yellow-800 text-sm">{t.backup.needOtherDevice}</p>
              <p className="text-xs text-yellow-700 mt-1">
                {t.backup.backupInstructions}
              </p>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <Button onClick={handleExportData} className="h-auto p-4 flex flex-col gap-2">
            <FileDown className="h-6 w-6" />
            <div className="text-center">
              <div className="font-medium">{t.backup.exportData}</div>
              <div className="text-xs opacity-90">{t.backup.downloadBackup}</div>
            </div>
          </Button>
          
          <div>
            <input
              type="file"
              accept=".json"
              onChange={handleImportData}
              style={{ display: 'none' }}
              id="import-file"
            />
            <Button 
              onClick={() => document.getElementById('import-file')?.click()} 
              variant="outline" 
              className="h-auto p-4 flex flex-col gap-2 w-full border-blue-200 hover:bg-blue-50"
            >
              <FileUp className="h-6 w-6" />
              <div className="text-center">
                <div className="font-medium">{t.backup.importData}</div>
                <div className="text-xs opacity-70">{t.backup.uploadBackup}</div>
              </div>
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 text-center">
          <div className="bg-white/60 rounded-lg p-3">
            <HardDrive className="h-5 w-5 text-blue-600 mx-auto mb-1" />
            <p className="text-xs font-medium text-blue-800">{t.backup.localStorage}</p>
            <p className="text-xs text-blue-600">{t.backup.dataInBrowser}</p>
          </div>
          <div className="bg-white/60 rounded-lg p-3">
            <Shield className="h-5 w-5 text-green-600 mx-auto mb-1" />
            <p className="text-xs font-medium text-green-800">{t.backup.private}</p>
            <p className="text-xs text-green-600">{t.backup.totalControl}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default LocalBackupManager;
