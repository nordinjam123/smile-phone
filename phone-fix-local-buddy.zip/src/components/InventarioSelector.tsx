import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import jsPDF from "jspdf";
import QRCode from "qrcode";
import {
  Plus,
  Search,
  Edit,
  Trash2,
  Package,
  AlertTriangle,
  TrendingDown,
  TrendingUp,
  Wrench,
  ShoppingCart,
  Receipt,
  DollarSign,
  Ticket,
  Eye,
  ScanLine
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { format } from "date-fns";
import BarcodeScanner from "./BarcodeScanner";
import { useEmpresaConfig } from "@/hooks/useEmpresaConfig";

interface ProductoPieza {
  id: string;
  nombre: string;
  categoria: string;
  marca: string;
  modelo: string;
  descripcion: string;
  stock: number;
  stockMinimo: number;
  precio: number;
  proveedor: string;
  fechaIngreso: string;
  codigoBarras?: string;
}

interface ProductoMercancia {
  id: string;
  nombre: string;
  descripcion: string;
  categoria: string;
  precio: number;
  codigoBarras?: string;
  stock: number;
  stock_minimo: number;
  proveedor: string;
  created_at: string;
  updated_at: string;
}

type TipoInventario = "piezas" | "mercancia";

const categoriasPiezas = [
  "Pantallas",
  "Baterías", 
  "Cargadores",
  "Cables",
  "Componentes Internos",
  "Herramientas",
  "Otros"
];

const categoriasMercancia = [
  "Protectores y Cristales",
  "Audio y Auriculares", 
  "Cargadores y Cables",
  "Fundas y Accesorios",
  "Repuestos Externos",
  "Otros"
];

export default function InventarioSelector() {
  const [tipoInventario, setTipoInventario] = useState<TipoInventario>("piezas");
  const [productosPiezas, setProductosPiezas] = useLocalStorage<ProductoPieza[]>("inventario_piezas", []);
  const [productosMercancia, setProductosMercancia] = useState<ProductoMercancia[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCategoria, setFilterCategoria] = useState<string>("todas");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isVentaDialogOpen, setIsVentaDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<any>(null);
  const [productoVenta, setProductoVenta] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [isBarcodeSearchOpen, setIsBarcodeSearchOpen] = useState(false);
  const [isBarcodeAddOpen, setIsBarcodeAddOpen] = useState(false);
  const { config: empresaConfig } = useEmpresaConfig();
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    nombre: "",
    categoria: "",
    marca: "",
    modelo: "",
    descripcion: "",
    stock: "",
    stockMinimo: "",
    precio: "",
    proveedor: "",
    codigoBarras: ""
  });

  const [ventaData, setVentaData] = useState({
    cantidad: "1",
    cliente_nombre: "",
    cliente_telefono: "",
    descuento: "0"
  });

  useEffect(() => {
    if (tipoInventario === "mercancia") {
      fetchProductosMercancia();
    }
  }, [tipoInventario]);

  const fetchProductosMercancia = async () => {
    try {
      // Cargar desde localStorage (sincronizado con gastos)
      const mercanciaLocal = localStorage.getItem('inventario_mercancia');
      if (mercanciaLocal) {
        setProductosMercancia(JSON.parse(mercanciaLocal));
        return;
      }

      // Si no hay datos locales, cargar desde Supabase
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) return;

      const { data, error } = await supabase
        .from('inventario')
        .select('*')
        .eq('user_id', user.user.id)
        .in('categoria', categoriasMercancia);

      if (error) {
        console.log('Usando localStorage para mercancía');
        setProductosMercancia([]);
        return;
      }

      setProductosMercancia(data || []);
    } catch (error) {
      console.error('Error fetching mercancia:', error);
      setProductosMercancia([]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.nombre || !formData.categoria || !formData.stock || !formData.precio) {
      toast({
        title: "Error",
        description: "Por favor completa los campos obligatorios",
        variant: "destructive"
      });
      return;
    }

    const productData = {
      nombre: formData.nombre,
      categoria: formData.categoria,
      marca: formData.marca,
      modelo: formData.modelo,
      descripcion: formData.descripcion,
      stock: parseInt(formData.stock),
      stockMinimo: parseInt(formData.stockMinimo) || 5,
      precio: parseFloat(formData.precio),
      proveedor: formData.proveedor,
      fechaIngreso: format(new Date(), "yyyy-MM-dd")
    };

    try {
      if (tipoInventario === "piezas") {
        if (editingProduct) {
          const updatedProducts = productosPiezas.map(p => 
            p.id === editingProduct.id ? { ...productData, id: editingProduct.id } : p
          );
          setProductosPiezas(updatedProducts);
        } else {
          const newProduct = { ...productData, id: Date.now().toString() };
          setProductosPiezas([...productosPiezas, newProduct]);
        }
      } else {
        // Mercancía - guardar en localStorage
        const mercanciaLocal = JSON.parse(localStorage.getItem('inventario_mercancia') || '[]');
        if (editingProduct) {
          const updatedMercancia = mercanciaLocal.map((p: any) => 
            p.id === editingProduct.id ? { ...productData, id: editingProduct.id } : p
          );
          localStorage.setItem('inventario_mercancia', JSON.stringify(updatedMercancia));
          setProductosMercancia(updatedMercancia);
        } else {
          const newProduct = { 
            ...productData, 
            id: Date.now().toString(),
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          };
          const updatedMercancia = [...mercanciaLocal, newProduct];
          localStorage.setItem('inventario_mercancia', JSON.stringify(updatedMercancia));
          setProductosMercancia(updatedMercancia);
        }
      }

      toast({
        title: editingProduct ? "Producto actualizado" : "Producto añadido",
        description: "El producto ha sido guardado exitosamente"
      });

      resetForm();
      setIsDialogOpen(false);
    } catch (error) {
      console.error('Error saving product:', error);
      toast({
        title: "Error",
        description: "No se pudo guardar el producto",
        variant: "destructive"
      });
    }
  };

  const resetForm = () => {
    setFormData({
      nombre: "",
      categoria: "",
      marca: "",
      modelo: "",
      descripcion: "",
      stock: "",
      stockMinimo: "",
      precio: "",
      proveedor: "",
      codigoBarras: ""
    });
    setEditingProduct(null);
  };

  const handleBarcodeSearch = (code: string) => {
    console.log("Buscando producto con código:", code);

    // Buscar en productos actuales por código de barras exacto o nombre
    const currentProducts = tipoInventario === "piezas" ? productosPiezas : productosMercancia;
    const foundProduct = currentProducts.find(p =>
      p.codigoBarras === code ||
      p.nombre.toLowerCase().includes(code.toLowerCase()) ||
      p.descripcion?.toLowerCase().includes(code.toLowerCase())
    );

    if (foundProduct) {
      setSearchTerm(foundProduct.codigoBarras || code);
      toast({
        title: "Producto encontrado",
        description: `${foundProduct.nombre} - Stock: ${foundProduct.stock}`,
        variant: "default"
      });
    } else {
      toast({
        title: "Producto no encontrado",
        description: `No se encontró ningún producto con el código: ${code}`,
        variant: "destructive"
      });
    }

    setIsBarcodeSearchOpen(false);
  };

  const handleBarcodeAdd = (code: string) => {
    // Rellenar automáticamente el formulario con el código de barras
    setFormData({
      ...formData,
      nombre: `Producto-${code}`,
      descripcion: `Código de barras: ${code}`,
      codigoBarras: code
    });

    toast({
      title: "Código capturado",
      description: `Código ${code} añadido al formulario`,
      variant: "default"
    });

    setIsBarcodeAddOpen(false);
    setIsDialogOpen(true);
  };

  const handleEdit = (product: any) => {
    setEditingProduct(product);
    setFormData({
      nombre: product.nombre,
      categoria: product.categoria,
      marca: product.marca || "",
      modelo: product.modelo || "",
      descripcion: product.descripcion || "",
      stock: product.stock.toString(),
      stockMinimo: (product.stockMinimo || product.stock_minimo || 5).toString(),
      precio: product.precio.toString(),
      proveedor: product.proveedor || "",
      codigoBarras: product.codigoBarras || ""
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    if (tipoInventario === "piezas") {
      setProductosPiezas(productosPiezas.filter(p => p.id !== id));
    } else {
      const mercanciaLocal = JSON.parse(localStorage.getItem('inventario_mercancia') || '[]');
      const updatedMercancia = mercanciaLocal.filter((p: any) => p.id !== id);
      localStorage.setItem('inventario_mercancia', JSON.stringify(updatedMercancia));
      setProductosMercancia(updatedMercancia);
    }

    toast({
      title: "Producto eliminado",
      description: "El producto ha sido eliminado del inventario"
    });
  };

  const handleVenta = (product: any) => {
    setProductoVenta(product);
    setVentaData({
      cantidad: "1",
      cliente_nombre: "",
      cliente_telefono: "",
      descuento: "0"
    });
    setIsVentaDialogOpen(true);
  };

  const procesarVenta = async () => {
    if (!productoVenta) return;

    const cantidad = parseInt(ventaData.cantidad);
    const descuento = parseFloat(ventaData.descuento);
    
    if (cantidad > productoVenta.stock) {
      toast({
        title: "Error",
        description: "No hay suficiente stock disponible",
        variant: "destructive"
      });
      return;
    }

    const subtotal = productoVenta.precio * cantidad;
    const totalDescuento = (subtotal * descuento) / 100;
    const total = subtotal - totalDescuento;

    // Actualizar stock
    if (tipoInventario === "piezas") {
      const updatedProducts = productosPiezas.map(p => 
        p.id === productoVenta.id ? { ...p, stock: p.stock - cantidad } : p
      );
      setProductosPiezas(updatedProducts);
    } else {
      const mercanciaLocal = JSON.parse(localStorage.getItem('inventario_mercancia') || '[]');
      const updatedMercancia = mercanciaLocal.map((p: any) => 
        p.id === productoVenta.id ? { ...p, stock: p.stock - cantidad } : p
      );
      localStorage.setItem('inventario_mercancia', JSON.stringify(updatedMercancia));
      setProductosMercancia(updatedMercancia);
    }

    // Generar factura automáticamente si hay cliente
    if (ventaData.cliente_nombre) {
      await crearFacturaVenta(productoVenta, cantidad, total);
    }

    toast({
      title: "Venta procesada",
      description: `Se han vendido ${cantidad} unidades de ${productoVenta.nombre}`
    });

    setIsVentaDialogOpen(false);
    setProductoVenta(null);
  };

  const crearFacturaVenta = async (producto: any, cantidad: number, total: number) => {
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) return;

      const subtotal = total / 1.21; // Quitar IVA para calcular subtotal
      const iva = total - subtotal;

      const conceptos = [{
        id: "1",
        descripcion: producto.nombre,
        cantidad: cantidad,
        precio: producto.precio,
        total: producto.precio * cantidad
      }];

      const facturaData = {
        numero: `VTA-${Date.now()}`,
        cliente_nombre: ventaData.cliente_nombre,
        cliente_telefono: ventaData.cliente_telefono,
        fecha: format(new Date(), "yyyy-MM-dd"),
        conceptos: conceptos,
        subtotal: subtotal,
        iva: iva,
        total: total,
        estado: "pagada",
        tipo: "inventario",
        empresa_nombre: "TechRepair Pro",
        user_id: user.user.id
      };

      await supabase.from('facturas').insert(facturaData);
      
      toast({
        title: "Factura creada",
        description: "Se ha generado la factura de venta automáticamente"
      });
    } catch (error) {
      console.error('Error creating invoice:', error);
    }
  };

  const generarTicket = async (product: any) => {
    const doc = new jsPDF({
      format: [80, 200],
      unit: 'mm'
    });

    let y = 10;
    const margen = 5;

    // Datos para el código QR
    const productoData = {
      id: product.id,
      nombre: product.nombre,
      tipo: 'INVENTARIO',
      categoria: product.categoria,
      precio: product.precio,
      stock: product.stock,
      empresa: 'TECHREPAIR PRO' // Se actualizará después de cargar la configuración
    };

    // Actualizar datos del QR con configuración de empresa
    productoData.empresa = empresaConfig.nombreEmpresa;

    // Header con datos completos de la empresa
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text(empresaConfig.nombreEmpresa, 40, y, { align: 'center' });
    y += 8;

    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    if (empresaConfig.direccion) {
      doc.text(empresaConfig.direccion, 40, y, { align: 'center' });
      y += 5;
    }
    if (empresaConfig.telefono) {
      doc.text(`Tel: ${empresaConfig.telefono}`, 40, y, { align: 'center' });
      y += 5;
    }
    if (empresaConfig.cif) {
      doc.text(`${empresaConfig.tipoDocumento}: ${empresaConfig.cif}`, 40, y, { align: 'center' });
      y += 5;
    }
    if (empresaConfig.email) {
      doc.text(empresaConfig.email, 40, y, { align: 'center' });
      y += 5;
    }

    // Línea separadora
    y += 3;
    doc.setLineWidth(0.5);
    doc.line(margen, y, 75, y);
    y += 7;

    doc.setFont('helvetica', 'bold');
    doc.text('TICKET DE INVENTARIO', 40, y, { align: 'center' });
    y += 10;
    
    // Información del producto
    doc.setFontSize(10);
    doc.text(`Producto: ${product.nombre}`, margen, y);
    y += 6;
    
    if (product.marca) {
      doc.text(`Marca: ${product.marca}`, margen, y);
      y += 5;
    }
    
    if (product.modelo) {
      doc.text(`Modelo: ${product.modelo}`, margen, y);
      y += 5;
    }
    
    doc.text(`Categoría: ${product.categoria}`, margen, y);
    y += 5;
    
    doc.text(`Stock: ${product.stock} unidades`, margen, y);
    y += 5;
    
    doc.text(`Precio: €${product.precio.toFixed(2)}`, margen, y);
    y += 5;
    
    if (product.proveedor) {
      doc.text(`Proveedor: ${product.proveedor}`, margen, y);
      y += 5;
    }
    
    y += 5;
    doc.line(margen, y, 75, y);
    y += 5;

    // Configuración específica de inventario
    if (empresaConfig.configuracionInventario?.mostrarEnTicket) {
      if (empresaConfig.configuracionInventario.textoPersonalizado) {
        doc.setFontSize(7);
        doc.setFont('helvetica', 'bold');
        doc.text(empresaConfig.configuracionInventario.textoPersonalizado, 40, y, { align: 'center' });
        y += 4;
      }

      if (empresaConfig.configuracionInventario.informacionAdicional) {
        doc.setFontSize(6);
        doc.setFont('helvetica', 'normal');
        doc.text(empresaConfig.configuracionInventario.informacionAdicional, 40, y, { align: 'center' });
        y += 4;
      }

      if (empresaConfig.configuracionInventario.terminos) {
        doc.setFontSize(6);
        doc.setFont('helvetica', 'normal');
        empresaConfig.configuracionInventario.terminos.split('\n').forEach(termino => {
          if (termino.trim()) {
            doc.text(termino.trim(), margen, y);
            y += 3;
          }
        });
        y += 2;
      }
    }

    doc.setFontSize(8);
    doc.text(`Fecha: ${format(new Date(), "dd/MM/yyyy HH:mm")}`, margen, y);
    y += 10;

    // Código QR
    try {
      const qrDataString = JSON.stringify(productoData);
      const qrCodeDataURL = await QRCode.toDataURL(qrDataString, {
        width: 120,
        margin: 2,
        color: {
          dark: '#000000',
          light: '#FFFFFF'
        },
        errorCorrectionLevel: 'M'
      });

      doc.addImage(qrCodeDataURL, 'PNG', 25, y, 30, 30);
      y += 35;

    } catch (error) {
      console.error('Error generando código QR:', error);
      // Continuar sin QR si hay error
    }

    window.open(doc.output('bloburl'), '_blank');
  };

  const currentProducts = tipoInventario === "piezas" ? productosPiezas : productosMercancia;
  const currentCategorias = tipoInventario === "piezas" ? categoriasPiezas : categoriasMercancia;

  const filteredProducts = currentProducts.filter(product => {
    const matchesSearch = product.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.categoria.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (product.descripcion && product.descripcion.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategoria = filterCategoria === "todas" || product.categoria === filterCategoria;
    return matchesSearch && matchesCategoria;
  });

  const stockBajo = currentProducts.filter(p => p.stock <= (p.stockMinimo || p.stock_minimo || 5));
  const valorTotal = currentProducts.reduce((total, p) => total + (p.precio * p.stock), 0);

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">Inventario</h1>
          <p className="text-slate-600">Gestión de piezas y mercancía</p>
        </div>
        <div className="flex gap-4">
          <Select value={tipoInventario} onValueChange={(value) => setTipoInventario(value as TipoInventario)}>
            <SelectTrigger className="w-[200px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="piezas">
                <div className="flex items-center gap-2">
                  <Wrench className="w-4 h-4" />
                  Piezas de Telefonía
                </div>
              </SelectItem>
              <SelectItem value="mercancia">
                <div className="flex items-center gap-2">
                  <ShoppingCart className="w-4 h-4" />
                  Mercancía y Accesorios
                </div>
              </SelectItem>
            </SelectContent>
          </Select>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={resetForm}>
                <Plus className="w-4 h-4 mr-2" />
                Nuevo Producto
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>
                  {editingProduct ? "Editar Producto" : `Nuevo Producto - ${tipoInventario === "piezas" ? "Piezas" : "Mercancía"}`}
                </DialogTitle>
              </DialogHeader>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="nombre">Nombre del Producto *</Label>
                    <div className="flex gap-2">
                      <Input
                        id="nombre"
                        value={formData.nombre}
                        onChange={(e) => setFormData({...formData, nombre: e.target.value})}
                        placeholder="Nombre del producto"
                        required
                        className="flex-1"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setIsBarcodeAddOpen(true)}
                        className="px-3"
                      >
                        <ScanLine className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="categoria">Categoría *</Label>
                    <Select value={formData.categoria} onValueChange={(value) => setFormData({...formData, categoria: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecciona una categoría" />
                      </SelectTrigger>
                      <SelectContent>
                        {currentCategorias.map(categoria => (
                          <SelectItem key={categoria} value={categoria}>{categoria}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {tipoInventario === "piezas" && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="marca">Marca</Label>
                      <Input
                        id="marca"
                        value={formData.marca}
                        onChange={(e) => setFormData({...formData, marca: e.target.value})}
                        placeholder="Marca del producto"
                      />
                    </div>
                    <div>
                      <Label htmlFor="modelo">Modelo</Label>
                      <Input
                        id="modelo"
                        value={formData.modelo}
                        onChange={(e) => setFormData({...formData, modelo: e.target.value})}
                        placeholder="Modelo específico"
                      />
                    </div>
                  </div>
                )}

                <div>
                  <Label htmlFor="descripcion">Descripción</Label>
                  <Textarea
                    id="descripcion"
                    value={formData.descripcion}
                    onChange={(e) => setFormData({...formData, descripcion: e.target.value})}
                    placeholder="Descripción del producto"
                    rows={2}
                  />
                </div>

                <div>
                  <Label htmlFor="codigoBarras">Código de Barras</Label>
                  <Input
                    id="codigoBarras"
                    value={formData.codigoBarras}
                    onChange={(e) => setFormData({...formData, codigoBarras: e.target.value})}
                    placeholder="Código de barras del producto"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <Label htmlFor="stock">Stock *</Label>
                    <Input
                      id="stock"
                      type="number"
                      min="0"
                      value={formData.stock}
                      onChange={(e) => setFormData({...formData, stock: e.target.value})}
                      placeholder="0"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="stockMinimo">Stock Mínimo</Label>
                    <Input
                      id="stockMinimo"
                      type="number"
                      min="0"
                      value={formData.stockMinimo}
                      onChange={(e) => setFormData({...formData, stockMinimo: e.target.value})}
                      placeholder="5"
                    />
                  </div>
                  <div>
                    <Label htmlFor="precio">Precio (€) *</Label>
                    <Input
                      id="precio"
                      type="number"
                      min="0"
                      step="0.01"
                      value={formData.precio}
                      onChange={(e) => setFormData({...formData, precio: e.target.value})}
                      placeholder="0.00"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="proveedor">Proveedor</Label>
                    <Input
                      id="proveedor"
                      value={formData.proveedor}
                      onChange={(e) => setFormData({...formData, proveedor: e.target.value})}
                      placeholder="Proveedor"
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancelar
                  </Button>
                  <Button type="submit">
                    {editingProduct ? "Actualizar" : "Añadir"} Producto
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Métricas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Productos</p>
                <p className="text-2xl font-bold">{currentProducts.length}</p>
              </div>
              <Package className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Stock Bajo</p>
                <p className="text-2xl font-bold text-red-600">{stockBajo.length}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Valor Total</p>
                <p className="text-2xl font-bold text-green-600">€{valorTotal.toLocaleString()}</p>
              </div>
              <DollarSign className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Categorías</p>
                <p className="text-2xl font-bold text-purple-600">
                  {new Set(currentProducts.map(p => p.categoria)).size}
                </p>
              </div>
              <TrendingUp className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar productos..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Button
              variant="outline"
              onClick={() => setIsBarcodeSearchOpen(true)}
              className="flex items-center gap-2"
            >
              <ScanLine className="w-4 h-4" />
              Buscar por Código
            </Button>
            <Select value={filterCategoria} onValueChange={setFilterCategoria}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Filtrar por categoría" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todas">Todas las categorías</SelectItem>
                {currentCategorias.map(categoria => (
                  <SelectItem key={categoria} value={categoria}>{categoria}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Products List */}
      <div className="grid gap-4">
        {filteredProducts.length === 0 ? (
          <Card>
            <CardContent className="pt-6 text-center">
              <Package className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No hay productos</h3>
              <p className="text-muted-foreground">
                {searchTerm || filterCategoria !== "todas" 
                  ? "No se encontraron productos con los filtros aplicados"
                  : "Añade tu primer producto al inventario"
                }
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredProducts.map((product) => (
            <Card key={product.id} className="hover:shadow-md transition-shadow">
              <CardContent className="pt-6">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="text-lg font-semibold">{product.nombre}</h3>
                      <Badge variant="outline">{product.categoria}</Badge>
                      {product.stock <= (product.stockMinimo || product.stock_minimo || 5) && (
                        <Badge variant="destructive">Stock Bajo</Badge>
                      )}
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm text-muted-foreground">
                      <div>Stock: {product.stock} unidades</div>
                      <div>Precio: €{product.precio.toFixed(2)}</div>
                      {product.marca && <div>Marca: {product.marca}</div>}
                      {product.proveedor && <div>Proveedor: {product.proveedor}</div>}
                    </div>
                    {product.descripcion && (
                      <p className="mt-2 text-sm">{product.descripcion}</p>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => generarTicket(product)}
                      title="Generar Ticket"
                    >
                      <Receipt className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleVenta(product)}
                      title="Procesar Venta"
                      disabled={product.stock === 0}
                    >
                      <DollarSign className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEdit(product)}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleDelete(product.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Dialog de Venta */}
      <Dialog open={isVentaDialogOpen} onOpenChange={setIsVentaDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Procesar Venta</DialogTitle>
          </DialogHeader>
          
          {productoVenta && (
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold">{productoVenta.nombre}</h3>
                <p className="text-sm text-gray-600">Stock disponible: {productoVenta.stock}</p>
                <p className="text-sm text-gray-600">Precio: €{productoVenta.precio.toFixed(2)}</p>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="cantidad">Cantidad</Label>
                  <Input
                    id="cantidad"
                    type="number"
                    min="1"
                    max={productoVenta.stock}
                    value={ventaData.cantidad}
                    onChange={(e) => setVentaData({...ventaData, cantidad: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="descuento">Descuento (%)</Label>
                  <Input
                    id="descuento"
                    type="number"
                    min="0"
                    max="100"
                    value={ventaData.descuento}
                    onChange={(e) => setVentaData({...ventaData, descuento: e.target.value})}
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="cliente_nombre">Cliente (opcional)</Label>
                <Input
                  id="cliente_nombre"
                  value={ventaData.cliente_nombre}
                  onChange={(e) => setVentaData({...ventaData, cliente_nombre: e.target.value})}
                  placeholder="Nombre del cliente"
                />
              </div>
              
              <div>
                <Label htmlFor="cliente_telefono">Teléfono (opcional)</Label>
                <Input
                  id="cliente_telefono"
                  value={ventaData.cliente_telefono}
                  onChange={(e) => setVentaData({...ventaData, cliente_telefono: e.target.value})}
                  placeholder="Teléfono del cliente"
                />
              </div>
              
              <div className="border-t pt-4">
                <div className="flex justify-between text-lg font-semibold">
                  <span>Total:</span>
                  <span>
                    €{(
                      (productoVenta.precio * parseInt(ventaData.cantidad || "1")) * 
                      (1 - parseFloat(ventaData.descuento || "0") / 100)
                    ).toFixed(2)}
                  </span>
                </div>
              </div>
              
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setIsVentaDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button onClick={procesarVenta}>
                  Procesar Venta
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Escáner para búsqueda */}
      <BarcodeScanner
        isOpen={isBarcodeSearchOpen}
        onClose={() => setIsBarcodeSearchOpen(false)}
        onScan={handleBarcodeSearch}
        title="Buscar Producto por Código de Barras"
      />

      {/* Escáner para añadir producto */}
      <BarcodeScanner
        isOpen={isBarcodeAddOpen}
        onClose={() => setIsBarcodeAddOpen(false)}
        onScan={handleBarcodeAdd}
        title="Capturar Código de Barras para Nuevo Producto"
      />
    </div>
  );
}
