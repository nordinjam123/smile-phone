-- Additional security fixes: Properly restrict RLS policies to authenticated users only

-- Fix profiles table policies - restrict to authenticated role only (remove anon access)
DROP POLICY IF EXISTS "Authenticated users can view their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Authenticated users can update their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Authenticated users can insert their own profile" ON public.profiles;

-- Create new super secure policies for profiles (authenticated role only, no anon access)
CREATE POLICY "Authenticated users view own profile" 
ON public.profiles 
FOR SELECT 
TO authenticated
USING (auth.uid() = id);

CREATE POLICY "Authenticated users update own profile" 
ON public.profiles 
FOR UPDATE 
TO authenticated
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);

CREATE POLICY "Authenticated users insert own profile" 
ON public.profiles 
FOR INSERT 
TO authenticated
WITH CHECK (auth.uid() = id);

-- Fix subscribers table policies - restrict to authenticated and service_role only
DROP POLICY IF EXISTS "Authenticated users can view their own subscription" ON public.subscribers;
DROP POLICY IF EXISTS "Service role can update subscriptions" ON public.subscribers;
DROP POLICY IF EXISTS "Authenticated users can insert their own subscription" ON public.subscribers;
DROP POLICY IF EXISTS "Edge functions can manage subscriptions" ON public.subscribers;

-- Create new secure policies for subscribers (no anon access)
CREATE POLICY "Authenticated users view own subscription" 
ON public.subscribers 
FOR SELECT 
TO authenticated
USING (user_id = auth.uid() OR email = auth.email());

-- Service role for edge functions (Stripe operations)
CREATE POLICY "Service role manages subscriptions" 
ON public.subscribers 
FOR ALL 
TO service_role
USING (true)
WITH CHECK (true);

-- Authenticated users can only insert their own subscription record
CREATE POLICY "Authenticated users insert own subscription" 
ON public.subscribers 
FOR INSERT 
TO authenticated
WITH CHECK (user_id = auth.uid() OR email = auth.email());