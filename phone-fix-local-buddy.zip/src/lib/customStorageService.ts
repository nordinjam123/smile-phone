import { createClient, SupabaseClient } from '@supabase/supabase-js';

export interface StorageProvider {
  id: string;
  name: string;
  description: string;
  icon: string;
  setupInstructions: string;
  estimatedCost: string;
  features: string[];
}

export interface CustomStorageConfig {
  provider: string;
  supabaseUrl?: string;
  supabaseKey?: string;
  awsAccessKey?: string;
  awsSecretKey?: string;
  awsRegion?: string;
  gcpProjectId?: string;
  gcpCredentials?: string;
  firebaseConfig?: string;
  connectionString?: string;
  isActive: boolean;
  createdAt: string;
  lastTested?: string;
  status: 'pending' | 'connected' | 'error' | 'testing';
  errorMessage?: string;
}

export const STORAGE_PROVIDERS: StorageProvider[] = [
  {
    id: 'supabase',
    name: 'Supabase (Propio)',
    description: 'Crea tu propia instancia de Supabase y paga directamente a ellos',
    icon: '🐘',
    estimatedCost: '$0-25/mes según uso',
    setupInstructions: `
1. Ve a supabase.com y crea una cuenta
2. Crea un nuevo proyecto
3. Ve a Settings > API
4. Copia la URL y la clave anon/public
5. Configura las tablas usando nuestro SQL automático
    `,
    features: [
      'Base de datos PostgreSQL completa',
      'Autenticación integrada', 
      'Almacenamiento de archivos',
      'Edge Functions',
      'Realtime subscriptions',
      'Backup automático'
    ]
  },
  {
    id: 'aws',
    name: 'AWS RDS + S3',
    description: 'Usa Amazon Web Services con tu propia cuenta',
    icon: '☁️',
    estimatedCost: '$10-50/mes según uso',
    setupInstructions: `
1. Crea una cuenta en AWS
2. Configura RDS PostgreSQL
3. Configura S3 bucket para archivos
4. Crea usuario IAM con permisos necesarios
5. Ingresa las credenciales aquí
    `,
    features: [
      'Escalabilidad infinita',
      'Múltiples regiones',
      'Alta disponibilidad',
      'Backups automáticos',
      'Monitoreo avanzado'
    ]
  },
  {
    id: 'gcp',
    name: 'Google Cloud Platform',
    description: 'Usa Google Cloud con tu propia facturación',
    icon: '🔵',
    estimatedCost: '$8-40/mes según uso',
    setupInstructions: `
1. Crea proyecto en Google Cloud Platform
2. Activa Cloud SQL (PostgreSQL)
3. Configura Cloud Storage
4. Crea service account
5. Descarga credenciales JSON
    `,
    features: [
      'Integración con Google Workspace',
      'BigQuery para analytics',
      'Machine Learning APIs',
      'Global CDN',
      'Kubernetes nativo'
    ]
  },
  {
    id: 'firebase',
    name: 'Firebase (Google)',
    description: 'Firebase Auth + Firestore - Autenticación y base de datos de Google',
    icon: '🔥',
    estimatedCost: 'Gratis hasta 50K lecturas/día',
    setupInstructions: `
1. Ve a Firebase Console (console.firebase.google.com)
2. Crea un nuevo proyecto
3. Activa Authentication (Email/Password + Google)
4. Activa Firestore Database
5. Configura reglas de seguridad
6. Copia la configuración web
    `,
    features: [
      'Autenticación Google nativa',
      'Base de datos NoSQL en tiempo real',
      'Hosting gratuito',
      'Cloud Functions',
      'Analytics integrados',
      'Push notifications'
    ]
  },
  {
    id: 'azure',
    name: 'Microsoft Azure',
    description: 'Usa Azure con tu suscripción empresarial',
    icon: '🔷',
    estimatedCost: '$12-45/mes según uso',
    setupInstructions: `
1. Crea suscripción Azure
2. Configura Azure Database for PostgreSQL
3. Configura Blob Storage
4. Crea App Registration
5. Configura permisos y conexión
    `,
    features: [
      'Integración Office 365',
      'Active Directory',
      'Compliance empresarial',
      'Híbrido on-premise',
      'Power BI integration'
    ]
  },
  {
    id: 'selfhosted',
    name: 'Servidor Propio',
    description: 'Hostea en tu propia infraestructura',
    icon: '🖥️',
    estimatedCost: '$20-100/mes servidor',
    setupInstructions: `
1. Configura servidor con PostgreSQL
2. Instala y configura autenticación
3. Configura SSL/HTTPS
4. Abre puertos necesarios
5. Proporciona string de conexión
    `,
    features: [
      'Control total',
      'Sin límites de transferencia',
      'Datos 100% privados',
      'Personalización completa',
      'Sin dependencias externas'
    ]
  }
];

class CustomStorageService {
  private customClient: SupabaseClient | null = null;
  private config: CustomStorageConfig | null = null;

  async saveStorageConfig(config: CustomStorageConfig): Promise<boolean> {
    try {
      // Encrypt sensitive data before saving
      const encryptedConfig = this.encryptSensitiveData(config);
      
      // Save to localStorage for now (in production, this should be encrypted)
      localStorage.setItem('customStorageConfig', JSON.stringify(encryptedConfig));
      
      this.config = config;
      return true;
    } catch (error) {
      console.error('Error saving storage config:', error);
      return false;
    }
  }

  async loadStorageConfig(): Promise<CustomStorageConfig | null> {
    try {
      const saved = localStorage.getItem('customStorageConfig');
      if (saved) {
        const config = JSON.parse(saved);
        this.config = this.decryptSensitiveData(config);
        return this.config;
      }
    } catch (error) {
      console.error('Error loading storage config:', error);
    }
    return null;
  }

  async testConnection(config: CustomStorageConfig): Promise<{ success: boolean; error?: string }> {
    try {
      if (config.provider === 'supabase' && config.supabaseUrl && config.supabaseKey) {
        const testClient = createClient(config.supabaseUrl, config.supabaseKey);
        
        // Test basic connection
        const { error } = await testClient
          .from('profiles')
          .select('count', { count: 'exact', head: true });
          
        if (error && !error.message.includes('does not exist')) {
          throw error;
        }
        
        return { success: true };
      }
      
      // Add tests for other providers here
      return { success: false, error: 'Provider not implemented yet' };
      
    } catch (error: any) {
      return { 
        success: false, 
        error: error.message || 'Connection test failed' 
      };
    }
  }

  async initializeCustomStorage(): Promise<boolean> {
    const config = await this.loadStorageConfig();
    if (!config || !config.isActive) {
      return false;
    }

    try {
      if (config.provider === 'supabase') {
        this.customClient = createClient(config.supabaseUrl!, config.supabaseKey!);
        return true;
      }
      
      // Initialize other providers here
      return false;
    } catch (error) {
      console.error('Error initializing custom storage:', error);
      return false;
    }
  }

  getCustomClient(): SupabaseClient | null {
    return this.customClient;
  }

  isUsingCustomStorage(): boolean {
    return this.customClient !== null && this.config?.isActive === true;
  }

  async createTables(client: SupabaseClient): Promise<{ success: boolean; errors: string[] }> {
    const errors: string[] = [];
    
    const tableCreationSQL = [
      // Clientes table
      `
      CREATE TABLE IF NOT EXISTS clientes (
        id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
        user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
        nombre TEXT NOT NULL,
        telefono TEXT,
        email TEXT,
        direccion TEXT,
        notas TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      );
      `,
      
      // Inventario table
      `
      CREATE TABLE IF NOT EXISTS inventario (
        id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
        user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
        nombre TEXT NOT NULL,
        descripcion TEXT,
        stock INTEGER DEFAULT 0,
        stock_minimo INTEGER DEFAULT 0,
        precio DECIMAL(10,2) DEFAULT 0,
        categoria TEXT,
        proveedor TEXT,
        ubicacion TEXT,
        codigo_barras TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      );
      `,
      
      // Ordenes de trabajo table
      `
      CREATE TABLE IF NOT EXISTS ordenes_trabajo (
        id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
        user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
        numero_orden TEXT NOT NULL,
        cliente_nombre TEXT NOT NULL,
        cliente_telefono TEXT,
        cliente_email TEXT,
        dispositivo TEXT NOT NULL,
        problema TEXT NOT NULL,
        solucion TEXT,
        estado TEXT DEFAULT 'pendiente',
        prioridad TEXT DEFAULT 'normal',
        precio DECIMAL(10,2),
        fecha_ingreso DATE DEFAULT CURRENT_DATE,
        fecha_estimada DATE,
        fecha_completado DATE,
        notas TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      );
      `,
      
      // Facturas table
      `
      CREATE TABLE IF NOT EXISTS facturas (
        id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
        user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
        numero TEXT NOT NULL,
        cliente_nombre TEXT NOT NULL,
        cliente_telefono TEXT,
        cliente_email TEXT,
        cliente_nif TEXT,
        cliente_cif TEXT,
        cliente_direccion TEXT,
        empresa_nombre TEXT,
        empresa_telefono TEXT,
        empresa_email TEXT,
        empresa_direccion TEXT,
        empresa_cif TEXT,
        conceptos JSONB DEFAULT '[]',
        subtotal DECIMAL(10,2) DEFAULT 0,
        iva DECIMAL(10,2) DEFAULT 0,
        total DECIMAL(10,2) DEFAULT 0,
        tipo TEXT DEFAULT 'factura',
        estado TEXT DEFAULT 'borrador',
        fecha DATE DEFAULT CURRENT_DATE,
        notas TEXT,
        logo_url TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      );
      `,
      
      // Gastos mercancia table
      `
      CREATE TABLE IF NOT EXISTS gastos_mercancia (
        id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
        user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
        categoria TEXT NOT NULL,
        tipo_producto TEXT NOT NULL,
        descripcion TEXT,
        proveedor TEXT NOT NULL,
        precio_unitario DECIMAL(10,2) NOT NULL,
        cantidad INTEGER NOT NULL DEFAULT 1,
        total DECIMAL(10,2) NOT NULL,
        fecha DATE DEFAULT CURRENT_DATE,
        notas TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      );
      `,
      
      // Citas table
      `
      CREATE TABLE IF NOT EXISTS citas (
        id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
        user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
        cliente_nombre TEXT NOT NULL,
        cliente_telefono TEXT,
        cliente_email TEXT,
        servicio TEXT NOT NULL,
        fecha DATE NOT NULL,
        hora TIME NOT NULL,
        estado TEXT DEFAULT 'programada',
        notas TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      );
      `
    ];

    try {
      for (const sql of tableCreationSQL) {
        const { error } = await client.rpc('exec_sql', { sql_query: sql });
        if (error) {
          console.warn('Table creation warning:', error);
          // Don't treat warnings as errors for table creation
        }
      }
      
      return { success: true, errors };
    } catch (error: any) {
      errors.push(error.message);
      return { success: false, errors };
    }
  }

  private encryptSensitiveData(config: CustomStorageConfig): any {
    // In production, implement proper encryption
    // For now, just return as-is (this is not secure!)
    return config;
  }

  private decryptSensitiveData(config: any): CustomStorageConfig {
    // In production, implement proper decryption
    return config;
  }

  async migrateToCustomStorage(sourceData: any): Promise<{ success: boolean; migrated: number; errors: string[] }> {
    if (!this.customClient) {
      return { success: false, migrated: 0, errors: ['Custom storage not initialized'] };
    }

    let migrated = 0;
    const errors: string[] = [];

    try {
      // Migrate each data type
      for (const [tableName, data] of Object.entries(sourceData)) {
        if (Array.isArray(data) && data.length > 0) {
          const { error } = await this.customClient
            .from(tableName)
            .upsert(data);
            
          if (error) {
            errors.push(`${tableName}: ${error.message}`);
          } else {
            migrated += data.length;
          }
        }
      }

      return { success: errors.length === 0, migrated, errors };
    } catch (error: any) {
      return { success: false, migrated, errors: [error.message] };
    }
  }
}

export const customStorageService = new CustomStorageService();
