import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Calculator,
  PieChart,
  BarChart3,
  FileText,
  Package
} from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart as RechartsPieChart, Cell, BarChart, Bar, Pie } from "recharts";

interface Orden {
  id: string;
  clienteNombre: string;
  dispositivo: string;
  marca: string;
  modelo: string;
  problema: string;
  coste: number;
  precio: number;
  estado: "pendiente" | "en_proceso" | "completado" | "entregado";
  fechaIngreso: string;
  fechaCompletado?: string;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

export default function BalancePage() {
  const [ordenes] = useLocalStorage<Orden[]>("ordenes", []);
  const [moviles] = useLocalStorage("moviles", []);
  const [movimientosRestock] = useLocalStorage("movimientos_restock", []);
  const [gastos] = useLocalStorage("gastos_mercancia", []);
  const [timeRange, setTimeRange] = useState<"semana" | "mes" | "trimestre" | "año">("mes");

  // Filtrar órdenes completadas
  const ordenesCompletadas = ordenes.filter(orden => orden.estado === "completado" || orden.estado === "entregado");
  
  // Calcular métricas totales (reparaciones + móviles)
  const totalIngresosReparaciones = ordenesCompletadas.reduce((sum, orden) => sum + orden.precio, 0);
  const totalCostesReparaciones = ordenesCompletadas.reduce((sum, orden) => sum + orden.coste, 0);
  
  const movilesVendidos = moviles.filter((m: any) => m.vendido);
  const totalIngresosMoviles = movilesVendidos.reduce((sum: number, movil: any) => sum + (movil.precioVenta || 0), 0);
  const totalCostesMoviles = movilesVendidos.reduce((sum: number, movil: any) => sum + movil.precioCompra, 0);

  // Calcular costes de restock de mercancía
  const totalCostesRestock = movimientosRestock.reduce((sum: number, movimiento: any) => sum + (movimiento.totalCoste || 0), 0);

  // Calcular gastos generales del negocio
  const totalGastos = gastos.reduce((sum: number, gasto: any) => sum + (gasto.total || 0), 0);

  const totalIngresos = totalIngresosReparaciones + totalIngresosMoviles;
  const totalCostes = totalCostesReparaciones + totalCostesMoviles + totalCostesRestock + totalGastos;
  const totalBeneficio = totalIngresos - totalCostes;
  const margenBeneficio = totalIngresos > 0 ? ((totalBeneficio / totalIngresos) * 100) : 0;

  // Métricas por período
  const today = new Date();
  const getDateRange = (range: string) => {
    const start = new Date(today);
    switch (range) {
      case "semana":
        start.setDate(today.getDate() - 7);
        break;
      case "mes":
        start.setMonth(today.getMonth() - 1);
        break;
      case "trimestre":
        start.setMonth(today.getMonth() - 3);
        break;
      case "año":
        start.setFullYear(today.getFullYear() - 1);
        break;
    }
    return start;
  };

  const startDate = getDateRange(timeRange);
  const ordenesPeriodo = ordenesCompletadas.filter(orden => {
    const fechaOrden = new Date(orden.fechaCompletado || orden.fechaIngreso);
    return fechaOrden >= startDate;
  });

  const ingresosPeriodo = ordenesPeriodo.reduce((sum, orden) => sum + orden.precio, 0);
  const costesPeriodo = ordenesPeriodo.reduce((sum, orden) => sum + orden.coste, 0);
  const beneficioPeriodo = ingresosPeriodo - costesPeriodo;

  // Datos para gráficos
  const generateTimeSeriesData = () => {
    const data = [];
    const days = timeRange === "semana" ? 7 : timeRange === "mes" ? 30 : timeRange === "trimestre" ? 90 : 365;
    
    for (let i = days; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(today.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      
      const ordenesDia = ordenesCompletadas.filter(orden => {
        const fechaOrden = orden.fechaCompletado || orden.fechaIngreso;
        return fechaOrden === dateStr;
      });
      
      const ingresos = ordenesDia.reduce((sum, orden) => sum + orden.precio, 0);
      const costes = ordenesDia.reduce((sum, orden) => sum + orden.coste, 0);
      
      data.push({
        fecha: dateStr,
        ingresos,
        costes,
        beneficio: ingresos - costes
      });
    }
    
    return data;
  };

  // Análisis por tipo de dispositivo
  const dispositivosData = ordenesCompletadas.reduce((acc, orden) => {
    const tipo = orden.dispositivo;
    if (!acc[tipo]) {
      acc[tipo] = { ingresos: 0, costes: 0, cantidad: 0 };
    }
    acc[tipo].ingresos += orden.precio;
    acc[tipo].costes += orden.coste;
    acc[tipo].cantidad += 1;
    return acc;
  }, {} as Record<string, { ingresos: number; costes: number; cantidad: number }>);

  const pieData = Object.entries(dispositivosData).map(([tipo, data]) => ({
    name: tipo,
    value: data.ingresos,
    beneficio: data.ingresos - data.costes
  }));

  const barData = Object.entries(dispositivosData).map(([tipo, data]) => ({
    dispositivo: tipo,
    ingresos: data.ingresos,
    costes: data.costes,
    beneficio: data.ingresos - data.costes,
    cantidad: data.cantidad
  }));

  const timeSeriesData = generateTimeSeriesData();

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
              <h1 className="text-3xl font-bold text-slate-800">Balance Financiero</h1>
              <p className="text-slate-600">Análisis completo: ingresos, gastos operativos, alquiler, impuestos y rentabilidad del negocio</p>
        </div>
        <div className="flex gap-2">
          {["semana", "mes", "trimestre", "año"].map((range) => (
            <Button
              key={range}
              variant={timeRange === range ? "default" : "outline"}
              size="sm"
              onClick={() => setTimeRange(range as any)}
            >
              {range.charAt(0).toUpperCase() + range.slice(1)}
            </Button>
          ))}
        </div>
      </div>

      {/* Métricas principales */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ingresos Totales</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">€{totalIngresos.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              €{ingresosPeriodo.toLocaleString()} en último {timeRange}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Costes Totales</CardTitle>
            <TrendingDown className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
             <div className="text-2xl font-bold text-red-600">€{totalCostes.toLocaleString()}</div>
             <div className="text-xs text-muted-foreground space-y-1 mt-2">
               <div>Reparaciones: €{totalCostesReparaciones.toLocaleString()}</div>
               <div>Móviles: €{totalCostesMoviles.toLocaleString()}</div>
               <div>Restock: €{totalCostesRestock.toLocaleString()}</div>
               <div>Gastos: €{totalGastos.toLocaleString()}</div>
             </div>
           </CardContent>
         </Card>

         <Card>
           <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
             <CardTitle className="text-sm font-medium">Beneficio Total</CardTitle>
             <TrendingUp className="h-4 w-4 text-muted-foreground" />
           </CardHeader>
           <CardContent>
             <div className="text-2xl font-bold text-blue-600">€{totalBeneficio.toLocaleString()}</div>
             <p className="text-xs text-muted-foreground">
               €{beneficioPeriodo.toLocaleString()} en último {timeRange}
             </p>
           </CardContent>
         </Card>

         <Card>
           <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
             <CardTitle className="text-sm font-medium">Margen de Beneficio</CardTitle>
             <Calculator className="h-4 w-4 text-muted-foreground" />
           </CardHeader>
           <CardContent>
             <div className="text-2xl font-bold text-purple-600">{margenBeneficio.toFixed(1)}%</div>
             <p className="text-xs text-muted-foreground">
               {ordenesCompletadas.length} órdenes completadas
             </p>
           </CardContent>
         </Card>
       </div>

       {/* Gráfico de tendencias */}
       <Card>
         <CardHeader>
           <CardTitle className="flex items-center gap-2">
             <BarChart3 className="h-5 w-5" />
             Tendencia Financiera - Último {timeRange}
           </CardTitle>
         </CardHeader>
         <CardContent>
           <ResponsiveContainer width="100%" height={300}>
             <LineChart data={timeSeriesData}>
               <CartesianGrid strokeDasharray="3 3" />
               <XAxis dataKey="fecha" />
               <YAxis />
               <Tooltip formatter={(value) => `€${Number(value).toLocaleString()}`} />
               <Legend />
               <Line type="monotone" dataKey="ingresos" stroke="#22c55e" strokeWidth={2} name="Ingresos" />
               <Line type="monotone" dataKey="costes" stroke="#ef4444" strokeWidth={2} name="Costes" />
               <Line type="monotone" dataKey="beneficio" stroke="#3b82f6" strokeWidth={2} name="Beneficio" />
             </LineChart>
           </ResponsiveContainer>
         </CardContent>
       </Card>

       {/* Análisis por dispositivos */}
       <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
         <Card>
           <CardHeader>
             <CardTitle className="flex items-center gap-2">
               <PieChart className="h-5 w-5" />
               Ingresos por Tipo de Dispositivo
             </CardTitle>
           </CardHeader>
           <CardContent>
             <ResponsiveContainer width="100%" height={300}>
               <RechartsPieChart>
                 <Pie
                   data={pieData}
                   cx="50%"
                   cy="50%"
                   labelLine={false}
                   label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                   outerRadius={80}
                   fill="#8884d8"
                   dataKey="value"
                 >
                   {pieData.map((entry, index) => (
                     <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                   ))}
                 </Pie>
                 <Tooltip formatter={(value) => `€${Number(value).toLocaleString()}`} />
               </RechartsPieChart>
             </ResponsiveContainer>
           </CardContent>
         </Card>

         <Card>
           <CardHeader>
             <CardTitle className="flex items-center gap-2">
               <BarChart3 className="h-5 w-5" />
               Análisis Detallado por Dispositivo
             </CardTitle>
           </CardHeader>
           <CardContent>
             <ResponsiveContainer width="100%" height={300}>
               <BarChart data={barData}>
                 <CartesianGrid strokeDasharray="3 3" />
                 <XAxis dataKey="dispositivo" />
                 <YAxis />
                 <Tooltip formatter={(value) => `€${Number(value).toLocaleString()}`} />
                 <Legend />
                 <Bar dataKey="ingresos" fill="#22c55e" name="Ingresos" />
                 <Bar dataKey="costes" fill="#ef4444" name="Costes" />
                 <Bar dataKey="beneficio" fill="#3b82f6" name="Beneficio" />
               </BarChart>
             </ResponsiveContainer>
           </CardContent>
         </Card>
       </div>

       {/* Movimientos de Restock */}
      {movimientosRestock.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Package className="h-5 w-5" />
              Movimientos de Restock de Mercancía
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 bg-blue-50 rounded-lg">
                  <h4 className="font-semibold text-blue-800">Total Invertido</h4>
                  <p className="text-2xl font-bold text-blue-600">€{totalCostesRestock.toFixed(2)}</p>
                </div>
                <div className="p-4 bg-green-50 rounded-lg">
                  <h4 className="font-semibold text-green-800">Productos Restockeados</h4>
                  <p className="text-2xl font-bold text-green-600">{movimientosRestock.length}</p>
                </div>
                <div className="p-4 bg-purple-50 rounded-lg">
                  <h4 className="font-semibold text-purple-800">Margen Promedio</h4>
                  <p className="text-2xl font-bold text-purple-600">
                    {movimientosRestock.length > 0
                      ? (movimientosRestock.reduce((sum: number, mov: any) => sum + (mov.margen || 0), 0) / movimientosRestock.length).toFixed(1)
                      : '0.0'
                    }%
                  </p>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-2">Producto</th>
                      <th className="text-right p-2">Cantidad</th>
                      <th className="text-right p-2">Precio Coste</th>
                      <th className="text-right p-2">Precio Venta</th>
                      <th className="text-right p-2">Total Coste</th>
                      <th className="text-right p-2">Margen</th>
                      <th className="text-right p-2">Fecha</th>
                    </tr>
                  </thead>
                  <tbody>
                    {movimientosRestock.slice(-10).reverse().map((movimiento: any) => (
                      <tr key={movimiento.id} className="border-b hover:bg-gray-50">
                        <td className="p-2 font-medium">{movimiento.producto}</td>
                        <td className="p-2 text-right">{movimiento.cantidad}</td>
                        <td className="p-2 text-right">€{movimiento.precioCoste.toFixed(2)}</td>
                        <td className="p-2 text-right">€{(movimiento.precioVenta * 1.21).toFixed(2)}</td>
                        <td className="p-2 text-right text-red-600">€{movimiento.totalCoste.toFixed(2)}</td>
                        <td className="p-2 text-right text-green-600">{movimiento.margen.toFixed(1)}%</td>
                        <td className="p-2 text-right text-gray-600">
                          {new Date(movimiento.fecha).toLocaleDateString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {movimientosRestock.length > 10 && (
                <p className="text-sm text-gray-500 text-center">
                  Mostrando los últimos 10 movimientos de {movimientosRestock.length} totales
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Gastos del Negocio */}
      {gastos.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingDown className="h-5 w-5" />
              Gastos del Negocio
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Resumen por categorías */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {(() => {
                  const gastosPorCategoria = gastos.reduce((acc: any, gasto: any) => {
                    const categoria = gasto.categoria || 'Sin categoría';
                    if (!acc[categoria]) {
                      acc[categoria] = { total: 0, cantidad: 0 };
                    }
                    acc[categoria].total += gasto.total || 0;
                    acc[categoria].cantidad += 1;
                    return acc;
                  }, {});

                  return Object.entries(gastosPorCategoria).map(([categoria, datos]: [string, any]) => (
                    <div key={categoria} className="p-4 bg-red-50 rounded-lg border border-red-200">
                      <h4 className="font-semibold text-red-800 text-sm">{categoria}</h4>
                      <p className="text-2xl font-bold text-red-600">€{datos.total.toFixed(2)}</p>
                      <p className="text-xs text-red-700">{datos.cantidad} gasto{datos.cantidad !== 1 ? 's' : ''}</p>
                    </div>
                  ));
                })()}
              </div>

              {/* Total de gastos */}
              <div className="p-4 bg-gradient-to-r from-red-100 to-orange-100 rounded-lg border-2 border-red-300">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-red-800">Total Gastos del Período</h3>
                    <p className="text-sm text-red-700">Todos los gastos del negocio</p>
                  </div>
                  <div className="text-right">
                    <p className="text-3xl font-bold text-red-600">€{totalGastos.toFixed(2)}</p>
                    <p className="text-sm text-red-700">{gastos.length} registros</p>
                  </div>
                </div>
              </div>

              {/* Tabla de gastos recientes */}
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-2">Tipo</th>
                      <th className="text-left p-2">Descripción</th>
                      <th className="text-left p-2">Categoría</th>
                      <th className="text-right p-2">Cantidad</th>
                      <th className="text-right p-2">Precio Unit.</th>
                      <th className="text-right p-2">Total</th>
                      <th className="text-right p-2">Fecha</th>
                    </tr>
                  </thead>
                  <tbody>
                    {gastos.slice(-15).reverse().map((gasto: any) => (
                      <tr key={gasto.id} className="border-b hover:bg-gray-50">
                        <td className="p-2 font-medium">{gasto.tipo_producto}</td>
                        <td className="p-2">{gasto.descripcion}</td>
                        <td className="p-2">
                          <Badge variant="secondary" className="text-xs">
                            {gasto.categoria}
                          </Badge>
                        </td>
                        <td className="p-2 text-right">{gasto.cantidad}</td>
                        <td className="p-2 text-right">€{gasto.precio_unitario.toFixed(2)}</td>
                        <td className="p-2 text-right text-red-600 font-semibold">€{gasto.total.toFixed(2)}</td>
                        <td className="p-2 text-right text-gray-600">
                          {new Date(gasto.fecha).toLocaleDateString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {gastos.length > 15 && (
                <p className="text-sm text-gray-500 text-center">
                  Mostrando los últimos 15 gastos de {gastos.length} totales
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Resumen detallado */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Resumen Detallado por Tipo de Dispositivo
          </CardTitle>
        </CardHeader>
         <CardContent>
           <div className="overflow-x-auto">
             <table className="w-full text-sm">
               <thead>
                 <tr className="border-b">
                   <th className="text-left p-2">Dispositivo</th>
                   <th className="text-right p-2">Cantidad</th>
                   <th className="text-right p-2">Ingresos</th>
                   <th className="text-right p-2">Costes</th>
                   <th className="text-right p-2">Beneficio</th>
                   <th className="text-right p-2">Margen</th>
                   <th className="text-right p-2">Promedio</th>
                 </tr>
               </thead>
               <tbody>
                 {Object.entries(dispositivosData).map(([tipo, data]) => {
                   const beneficio = data.ingresos - data.costes;
                   const margen = data.ingresos > 0 ? ((beneficio / data.ingresos) * 100) : 0;
                   const promedio = data.cantidad > 0 ? (beneficio / data.cantidad) : 0;
                   
                   return (
                     <tr key={tipo} className="border-b hover:bg-gray-50">
                       <td className="p-2 font-medium capitalize">{tipo}</td>
                       <td className="p-2 text-right">{data.cantidad}</td>
                       <td className="p-2 text-right text-green-600">€{data.ingresos.toLocaleString()}</td>
                       <td className="p-2 text-right text-red-600">€{data.costes.toLocaleString()}</td>
                       <td className="p-2 text-right text-blue-600 font-semibold">€{beneficio.toLocaleString()}</td>
                       <td className="p-2 text-right">{margen.toFixed(1)}%</td>
                       <td className="p-2 text-right">€{promedio.toLocaleString()}</td>
                     </tr>
                   );
                 })}
               </tbody>
             </table>
           </div>
         </CardContent>
       </Card>
    </div>
  );
}
