import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  Calendar as CalendarIcon,
  Clock,
  User,
  Phone,
  CheckCircle,
  AlertTriangle
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { cn } from "@/lib/utils";

interface Cita {
  id: string;
  clienteNombre: string;
  clienteTelefono: string;
  fecha: string;
  hora: string;
  servicio: string;
  dispositivo: string;
  notas: string;
  estado: "programada" | "confirmada" | "en_proceso" | "completada" | "cancelada";
  fechaCreacion: string;
}

const estadoColors = {
  programada: "bg-blue-100 text-blue-800 border-blue-300",
  confirmada: "bg-green-100 text-green-800 border-green-300", 
  en_proceso: "bg-yellow-100 text-yellow-800 border-yellow-300",
  completada: "bg-gray-100 text-gray-800 border-gray-300",
  cancelada: "bg-red-100 text-red-800 border-red-300"
};

const estadoLabels = {
  programada: "Programada",
  confirmada: "Confirmada",
  en_proceso: "En Proceso", 
  completada: "Completada",
  cancelada: "Cancelada"
};

const servicios = [
  "Reparación de Pantalla",
  "Cambio de Batería",
  "Reparación de Puerto de Carga",
  "Limpieza Interna",
  "Actualización de Software",
  "Diagnóstico General",
  "Reparación de Altavoz",
  "Cambio de Cámara",
  "Otros"
];

const horarios = [
  "09:00", "09:30", "10:00", "10:30", "11:00", "11:30",
  "12:00", "12:30", "14:00", "14:30", "15:00", "15:30",
  "16:00", "16:30", "17:00", "17:30", "18:00", "18:30"
];

export default function CitasPage() {
  const [citas, setCitas] = useLocalStorage<Cita[]>("citas", []);
  const [clientes] = useLocalStorage("clientes", []);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterFecha, setFilterFecha] = useState<Date | undefined>(undefined);
  const [filterEstado, setFilterEstado] = useState<string>("todas");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingCita, setEditingCita] = useState<Cita | null>(null);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    clienteNombre: "",
    clienteTelefono: "",
    fecha: "",
    hora: "",
    servicio: "",
    dispositivo: "",
    notas: "",
    estado: "programada" as Cita["estado"]
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.clienteNombre || !formData.fecha || !formData.hora || !formData.servicio) {
      toast({
        title: "Error",
        description: "Por favor completa todos los campos obligatorios",
        variant: "destructive"
      });
      return;
    }

    // Verificar si ya existe una cita en esa fecha y hora
    const citaExistente = citas.find(cita => 
      cita.fecha === formData.fecha && 
      cita.hora === formData.hora && 
      cita.id !== editingCita?.id &&
      cita.estado !== "cancelada"
    );

    if (citaExistente) {
      toast({
        title: "Horario ocupado",
        description: "Ya existe una cita programada para esa fecha y hora",
        variant: "destructive"
      });
      return;
    }

    const nuevaCita: Cita = {
      id: editingCita?.id || Date.now().toString(),
      clienteNombre: formData.clienteNombre,
      clienteTelefono: formData.clienteTelefono,
      fecha: formData.fecha,
      hora: formData.hora,
      servicio: formData.servicio,
      dispositivo: formData.dispositivo,
      notas: formData.notas,
      estado: formData.estado,
      fechaCreacion: editingCita?.fechaCreacion || new Date().toISOString()
    };

    if (editingCita) {
      setCitas(citas.map(cita => cita.id === editingCita.id ? nuevaCita : cita));
      toast({
        title: "Cita actualizada",
        description: "La cita ha sido actualizada exitosamente"
      });
    } else {
      setCitas([...citas, nuevaCita]);
      toast({
        title: "Cita programada",
        description: `Cita programada para el ${formData.fecha} a las ${formData.hora}`
      });
    }

    resetForm();
    setIsDialogOpen(false);
  };

  const resetForm = () => {
    setFormData({
      clienteNombre: "",
      clienteTelefono: "",
      fecha: "",
      hora: "",
      servicio: "",
      dispositivo: "",
      notas: "",
      estado: "programada"
    });
    setEditingCita(null);
    setSelectedDate(undefined);
  };

  const handleEdit = (cita: Cita) => {
    setEditingCita(cita);
    setFormData({
      clienteNombre: cita.clienteNombre,
      clienteTelefono: cita.clienteTelefono,
      fecha: cita.fecha,
      hora: cita.hora,
      servicio: cita.servicio,
      dispositivo: cita.dispositivo,
      notas: cita.notas,
      estado: cita.estado
    });
    setSelectedDate(new Date(cita.fecha));
    setIsDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    setCitas(citas.filter(cita => cita.id !== id));
    toast({
      title: "Cita eliminada",
      description: "La cita ha sido eliminada del calendario"
    });
  };

  const cambiarEstado = (id: string, nuevoEstado: Cita["estado"]) => {
    setCitas(citas.map(cita => 
      cita.id === id ? { ...cita, estado: nuevoEstado } : cita
    ));
    toast({
      title: "Estado actualizado",
      description: `Cita marcada como ${estadoLabels[nuevoEstado].toLowerCase()}`
    });
  };

  const llenarDatosCliente = (nombreCliente: string) => {
    const cliente = clientes.find((c: any) => c.nombre === nombreCliente);
    if (cliente) {
      setFormData(prev => ({
        ...prev,
        clienteNombre: cliente.nombre,
        clienteTelefono: cliente.telefono
      }));
    }
  };

  const filteredCitas = citas.filter(cita => {
    const matchesSearch = cita.clienteNombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         cita.servicio.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         cita.dispositivo.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFecha = !filterFecha || cita.fecha === format(filterFecha, "yyyy-MM-dd");
    const matchesEstado = filterEstado === "todas" || cita.estado === filterEstado;
    return matchesSearch && matchesFecha && matchesEstado;
  });

  const citasHoy = citas.filter(cita => 
    cita.fecha === format(new Date(), "yyyy-MM-dd") && 
    cita.estado !== "cancelada"
  );

  const citasProgramadas = citas.filter(cita => cita.estado === "programada").length;
  const citasConfirmadas = citas.filter(cita => cita.estado === "confirmada").length;

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">Agenda de Citas</h1>
          <p className="text-slate-600">Gestiona las citas y horarios de tu taller</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={resetForm}>
              <Plus className="w-4 h-4 mr-2" />
              Nueva Cita
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingCita ? "Editar Cita" : "Nueva Cita"}
              </DialogTitle>
            </DialogHeader>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="clienteNombre">Cliente *</Label>
                  <Select 
                    value={formData.clienteNombre} 
                    onValueChange={(value) => {
                      setFormData({...formData, clienteNombre: value});
                      llenarDatosCliente(value);
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar cliente" />
                    </SelectTrigger>
                    <SelectContent>
                      {clientes.map((cliente: any) => (
                        <SelectItem key={cliente.id} value={cliente.nombre}>
                          {cliente.nombre}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Input
                    className="mt-2"
                    value={formData.clienteNombre}
                    onChange={(e) => setFormData({...formData, clienteNombre: e.target.value})}
                    placeholder="O escribir nombre nuevo"
                  />
                </div>
                <div>
                  <Label htmlFor="clienteTelefono">Teléfono</Label>
                  <Input
                    id="clienteTelefono"
                    value={formData.clienteTelefono}
                    onChange={(e) => setFormData({...formData, clienteTelefono: e.target.value})}
                    placeholder="Número de teléfono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Fecha de la Cita *</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !selectedDate && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {selectedDate ? format(selectedDate, "PPP", { locale: es }) : "Seleccionar fecha"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={selectedDate}
                        onSelect={(date) => {
                          setSelectedDate(date);
                          if (date) {
                            setFormData({...formData, fecha: format(date, "yyyy-MM-dd")});
                          }
                        }}
                        disabled={(date) => date < new Date(new Date().setHours(0, 0, 0, 0))}
                        initialFocus
                        className="pointer-events-auto"
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                <div>
                  <Label htmlFor="hora">Hora *</Label>
                  <Select value={formData.hora} onValueChange={(value) => setFormData({...formData, hora: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar hora" />
                    </SelectTrigger>
                    <SelectContent>
                      {horarios.map(hora => {
                        const ocupado = citas.find(cita => 
                          cita.fecha === formData.fecha && 
                          cita.hora === hora && 
                          cita.estado !== "cancelada" &&
                          cita.id !== editingCita?.id
                        );
                        return (
                          <SelectItem 
                            key={hora} 
                            value={hora} 
                            disabled={!!ocupado}
                            className={ocupado ? "text-red-500" : ""}
                          >
                            {hora} {ocupado && "(Ocupado)"}
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="servicio">Servicio *</Label>
                  <Select value={formData.servicio} onValueChange={(value) => setFormData({...formData, servicio: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Tipo de servicio" />
                    </SelectTrigger>
                    <SelectContent>
                      {servicios.map(servicio => (
                        <SelectItem key={servicio} value={servicio}>{servicio}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="dispositivo">Dispositivo</Label>
                  <Input
                    id="dispositivo"
                    value={formData.dispositivo}
                    onChange={(e) => setFormData({...formData, dispositivo: e.target.value})}
                    placeholder="Ej: iPhone 12, Samsung Galaxy"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="notas">Notas</Label>
                <Textarea
                  id="notas"
                  value={formData.notas}
                  onChange={(e) => setFormData({...formData, notas: e.target.value})}
                  placeholder="Información adicional sobre la cita"
                />
              </div>

              {editingCita && (
                <div>
                  <Label htmlFor="estado">Estado</Label>
                  <Select value={formData.estado} onValueChange={(value: Cita["estado"]) => setFormData({...formData, estado: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="programada">Programada</SelectItem>
                      <SelectItem value="confirmada">Confirmada</SelectItem>
                      <SelectItem value="en_proceso">En Proceso</SelectItem>
                      <SelectItem value="completada">Completada</SelectItem>
                      <SelectItem value="cancelada">Cancelada</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit">
                  {editingCita ? "Actualizar" : "Programar"} Cita
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <CalendarIcon className="w-5 h-5 text-blue-500" />
              <div>
                <p className="text-sm text-muted-foreground">Citas Hoy</p>
                <p className="text-2xl font-bold">{citasHoy.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-yellow-500" />
              <div>
                <p className="text-sm text-muted-foreground">Programadas</p>
                <p className="text-2xl font-bold">{citasProgramadas}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-500" />
              <div>
                <p className="text-sm text-muted-foreground">Confirmadas</p>
                <p className="text-2xl font-bold">{citasConfirmadas}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <User className="w-5 h-5 text-purple-500" />
              <div>
                <p className="text-sm text-muted-foreground">Total Citas</p>
                <p className="text-2xl font-bold">{citas.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar por cliente, servicio o dispositivo..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-[200px] justify-start">
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {filterFecha ? format(filterFecha, "PPP", { locale: es }) : "Filtrar por fecha"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={filterFecha}
                  onSelect={setFilterFecha}
                  className="pointer-events-auto"
                />
                {filterFecha && (
                  <div className="p-3 border-t">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => setFilterFecha(undefined)}
                      className="w-full"
                    >
                      Limpiar filtro
                    </Button>
                  </div>
                )}
              </PopoverContent>
            </Popover>
            <Select value={filterEstado} onValueChange={setFilterEstado}>
              <SelectTrigger className="w-[180px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todas">Todos los estados</SelectItem>
                <SelectItem value="programada">Programadas</SelectItem>
                <SelectItem value="confirmada">Confirmadas</SelectItem>
                <SelectItem value="en_proceso">En Proceso</SelectItem>
                <SelectItem value="completada">Completadas</SelectItem>
                <SelectItem value="cancelada">Canceladas</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Citas List */}
      <div className="grid gap-4">
        {filteredCitas.length === 0 ? (
          <Card>
            <CardContent className="pt-6 text-center">
              <CalendarIcon className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No hay citas</h3>
              <p className="text-muted-foreground">
                {searchTerm || filterFecha || filterEstado !== "todas"
                  ? "No se encontraron citas con los filtros aplicados"
                  : "Programa tu primera cita para comenzar"
                }
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredCitas
            .sort((a, b) => new Date(`${a.fecha} ${a.hora}`).getTime() - new Date(`${b.fecha} ${b.hora}`).getTime())
            .map((cita) => (
              <Card key={cita.id} className="hover:shadow-md transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-3">
                        <h3 className="text-lg font-semibold">{cita.clienteNombre}</h3>
                        <Badge className={estadoColors[cita.estado]}>
                          {estadoLabels[cita.estado]}
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-2 text-sm text-muted-foreground mb-3">
                        <div className="flex items-center gap-1">
                          <CalendarIcon className="w-4 h-4" />
                          {format(new Date(cita.fecha), "PPP", { locale: es })}
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {cita.hora}
                        </div>
                        <div className="flex items-center gap-1">
                          <Phone className="w-4 h-4" />
                          {cita.clienteTelefono || "Sin teléfono"}
                        </div>
                        <div>
                          <strong>Servicio:</strong> {cita.servicio}
                        </div>
                      </div>

                      {cita.dispositivo && (
                        <p className="text-sm mb-2">
                          <strong>Dispositivo:</strong> {cita.dispositivo}
                        </p>
                      )}

                      {cita.notas && (
                        <p className="text-sm text-muted-foreground italic mb-3">
                          {cita.notas}
                        </p>
                      )}

                      {/* Quick Actions */}
                      <div className="flex gap-2 flex-wrap">
                        {cita.estado === "programada" && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => cambiarEstado(cita.id, "confirmada")}
                          >
                            Confirmar
                          </Button>
                        )}
                        {cita.estado === "confirmada" && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => cambiarEstado(cita.id, "en_proceso")}
                          >
                            Iniciar
                          </Button>
                        )}
                        {cita.estado === "en_proceso" && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => cambiarEstado(cita.id, "completada")}
                          >
                            Completar
                          </Button>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEdit(cita)}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDelete(cita.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
        )}
      </div>
    </div>
  );
}