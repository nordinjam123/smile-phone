import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { localStorageService, LocalData } from '@/lib/localStorageService';
import { localAuthService, LocalUser } from '@/lib/localAuthService';

interface LocalDataContextType {
  // Data collections
  clientes: LocalData[];
  inventario: LocalData[];
  ordenes: LocalData[];
  facturas: LocalData[];
  gastos: LocalData[];
  citas: LocalData[];
  
  // Loading states
  loading: boolean;
  
  // CRUD operations
  addCliente: (cliente: any) => Promise<string | null>;
  updateCliente: (id: string, cliente: any) => Promise<boolean>;
  deleteCliente: (id: string) => Promise<boolean>;
  
  addInventario: (item: any) => Promise<string | null>;
  updateInventario: (id: string, item: any) => Promise<boolean>;
  deleteInventario: (id: string) => Promise<boolean>;
  
  addOrden: (orden: any) => Promise<string | null>;
  updateOrden: (id: string, orden: any) => Promise<boolean>;
  deleteOrden: (id: string) => Promise<boolean>;
  
  addFactura: (factura: any) => Promise<string | null>;
  updateFactura: (id: string, factura: any) => Promise<boolean>;
  deleteFactura: (id: string) => Promise<boolean>;
  
  addGasto: (gasto: any) => Promise<string | null>;
  updateGasto: (id: string, gasto: any) => Promise<boolean>;
  deleteGasto: (id: string) => Promise<boolean>;
  
  addCita: (cita: any) => Promise<string | null>;
  updateCita: (id: string, cita: any) => Promise<boolean>;
  deleteCita: (id: string) => Promise<boolean>;
  
  // Utility functions
  refreshData: () => Promise<void>;
  migrateFromOldStorage: () => Promise<{ success: boolean; migrated: number; errors: string[] }>;
  isOnline: boolean;
  
  // Statistics
  getStorageStats: () => { collections: number; totalDocuments: number; storageUsed: string };
  exportData: () => { [collection: string]: LocalData[] };
  importData: (data: { [collection: string]: LocalData[] }) => Promise<{ success: boolean; errors: string[] }>;
}

const LocalDataContext = createContext<LocalDataContextType | undefined>(undefined);

interface LocalDataProviderProps {
  children: ReactNode;
}

export const LocalDataProvider: React.FC<LocalDataProviderProps> = ({ children }) => {
  const [user, setUser] = useState<LocalUser | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  
  // Data states
  const [clientes, setClientes] = useState<LocalData[]>([]);
  const [inventario, setInventario] = useState<LocalData[]>([]);
  const [ordenes, setOrdenes] = useState<LocalData[]>([]);
  const [facturas, setFacturas] = useState<LocalData[]>([]);
  const [gastos, setGastos] = useState<LocalData[]>([]);
  const [citas, setCitas] = useState<LocalData[]>([]);
  
  const [loading, setLoading] = useState(false);
  const [isOnline] = useState(true); // Always online for local storage

  useEffect(() => {
    // Listen to auth changes
    const unsubscribeAuth = localAuthService.onAuthStateChanged((newUser) => {
      setUser(newUser);
      setIsAuthenticated(!!newUser);
      
      if (newUser) {
        loadUserData(newUser.id);
      } else {
        clearData();
      }
    });

    return unsubscribeAuth;
  }, []);

  const loadUserData = (userId: string) => {
    setLoading(true);
    
    try {
      // Load all collections for the user
      setClientes(localStorageService.getUserDocuments('clientes', userId));
      setInventario(localStorageService.getUserDocuments('inventario', userId));
      setOrdenes(localStorageService.getUserDocuments('ordenes_trabajo', userId));
      setFacturas(localStorageService.getUserDocuments('facturas', userId));
      setGastos(localStorageService.getUserDocuments('gastos_mercancia', userId));
      setCitas(localStorageService.getUserDocuments('citas', userId));
    } catch (error) {
      console.error('Error loading user data:', error);
    } finally {
      setLoading(false);
    }
  };

  const clearData = () => {
    setClientes([]);
    setInventario([]);
    setOrdenes([]);
    setFacturas([]);
    setGastos([]);
    setCitas([]);
  };

  // Generic CRUD operations
  const addDocument = async (collection: string, data: any, setState: React.Dispatch<React.SetStateAction<LocalData[]>>): Promise<string | null> => {
    if (!user) return null;

    const result = localStorageService.addDocument(collection, data, user.id);
    if (result.id && !result.error) {
      // Update local state
      const updatedDocuments = localStorageService.getUserDocuments(collection, user.id);
      setState(updatedDocuments);
      return result.id;
    }
    return null;
  };

  const updateDocument = async (collection: string, docId: string, data: any, setState: React.Dispatch<React.SetStateAction<LocalData[]>>): Promise<boolean> => {
    if (!user) return false;

    const result = localStorageService.updateDocument(collection, docId, data, user.id);
    if (result.success) {
      // Update local state
      const updatedDocuments = localStorageService.getUserDocuments(collection, user.id);
      setState(updatedDocuments);
      return true;
    }
    return false;
  };

  const deleteDocument = async (collection: string, docId: string, setState: React.Dispatch<React.SetStateAction<LocalData[]>>): Promise<boolean> => {
    if (!user) return false;

    const result = localStorageService.deleteDocument(collection, docId, user.id);
    if (result.success) {
      // Update local state
      const updatedDocuments = localStorageService.getUserDocuments(collection, user.id);
      setState(updatedDocuments);
      return true;
    }
    return false;
  };

  // Specific CRUD operations
  const addCliente = (cliente: any) => addDocument('clientes', cliente, setClientes);
  const updateCliente = (id: string, cliente: any) => updateDocument('clientes', id, cliente, setClientes);
  const deleteCliente = (id: string) => deleteDocument('clientes', id, setClientes);

  const addInventario = (item: any) => addDocument('inventario', item, setInventario);
  const updateInventario = (id: string, item: any) => updateDocument('inventario', id, item, setInventario);
  const deleteInventario = (id: string) => deleteDocument('inventario', id, setInventario);

  const addOrden = (orden: any) => addDocument('ordenes_trabajo', orden, setOrdenes);
  const updateOrden = (id: string, orden: any) => updateDocument('ordenes_trabajo', id, orden, setOrdenes);
  const deleteOrden = (id: string) => deleteDocument('ordenes_trabajo', id, setOrdenes);

  const addFactura = (factura: any) => addDocument('facturas', factura, setFacturas);
  const updateFactura = (id: string, factura: any) => updateDocument('facturas', id, factura, setFacturas);
  const deleteFactura = (id: string) => deleteDocument('facturas', id, setFacturas);

  const addGasto = (gasto: any) => addDocument('gastos_mercancia', gasto, setGastos);
  const updateGasto = (id: string, gasto: any) => updateDocument('gastos_mercancia', id, gasto, setGastos);
  const deleteGasto = (id: string) => deleteDocument('gastos_mercancia', id, setGastos);

  const addCita = (cita: any) => addDocument('citas', cita, setCitas);
  const updateCita = (id: string, cita: any) => updateDocument('citas', id, cita, setCitas);
  const deleteCita = (id: string) => deleteDocument('citas', id, setCitas);

  // Utility functions
  const refreshData = async (): Promise<void> => {
    if (user) {
      loadUserData(user.id);
    }
  };

  const migrateFromOldStorage = async (): Promise<{ success: boolean; migrated: number; errors: string[] }> => {
    const result = localStorageService.migrateFromOldStorage();
    if (result.success && user) {
      loadUserData(user.id); // Reload data after migration
    }
    return result;
  };

  const getStorageStats = () => localStorageService.getStorageStats();
  
  const exportData = () => {
    if (!user) return {};
    return localStorageService.exportUserData(user.id);
  };

  const importData = async (data: { [collection: string]: LocalData[] }): Promise<{ success: boolean; errors: string[] }> => {
    if (!user) return { success: false, errors: ['Usuario no autenticado'] };
    
    const result = localStorageService.importUserData(user.id, data);
    if (result.success) {
      loadUserData(user.id); // Reload data after import
    }
    return result;
  };

  const value: LocalDataContextType = {
    clientes,
    inventario,
    ordenes,
    facturas,
    gastos,
    citas,
    loading,
    addCliente,
    updateCliente,
    deleteCliente,
    addInventario,
    updateInventario,
    deleteInventario,
    addOrden,
    updateOrden,
    deleteOrden,
    addFactura,
    updateFactura,
    deleteFactura,
    addGasto,
    updateGasto,
    deleteGasto,
    addCita,
    updateCita,
    deleteCita,
    refreshData,
    migrateFromOldStorage,
    isOnline,
    getStorageStats,
    exportData,
    importData
  };

  return (
    <LocalDataContext.Provider value={value}>
      {children}
    </LocalDataContext.Provider>
  );
};

export const useLocalData = (): LocalDataContextType => {
  const context = useContext(LocalDataContext);
  if (context === undefined) {
    throw new Error('useLocalData must be used within a LocalDataProvider');
  }
  return context;
};
