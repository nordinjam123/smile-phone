import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Wrench, AlertCircle, ArrowLeft } from 'lucide-react';
import { z } from 'zod';

const ForgotPassword: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [emailSent, setEmailSent] = useState(false);
  const { toast } = useToast();

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrors({});

    try {
      if (!email) {
        setErrors({ email: 'Email es requerido' });
        return;
      }

      const emailValidation = z.string().email().safeParse(email);
      if (!emailValidation.success) {
        setErrors({ email: 'Email inválido' });
        return;
      }

      // Llamar a la función edge para enviar contraseña temporal
      const { error } = await supabase.functions.invoke('send-temporary-password', {
        body: { email: email.trim() }
      });

      if (error) throw error;

      setEmailSent(true);
      toast({
        title: "Contraseña temporal enviada",
        description: "Revisa tu correo para obtener tu contraseña temporal.",
      });
    } catch (error: any) {
      const errorMessage = error.message || "Error al enviar correo de recuperación";
      setErrors({ general: errorMessage });
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  if (emailSent) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/10 to-secondary/10 p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <div className="p-3 bg-primary rounded-full">
                <Wrench className="h-8 w-8 text-primary-foreground" />
              </div>
            </div>
            <CardTitle className="text-2xl">Correo Enviado</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-muted-foreground">
              Hemos enviado una contraseña temporal a <strong>{email}</strong>
            </p>
            <p className="text-sm text-muted-foreground">
              Usa la contraseña temporal para iniciar sesión y luego podrás cambiarla por una permanente.
            </p>
            <div className="space-y-2">
              <Button 
                onClick={() => setEmailSent(false)} 
                variant="outline" 
                className="w-full"
              >
                Enviar otro correo
              </Button>
              <Link to="/">
                <Button variant="ghost" className="w-full">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Volver al inicio
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/10 to-secondary/10 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="p-3 bg-primary rounded-full">
              <Wrench className="h-8 w-8 text-primary-foreground" />
            </div>
          </div>
          <CardTitle className="text-2xl">Recuperar Contraseña</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleResetPassword} className="space-y-4">
            {errors.general && (
              <div className="flex items-center gap-2 p-3 text-sm text-destructive bg-destructive/10 rounded-md">
                <AlertCircle className="h-4 w-4" />
                {errors.general}
              </div>
            )}
            
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="tu@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className={errors.email ? 'border-destructive' : ''}
                required
              />
              {errors.email && (
                <div className="flex items-center gap-1 text-sm text-destructive">
                  <AlertCircle className="h-4 w-4" />
                  {errors.email}
                </div>
              )}
              <p className="text-xs text-muted-foreground">
                Te enviaremos una contraseña temporal por correo electrónico
              </p>
            </div>
            
            <Button type="submit" className="w-full" disabled={loading}>
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Enviar correo de recuperación
            </Button>
          </form>
          
          <div className="mt-6 text-center">
            <Link to="/">
              <button
                type="button"
                className="text-sm text-primary hover:underline inline-flex items-center"
              >
                <ArrowLeft className="mr-1 h-3 w-3" />
                Volver al inicio de sesión
              </button>
            </Link>
          </div>
          
          <div className="mt-6 text-center">
            <p className="text-xs text-muted-foreground">
              ¿Necesitas ayuda? Contacta con nosotros en: 
              <a href="mailto:mitaller@mitallerenlinea.org" className="text-primary hover:underline ml-1">
                mitaller@mitallerenlinea.org
              </a>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ForgotPassword;