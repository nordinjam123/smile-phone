-- Fix function search path security issues
CREATE OR REPLACE FUNCTION public.calculate_trial_status()
RETURNS TRIGGER AS $$
BEGIN
  -- If this is a new subscription and no trial has been set
  IF NEW.trial_start IS NULL AND NEW.subscribed = false AND OLD.trial_start IS NULL THEN
    NEW.trial_start = now();
    NEW.trial_end = now() + INTERVAL '3 days';
  END IF;
  
  -- Update timestamp
  NEW.updated_at = now();
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = '';

-- Fix user access function search path
CREATE OR REPLACE FUNCTION public.user_has_access(user_email TEXT)
RETURNS BOOLEAN AS $$
DECLARE
  subscriber_record public.subscribers%ROWTYPE;
BEGIN
  SELECT * INTO subscriber_record 
  FROM public.subscribers 
  WHERE email = user_email;
  
  -- If no record exists, no access
  IF NOT FOUND THEN
    RETURN FALSE;
  END IF;
  
  -- If lifetime free user
  IF subscriber_record.is_lifetime_free = true THEN
    RETURN TRUE;
  END IF;
  
  -- If subscribed
  IF subscriber_record.subscribed = true THEN
    RETURN TRUE;
  END IF;
  
  -- If in trial period
  IF subscriber_record.trial_start IS NOT NULL 
     AND subscriber_record.trial_end IS NOT NULL 
     AND now() BETWEEN subscriber_record.trial_start AND subscriber_record.trial_end THEN
    RETURN TRUE;
  END IF;
  
  RETURN FALSE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = '';