import { useState, useEffect } from 'react';
import { centralizedFirebaseService, FirebaseUser } from '@/lib/centralizedFirebaseService';

interface UseCentralizedAuthReturn {
  user: FirebaseUser | null;
  loading: boolean;
  isAuthenticated: boolean;
  signOut: () => Promise<void>;
  isReady: boolean;
}

export const useCentralizedAuth = (): UseCentralizedAuthReturn => {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    let unsubscribe: (() => void) | undefined;

    const initializeAuth = () => {
      const ready = centralizedFirebaseService.isReady();
      setIsReady(ready);

      if (ready) {
        // Set up auth state listener
        unsubscribe = centralizedFirebaseService.onAuthStateChanged((firebaseUser) => {
          setUser(firebaseUser);
          setLoading(false);
        });
      } else {
        // Retry after a short delay
        setTimeout(initializeAuth, 1000);
      }
    };

    initializeAuth();

    return () => {
      if (unsubscribe) {
        unsubscribe();
      }
    };
  }, []);

  const signOut = async (): Promise<void> => {
    try {
      setLoading(true);
      const { success, error } = await centralizedFirebaseService.signOut();
      if (error) {
        throw new Error(error);
      }
      setUser(null);
    } catch (error) {
      console.error('Error signing out:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  return {
    user,
    loading,
    isAuthenticated: !!user,
    signOut,
    isReady
  };
};
