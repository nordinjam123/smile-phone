const express = require('express');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3001;

// Configurar middleware
app.use(cors());
app.use(express.json());

// Variables de estado simulado
let connectionStatus = 'disconnected';
let qrCode = `

██████████████████████████████████████
██ ▄▄▄▄▄ █▀ █▀▄█▄▀█▄▀█▄▀█▄ ▄▄▄▄▄ ██
██ █   █ █▀▄█ ▄▀▄█▄▄█▄▄█▄█ █   █ ██
██ █▄▄▄█ █▄█▀ ▄█▄▀▄█▄█▄▀▄█ █▄▄▄█ ██
██▄▄▄▄▄▄▄█ █▄█ █▄█▄█ █▄█ █▄▄▄▄▄▄▄██
██ ▄ ▄▄▄▄▄▀▄█▄▀▄█▄██▄ ▄█▄▄▄ ▀▄█▄▄██
██▄█▀█▀▄▄▀ ▄ ▄▄█▄▀▄▄▄▄▄█▄██▀▄▄▀▄▄██
████▄▄▀▄▄█▀▄▀█▄█▄▄▄▄ █▄█▄█▄▄▄ ▄▄▄██
██▄▄██▄▄▄▄█ ▄▀▄ ▄▄██▄▄ ▄▄▄ ▀▄█▄▄▄██
██ ▄▄▄▄▄ █▄▀▄▄█▄▄▄▄▄██ █▄█  ▄▄██▄██
██ █   █ █ ▄█▀▄▀▄█▀▄▄▄█▄▄▄▄▄▀▄ ▄▄██
██ █▄▄▄█ █▄█▄█▀▄▄█▄▀█▄▄▀▄▄ ▄▄▀ █▀██
██▄▄▄▄▄▄▄█▄▄▄██▄▄▄▄▄▄██▄▄█▄▄▄▄██▄██
██████████████████████████████████████

`;

// Rutas de la API

// Obtener estado de conexión
app.get('/api/whatsapp/status', (req, res) => {
  res.json({
    status: connectionStatus,
    qr: connectionStatus === 'qr_pending' ? qrCode : '',
    info: connectionStatus === 'connected' ? {
      number: '34123456789',
      pushname: 'Tu Nombre',
      platform: 'WhatsApp Web'
    } : null
  });
});

// Conectar WhatsApp
app.post('/api/whatsapp/connect', (req, res) => {
  connectionStatus = 'qr_pending';
  console.log('📱 Mostrando código QR para conexión');
  
  res.json({
    message: 'Código QR generado - Escanéalo con WhatsApp',
    status: 'qr_pending',
    qr: qrCode,
    info: null
  });
  
  // Simular conexión después de 10 segundos
  setTimeout(() => {
    connectionStatus = 'connected';
    console.log('✅ WhatsApp Web conectado (simulado)');
  }, 10000);
});

// Desconectar WhatsApp
app.post('/api/whatsapp/disconnect', (req, res) => {
  connectionStatus = 'disconnected';
  console.log('🔌 WhatsApp Web desconectado');
  
  res.json({ message: 'WhatsApp Web desconectado correctamente' });
});

// Enviar mensaje
app.post('/api/whatsapp/send', (req, res) => {
  try {
    const { to, message } = req.body;
    
    if (connectionStatus !== 'connected') {
      // Devolver URL de fallback para abrir WhatsApp Web
      const cleanPhone = to ? to.replace('@c.us', '').replace(/\D/g, '') : '';
      return res.json({ 
        success: false,
        fallback: true,
        whatsappUrl: `https://web.whatsapp.com/send?phone=${cleanPhone}&text=${encodeURIComponent(message || '')}`
      });
    }
    
    if (!to || !message) {
      return res.status(400).json({ error: 'Número de teléfono y mensaje requeridos' });
    }
    
    // Simular envío exitoso
    console.log(`📤 Mensaje enviado a ${to}: ${message.substring(0, 50)}...`);
    res.json({ 
      success: true, 
      message: 'Mensaje enviado correctamente',
      to: to
    });
    
  } catch (error) {
    console.error('Error enviando mensaje:', error);
    
    // En caso de error, devolver URL de fallback
    const { to, message } = req.body;
    const cleanPhone = to ? to.replace('@c.us', '').replace(/\D/g, '') : '';
    
    res.json({ 
      success: false,
      fallback: true,
      whatsappUrl: `https://web.whatsapp.com/send?phone=${cleanPhone}&text=${encodeURIComponent(message || '')}`
    });
  }
});

// Ruta de prueba
app.get('/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    whatsapp: connectionStatus,
    timestamp: new Date().toISOString(),
    mode: 'demo'
  });
});

// Ruta principal
app.get('/', (req, res) => {
  res.json({
    message: 'Servidor WhatsApp Web Demo',
    status: connectionStatus,
    endpoints: [
      'GET /health',
      'GET /api/whatsapp/status',
      'POST /api/whatsapp/connect',
      'POST /api/whatsapp/disconnect',
      'POST /api/whatsapp/send'
    ]
  });
});

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`🚀 Servidor WhatsApp Web DEMO ejecutándose en puerto ${PORT}`);
  console.log(`📱 Health check: http://localhost:${PORT}/health`);
  console.log(`🔗 API Status: http://localhost:${PORT}/api/whatsapp/status`);
  console.log('');
  console.log('💡 MODO DEMO: Los mensajes se abrirán en WhatsApp Web automáticamente');
  console.log('📋 Para usar en producción, configura un servidor con Chrome/Chromium');
});
