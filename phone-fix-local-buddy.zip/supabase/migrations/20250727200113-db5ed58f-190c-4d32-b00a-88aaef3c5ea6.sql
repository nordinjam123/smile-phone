-- Set a specific user as lifetime free (replace with actual email)
-- UPDATE public.subscribers 
-- SET is_lifetime_free = true 
-- WHERE email = 'your-email@example.com';

-- For demonstration, create a special function to grant lifetime access
CREATE OR REPLACE FUNCTION public.grant_lifetime_access(user_email TEXT)
RETURNS BOOLEAN AS $$
BEGIN
  UPDATE public.subscribers 
  SET is_lifetime_free = true,
      updated_at = now()
  WHERE email = user_email;
  
  IF NOT FOUND THEN
    INSERT INTO public.subscribers (email, is_lifetime_free, subscribed, updated_at, created_at)
    VALUES (user_email, true, false, now(), now());
  END IF;
  
  RETURN true;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = '';

-- Grant lifetime access to specific email (uncomment and replace with actual email)
-- SELECT public.grant_lifetime_access('tu-email@example.com');