import { useState } from "react";
import { useLocalAuth } from "@/hooks/useLocalAuth";
import LocalAuthPage from "@/components/LocalAuthPage";
import SubscriptionPage from "@/components/SubscriptionPage";
import Sidebar from "@/components/Sidebar";
import Dashboard from "@/components/Dashboard";
import ServiciosPage from "@/components/ServiciosPage";
import ClientesPage from "@/components/ClientesPage";
import InventarioSelector from "@/components/InventarioSelector";
import OrdenesTrabajoPage from "@/components/OrdenesTrabajoPage";
import FacturasPage from "@/components/FacturasPage";
import ReportesPage from "@/components/ReportesPage";
import MovilesPage from "@/components/MovilesPage";
import CitasPage from "@/components/CitasPage";
import BalanceSelector from "@/components/BalanceSelector";
import GastosPage from "@/components/GastosPage";
import TPVPage from "@/components/TPVPage";
import ConfiguracionPage from "@/components/ConfiguracionPage";
import ConfiguracionEmpresa from "@/components/ConfiguracionEmpresa";
import WhatsAppConfig from "@/components/WhatsAppConfig";
import UserProfilePage from "@/components/UserProfilePage";
import YouTubeRepairSearch from "@/components/YouTubeRepairSearch";

import NetworkStatus from "@/components/NetworkStatus";
import AutoMigrationWrapper from "@/components/AutoMigrationWrapper";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Crown, Loader2, Wrench, User, Timer, CheckCircle, Menu } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const Index = () => {
  const { user, isLoading, isAuthenticated, signOut } = useLocalAuth();
  // Para compatibilidad, simulamos subscriptionData como activa
  const subscriptionData = { subscribed: true, has_access: true };
  const initialCheck = true;
  const [activeSection, setActiveSection] = useState("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { toast } = useToast();

  const handleAuthSuccess = (authenticatedUser: any) => {
    // Auth state is managed by useAuth hook
  };

  const handleLogout = async () => {
    try {
      // Reset section first
      setActiveSection("dashboard");

      // Clear any local data
      localStorage.removeItem('currentUser');

      // Then sign out
      await signOut();

      // Show success message
      toast({
        title: "Sesión cerrada",
        description: "Has cerrado sesión correctamente",
        variant: "default",
      });

    } catch (error) {
      console.warn('Logout error handled:', error);
      // Force reset even if signOut fails
      setActiveSection("dashboard");

      // Still show success since user will be logged out anyway
      toast({
        title: "Sesión cerrada",
        description: "Has cerrado sesión correctamente",
        variant: "default",
      });
    }
  };

  if (isLoading || !initialCheck) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return <LocalAuthPage onAuthSuccess={handleAuthSuccess} />;
  }

  const renderContent = () => {
    // Check subscription status for access control - includes 7-day trial
    const hasAccess = subscriptionData?.subscribed ||
                     subscriptionData?.is_lifetime_free ||
                     subscriptionData?.has_access; // Includes 7-day trial access

    if (!hasAccess && activeSection !== "dashboard" && activeSection !== "suscripcion" && activeSection !== "perfil") {
      return (
        <div className="p-6">
          <Card className="max-w-2xl mx-auto border-blue-200 bg-gradient-to-r from-blue-50 to-indigo-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-blue-800">
                <Crown className="h-5 w-5" />
                Suscripción Requerida
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-blue-700">
                Para acceder a las funcionalidades profesionales de TallerPro puedes comenzar con una prueba gratuita
                de 7 días o elegir directamente un plan de suscripción.
              </p>
              <div className="flex items-center gap-4">
                <Button onClick={() => setActiveSection("suscripcion")} className="bg-blue-600 hover:bg-blue-700">
                  <Crown className="h-4 w-4 mr-2" />
                  Prueba 7 días GRATIS
                </Button>
                <div className="text-sm text-blue-600">
                  Después desde 15€/mes • Sin permanencia
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      );
    }

    switch (activeSection) {
      case "dashboard":
        return <Dashboard onSectionChange={setActiveSection} />;
      case "tpv":
        return <TPVPage onExit={() => setActiveSection("dashboard")} />;
      case "servicios":
        return <ServiciosPage />;
      case "perfil":
        return <UserProfilePage user={user} onLogout={handleLogout} />;
      case "suscripcion":
        return <SubscriptionPage user={user} />;
      case "clientes":
        return <ClientesPage />;
      case "inventario":
        return <InventarioSelector />;
      case "ordenes":
        return <OrdenesTrabajoPage />;
      case "facturas":
        return <FacturasPage />;
      case "reportes":
        return <ReportesPage />;
      case "moviles":
        return <MovilesPage />;
      case "citas":
        return <CitasPage />;
      case "balance":
        return <BalanceSelector />;
      case "gastos":
        return <GastosPage />;
      case "configuracion":
        return <ConfiguracionPage />;

      case "empresa":
        return <ConfiguracionEmpresa />;
      case "whatsapp":
        return <WhatsAppConfig />;
      case "youtube-repair":
        return <YouTubeRepairSearch />;
      default:
        return <Dashboard onSectionChange={setActiveSection} />;
    }
  };

  return (
    <div className="h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 overflow-hidden">
      <NetworkStatus />
      {/* Mobile Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-gray-200/50 sticky top-0 z-50">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            {/* Mobile menu button */}
            <Button
              variant="ghost"
              size="sm"
              className="md:hidden"
              onClick={() => setSidebarOpen(!sidebarOpen)}
            >
              <Menu className="h-5 w-5" />
            </Button>
            
            <div>
              <h1 className="text-lg md:text-xl font-bold bg-gradient-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent">
                TechRepair Pro
              </h1>
              <p className="text-xs md:text-sm text-gray-500 hidden sm:block">Gestión Integral de Talleres</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2 md:gap-4">
            {/* Status Indicator */}
            {subscriptionData?.is_lifetime_free ? (
              <div className="flex items-center gap-1 md:gap-2 px-2 md:px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-xs md:text-sm font-medium">
                <Crown className="h-3 w-3 md:h-4 md:w-4" />
                <span className="hidden sm:inline">Usuario Premium</span>
                <span className="sm:hidden">Premium</span>
              </div>
            ) : subscriptionData?.has_access && !subscriptionData?.subscribed ? (
              <div className="flex items-center gap-1 md:gap-2 px-2 md:px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-xs md:text-sm font-medium">
                <Timer className="h-3 w-3 md:h-4 md:w-4" />
                <span className="hidden sm:inline">Prueba Activa</span>
                <span className="sm:hidden">Prueba</span>
              </div>
            ) : subscriptionData?.subscribed ? (
              <div className="flex items-center gap-1 md:gap-2 px-2 md:px-3 py-1 bg-green-100 text-green-800 rounded-full text-xs md:text-sm font-medium">
                <CheckCircle className="h-3 w-3 md:h-4 md:w-4" />
                <span className="hidden sm:inline">Suscrito</span>
                <span className="sm:hidden">Activo</span>
              </div>
            ) : null}
            
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => setActiveSection("perfil")}
              className="hover:bg-gray-100 text-xs md:text-sm"
            >
              <User className="h-3 w-3 md:h-4 md:w-4 mr-1 md:mr-2" />
              <span className="hidden sm:inline">{user.email?.split('@')[0]}</span>
              <span className="sm:hidden">Perfil</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="flex relative overflow-hidden">
        {/* Mobile Sidebar Overlay */}
        {sidebarOpen && (
          <div 
            className="fixed inset-0 bg-black/50 z-40 md:hidden" 
            onClick={() => setSidebarOpen(false)}
          />
        )}
        
        {/* Sidebar */}
        <div className={`
          fixed md:sticky top-0 z-50 md:z-0
          transform transition-transform duration-300 ease-in-out
          ${sidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
          h-[calc(100vh-60px)] md:h-[calc(100vh-60px)] w-64 bg-white/90 backdrop-blur-md border-r border-gray-200/50
        `}>
          <Sidebar 
            activeSection={activeSection} 
            setActiveSection={(section) => {
              setActiveSection(section);
              setSidebarOpen(false); // Close sidebar on mobile after selection
            }}
            subscriptionData={subscriptionData}
          />
        </div>
        
        <main className="flex-1 p-3 md:p-6 min-h-screen overflow-y-auto max-h-[calc(100vh-60px)]">
          <AutoMigrationWrapper>
            <div className="max-w-7xl mx-auto">
              {renderContent()}
            </div>
          </AutoMigrationWrapper>
        </main>
      </div>
    </div>
  );
};

export default Index;
