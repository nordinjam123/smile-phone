import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Crown, CreditCard, CheckCircle, Calendar } from 'lucide-react';

interface SubscriptionPageProps {
  user: any;
}

const SubscriptionPage: React.FC<SubscriptionPageProps> = ({ user }) => {
  const [loading, setLoading] = useState(false);
  const [subscriptionData, setSubscriptionData] = useState<any>(null);
  const [checking, setChecking] = useState(true);
  const { toast } = useToast();

  const checkSubscription = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('check-subscription');
      
      if (error) throw error;
      
      setSubscriptionData(data);
    } catch (error: any) {
      console.error('Error checking subscription:', error);
      toast({
        title: "Error",
        description: "No se pudo verificar el estado de la suscripción",
        variant: "destructive",
      });
    } finally {
      setChecking(false);
    }
  };

  const handleCreateCheckout = async (planType: string, amount: number) => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('create-checkout', {
        body: { planType, amount }
      });
      
      if (error) throw error;
      
      if (data?.url) {
        window.open(data.url, '_blank');
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Error al crear la sesión de pago",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleManageSubscription = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('customer-portal');
      
      if (error) throw error;
      
      if (data?.url) {
        window.open(data.url, '_blank');
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Error al acceder al portal de gestión",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
      checkSubscription();
    }
  }, [user]);

  if (checking) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
      </div>
    );
  }

  const isSubscribed = subscriptionData?.subscribed;
  const isLifetimeFree = subscriptionData?.is_lifetime_free;
  const hasAccess = subscriptionData?.has_access;
  const isInTrial = subscriptionData?.trial_start && subscriptionData?.trial_end;
  const trialEnd = subscriptionData?.trial_end 
    ? new Date(subscriptionData.trial_end).toLocaleDateString('es-ES') 
    : null;
  const subscriptionEnd = subscriptionData?.subscription_end 
    ? new Date(subscriptionData.subscription_end).toLocaleDateString('es-ES') 
    : null;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Mi Suscripción</h1>
          <p className="text-muted-foreground">Gestiona tu suscripción a la plataforma</p>
        </div>
        <Button 
          onClick={checkSubscription}
          variant="outline"
          disabled={checking}
        >
          {checking && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Actualizar Estado
        </Button>
      </div>

      {/* Estado Actual */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Crown className="h-5 w-5" />
            Estado de Suscripción
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-2">
            {isLifetimeFree ? (
              <Badge className="bg-purple-100 text-purple-800 border-purple-300">
                Usuario Gratuito de por Vida
              </Badge>
            ) : isSubscribed ? (
              <Badge variant="default">Activa</Badge>
            ) : isInTrial && hasAccess ? (
              <Badge className="bg-blue-100 text-blue-800 border-blue-300">
                Prueba Gratuita
              </Badge>
            ) : (
              <Badge variant="secondary">Inactiva</Badge>
            )}
            {(isSubscribed || isLifetimeFree || (isInTrial && hasAccess)) && (
              <CheckCircle className="h-4 w-4 text-green-500" />
            )}
          </div>
          
          {isLifetimeFree ? (
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">
                <strong>Plan:</strong> Usuario Gratuito de por Vida
              </p>
              <p className="text-sm text-muted-foreground">
                Tienes acceso completo sin limitaciones de tiempo.
              </p>
            </div>
          ) : isSubscribed ? (
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">
                <strong>Plan:</strong> Taller Workshop
              </p>
              {subscriptionEnd && (
                <p className="text-sm text-muted-foreground flex items-center gap-1">
                  <Calendar className="h-4 w-4" />
                  <strong>Renovación:</strong> {subscriptionEnd}
                </p>
              )}
            </div>
          ) : isInTrial && hasAccess ? (
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">
                <strong>Plan:</strong> Prueba Gratuita (3 días)
              </p>
              {trialEnd && (
                <p className="text-sm text-muted-foreground flex items-center gap-1">
                  <Calendar className="h-4 w-4" />
                  <strong>Expira:</strong> {trialEnd}
                </p>
              )}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">
              No tienes una suscripción activa. Elige un plan para continuar.
            </p>
          )}
        </CardContent>
      </Card>

      {/* Planes de Suscripción */}
      <div className="space-y-4 mb-6">
        <h2 className="text-2xl font-semibold">Planes de Suscripción</h2>
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <p className="text-green-800 font-medium">
            🎉 Prueba GRATUITA de 7 días - Sin tarjeta de crédito
          </p>
          <p className="text-green-600 text-sm mt-1">
            Acceso completo a todas las funcionalidades durante una semana. Después elige el plan que mejor se adapte a tu taller.
          </p>
        </div>
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <p className="text-blue-800 font-medium">
            ✨ Todos los planes incluyen acceso completo a todas las funcionalidades
          </p>
          <p className="text-blue-600 text-sm mt-1">
            La única diferencia entre los planes es el precio y la duración. Sin permanencia ni costes ocultos.
          </p>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-3">
        {/* Plan Mensual */}
        <Card className={isSubscribed && subscriptionData?.subscription_tier === 'monthly' ? "border-primary" : ""}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5" />
              Mensual
              {isSubscribed && subscriptionData?.subscription_tier === 'monthly' && <Badge>Tu Plan</Badge>}
            </CardTitle>
            <CardDescription>
              Pago mensual
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-3xl font-bold">
              15€ <span className="text-sm font-normal text-muted-foreground">/mes</span>
            </div>
            
            <ul className="space-y-2 text-sm">
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Gestión completa de servicios
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Clientes ilimitados
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Inventario y stock
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Órdenes de trabajo
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Facturas ilimitadas
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Reportes completos
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Gestión de móviles
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Sistema de citas
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Balance financiero
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Configuración avanzada
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Soporte incluido
              </li>
            </ul>

            <div className="pt-4">
              {isLifetimeFree ? (
                <Button variant="outline" className="w-full" disabled>
                  Usuario Gratuito ✨
                </Button>
              ) : !isSubscribed ? (
                <Button 
                  onClick={() => handleCreateCheckout('monthly', 1500)} 
                  className="w-full"
                  disabled={loading}
                >
                  {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Suscribirse
                </Button>
              ) : subscriptionData?.subscription_tier === 'monthly' ? (
                <Button 
                  onClick={handleManageSubscription} 
                  variant="outline" 
                  className="w-full"
                  disabled={loading}
                >
                  {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Gestionar Plan
                </Button>
              ) : (
                <Button 
                  onClick={() => handleCreateCheckout('monthly', 1500)} 
                  variant="outline"
                  className="w-full"
                  disabled={loading}
                >
                  {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Cambiar Plan
                </Button>
              )}
            </div>
          </CardContent>
        </Card>



        {/* Plan Semestral */}
        <Card className={isSubscribed && subscriptionData?.subscription_tier === 'biannual' ? "border-primary" : ""}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5" />
              Semestral
              {isSubscribed && subscriptionData?.subscription_tier === 'biannual' && <Badge>Tu Plan</Badge>}
            </CardTitle>
            <CardDescription>
              Ahorra 33% anual
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-3xl font-bold">
              60€ <span className="text-sm font-normal text-muted-foreground">/semestre</span>
            </div>
            
            <ul className="space-y-2 text-sm">
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Gestión completa de servicios
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Clientes ilimitados
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Inventario y stock
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Órdenes de trabajo
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Facturas ilimitadas
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Reportes completos
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Gestión de móviles
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Sistema de citas
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Balance financiero
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Configuración avanzada
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Soporte incluido
              </li>
            </ul>

            <div className="pt-4">
              {isLifetimeFree ? (
                <Button variant="outline" className="w-full" disabled>
                  Usuario Gratuito ✨
                </Button>
              ) : !isSubscribed ? (
                <Button 
                  onClick={() => handleCreateCheckout('biannual', 6000)} 
                  className="w-full"
                  disabled={loading}
                >
                  {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Suscribirse
                </Button>
              ) : subscriptionData?.subscription_tier === 'biannual' ? (
                <Button 
                  onClick={handleManageSubscription} 
                  variant="outline" 
                  className="w-full"
                  disabled={loading}
                >
                  {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Gestionar Plan
                </Button>
              ) : (
                <Button 
                  onClick={() => handleCreateCheckout('biannual', 6000)} 
                  variant="outline"
                  className="w-full"
                  disabled={loading}
                >
                  {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Cambiar Plan
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Plan Anual */}
        <Card className={isSubscribed && subscriptionData?.subscription_tier === 'yearly' ? "border-primary" : ""}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5" />
              Anual
              {isSubscribed && subscriptionData?.subscription_tier === 'yearly' && <Badge>Tu Plan</Badge>}
            </CardTitle>
            <CardDescription>
              Ahorra 44% anual
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-3xl font-bold">
              100€ <span className="text-sm font-normal text-muted-foreground">/año</span>
            </div>
            
            <ul className="space-y-2 text-sm">
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Gestión completa de servicios
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Clientes ilimitados
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Inventario y stock
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Órdenes de trabajo
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Facturas ilimitadas
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Reportes completos
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Gestión de móviles
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Sistema de citas
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Balance financiero
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Configuración avanzada
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Soporte incluido
              </li>
            </ul>

            <div className="pt-4">
              {isLifetimeFree ? (
                <Button variant="outline" className="w-full" disabled>
                  Usuario Gratuito ✨
                </Button>
              ) : !isSubscribed ? (
                <Button 
                  onClick={() => handleCreateCheckout('yearly', 10000)} 
                  className="w-full"
                  disabled={loading}
                >
                  {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Suscribirse
                </Button>
              ) : subscriptionData?.subscription_tier === 'yearly' ? (
                <Button 
                  onClick={handleManageSubscription} 
                  variant="outline" 
                  className="w-full"
                  disabled={loading}
                >
                  {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Gestionar Plan
                </Button>
              ) : (
                <Button 
                  onClick={() => handleCreateCheckout('yearly', 10000)} 
                  variant="outline"
                  className="w-full"
                  disabled={loading}
                >
                  {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Cambiar Plan
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Información de Contacto */}
      <Card>
        <CardHeader>
          <CardTitle>¿Necesitas ayuda?</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground mb-2">
            Si tienes alguna pregunta sobre los planes o necesitas asistencia técnica, no dudes en contactarnos:
          </p>
          <p className="font-medium">
            📧 Email: <a href="mailto:mitaller@mitallerenlinea.org" className="text-primary hover:underline">
              mitaller@mitallerenlinea.org
            </a>
          </p>
        </CardContent>
      </Card>
    </div>
  );
};

export default SubscriptionPage;
