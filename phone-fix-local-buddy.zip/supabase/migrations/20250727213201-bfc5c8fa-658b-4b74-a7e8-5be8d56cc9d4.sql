-- Quitar el campo color_factura de la tabla facturas
ALTER TABLE public.facturas 
DROP COLUMN color_factura;