import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  ExternalLink, 
  CreditCard, 
  Shield, 
  Zap, 
  Globe, 
  Users,
  TrendingUp,
  Server
} from 'lucide-react';

const StorageProviderInfo: React.FC = () => {
  const benefits = [
    {
      icon: CreditCard,
      title: "Pago Directo",
      description: "Pagas directamente al proveedor según tu uso real",
      color: "text-green-600"
    },
    {
      icon: Shield,
      title: "Control Total",
      description: "Tus datos están en tu propia infraestructura",
      color: "text-blue-600"
    },
    {
      icon: Zap,
      title: "Escalabilidad",
      description: "Crece según las necesidades de tu negocio",
      color: "text-purple-600"
    },
    {
      icon: Globe,
      title: "Sin Límites",
      description: "Sin restricciones de transferencia de datos",
      color: "text-orange-600"
    }
  ];

  const useCases = [
    {
      title: "Taller Pequeño (1-2 empleados)",
      provider: "Supabase",
      cost: "€0-8/mes",
      description: "Perfecto para empezar con costes mínimos",
      features: ["Hasta 500MB base de datos", "100GB ancho de banda", "50MB archivos"]
    },
    {
      title: "Taller Mediano (3-10 empleados)", 
      provider: "Supabase Pro",
      cost: "€25/mes",
      description: "Para talleres en crecimiento",
      features: ["8GB base de datos", "250GB ancho de banda", "100GB archivos"]
    },
    {
      title: "Cadena de Talleres (10+ empleados)",
      provider: "AWS/GCP",
      cost: "€50-200/mes",
      description: "Infraestructura empresarial completa",
      features: ["Bases de datos ilimitadas", "CDN global", "Backups automáticos", "Soporte 24/7"]
    }
  ];

  const comparisonData = [
    {
      feature: "Coste mensual inicial",
      centralized: "€15/mes por usuario",
      custom: "€0-25/mes total",
      winner: "custom"
    },
    {
      feature: "Control de datos",
      centralized: "Compartido con otros usuarios",
      custom: "100% privado y controlado",
      winner: "custom"
    },
    {
      feature: "Escalabilidad",
      centralized: "Limitada por el plan",
      custom: "Ilimitada según proveedor",
      winner: "custom"
    },
    {
      feature: "Facilidad de configuración",
      centralized: "Inmediata",
      custom: "Requiere configuración inicial",
      winner: "centralized"
    },
    {
      feature: "Mantenimiento",
      centralized: "Incluido",
      custom: "Responsabilidad del usuario",
      winner: "centralized"
    }
  ];

  return (
    <div className="space-y-6">
      {/* Hero Section */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
        <CardHeader>
          <CardTitle className="text-2xl">🏗️ Almacenamiento Personalizado</CardTitle>
          <CardDescription className="text-lg">
            Usa tu propia infraestructura y paga directamente al proveedor de tu elección
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {benefits.map((benefit) => (
              <div key={benefit.title} className="flex items-start gap-3 p-4 bg-white rounded-lg">
                <benefit.icon className={`h-6 w-6 ${benefit.color} mt-1`} />
                <div>
                  <h3 className="font-medium">{benefit.title}</h3>
                  <p className="text-sm text-gray-600">{benefit.description}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Use Cases */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Casos de Uso y Costes
          </CardTitle>
          <CardDescription>
            Encuentra la configuración perfecta para tu taller
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {useCases.map((useCase, index) => (
              <Card key={index} className="border-2">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <Badge variant="outline">{useCase.provider}</Badge>
                    <span className="text-2xl font-bold text-green-600">{useCase.cost}</span>
                  </div>
                  <CardTitle className="text-lg">{useCase.title}</CardTitle>
                  <CardDescription>{useCase.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {useCase.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center gap-2 text-sm">
                        <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Comparison Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Server className="h-5 w-5" />
            Comparación: Centralizado vs Personalizado
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-3">Característica</th>
                  <th className="text-left p-3">Almacenamiento Centralizado</th>
                  <th className="text-left p-3">Almacenamiento Personalizado</th>
                  <th className="text-left p-3">Mejor Opción</th>
                </tr>
              </thead>
              <tbody>
                {comparisonData.map((row, index) => (
                  <tr key={index} className="border-b hover:bg-gray-50">
                    <td className="p-3 font-medium">{row.feature}</td>
                    <td className="p-3 text-sm">{row.centralized}</td>
                    <td className="p-3 text-sm">{row.custom}</td>
                    <td className="p-3">
                      <Badge 
                        variant={row.winner === 'custom' ? 'default' : 'secondary'}
                        className={row.winner === 'custom' ? 'bg-green-600' : 'bg-blue-600'}
                      >
                        {row.winner === 'custom' ? 'Personalizado' : 'Centralizado'}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Provider Links */}
      <Card>
        <CardHeader>
          <CardTitle>🔗 Enlaces Útiles de Proveedores</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <Button variant="outline" className="h-auto p-4 justify-start">
              <div className="flex items-center gap-3">
                <span className="text-2xl">🐘</span>
                <div className="text-left">
                  <div className="font-medium">Supabase</div>
                  <div className="text-xs text-gray-500">supabase.com</div>
                </div>
                <ExternalLink className="h-4 w-4 ml-auto" />
              </div>
            </Button>

            <Button variant="outline" className="h-auto p-4 justify-start">
              <div className="flex items-center gap-3">
                <span className="text-2xl">☁️</span>
                <div className="text-left">
                  <div className="font-medium">AWS</div>
                  <div className="text-xs text-gray-500">aws.amazon.com</div>
                </div>
                <ExternalLink className="h-4 w-4 ml-auto" />
              </div>
            </Button>

            <Button variant="outline" className="h-auto p-4 justify-start">
              <div className="flex items-center gap-3">
                <span className="text-2xl">🔵</span>
                <div className="text-left">
                  <div className="font-medium">Google Cloud</div>
                  <div className="text-xs text-gray-500">cloud.google.com</div>
                </div>
                <ExternalLink className="h-4 w-4 ml-auto" />
              </div>
            </Button>

            <Button variant="outline" className="h-auto p-4 justify-start">
              <div className="flex items-center gap-3">
                <span className="text-2xl">🔷</span>
                <div className="text-left">
                  <div className="font-medium">Azure</div>
                  <div className="text-xs text-gray-500">azure.microsoft.com</div>
                </div>
                <ExternalLink className="h-4 w-4 ml-auto" />
              </div>
            </Button>

            <Button variant="outline" className="h-auto p-4 justify-start">
              <div className="flex items-center gap-3">
                <span className="text-2xl">🌊</span>
                <div className="text-left">
                  <div className="font-medium">DigitalOcean</div>
                  <div className="text-xs text-gray-500">digitalocean.com</div>
                </div>
                <ExternalLink className="h-4 w-4 ml-auto" />
              </div>
            </Button>

            <Button variant="outline" className="h-auto p-4 justify-start">
              <div className="flex items-center gap-3">
                <span className="text-2xl">🏢</span>
                <div className="text-left">
                  <div className="font-medium">Servidor Propio</div>
                  <div className="text-xs text-gray-500">Tu infraestructura</div>
                </div>
                <Users className="h-4 w-4 ml-auto" />
              </div>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Security Notice */}
      <Card className="border-orange-200 bg-orange-50">
        <CardContent className="p-6">
          <div className="flex items-start gap-3">
            <Shield className="h-6 w-6 text-orange-600 mt-1" />
            <div>
              <h3 className="font-medium text-orange-900 mb-2">Importante sobre Seguridad</h3>
              <div className="text-sm text-orange-800 space-y-2">
                <p>
                  • <strong>Responsabilidad:</strong> Al usar almacenamiento personalizado, eres responsable de la seguridad y backups
                </p>
                <p>
                  • <strong>Configuración:</strong> Asegúrate de configurar SSL/HTTPS y autenticación adecuada
                </p>
                <p>
                  • <strong>Backups:</strong> Configura backups automáticos en tu proveedor elegido
                </p>
                <p>
                  • <strong>Monitoreo:</strong> Supervisa el uso y rendimiento de tu infraestructura
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default StorageProviderInfo;
