// Gestor para WhatsApp Desktop con fallback a Web
export interface WhatsAppMethod {
  type: 'desktop' | 'web' | 'mobile' | 'clipboard';
  available: boolean;
  name: string;
  priority: number;
}

export interface WhatsAppSendResult {
  success: boolean;
  method: WhatsAppMethod['type'];
  error?: string;
  fallbackUsed?: boolean;
}

class WhatsAppDesktopManager {
  private methods: WhatsAppMethod[] = [
    { type: 'desktop', available: false, name: 'WhatsApp Desktop', priority: 1 },
    { type: 'web', available: false, name: 'WhatsApp Web', priority: 2 },
    { type: 'mobile', available: true, name: 'WhatsApp Móvil', priority: 3 },
    { type: 'clipboard', available: true, name: 'Copiar al portapapeles', priority: 4 }
  ];

  /**
   * Detecta si WhatsApp Desktop está instalado
   */
  async detectWhatsAppDesktop(): Promise<boolean> {
    try {
      // Método 1: Intentar protocol handler whatsapp://
      const desktopSupported = await this.testDesktopProtocol();
      
      if (desktopSupported) {
        console.log('✅ WhatsApp Desktop detectado via protocol handler');
        return true;
      }

      // Método 2: Verificar características del navegador que indican aplicación desktop
      const isDesktopApp = await this.detectDesktopEnvironment();
      
      if (isDesktopApp) {
        console.log('✅ Entorno de aplicación desktop detectado');
        return true;
      }

      console.log('❌ WhatsApp Desktop no detectado');
      return false;
    } catch (error) {
      console.warn('Error detectando WhatsApp Desktop:', error);
      return false;
    }
  }

  /**
   * Prueba el protocol handler de WhatsApp Desktop
   */
  private async testDesktopProtocol(): Promise<boolean> {
    return new Promise((resolve) => {
      try {
        // Crear un enlace temporal para probar el protocol handler
        const testLink = document.createElement('a');
        testLink.href = 'whatsapp://send?text=test';
        testLink.style.display = 'none';
        
        let resolved = false;
        const timeout = setTimeout(() => {
          if (!resolved) {
            resolved = true;
            resolve(false);
          }
        }, 1000);

        // Intentar abrir el protocol handler
        const clickHandler = () => {
          if (!resolved) {
            resolved = true;
            clearTimeout(timeout);
            resolve(true);
          }
        };

        // Escuchar eventos que indican que el protocol handler funcionó
        window.addEventListener('blur', clickHandler, { once: true });
        window.addEventListener('focus', () => {
          setTimeout(() => {
            if (!resolved) {
              resolved = true;
              clearTimeout(timeout);
              resolve(true);
            }
          }, 100);
        }, { once: true });

        document.body.appendChild(testLink);
        testLink.click();
        document.body.removeChild(testLink);

      } catch (error) {
        resolve(false);
      }
    });
  }

  /**
   * Detecta si estamos en un entorno de aplicación desktop
   */
  private async detectDesktopEnvironment(): Promise<boolean> {
    try {
      // Verificar user agent para indicios de aplicación desktop
      const userAgent = navigator.userAgent.toLowerCase();
      
      // Características que sugieren aplicación desktop
      const desktopIndicators = [
        'electron',
        'whatsapp',
        'desktop'
      ];

      const hasDesktopIndicator = desktopIndicators.some(indicator => 
        userAgent.includes(indicator)
      );

      // Verificar capacidades que sugieren aplicación nativa
      const hasNativeCapabilities = (
        'serviceWorker' in navigator &&
        'notification' in window &&
        !('ontouchstart' in window) && // No es móvil
        navigator.platform !== 'iPhone' &&
        navigator.platform !== 'iPad'
      );

      return hasDesktopIndicator || hasNativeCapabilities;
    } catch (error) {
      return false;
    }
  }

  /**
   * Actualiza la disponibilidad de métodos
   */
  async updateMethodAvailability(): Promise<void> {
    // Verificar WhatsApp Desktop
    const desktopAvailable = await this.detectWhatsAppDesktop();
    this.setMethodAvailability('desktop', desktopAvailable);

    // WhatsApp Web siempre está disponible en navegadores
    this.setMethodAvailability('web', true);
    
    // Móvil y clipboard siempre disponibles
    this.setMethodAvailability('mobile', true);
    this.setMethodAvailability('clipboard', true);
  }

  /**
   * Establece la disponibilidad de un método
   */
  private setMethodAvailability(type: WhatsAppMethod['type'], available: boolean): void {
    const method = this.methods.find(m => m.type === type);
    if (method) {
      method.available = available;
    }
  }

  /**
   * Obtiene métodos disponibles ordenados por prioridad
   */
  getAvailableMethods(): WhatsAppMethod[] {
    return this.methods
      .filter(method => method.available)
      .sort((a, b) => a.priority - b.priority);
  }

  /**
   * Envía mensaje usando el mejor método disponible
   */
  async sendMessage(phoneNumber: string, message: string): Promise<WhatsAppSendResult> {
    await this.updateMethodAvailability();
    const availableMethods = this.getAvailableMethods();

    console.log('🔍 Métodos disponibles:', availableMethods.map(m => m.name));

    for (const method of availableMethods) {
      try {
        console.log(`🔄 Intentando: ${method.name}`);
        const result = await this.tryMethod(method.type, phoneNumber, message);
        
        if (result.success) {
          console.log(`✅ Éxito con: ${method.name}`);
          return {
            success: true,
            method: method.type,
            fallbackUsed: method.priority > 1
          };
        }
      } catch (error) {
        console.warn(`❌ Falló ${method.name}:`, error);
        continue;
      }
    }

    // Si todos los métodos fallan, usar clipboard como último recurso
    return this.copyToClipboard(phoneNumber, message);
  }

  /**
   * Intenta un método específico
   */
  private async tryMethod(
    type: WhatsAppMethod['type'], 
    phoneNumber: string, 
    message: string
  ): Promise<WhatsAppSendResult> {
    const formattedPhone = this.formatPhoneNumber(phoneNumber);
    const encodedMessage = encodeURIComponent(message);

    switch (type) {
      case 'desktop':
        return this.tryDesktop(formattedPhone, encodedMessage);
      
      case 'web':
        return this.tryWeb(formattedPhone, encodedMessage);
      
      case 'mobile':
        return this.tryMobile(formattedPhone, encodedMessage);
      
      case 'clipboard':
        return this.copyToClipboard(phoneNumber, message);
      
      default:
        throw new Error(`Método no soportado: ${type}`);
    }
  }

  /**
   * Intenta abrir WhatsApp Desktop
   */
  private async tryDesktop(phoneNumber: string, encodedMessage: string): Promise<WhatsAppSendResult> {
    try {
      // Intentar protocol handler específico de WhatsApp Desktop
      const desktopUrl = `whatsapp://send?phone=${phoneNumber}&text=${encodedMessage}`;
      
      // Crear enlace temporal
      const link = document.createElement('a');
      link.href = desktopUrl;
      link.style.display = 'none';
      
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      // Verificar si se abrió correctamente
      await new Promise(resolve => setTimeout(resolve, 500));
      
      return {
        success: true,
        method: 'desktop'
      };
    } catch (error) {
      throw new Error(`Desktop falló: ${error}`);
    }
  }

  /**
   * Intenta abrir WhatsApp Web
   */
  private async tryWeb(phoneNumber: string, encodedMessage: string): Promise<WhatsAppSendResult> {
    try {
      const webUrl = `https://web.whatsapp.com/send?phone=${phoneNumber}&text=${encodedMessage}`;
      
      const webWindow = window.open(
        webUrl, 
        '_blank', 
        'width=1200,height=800,scrollbars=yes,resizable=yes'
      );

      if (!webWindow) {
        throw new Error('Popup bloqueado');
      }

      return {
        success: true,
        method: 'web'
      };
    } catch (error) {
      throw new Error(`Web falló: ${error}`);
    }
  }

  /**
   * Intenta abrir WhatsApp móvil
   */
  private async tryMobile(phoneNumber: string, encodedMessage: string): Promise<WhatsAppSendResult> {
    try {
      const mobileUrl = `https://wa.me/${phoneNumber}?text=${encodedMessage}`;
      
      const mobileWindow = window.open(mobileUrl, '_blank');
      
      if (!mobileWindow) {
        throw new Error('No se pudo abrir WhatsApp móvil');
      }

      return {
        success: true,
        method: 'mobile'
      };
    } catch (error) {
      throw new Error(`Móvil falló: ${error}`);
    }
  }

  /**
   * Copia mensaje al portapapeles como último recurso
   */
  private async copyToClipboard(phoneNumber: string, message: string): Promise<WhatsAppSendResult> {
    try {
      const textToCopy = `📱 WhatsApp para: ${phoneNumber}\n\n📝 Mensaje:\n${message}\n\n💡 Pega esto manualmente en WhatsApp`;
      
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(textToCopy);
      } else {
        // Fallback para navegadores sin clipboard API
        const textArea = document.createElement('textarea');
        textArea.value = textToCopy;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
      }

      // Mostrar notificación visual
      this.showClipboardNotification();

      return {
        success: true,
        method: 'clipboard'
      };
    } catch (error) {
      return {
        success: false,
        method: 'clipboard',
        error: `Error copiando al portapapeles: ${error}`
      };
    }
  }

  /**
   * Muestra notificación de que se copió al portapapeles
   */
  private showClipboardNotification(): void {
    const notification = document.createElement('div');
    notification.innerHTML = `
      <div style="
        position: fixed; 
        top: 20px; 
        right: 20px; 
        background: #10b981; 
        color: white; 
        padding: 16px 24px; 
        border-radius: 8px; 
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 9999;
        font-family: system-ui, -apple-system, sans-serif;
        font-size: 14px;
        max-width: 300px;
      ">
        <div style="font-weight: 600; margin-bottom: 4px;">
          📋 Mensaje copiado al portapapeles
        </div>
        <div style="font-size: 12px; opacity: 0.9;">
          Pégalo manualmente en WhatsApp Desktop o Web
        </div>
      </div>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
      if (notification.parentNode) {
        notification.parentNode.removeChild(notification);
      }
    }, 5000);
  }

  /**
   * Formatea número de teléfono
   */
  private formatPhoneNumber(phone: string): string {
    let cleaned = phone.replace(/\D/g, '');
    
    if (!cleaned.startsWith('34') && cleaned.length === 9) {
      cleaned = '34' + cleaned;
    }
    
    return cleaned;
  }

  /**
   * Obtiene información sobre métodos disponibles
   */
  async getMethodsInfo(): Promise<WhatsAppMethod[]> {
    await this.updateMethodAvailability();
    return [...this.methods];
  }
}

// Instancia singleton
export const whatsappDesktopManager = new WhatsAppDesktopManager();

// Función principal para enviar mensajes con prioridad a Desktop
export async function sendWhatsAppMessageDesktopFirst(
  phoneNumber: string, 
  message: string
): Promise<WhatsAppSendResult> {
  return whatsappDesktopManager.sendMessage(phoneNumber, message);
}

// Función para obtener información de métodos disponibles
export async function getAvailableWhatsAppMethods(): Promise<WhatsAppMethod[]> {
  return whatsappDesktopManager.getMethodsInfo();
}
