import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useEmpresaConfig, EmpresaConfig, ConfiguracionSeccion } from '@/hooks/useEmpresaConfig';
import {
  Building2,
  Save,
  RotateCcw,
  MapPin,
  Phone,
  Mail,
  FileText,
  CheckCircle,
  AlertCircle,
  Settings,
  ShoppingCart,
  Smartphone,
  Receipt,
  Package,
  ChevronDown,
  ChevronUp
} from 'lucide-react';

export default function ConfiguracionEmpresa() {
  const { config, loading, saveConfig, resetToDefaults } = useEmpresaConfig();
  const [formData, setFormData] = useState<EmpresaConfig>(config);
  const [saving, setSaving] = useState(false);
  const [expandedSection, setExpandedSection] = useState<string | null>(null);
  const { toast } = useToast();

  // Actualizar formData cuando config cambie
  useEffect(() => {
    setFormData(config);
  }, [config]);

  const handleSave = async () => {
    setSaving(true);
    try {
      const success = await saveConfig(formData);
      if (success) {
        toast({
          title: "✅ Configuración guardada",
          description: "Los datos se aplicarán automáticamente a todos los tickets",
          variant: "default"
        });
      }
    } catch (error) {
      console.error('Error saving:', error);
    } finally {
      setSaving(false);
    }
  };

  const handleReset = () => {
    resetToDefaults();
    setFormData(config);
    toast({
      title: "Configuración restablecida",
      description: "Se han restaurado los valores por defecto",
      variant: "default"
    });
  };

  const updateField = (field: keyof EmpresaConfig, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-slate-800 flex items-center gap-2">
            <Building2 className="w-8 h-8" />
            Configuración de Empresa
          </h1>
          <p className="text-slate-600 mt-2">
            Configura los datos de tu empresa que aparecerán en todos los tickets y facturas
          </p>
        </div>
        <Badge variant="outline" className="bg-green-50 text-green-700">
          <CheckCircle className="w-4 h-4 mr-1" />
          Sincronización Automática
        </Badge>
      </div>

      {/* Información importante */}
      <Card className="border-blue-200 bg-blue-50">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
            <div>
              <h3 className="font-semibold text-blue-800">Configuración Centralizada</h3>
              <p className="text-sm text-blue-700 mt-1">
                Estos datos se aplicarán automáticamente a:
                <span className="font-medium"> Tickets TPV, Facturas, Inventario, Órdenes de Trabajo</span> y todos los códigos QR.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Formulario principal */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Datos de la Empresa
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Información básica */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <Label htmlFor="nombreEmpresa" className="flex items-center gap-2">
                <Building2 className="w-4 h-4" />
                Nombre de la Empresa *
              </Label>
              <Input
                id="nombreEmpresa"
                value={formData.nombreEmpresa}
                onChange={(e) => updateField('nombreEmpresa', e.target.value)}
                placeholder="Ej: TECHREPAIR PRO"
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="telefono" className="flex items-center gap-2">
                <Phone className="w-4 h-4" />
                Teléfono
              </Label>
              <Input
                id="telefono"
                value={formData.telefono}
                onChange={(e) => updateField('telefono', e.target.value)}
                placeholder="Ej: +34 123 456 789"
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="email" className="flex items-center gap-2">
                <Mail className="w-4 h-4" />
                Email
              </Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => updateField('email', e.target.value)}
                placeholder="Ej: info@techrepair.com"
                className="mt-1"
              />
            </div>

            <div className="md:col-span-2">
              <Label htmlFor="direccion" className="flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                Dirección Completa
              </Label>
              <Input
                id="direccion"
                value={formData.direccion}
                onChange={(e) => updateField('direccion', e.target.value)}
                placeholder="Ej: Calle Mayor 123, 28001 Madrid"
                className="mt-1"
              />
            </div>
          </div>

          {/* Documento fiscal */}
          <div className="border-t pt-6">
            <h3 className="text-lg font-semibold mb-4">Información Fiscal</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="tipoDocumento">Tipo de Documento</Label>
                <Select 
                  value={formData.tipoDocumento} 
                  onValueChange={(value: 'CIF' | 'NIF') => updateField('tipoDocumento', value)}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="CIF">CIF (Código de Identificación Fiscal)</SelectItem>
                    <SelectItem value="NIF">NIF (Número de Identificación Fiscal)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="md:col-span-2">
                <Label htmlFor="cif">
                  {formData.tipoDocumento === 'CIF' ? 'CIF' : 'NIF'}
                </Label>
                <Input
                  id="cif"
                  value={formData.cif}
                  onChange={(e) => updateField('cif', e.target.value)}
                  placeholder={formData.tipoDocumento === 'CIF' ? 'Ej: A12345678' : 'Ej: 12345678X'}
                  className="mt-1"
                />
              </div>
            </div>
          </div>

          {/* Términos y condiciones */}
          <div className="border-t pt-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Términos y Condiciones Generales
            </h3>
            <div>
              <Label htmlFor="terminosTicket">
                Texto que aparecerá en todos los tickets de resguardo
              </Label>
              <Textarea
                id="terminosTicket"
                value={formData.terminosTicket}
                onChange={(e) => updateField('terminosTicket', e.target.value)}
                placeholder="Escribe los términos y condiciones generales..."
                rows={6}
                className="mt-1"
              />
              <p className="text-xs text-gray-500 mt-1">
                Cada línea se mostrará como un punto separado en el ticket
              </p>
            </div>
          </div>

          {/* Configuraciones específicas por sección */}
          <div className="border-t pt-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Settings className="w-5 h-5" />
              Configuraciones Específicas por Sección
            </h3>
            <p className="text-sm text-gray-600 mb-4">
              Personaliza la información que aparece en la parte inferior de cada tipo de ticket
            </p>

            {/* TPV */}
            <ConfiguracionSeccionCard
              titulo="TPV - Terminal Punto de Venta"
              icono={<ShoppingCart className="w-5 h-5" />}
              seccion="configuracionTPV"
              config={formData.configuracionTPV}
              expanded={expandedSection === 'tpv'}
              onToggle={() => setExpandedSection(expandedSection === 'tpv' ? null : 'tpv')}
              onUpdate={(newConfig) => setFormData(prev => ({ ...prev, configuracionTPV: newConfig }))}
            />

            {/* Móviles */}
            <ConfiguracionSeccionCard
              titulo="Órdenes de Trabajo - Móviles"
              icono={<Smartphone className="w-5 h-5" />}
              seccion="configuracionMoviles"
              config={formData.configuracionMoviles}
              expanded={expandedSection === 'moviles'}
              onToggle={() => setExpandedSection(expandedSection === 'moviles' ? null : 'moviles')}
              onUpdate={(newConfig) => setFormData(prev => ({ ...prev, configuracionMoviles: newConfig }))}
            />

            {/* Facturas */}
            <ConfiguracionSeccionCard
              titulo="Facturas"
              icono={<Receipt className="w-5 h-5" />}
              seccion="configuracionFacturas"
              config={formData.configuracionFacturas}
              expanded={expandedSection === 'facturas'}
              onToggle={() => setExpandedSection(expandedSection === 'facturas' ? null : 'facturas')}
              onUpdate={(newConfig) => setFormData(prev => ({ ...prev, configuracionFacturas: newConfig }))}
            />

            {/* Inventario */}
            <ConfiguracionSeccionCard
              titulo="Inventario"
              icono={<Package className="w-5 h-5" />}
              seccion="configuracionInventario"
              config={formData.configuracionInventario}
              expanded={expandedSection === 'inventario'}
              onToggle={() => setExpandedSection(expandedSection === 'inventario' ? null : 'inventario')}
              onUpdate={(newConfig) => setFormData(prev => ({ ...prev, configuracionInventario: newConfig }))}
            />
          </div>

          {/* Botones de acción */}
          <div className="flex justify-between items-center pt-6 border-t">
            <Button 
              variant="outline" 
              onClick={handleReset}
              className="text-gray-600"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              Restablecer
            </Button>

            <Button 
              onClick={handleSave}
              disabled={saving || !formData.nombreEmpresa.trim()}
              className="min-w-32"
            >
              {saving ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  Guardando...
                </div>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  Guardar Configuración
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Vista previa */}
      <Card>
        <CardHeader>
          <CardTitle>Vista Previa del Header</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-gray-50 p-4 rounded-lg font-mono text-sm">
            <div className="text-center border-b-2 border-gray-300 pb-3 mb-3">
              <div className="font-bold text-lg">{formData.nombreEmpresa || 'NOMBRE DE EMPRESA'}</div>
              <div className="mt-2 space-y-1 text-xs">
                {formData.telefono && <div>📞 {formData.telefono}</div>}
                {formData.direccion && <div>📍 {formData.direccion}</div>}
                {formData.email && <div>📧 {formData.email}</div>}
                {formData.cif && (
                  <div>🏢 {formData.tipoDocumento}: {formData.cif}</div>
                )}
              </div>
            </div>
            <div className="text-xs text-gray-600 text-center">
              Así aparecerá en todos los tickets y facturas
            </div>

            {/* Ejemplo de configuración específica */}
            {expandedSection && (
              <div className="mt-4 p-3 bg-blue-50 rounded border">
                <div className="text-xs font-semibold text-blue-800 mb-2">
                  Información específica de sección:
                </div>
                <div className="text-xs text-blue-700">
                  {expandedSection === 'tpv' && formData.configuracionTPV.textoPersonalizado}
                  {expandedSection === 'moviles' && formData.configuracionMoviles.textoPersonalizado}
                  {expandedSection === 'facturas' && formData.configuracionFacturas.textoPersonalizado}
                  {expandedSection === 'inventario' && formData.configuracionInventario.textoPersonalizado}
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Componente para configuración de sección específica
interface ConfiguracionSeccionCardProps {
  titulo: string;
  icono: React.ReactNode;
  seccion: string;
  config: ConfiguracionSeccion;
  expanded: boolean;
  onToggle: () => void;
  onUpdate: (config: ConfiguracionSeccion) => void;
}

function ConfiguracionSeccionCard({
  titulo,
  icono,
  config,
  expanded,
  onToggle,
  onUpdate
}: ConfiguracionSeccionCardProps) {
  return (
    <Card className="mb-4">
      <CardHeader
        className="cursor-pointer hover:bg-gray-50 transition-colors"
        onClick={onToggle}
      >
        <CardTitle className="flex items-center justify-between text-base">
          <div className="flex items-center gap-2">
            {icono}
            {titulo}
          </div>
          <div className="flex items-center gap-2">
            <Badge variant={config.mostrarEnTicket ? "default" : "secondary"}>
              {config.mostrarEnTicket ? "Activo" : "Inactivo"}
            </Badge>
            {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </div>
        </CardTitle>
      </CardHeader>

      {expanded && (
        <CardContent className="space-y-4">
          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id={`mostrar-${titulo}`}
              checked={config.mostrarEnTicket}
              onChange={(e) => onUpdate({ ...config, mostrarEnTicket: e.target.checked })}
              className="rounded"
            />
            <Label htmlFor={`mostrar-${titulo}`} className="text-sm">
              Mostrar configuración específica en tickets
            </Label>
          </div>

          <div>
            <Label htmlFor={`texto-${titulo}`}>Texto Personalizado</Label>
            <Input
              id={`texto-${titulo}`}
              value={config.textoPersonalizado}
              onChange={(e) => onUpdate({ ...config, textoPersonalizado: e.target.value })}
              placeholder="Ej: Terminal Punto de Venta"
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor={`info-${titulo}`}>Información Adicional</Label>
            <Input
              id={`info-${titulo}`}
              value={config.informacionAdicional}
              onChange={(e) => onUpdate({ ...config, informacionAdicional: e.target.value })}
              placeholder="Ej: Horario de atención, contacto específico..."
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor={`terminos-${titulo}`}>Términos Específicos</Label>
            <Textarea
              id={`terminos-${titulo}`}
              value={config.terminos}
              onChange={(e) => onUpdate({ ...config, terminos: e.target.value })}
              placeholder="Términos y condiciones específicos para esta sección..."
              rows={3}
              className="mt-1"
            />
            <p className="text-xs text-gray-500 mt-1">
              Estos términos aparecerán además de los términos generales
            </p>
          </div>
        </CardContent>
      )}
    </Card>
  );
}
