/**
 * Utility functions for consistent error handling and logging
 */

export interface SupabaseError {
  message?: string;
  details?: string;
  hint?: string;
  code?: string;
  error_description?: string;
}

/**
 * Logs Supabase errors with consistent formatting
 * @param context - Description of where the error occurred
 * @param error - The error object from Supabase
 * @param operation - Optional operation details (e.g., 'insert', 'update', 'select')
 */
export function logSupabaseError(context: string, error: any, operation?: string) {
  console.error(`Supabase Error - ${context}:`, {
    error: error,
    message: error?.message || 'Unknown error',
    details: error?.details || 'No details available',
    hint: error?.hint || 'No hint available',
    code: error?.code || 'No error code',
    operation: operation || 'unknown',
    timestamp: new Date().toISOString()
  });
}

/**
 * Extracts a user-friendly error message from a Supabase error
 * @param error - The error object from Supabase
 * @param fallbackMessage - Default message if no specific message is found
 * @returns User-friendly error message
 */
export function getErrorMessage(error: any, fallbackMessage: string = 'Error desconocido'): string {
  if (typeof error === 'string') {
    return error;
  }
  
  return error?.message || error?.error_description || fallbackMessage;
}

/**
 * Checks if an error is a Supabase authentication error
 * @param error - The error object to check
 * @returns True if it's an auth error
 */
export function isAuthError(error: any): boolean {
  return error?.code === 'invalid_credentials' || 
         error?.message?.includes('Invalid login credentials') ||
         error?.message?.includes('Email not confirmed');
}

/**
 * Checks if an error is a network/connection error
 * @param error - The error object to check
 * @returns True if it's a network error
 */
export function isNetworkError(error: any): boolean {
  return error?.code === 'NETWORK_ERROR' ||
         error?.message?.includes('network') ||
         error?.message?.includes('fetch');
}
