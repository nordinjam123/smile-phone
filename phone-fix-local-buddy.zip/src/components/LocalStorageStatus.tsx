import React from 'react';
import { Badge } from '@/components/ui/badge';
import { 
  HardDrive,
  CheckCircle,
  Database,
  User
} from 'lucide-react';
import { useLocalAuth } from '@/hooks/useLocalAuth';
import { useLocalData } from '@/contexts/LocalDataContext';

const LocalStorageStatus: React.FC = () => {
  const { user, isAuthenticated } = useLocalAuth();
  const { isOnline, getStorageStats } = useLocalData();
  
  if (!isAuthenticated || !user) {
    return null;
  }

  const stats = getStorageStats();

  const getStatusColor = () => {
    if (!isAuthenticated) return 'bg-amber-100 text-amber-800';
    return 'bg-green-100 text-green-800';
  };

  const getStatusText = () => {
    if (!isAuthenticated) return 'No autenticado';
    return 'Almacenamiento local activo';
  };

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <Badge className={`${getStatusColor()} flex items-center gap-2 px-3 py-1 shadow-lg`}>
        <HardDrive className="h-3 w-3" />
        <CheckCircle className="h-3 w-3" />
        <span className="text-xs font-medium">{getStatusText()}</span>
        {isAuthenticated && user && (
          <>
            <span className="text-xs opacity-75">
              | {user.email?.split('@')[0]}
            </span>
            <span className="text-xs opacity-75">
              | {stats.totalDocuments} docs
            </span>
          </>
        )}
      </Badge>
    </div>
  );
};

export default LocalStorageStatus;
