import { useState, useEffect } from 'react';
import { firebaseService, FirebaseUser } from '@/lib/firebaseService';

interface UseFirebaseAuthReturn {
  user: FirebaseUser | null;
  loading: boolean;
  isAuthenticated: boolean;
  signOut: () => Promise<void>;
  isFirebaseReady: boolean;
}

export const useFirebaseAuth = (): UseFirebaseAuthReturn => {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [isFirebaseReady, setIsFirebaseReady] = useState(false);

  useEffect(() => {
    let unsubscribe: (() => void) | undefined;

    const initializeAuth = async () => {
      try {
        // Try to load saved Firebase config
        const initialized = await firebaseService.loadSavedConfig();
        setIsFirebaseReady(initialized);

        if (initialized) {
          // Set up auth state listener
          unsubscribe = firebaseService.onAuthStateChanged((firebaseUser) => {
            setUser(firebaseUser);
            setLoading(false);
          });
        } else {
          setLoading(false);
        }
      } catch (error) {
        console.error('Error initializing Firebase auth:', error);
        setLoading(false);
      }
    };

    initializeAuth();

    return () => {
      if (unsubscribe) {
        unsubscribe();
      }
    };
  }, []);

  const signOut = async (): Promise<void> => {
    try {
      setLoading(true);
      const { success, error } = await firebaseService.signOut();
      if (error) {
        throw new Error(error);
      }
      setUser(null);
    } catch (error) {
      console.error('Error signing out:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  return {
    user,
    loading,
    isAuthenticated: !!user,
    signOut,
    isFirebaseReady
  };
};
