import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/useAuth';
import { Lock, AlertTriangle } from 'lucide-react';

interface AccessGuardProps {
  children: React.ReactNode;
  onUpgrade: () => void;
}

const AccessGuard: React.FC<AccessGuardProps> = ({ children, onUpgrade }) => {
  const { subscriptionData, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  // Allow access if: subscribed, lifetime free, or has trial access
  const hasAccess = subscriptionData?.subscribed || 
                   subscriptionData?.is_lifetime_free || 
                   subscriptionData?.has_access;

  if (hasAccess) {
    return <>{children}</>;
  }

  // No access - show upgrade prompt
  return (
    <div className="p-6">
      <Card className="border-orange-200 bg-orange-50">
        <CardContent className="p-8 text-center">
          <div className="flex justify-center mb-4">
            <div className="p-3 bg-orange-100 rounded-full">
              <Lock className="h-8 w-8 text-orange-600" />
            </div>
          </div>
          
          <h3 className="text-xl font-semibold text-orange-800 mb-2">
            Acceso Restringido
          </h3>
          
          <p className="text-orange-600 mb-4">
            Tu período de prueba ha terminado. Para continuar usando esta funcionalidad, 
            necesitas una suscripción activa.
          </p>

          <div className="flex items-center gap-2 justify-center mb-6 text-sm text-orange-700">
            <AlertTriangle className="h-4 w-4" />
            <span>Planes desde 15€/mes hasta 100€/año</span>
          </div>
          
          <Button onClick={onUpgrade} className="bg-orange-600 hover:bg-orange-700">
            Suscribirse Ahora
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default AccessGuard;