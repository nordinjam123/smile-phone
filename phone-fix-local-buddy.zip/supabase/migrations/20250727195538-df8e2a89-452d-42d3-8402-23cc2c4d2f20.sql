-- Add trial functionality to subscribers table
ALTER TABLE public.subscribers 
ADD COLUMN trial_start TIMESTAMPTZ,
ADD COLUMN trial_end TIMESTAMPTZ,
ADD COLUMN is_lifetime_free BOOLEAN DEFAULT false;

-- Create invoice templates table
CREATE TABLE public.invoice_templates (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  template_data JSONB NOT NULL,
  is_default BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS for invoice templates
ALTER TABLE public.invoice_templates ENABLE ROW LEVEL SECURITY;

-- Create policies for invoice templates
CREATE POLICY "Users can view their own invoice templates" 
ON public.invoice_templates 
FOR SELECT 
USING (user_id = auth.uid());

CREATE POLICY "Users can create their own invoice templates" 
ON public.invoice_templates 
FOR INSERT 
WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update their own invoice templates" 
ON public.invoice_templates 
FOR UPDATE 
USING (user_id = auth.uid());

CREATE POLICY "Users can delete their own invoice templates" 
ON public.invoice_templates 
FOR DELETE 
USING (user_id = auth.uid());

-- Insert some default templates
INSERT INTO public.invoice_templates (name, template_data, is_default, user_id) VALUES
('Plantilla Básica', '{"layout":"basic","fields":["cliente","fecha","conceptos","totales"],"colors":{"primary":"#3b82f6","secondary":"#64748b"},"logo_position":"top-left"}', true, null),
('Plantilla Moderna', '{"layout":"modern","fields":["cliente","fecha","conceptos","totales","notas"],"colors":{"primary":"#10b981","secondary":"#374151"},"logo_position":"center","show_qr":true}', false, null),
('Plantilla Minimalista', '{"layout":"minimal","fields":["cliente","conceptos","totales"],"colors":{"primary":"#000000","secondary":"#6b7280"},"logo_position":"none"}', false, null),
('Factura en Blanco', '{"layout":"blank","fields":[],"colors":{"primary":"#374151","secondary":"#9ca3af"},"editable":true}', false, null);

-- Create function to handle trial period
CREATE OR REPLACE FUNCTION public.calculate_trial_status()
RETURNS TRIGGER AS $$
BEGIN
  -- If this is a new subscription and no trial has been set
  IF NEW.trial_start IS NULL AND NEW.subscribed = false AND OLD.trial_start IS NULL THEN
    NEW.trial_start = now();
    NEW.trial_end = now() + INTERVAL '3 days';
  END IF;
  
  -- Update timestamp
  NEW.updated_at = now();
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for trial calculation
CREATE TRIGGER calculate_trial_trigger
  BEFORE UPDATE ON public.subscribers
  FOR EACH ROW
  EXECUTE FUNCTION public.calculate_trial_status();

-- Create function to check if user has access (trial or subscription)
CREATE OR REPLACE FUNCTION public.user_has_access(user_email TEXT)
RETURNS BOOLEAN AS $$
DECLARE
  subscriber_record public.subscribers%ROWTYPE;
BEGIN
  SELECT * INTO subscriber_record 
  FROM public.subscribers 
  WHERE email = user_email;
  
  -- If no record exists, no access
  IF NOT FOUND THEN
    RETURN FALSE;
  END IF;
  
  -- If lifetime free user
  IF subscriber_record.is_lifetime_free = true THEN
    RETURN TRUE;
  END IF;
  
  -- If subscribed
  IF subscriber_record.subscribed = true THEN
    RETURN TRUE;
  END IF;
  
  -- If in trial period
  IF subscriber_record.trial_start IS NOT NULL 
     AND subscriber_record.trial_end IS NOT NULL 
     AND now() BETWEEN subscriber_record.trial_start AND subscriber_record.trial_end THEN
    RETURN TRUE;
  END IF;
  
  RETURN FALSE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Update existing subscribers to have trial if they're not subscribed
UPDATE public.subscribers 
SET trial_start = created_at,
    trial_end = created_at + INTERVAL '3 days'
WHERE subscribed = false 
  AND trial_start IS NULL 
  AND is_lifetime_free = false;