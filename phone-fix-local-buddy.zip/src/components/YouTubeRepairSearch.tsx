import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import { 
  Search, 
  Play, 
  ExternalLink, 
  Clock,
  Eye,
  ThumbsUp,
  Wrench,
  Smartphone,
  Monitor,
  BookOpen,
  Youtube,
  Filter,
  Sparkles,
  TrendingUp
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface RepairVideo {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  duration: string;
  viewCount: string;
  likeCount: string;
  channelTitle: string;
  publishedAt: string;
  videoId: string;
  url: string;
}

interface Orden {
  id: string;
  dispositivo: string;
  marca: string;
  modelo: string;
  problema: string;
  estado: string;
}

export default function YouTubeRepairSearch() {
  const [ordenes] = useLocalStorage<Orden[]>("ordenes", []);
  const [searchTerm, setSearchTerm] = useState("");
  const [videos, setVideos] = useState<RepairVideo[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedProblem, setSelectedProblem] = useState<string>("");
  const { toast } = useToast();

  // Obtener problemas únicos de las órdenes
  const problemasComunes = ordenes.reduce((acc, orden) => {
    if (orden.problema && !acc.includes(orden.problema)) {
      acc.push(orden.problema);
    }
    return acc;
  }, [] as string[]);

  // Función para buscar videos en YouTube
  const buscarVideos = async (termino: string) => {
    setLoading(true);
    try {
      // Construir término de búsqueda optimizado
      const terminoBusqueda = `${termino} reparación repair tutorial como arreglar`;
      
      // Simulación de datos (en producción se usaría la API de YouTube)
      // Por ahora crearemos URLs directas de búsqueda
      const videosSimulados: RepairVideo[] = [
        {
          id: "1",
          title: `Cómo reparar ${termino} - Tutorial completo`,
          description: `Guía paso a paso para reparar problemas de ${termino}. Incluye herramientas necesarias y tips profesionales.`,
          thumbnail: "https://img.youtube.com/vi/dQw4w9WgXcQ/mqdefault.jpg",
          duration: "12:34",
          viewCount: "125K",
          likeCount: "3.2K",
          channelTitle: "TechRepair Pro",
          publishedAt: "2024-01-15",
          videoId: "dQw4w9WgXcQ",
          url: `https://www.youtube.com/results?search_query=${encodeURIComponent(terminoBusqueda)}`
        },
        {
          id: "2",
          title: `${termino} no funciona - Solución rápida`,
          description: `Método rápido y efectivo para solucionar problemas comunes de ${termino}.`,
          thumbnail: "https://img.youtube.com/vi/dQw4w9WgXcQ/mqdefault.jpg",
          duration: "8:45",
          viewCount: "89K",
          likeCount: "2.1K",
          channelTitle: "Repair Masters",
          publishedAt: "2024-01-10",
          videoId: "dQw4w9WgXcQ2",
          url: `https://www.youtube.com/results?search_query=${encodeURIComponent(terminoBusqueda + " " + "solución rápida")}`
        },
        {
          id: "3",
          title: `Tutorial profesional: ${termino} paso a paso`,
          description: `Tutorial detallado para técnicos. Herramientas profesionales y técnicas avanzadas.`,
          thumbnail: "https://img.youtube.com/vi/dQw4w9WgXcQ/mqdefault.jpg",
          duration: "18:22",
          viewCount: "67K",
          likeCount: "1.8K",
          channelTitle: "ProTech Solutions",
          publishedAt: "2024-01-05",
          videoId: "dQw4w9WgXcQ3",
          url: `https://www.youtube.com/results?search_query=${encodeURIComponent(terminoBusqueda + " " + "tutorial profesional")}`
        }
      ];

      setVideos(videosSimulados);
      toast({
        title: "Búsqueda completada",
        description: `Se encontraron ${videosSimulados.length} videos relacionados con "${termino}"`,
        variant: "default",
      });
    } catch (error) {
      toast({
        title: "Error en la búsqueda",
        description: "No se pudieron cargar los videos. Inténtalo de nuevo.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = () => {
    if (!searchTerm.trim()) {
      toast({
        title: "Término requerido",
        description: "Por favor ingresa un problema para buscar soluciones.",
        variant: "destructive",
      });
      return;
    }
    buscarVideos(searchTerm);
  };

  const seleccionarProblema = (problema: string) => {
    setSelectedProblem(problema);
    setSearchTerm(problema);
    buscarVideos(problema);
  };

  const abrirVideo = (url: string) => {
    window.open(url, '_blank');
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-3">
          <div className="p-3 bg-red-100 rounded-full">
            <Youtube className="h-8 w-8 text-red-600" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900">Búsqueda de Videos de Reparación</h1>
        </div>
        <p className="text-gray-600 max-w-2xl mx-auto">
          Encuentra videos tutoriales en YouTube para solucionar problemas de reparación. 
          Usa problemas de tus órdenes existentes o busca cualquier término específico.
        </p>
      </div>

      {/* Búsqueda manual */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="h-5 w-5" />
            Búsqueda Manual
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <Input
              placeholder="Ej: pantalla rota iPhone 12, batería no carga Samsung..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              className="flex-1"
            />
            <Button onClick={handleSearch} disabled={loading}>
              {loading ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Buscando
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Search className="h-4 w-4" />
                  Buscar
                </div>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Problemas comunes de órdenes */}
      {problemasComunes.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5" />
              Problemas de tus Órdenes de Trabajo
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {problemasComunes.slice(0, 12).map((problema, index) => (
                <Button
                  key={index}
                  variant={selectedProblem === problema ? "default" : "outline"}
                  className="text-left justify-start h-auto p-3"
                  onClick={() => seleccionarProblema(problema)}
                >
                  <div className="flex items-center gap-2">
                    <Wrench className="h-4 w-4 flex-shrink-0" />
                    <span className="truncate">{problema}</span>
                  </div>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Resultados de videos */}
      {videos.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Play className="h-5 w-5" />
              Videos Encontrados ({videos.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {videos.map((video) => (
                <Card key={video.id} className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer">
                  <div className="relative">
                    <img 
                      src={video.thumbnail} 
                      alt={video.title}
                      className="w-full h-48 object-cover"
                    />
                    <div className="absolute bottom-2 right-2 bg-black/80 text-white px-2 py-1 rounded text-xs">
                      {video.duration}
                    </div>
                    <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                      <Button 
                        size="sm" 
                        className="bg-red-600 hover:bg-red-700"
                        onClick={() => abrirVideo(video.url)}
                      >
                        <Play className="h-4 w-4 mr-2" />
                        Ver en YouTube
                      </Button>
                    </div>
                  </div>
                  
                  <CardContent className="p-4">
                    <h3 className="font-semibold text-sm mb-2 line-clamp-2">{video.title}</h3>
                    <p className="text-gray-600 text-xs mb-3 line-clamp-2">{video.description}</p>
                    
                    <div className="space-y-2">
                      <div className="flex items-center gap-4 text-xs text-gray-500">
                        <div className="flex items-center gap-1">
                          <Eye className="h-3 w-3" />
                          {video.viewCount}
                        </div>
                        <div className="flex items-center gap-1">
                          <ThumbsUp className="h-3 w-3" />
                          {video.likeCount}
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Badge variant="secondary" className="text-xs">
                          {video.channelTitle}
                        </Badge>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => abrirVideo(video.url)}
                          className="h-7 px-2 text-xs"
                        >
                          <ExternalLink className="h-3 w-3 mr-1" />
                          Abrir
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Estado vacío */}
      {videos.length === 0 && !loading && (
        <Card>
          <CardContent className="text-center py-12">
            <div className="space-y-4">
              <div className="p-4 bg-gray-100 rounded-full w-fit mx-auto">
                <BookOpen className="h-8 w-8 text-gray-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900">¡Busca videos de reparación!</h3>
              <p className="text-gray-600 max-w-md mx-auto">
                Ingresa un problema específico o selecciona uno de tus órdenes de trabajo 
                para encontrar tutoriales en YouTube que te ayuden con la reparación.
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Consejos de búsqueda */}
      <Card className="bg-blue-50 border-blue-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-blue-800">
            <TrendingUp className="h-5 w-5" />
            Consejos para Búsquedas Efectivas
          </CardTitle>
        </CardHeader>
        <CardContent className="text-blue-700">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <h4 className="font-semibold mb-2">Términos Específicos:</h4>
              <ul className="space-y-1">
                <li>• Incluye marca y modelo del dispositivo</li>
                <li>• Describe el problema exacto</li>
                <li>• Usa términos técnicos cuando sea posible</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Ejemplos de Búsquedas:</h4>
              <ul className="space-y-1">
                <li>• "iPhone 13 pantalla no responde"</li>
                <li>• "Samsung Galaxy batería se agota rápido"</li>
                <li>• "Xiaomi Redmi altavoz no funciona"</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
