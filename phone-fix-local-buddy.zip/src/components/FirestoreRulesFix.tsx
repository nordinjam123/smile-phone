import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Copy, ExternalLink, AlertTriangle, RefreshCw } from 'lucide-react';
import { centralizedFirebaseService } from '@/lib/centralizedFirebaseService';

const FirestoreRulesFix: React.FC = () => {
  const [copied, setCopied] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<string | null>(null);

  // Reglas que cubren TODAS las colecciones que están fallando
  const basicRules = `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // PERMITIR TODO A USUARIOS AUTENTICADOS
    match /{document=**} {
      allow read, write: if request.auth != null;
    }

    // ESPECÍFICAMENTE para las colecciones que están fallando:
    match /inventario_mercancia/{document} {
      allow read, write: if request.auth != null;
    }
    match /productos_mercancia/{document} {
      allow read, write: if request.auth != null;
    }
    match /gastos_mercancia/{document} {
      allow read, write: if request.auth != null;
    }
    match /clientes/{document} {
      allow read, write: if request.auth != null;
    }
    match /inventario/{document} {
      allow read, write: if request.auth != null;
    }
    match /ordenes_trabajo/{document} {
      allow read, write: if request.auth != null;
    }
    match /facturas/{document} {
      allow read, write: if request.auth != null;
    }
    match /citas/{document} {
      allow read, write: if request.auth != null;
    }
  }
}`;

  const copyRules = async () => {
    try {
      await navigator.clipboard.writeText(basicRules);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Error copying:', err);
    }
  };

  const testConnection = async () => {
    setTesting(true);
    setTestResult(null);

    try {
      const result = await centralizedFirebaseService.testConnection();
      if (result.success) {
        setTestResult('✅ ¡Conexión exitosa! Las reglas funcionan correctamente.');
        setTimeout(() => {
          window.location.reload();
        }, 2000);
      } else {
        setTestResult('❌ Aún hay problemas de permisos. Verifica que publicaste las reglas.');
      }
    } catch (error) {
      setTestResult('❌ Error de conexión. Verifica las reglas en Firebase Console.');
    } finally {
      setTesting(false);
    }
  };

  return (
    <Card className="border-red-200 bg-red-50">
      <CardHeader>
        <CardTitle className="text-red-800 flex items-center gap-2">
          <AlertTriangle className="h-5 w-5" />
          🚨 ERROR: Permisos Firestore Bloqueando el Sistema
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert className="border-yellow-200 bg-yellow-50">
          <AlertTriangle className="h-4 w-4 text-yellow-600" />
          <AlertDescription className="text-yellow-800">
            <strong>ERRORES DETECTADOS:</strong>
            <ul className="list-disc list-inside mt-2 text-sm">
              <li>❌ "Missing or insufficient permissions"</li>
              <li>❌ Error loading inventario_mercancia</li>
              <li>❌ Error loading productos_mercancia</li>
              <li>❌ Error loading gastos_mercancia</li>
            </ul>
            <p className="mt-2"><strong>CAUSA:</strong> Las reglas de Firestore tienen "if false" bloqueando todo acceso.</p>
          </AlertDescription>
        </Alert>

        <div className="space-y-3">
          <h4 className="font-semibold text-red-800">📋 Pasos para solucionar (2 minutos):</h4>
          <ol className="list-decimal list-inside space-y-2 text-sm">
            <li>Copia las reglas de abajo (botón "Copiar Reglas")</li>
            <li>Ve a Firebase Console → Firestore Database → Rules</li>
            <li>Reemplaza TODO el contenido con las reglas copiadas</li>
            <li>Click "Publish"</li>
            <li>Espera 30 segundos y refresca esta página</li>
          </ol>
        </div>

        <div className="bg-white p-4 rounded border">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium">Reglas temporales (funcionales):</span>
            <Button 
              size="sm" 
              variant="outline"
              onClick={copyRules}
              className="flex items-center gap-2"
            >
              <Copy className="h-4 w-4" />
              {copied ? '✅ Copiado' : 'Copiar Reglas'}
            </Button>
          </div>
          <div className="bg-gray-100 p-3 rounded text-xs font-mono">
            <pre className="whitespace-pre-wrap">{basicRules}</pre>
          </div>
        </div>

        <div className="flex gap-2 flex-wrap">
          <Button
            className="flex items-center gap-2"
            onClick={() => window.open('https://console.firebase.google.com/project/mitaller-91992/firestore/rules', '_blank')}
          >
            <ExternalLink className="h-4 w-4" />
            Abrir Reglas Firestore
          </Button>

          <Button
            variant="outline"
            onClick={testConnection}
            disabled={testing}
            className="flex items-center gap-2"
          >
            <RefreshCw className={`h-4 w-4 ${testing ? 'animate-spin' : ''}`} />
            {testing ? 'Probando...' : 'Probar Conexión'}
          </Button>
        </div>

        {testResult && (
          <Alert className={testResult.includes('✅') ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'}>
            <AlertDescription className={testResult.includes('✅') ? 'text-green-800' : 'text-red-800'}>
              {testResult}
            </AlertDescription>
          </Alert>
        )}

        <div className="text-xs text-gray-600 bg-blue-50 p-3 rounded">
          <strong>Nota:</strong> Estas reglas permiten acceso completo a usuarios autenticados. 
          Una vez que funcione el sistema, podrás configurar reglas más específicas si lo deseas.
        </div>
      </CardContent>
    </Card>
  );
};

export default FirestoreRulesFix;
