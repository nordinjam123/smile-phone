import EnhancedBalancePage from "./EnhancedBalancePage";

export default function BalanceSelector() {
  return <EnhancedBalancePage />;
}
