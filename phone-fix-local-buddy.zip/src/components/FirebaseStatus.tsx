import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Cloud, 
  CloudOff, 
  Wifi, 
  WifiOff,
  CheckCircle,
  AlertTriangle,
  Database
} from 'lucide-react';
import { useCentralizedAuth } from '@/hooks/useCentralizedAuth';
import { useCentralizedData } from '@/contexts/CentralizedDataContext';
import { centralizedFirebaseService } from '@/lib/centralizedFirebaseService';

const FirebaseStatus: React.FC = () => {
  const { user, isAuthenticated, isReady } = useCentralizedAuth();
  const { isOnline } = useCentralizedData();
  const isFirebaseReady = centralizedFirebaseService.isReady();

  if (!isFirebaseReady) {
    return (
      <Alert className="mb-4 bg-amber-50 border-amber-200">
        <AlertTriangle className="h-4 w-4 text-amber-600" />
        <AlertDescription className="text-amber-800">
          <strong>Sistema no configurado:</strong> Ve a "Configuración" para configurar tu base de datos.
        </AlertDescription>
      </Alert>
    );
  }

  const getStatusColor = () => {
    if (!isOnline) return 'bg-red-100 text-red-800';
    if (!isAuthenticated) return 'bg-amber-100 text-amber-800';
    return 'bg-green-100 text-green-800';
  };

  const getStatusIcon = () => {
    if (!isOnline) return <WifiOff className="h-3 w-3" />;
    if (!isAuthenticated) return <AlertTriangle className="h-3 w-3" />;
    return <CheckCircle className="h-3 w-3" />;
  };

  const getStatusText = () => {
    if (!isOnline) return 'Sin conexión';
    if (!isAuthenticated) return 'No autenticado';
    return 'Sistema conectado';
  };

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <Badge className={`${getStatusColor()} flex items-center gap-2 px-3 py-1 shadow-lg`}>
        <Database className="h-3 w-3" />
        {getStatusIcon()}
        <span className="text-xs font-medium">{getStatusText()}</span>
        {isAuthenticated && user && (
          <span className="text-xs opacity-75">
            | {user.email?.split('@')[0]}
          </span>
        )}
      </Badge>
      
      {isOnline && isAuthenticated && (
        <div className="mt-1 text-right">
          <Badge variant="outline" className="text-xs bg-white/80">
            <Cloud className="h-3 w-3 mr-1" />
            Tiempo real activo
          </Badge>
        </div>
      )}
    </div>
  );
};

export default FirebaseStatus;
