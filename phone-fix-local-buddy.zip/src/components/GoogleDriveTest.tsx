import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Cloud, AlertCircle } from 'lucide-react';
import { useGoogleAuth } from '@/hooks/useGoogleAuth';

const GoogleDriveTest: React.FC = () => {
  const { isGoogleConnected, loading, connectGoogle, disconnectGoogle } = useGoogleAuth();
  const { toast } = useToast();

  const handleConnect = async () => {
    const result = await connectGoogle();
    if (result.success) {
      toast({
        title: "Conectando con Google",
        description: "Serás redirigido para autorizar el acceso...",
      });
    } else {
      toast({
        title: "Error de conexión",
        description: result.error,
        variant: "destructive",
      });
    }
  };

  const handleDisconnect = async () => {
    const result = await disconnectGoogle();
    if (result.success) {
      toast({
        title: "Desconectado",
        description: "Se ha desconectado de Google Drive",
      });
    } else {
      toast({
        title: "Error",
        description: result.error,
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            <span className="ml-2">Verificando conexión...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Cloud className="h-5 w-5" />
          Estado de Google Drive
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            {isGoogleConnected ? (
              <>
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span className="text-green-700 font-medium">Conectado a Google Drive</span>
              </>
            ) : (
              <>
                <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                <span className="text-red-700 font-medium">No conectado</span>
              </>
            )}
          </div>

          {!isGoogleConnected ? (
            <div className="space-y-3">
              <p className="text-sm text-gray-600">
                Conecta tu cuenta de Google para acceder a las funciones de backup en Google Drive.
              </p>
              <Button onClick={handleConnect} className="w-full">
                <Cloud className="h-4 w-4 mr-2" />
                Conectar con Google Drive
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              <p className="text-sm text-green-700">
                ✅ Google Drive está conectado. Puedes crear y restaurar copias de seguridad.
              </p>
              <Button onClick={handleDisconnect} variant="outline" className="w-full">
                Desconectar Google Drive
              </Button>
            </div>
          )}

          <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
            <div className="flex items-start gap-2">
              <AlertCircle className="h-4 w-4 text-yellow-600 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-yellow-700">
                <p className="font-medium">Nota importante:</p>
                <p>Para que la autenticación con Google funcione correctamente, es necesario configurar Google OAuth en Supabase con las credenciales de tu proyecto de Google Cloud Platform.</p>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default GoogleDriveTest;
