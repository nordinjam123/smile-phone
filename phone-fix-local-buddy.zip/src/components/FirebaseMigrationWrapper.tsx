import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Cloud, 
  Database, 
  CheckCircle, 
  Loader2,
  Upload,
  ArrowRight
} from 'lucide-react';
import { centralizedFirebaseService } from '@/lib/centralizedFirebaseService';
import { useCentralizedAuth } from '@/hooks/useCentralizedAuth';
import { useToast } from '@/hooks/use-toast';

interface FirebaseMigrationWrapperProps {
  children: React.ReactNode;
}

const FirebaseMigrationWrapper: React.FC<FirebaseMigrationWrapperProps> = ({ children }) => {
  const { user, isAuthenticated, isReady } = useCentralizedAuth();
  const [migrationStatus, setMigrationStatus] = useState<'checking' | 'needed' | 'migrating' | 'completed' | 'error'>('checking');
  const [migrationProgress, setMigrationProgress] = useState(0);
  const [migratedCount, setMigratedCount] = useState(0);
  const [hasLocalData, setHasLocalData] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (isAuthenticated && isReady) {
      checkMigrationStatus();
    }
  }, [isAuthenticated, isReady]);

  const checkMigrationStatus = () => {
    // Check if there's local data to migrate
    const localKeys = ['clientes', 'inventario', 'ordenes', 'facturas', 'gastos_mercancia', 'citas'];
    const hasData = localKeys.some(key => {
      const data = localStorage.getItem(key);
      return data && JSON.parse(data).length > 0;
    });

    setHasLocalData(hasData);

    // Check if migration was already completed
    const migrationCompleted = localStorage.getItem('firebase_migration_completed');
    
    if (migrationCompleted === 'true') {
      setMigrationStatus('completed');
    } else if (hasData) {
      setMigrationStatus('needed');
    } else {
      setMigrationStatus('completed');
    }
  };

  const startMigration = async () => {
    setMigrationStatus('migrating');
    setMigrationProgress(0);

    try {
      // Simulate migration progress
      const progressInterval = setInterval(() => {
        setMigrationProgress(prev => Math.min(prev + 15, 90));
      }, 300);

      const result = await centralizedFirebaseService.migrateFromLocalStorage();
      
      clearInterval(progressInterval);
      setMigrationProgress(100);
      setMigratedCount(result.migrated);

      if (result.success) {
        // Mark migration as completed
        localStorage.setItem('firebase_migration_completed', 'true');
        setMigrationStatus('completed');
        
        toast({
          title: "🔥 Migración a Firebase Completada",
          description: `${result.migrated} elementos migrados exitosamente`,
        });

        // Optional: Clear localStorage after successful migration
        setTimeout(() => {
          if (confirm('¿Quieres limpiar los datos locales ya que están migrados a Firebase?')) {
            const localKeys = ['clientes', 'inventario', 'ordenes', 'facturas', 'gastos_mercancia', 'citas'];
            localKeys.forEach(key => localStorage.removeItem(key));
          }
        }, 2000);
      } else {
        setMigrationStatus('error');
        toast({
          title: "Error en migración",
          description: `${result.migrated} elementos migrados, ${result.errors.length} errores`,
          variant: "destructive",
        });
      }
    } catch (error: any) {
      setMigrationStatus('error');
      toast({
        title: "Error en migración",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const skipMigration = () => {
    localStorage.setItem('firebase_migration_completed', 'true');
    setMigrationStatus('completed');
  };

  // Show children if migration is completed or not needed
  if (migrationStatus === 'completed' || migrationStatus === 'checking') {
    return <>{children}</>;
  }

  // Show migration UI
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-orange-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl border-2 border-blue-200 shadow-xl">
        <CardHeader className="text-center pb-4">
          <div className="flex justify-center mb-4">
            <div className="p-4 bg-gradient-to-br from-blue-500 to-orange-500 rounded-xl">
              <Cloud className="h-12 w-12 text-white" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold text-gray-900">
            🔥 Migración a Firebase
          </CardTitle>
          <CardDescription className="text-lg">
            Sincroniza todos tus datos con Firebase para mejor rendimiento y seguridad
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          {migrationStatus === 'needed' && (
            <>
              <Alert className="bg-blue-50 border-blue-200">
                <Database className="h-4 w-4 text-blue-600" />
                <AlertDescription className="text-blue-800">
                  <strong>Datos locales detectados:</strong> Tienes información almacenada localmente que puede migrarse a Firebase para mejor sincronización y seguridad.
                </AlertDescription>
              </Alert>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                  <h4 className="font-medium text-green-900 mb-2">✅ Después de la migración:</h4>
                  <ul className="text-sm text-green-800 space-y-1">
                    <li>• Sincronización en tiempo real</li>
                    <li>• Acceso desde cualquier dispositivo</li>
                    <li>• Backup automático</li>
                    <li>• Mayor seguridad</li>
                  </ul>
                </div>
                
                <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                  <h4 className="font-medium text-blue-900 mb-2">🔄 Qué se migrará:</h4>
                  <ul className="text-sm text-blue-800 space-y-1">
                    <li>• Clientes y contactos</li>
                    <li>• Inventario y productos</li>
                    <li>• Órdenes de trabajo</li>
                    <li>• Facturas y gastos</li>
                    <li>• Citas programadas</li>
                  </ul>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <Button 
                  onClick={startMigration}
                  size="lg"
                  className="bg-gradient-to-r from-blue-600 to-orange-600 hover:from-blue-700 hover:to-orange-700"
                >
                  <Upload className="h-5 w-5 mr-2" />
                  Migrar a Firebase Ahora
                </Button>
                <Button 
                  onClick={skipMigration}
                  variant="outline"
                  size="lg"
                >
                  Continuar Sin Migrar
                </Button>
              </div>
            </>
          )}

          {migrationStatus === 'migrating' && (
            <div className="space-y-4">
              <div className="text-center">
                <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-blue-600" />
                <h3 className="text-lg font-medium">Migrando datos a Firebase...</h3>
                <p className="text-gray-600">No cierres esta ventana</p>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Progreso de migración</span>
                  <span>{migrationProgress}%</span>
                </div>
                <Progress value={migrationProgress} className="h-3" />
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-center gap-2 text-sm text-gray-700">
                  <Database className="h-4 w-4" />
                  <span>Transfiriendo datos de forma segura...</span>
                </div>
              </div>
            </div>
          )}

          {migrationStatus === 'error' && (
            <div className="space-y-4">
              <Alert variant="destructive">
                <AlertDescription>
                  Hubo un problema durante la migración. Puedes intentar de nuevo o continuar sin migrar.
                </AlertDescription>
              </Alert>

              <div className="flex gap-3 justify-center">
                <Button onClick={startMigration} variant="outline">
                  Intentar de Nuevo
                </Button>
                <Button onClick={skipMigration}>
                  Continuar Igualmente
                </Button>
              </div>
            </div>
          )}

          {migrationStatus === 'completed' && migratedCount > 0 && (
            <div className="space-y-4">
              <div className="text-center">
                <CheckCircle className="h-12 w-12 text-green-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-green-900">¡Migración Completada!</h3>
                <p className="text-green-700">{migratedCount} elementos migrados a Firebase</p>
              </div>

              <Button 
                onClick={() => setMigrationStatus('completed')}
                className="w-full"
                size="lg"
              >
                <ArrowRight className="h-5 w-5 mr-2" />
                Continuar a TallerPro
              </Button>
            </div>
          )}

          <div className="text-center text-xs text-gray-500">
            Powered by Firebase & Google Cloud
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default FirebaseMigrationWrapper;
