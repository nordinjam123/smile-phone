// Utilidades para WhatsApp Web (Versión simplificada sin servidor)
export interface WhatsAppData {
  cliente?: string;
  telefono?: string;
  ordenId?: string;
  dispositivo?: string;
  marca?: string;
  modelo?: string;
  problema?: string;
  precio?: string;
  numeroFactura?: string;
  total?: string;
  estado?: string;
  empresa?: string;
  direccion?: string;
  telefono_empresa?: string;
  fecha?: string;
  dias?: string;
}

export function replaceMessageVariables(template: string, data: WhatsAppData): string {
  let message = template;
  
  // Reemplazar todas las variables
  Object.entries(data).forEach(([key, value]) => {
    const regex = new RegExp(`{{${key}}}`, 'g');
    message = message.replace(regex, value || '');
  });
  
  // Limpiar variables no reemplazadas
  message = message.replace(/{{[^}]+}}/g, '');
  
  return message;
}

export function formatPhoneNumber(phone: string): string {
  // Limpiar el número
  let cleaned = phone.replace(/\D/g, '');
  
  // Si no empieza con código de país, añadir España (+34)
  if (!cleaned.startsWith('34') && cleaned.length === 9) {
    cleaned = '34' + cleaned;
  }
  
  return cleaned;
}

export function validatePhoneNumber(phone: string): boolean {
  const cleaned = phone.replace(/\D/g, '');
  return cleaned.length >= 9 && cleaned.length <= 15;
}

// Obtener configuración de la empresa
function getEmpresaInfo() {
  try {
    const empresaConfig = localStorage.getItem('empresa_config');
    if (empresaConfig) {
      const config = JSON.parse(empresaConfig);
      return {
        nombre: config.nombre || 'Tu Empresa',
        telefono: config.telefono || '123456789',
        direccion: config.direccion || 'Tu dirección aquí',
        email: config.email || 'info@tuempresa.com'
      };
    }
  } catch (error) {
    console.error('Error cargando configuración de empresa:', error);
  }
  
  return {
    nombre: 'Tu Empresa',
    telefono: '123456789',
    direccion: 'Tu dirección aquí',
    email: 'info@tuempresa.com'
  };
}

// Importar el nuevo gestor que prioriza WhatsApp Desktop
import { sendWhatsAppMessageDesktopFirst, getAvailableWhatsAppMethods } from './whatsappDesktopManager';
import { checkWhatsAppAvailability } from './whatsappSessionManager';

// Función principal que prioriza WhatsApp Desktop sobre Web
async function sendWhatsAppWebMessage(phoneNumber: string, message: string): Promise<boolean> {
  try {
    console.log(`📱 Enviando mensaje a ${phoneNumber}`);

    // Usar el nuevo sistema que prioriza Desktop
    const result = await sendWhatsAppMessageDesktopFirst(phoneNumber, message);

    if (result.success) {
      // Mostrar mensaje según el método usado
      switch (result.method) {
        case 'desktop':
          console.log(`🖥️ WhatsApp Desktop abierto para ${phoneNumber}`);
          showSuccessNotification('🖥️ WhatsApp Desktop', 'Mensaje enviado via aplicación desktop');
          break;
        case 'web':
          console.log(`🌍 WhatsApp Web abierto para ${phoneNumber}`);
          showSuccessNotification('🌍 WhatsApp Web', result.fallbackUsed ? 'Desktop no disponible, usando Web' : 'Mensaje enviado via web');
          break;
        case 'mobile':
          console.log(`📱 WhatsApp móvil abierto para ${phoneNumber}`);
          showSuccessNotification('📱 WhatsApp Móvil', 'Desktop y Web no disponibles, usando móvil');
          break;
        case 'clipboard':
          console.log(`📋 Mensaje copiado al portapapeles para ${phoneNumber}`);
          // La notificación ya se muestra en el manager
          break;
      }
      return true;
    } else {
      console.error('Error enviando mensaje WhatsApp:', result.error);
      showErrorNotification('Error enviando mensaje', result.error || 'Error desconocido');
      return false;
    }
  } catch (error) {
    console.error('Error en sendWhatsAppWebMessage:', error);
    showErrorNotification('Error inesperado', 'No se pudo enviar el mensaje');
    return false;
  }
}

// Función para mostrar notificaciones de éxito
function showSuccessNotification(title: string, message: string): void {
  if (typeof window !== 'undefined') {
    const notification = document.createElement('div');
    notification.innerHTML = `
      <div style="
        position: fixed;
        top: 20px;
        right: 20px;
        background: #10b981;
        color: white;
        padding: 16px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 9999;
        font-family: system-ui, -apple-system, sans-serif;
        font-size: 14px;
        max-width: 300px;
      ">
        <div style="font-weight: 600; margin-bottom: 4px;">${title}</div>
        <div style="font-size: 12px; opacity: 0.9;">${message}</div>
      </div>
    `;
    document.body.appendChild(notification);
    setTimeout(() => {
      if (notification.parentNode) {
        notification.parentNode.removeChild(notification);
      }
    }, 4000);
  }
}

// Función para mostrar notificaciones de error
function showErrorNotification(title: string, message: string): void {
  if (typeof window !== 'undefined') {
    const notification = document.createElement('div');
    notification.innerHTML = `
      <div style="
        position: fixed;
        top: 20px;
        right: 20px;
        background: #ef4444;
        color: white;
        padding: 16px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 9999;
        font-family: system-ui, -apple-system, sans-serif;
        font-size: 14px;
        max-width: 300px;
      ">
        <div style="font-weight: 600; margin-bottom: 4px;">${title}</div>
        <div style="font-size: 12px; opacity: 0.9;">${message}</div>
      </div>
    `;
    document.body.appendChild(notification);
    setTimeout(() => {
      if (notification.parentNode) {
        notification.parentNode.removeChild(notification);
      }
    }, 5000);
  }
}

// Enviar mensaje de orden recibida
export async function sendOrderReceivedMessage(orderData: {
  cliente: string;
  telefono: string;
  id: string;
  dispositivo: string;
  marca: string;
  modelo: string;
  descripcionProblema: string;
  fechaRecepcion: string;
}): Promise<boolean> {
  try {
    const config = getWhatsAppConfig();
    if (!config.enabled || !config.templates.orderReceived.enabled) {
      console.log('WhatsApp no está habilitado o plantilla desactivada');
      return false;
    }

    const empresaInfo = getEmpresaInfo();
    const messageData: WhatsAppData = {
      cliente: orderData.cliente,
      telefono: orderData.telefono,
      ordenId: orderData.id,
      dispositivo: orderData.dispositivo,
      marca: orderData.marca,
      modelo: orderData.modelo,
      problema: orderData.descripcionProblema,
      fecha: new Date(orderData.fechaRecepcion).toLocaleDateString('es-ES'),
      empresa: empresaInfo.nombre,
      telefono_empresa: empresaInfo.telefono,
      direccion: empresaInfo.direccion
    };

    const message = replaceMessageVariables(config.templates.orderReceived.message, messageData);
    return await sendWhatsAppWebMessage(orderData.telefono, message);
  } catch (error) {
    console.error('Error sending order received message:', error);
    return false;
  }
}

// Enviar mensaje de orden en proceso
export async function sendOrderInProgressMessage(orderData: {
  cliente: string;
  telefono: string;
  id: string;
  dispositivo: string;
  marca: string;
  modelo: string;
}): Promise<boolean> {
  try {
    const config = getWhatsAppConfig();
    if (!config.enabled || !config.templates.orderInProgress?.enabled) {
      console.log('WhatsApp no está habilitado o plantilla En Proceso desactivada');
      return false;
    }

    const empresaInfo = getEmpresaInfo();
    const messageData: WhatsAppData = {
      cliente: orderData.cliente,
      telefono: orderData.telefono,
      ordenId: orderData.id,
      dispositivo: orderData.dispositivo,
      marca: orderData.marca,
      modelo: orderData.modelo,
      empresa: empresaInfo.nombre,
      direccion: empresaInfo.direccion,
      telefono_empresa: empresaInfo.telefono,
      fecha: new Date().toLocaleDateString('es-ES')
    };

    const message = replaceMessageVariables(config.templates.orderInProgress.message, messageData);
    return await sendWhatsAppWebMessage(orderData.telefono, message);
  } catch (error) {
    console.error('Error sending order in progress message:', error);
    return false;
  }
}

// Enviar mensaje de orden completada
export async function sendOrderCompletedMessage(orderData: {
  cliente: string;
  telefono: string;
  id: string;
  dispositivo: string;
  marca: string;
  modelo: string;
  precio?: number;
}): Promise<boolean> {
  try {
    const config = getWhatsAppConfig();
    if (!config.enabled || !config.templates.orderCompleted.enabled) {
      console.log('WhatsApp no está habilitado o plantilla desactivada');
      return false;
    }

    const empresaInfo = getEmpresaInfo();
    const messageData: WhatsAppData = {
      cliente: orderData.cliente,
      telefono: orderData.telefono,
      ordenId: orderData.id,
      dispositivo: orderData.dispositivo,
      marca: orderData.marca,
      modelo: orderData.modelo,
      precio: orderData.precio ? orderData.precio.toFixed(2) : '0.00',
      empresa: empresaInfo.nombre,
      direccion: empresaInfo.direccion,
      telefono_empresa: empresaInfo.telefono,
      fecha: new Date().toLocaleDateString('es-ES')
    };

    const message = replaceMessageVariables(config.templates.orderCompleted.message, messageData);
    return await sendWhatsAppWebMessage(orderData.telefono, message);
  } catch (error) {
    console.error('Error sending order completed message:', error);
    return false;
  }
}

// Enviar mensaje de orden entregada
export async function sendOrderDeliveredMessage(orderData: {
  cliente: string;
  telefono: string;
  id: string;
  dispositivo: string;
  marca: string;
  modelo: string;
}): Promise<boolean> {
  try {
    const config = getWhatsAppConfig();
    if (!config.enabled || !config.templates.orderDelivered?.enabled) {
      console.log('WhatsApp no está habilitado o plantilla Entregado desactivada');
      return false;
    }

    const empresaInfo = getEmpresaInfo();
    const messageData: WhatsAppData = {
      cliente: orderData.cliente,
      telefono: orderData.telefono,
      ordenId: orderData.id,
      dispositivo: orderData.dispositivo,
      marca: orderData.marca,
      modelo: orderData.modelo,
      empresa: empresaInfo.nombre,
      direccion: empresaInfo.direccion,
      telefono_empresa: empresaInfo.telefono,
      fecha: new Date().toLocaleDateString('es-ES')
    };

    const message = replaceMessageVariables(config.templates.orderDelivered.message, messageData);
    return await sendWhatsAppWebMessage(orderData.telefono, message);
  } catch (error) {
    console.error('Error sending order delivered message:', error);
    return false;
  }
}

// Enviar mensaje de factura creada
export async function sendInvoiceCreatedMessage(invoiceData: {
  cliente_nombre: string;
  cliente_telefono: string;
  numero: string;
  total: number;
  fecha: string;
  estado: string;
}): Promise<boolean> {
  try {
    const config = getWhatsAppConfig();
    if (!config.enabled || !config.templates.invoiceCreated.enabled) {
      console.log('WhatsApp no está habilitado o plantilla desactivada');
      return false;
    }

    const empresaInfo = getEmpresaInfo();
    const messageData: WhatsAppData = {
      cliente: invoiceData.cliente_nombre,
      telefono: invoiceData.cliente_telefono,
      numeroFactura: invoiceData.numero,
      total: invoiceData.total.toFixed(2),
      estado: invoiceData.estado,
      fecha: new Date(invoiceData.fecha).toLocaleDateString('es-ES'),
      empresa: empresaInfo.nombre,
      telefono_empresa: empresaInfo.telefono
    };

    const message = replaceMessageVariables(config.templates.invoiceCreated.message, messageData);
    return await sendWhatsAppWebMessage(invoiceData.cliente_telefono, message);
  } catch (error) {
    console.error('Error sending invoice created message:', error);
    return false;
  }
}

// Enviar recordatorio
export async function sendReminderMessage(orderData: {
  cliente: string;
  telefono: string;
  id: string;
  dispositivo: string;
  fechaRecepcion: string;
}): Promise<boolean> {
  try {
    const config = getWhatsAppConfig();
    if (!config.enabled || !config.templates.reminder.enabled) {
      console.log('WhatsApp no está habilitado o plantilla desactivada');
      return false;
    }

    const fechaRecepcion = new Date(orderData.fechaRecepcion);
    const hoy = new Date();
    const diasTranscurridos = Math.floor((hoy.getTime() - fechaRecepcion.getTime()) / (1000 * 60 * 60 * 24));

    const empresaInfo = getEmpresaInfo();
    const messageData: WhatsAppData = {
      cliente: orderData.cliente,
      telefono: orderData.telefono,
      ordenId: orderData.id,
      dispositivo: orderData.dispositivo,
      dias: diasTranscurridos.toString(),
      empresa: empresaInfo.nombre,
      direccion: empresaInfo.direccion,
      telefono_empresa: empresaInfo.telefono
    };

    const message = replaceMessageVariables(config.templates.reminder.message, messageData);
    return await sendWhatsAppWebMessage(orderData.telefono, message);
  } catch (error) {
    console.error('Error sending reminder message:', error);
    return false;
  }
}

// Función para enviar mensaje de prueba
export async function sendTestMessage(): Promise<boolean> {
  try {
    const testMessage = `🧪 Mensaje de prueba\n\n✅ El sistema WhatsApp está funcionando correctamente.\n\n🖥️ Desktop → 🌍 Web → 📱 Móvil\n\nFecha: ${new Date().toLocaleString('es-ES')}`;

    // Usar el nuevo sistema de prioridad
    const result = await sendWhatsAppMessageDesktopFirst('', testMessage);

    if (result.success) {
      console.log(`✅ Test exitoso usando: ${result.method}`);
      return true;
    } else {
      console.error('❌ Test fallido:', result.error);
      return false;
    }
  } catch (error) {
    console.error('Error enviando mensaje de prueba:', error);
    return false;
  }
}

// Función para enviar mensaje personalizado
export async function sendCustomMessage(phoneNumber: string, message: string): Promise<boolean> {
  return await sendWhatsAppWebMessage(phoneNumber, message);
}

// Importar la función de auto-configuración
import { getWhatsAppConfigWithAutoSetup } from './whatsappAutoConfig';

// Función para obtener configuración con auto-configuración
function getWhatsAppConfig() {
  return getWhatsAppConfigWithAutoSetup();
}

// Función para verificar si WhatsApp está habilitado (siempre true con auto-config)
export function isWhatsAppEnabled(): boolean {
  const config = getWhatsAppConfig();
  return config.enabled === true;
}

// Función para obtener plantilla específica
export function getTemplate(templateName: string): { enabled: boolean; message: string } | null {
  const config = getWhatsAppConfig();
  if (config.templates && config.templates[templateName]) {
    return config.templates[templateName];
  }
  return null;
}
