import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import QRCode from "qrcode";
import QRReader from "./QRReader";

export default function QRTest() {
  const [qrImage, setQrImage] = useState<string>("");
  const [isReaderOpen, setIsReaderOpen] = useState(false);
  const [scannedResult, setScannedResult] = useState<any>(null);

  const generateTestQR = async () => {
    try {
      const testData = {
        id: "TEST-123",
        tipo: "TEST",
        mensaje: "Hola desde QR Test",
        fecha: new Date().toISOString()
      };

      const qrCodeDataURL = await QRCode.toDataURL(JSON.stringify(testData), {
        width: 200,
        margin: 2,
        color: {
          dark: '#000000',
          light: '#FFFFFF'
        },
        errorCorrectionLevel: 'M'
      });

      setQrImage(qrCodeDataURL);
    } catch (error) {
      console.error('Error generando QR de prueba:', error);
    }
  };

  const handleScan = (data: any) => {
    setScannedResult(data);
    // NO cerrar automáticamente - dejar que el usuario vea el resultado
  };

  return (
    <div className="p-6 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Test de QR - Generación y Escaneo</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-4">
            <Button onClick={generateTestQR}>
              Generar QR de Prueba
            </Button>
            <Button onClick={() => setIsReaderOpen(true)}>
              Escanear QR
            </Button>
          </div>

          {qrImage && (
            <div className="text-center">
              <p className="mb-2">QR Generado:</p>
              <img src={qrImage} alt="QR Test" className="mx-auto border" />
            </div>
          )}

          {scannedResult && (
            <div className="bg-green-50 p-4 rounded-lg">
              <h4 className="font-semibold text-green-800 mb-2">
                Resultado del Escaneo:
              </h4>
              <pre className="text-sm bg-white p-2 rounded border">
                {JSON.stringify(scannedResult, null, 2)}
              </pre>
            </div>
          )}
        </CardContent>
      </Card>

      <QRReader
        isOpen={isReaderOpen}
        onClose={() => setIsReaderOpen(false)}
        onScan={handleScan}
        title="Test de Escaneo QR"
      />
    </div>
  );
}
