-- Crear tabla para gastos en mercancía
CREATE TABLE IF NOT EXISTS gastos_mercancia (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  tipo_producto TEXT NOT NULL,
  descripcion TEXT,
  proveedor TEXT NOT NULL,
  cantidad INTEGER NOT NULL DEFAULT 1,
  precio_unitario DECIMAL(10,2) NOT NULL DEFAULT 0,
  total DECIMAL(10,2) NOT NULL DEFAULT 0,
  fecha DATE NOT NULL DEFAULT CURRENT_DATE,
  categoria TEXT NOT NULL,
  notas TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL
);

-- Crear índices para mejorar el rendimiento
CREATE INDEX IF NOT EXISTS idx_gastos_mercancia_user_id ON gastos_mercancia(user_id);
CREATE INDEX IF NOT EXISTS idx_gastos_mercancia_fecha ON gastos_mercancia(fecha);
CREATE INDEX IF NOT EXISTS idx_gastos_mercancia_categoria ON gastos_mercancia(categoria);
CREATE INDEX IF NOT EXISTS idx_gastos_mercancia_proveedor ON gastos_mercancia(proveedor);

-- Habilitar RLS (Row Level Security)
ALTER TABLE gastos_mercancia ENABLE ROW LEVEL SECURITY;

-- Crear políticas de seguridad
CREATE POLICY "Users can view their own gastos_mercancia" ON gastos_mercancia
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own gastos_mercancia" ON gastos_mercancia
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own gastos_mercancia" ON gastos_mercancia
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own gastos_mercancia" ON gastos_mercancia
  FOR DELETE USING (auth.uid() = user_id);

-- Trigger para actualizar updated_at automáticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = TIMEZONE('utc'::text, NOW());
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_gastos_mercancia_updated_at 
  BEFORE UPDATE ON gastos_mercancia 
  FOR EACH ROW 
  EXECUTE FUNCTION update_updated_at_column();
