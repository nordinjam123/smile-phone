import { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';

export interface ConfiguracionSeccion {
  textoPersonalizado: string;
  informacionAdicional: string;
  terminos: string;
  mostrarEnTicket: boolean;
}

export interface EmpresaConfig {
  nombreEmpresa: string;
  direccion: string;
  telefono: string;
  email: string;
  cif: string;
  tipoDocumento: 'CIF' | 'NIF';
  terminosTicket: string;
  // Configuraciones específicas por sección
  configuracionTPV: ConfiguracionSeccion;
  configuracionMoviles: ConfiguracionSeccion;
  configuracionFacturas: ConfiguracionSeccion;
  configuracionInventario: ConfiguracionSeccion;
}

const defaultSeccionConfig: ConfiguracionSeccion = {
  textoPersonalizado: "",
  informacionAdicional: "",
  terminos: "",
  mostrarEnTicket: true
};

const defaultConfig: EmpresaConfig = {
  nombreEmpresa: "TECHREPAIR PRO",
  direccion: "",
  telefono: "",
  email: "",
  cif: "",
  tipoDocumento: "CIF",
  terminosTicket: "• El presupuesto es válido por 15 días.\n• Los dispositivos no retirados en 30 días quedan en depósito.\n• No nos hacemos responsables de la pérdida de datos.\n• Se recomienda realizar copia de seguridad antes de la reparación.",
  configuracionTPV: {
    ...defaultSeccionConfig,
    textoPersonalizado: "Terminal Punto de Venta",
    informacionAdicional: "Horario de atención: L-V 9:00-18:00",
    terminos: "• Garantía de 30 días en productos nuevos\n�� No se admiten devoluciones de productos personalizados"
  },
  configuracionMoviles: {
    ...defaultSeccionConfig,
    textoPersonalizado: "Servicio de Reparación de Móviles",
    informacionAdicional: "Diagnóstico gratuito • Presupuesto sin compromiso",
    terminos: "• Garantía de 3 meses en reparaciones\n• 24h para retirar dispositivos reparados"
  },
  configuracionFacturas: {
    ...defaultSeccionConfig,
    textoPersonalizado: "Facturación Electrónica",
    informacionAdicional: "Empresa registrada en AEAT",
    terminos: "• Pago a 30 días\n• Intereses de demora según legislación vigente"
  },
  configuracionInventario: {
    ...defaultSeccionConfig,
    textoPersonalizado: "Gestión de Inventario",
    informacionAdicional: "Stock actualizado en tiempo real",
    terminos: "• Precios sujetos a cambios\n• Consulte disponibilidad"
  }
};

export function useEmpresaConfig() {
  const [config, setConfig] = useState<EmpresaConfig>(defaultConfig);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  // Cargar configuración al inicializar
  useEffect(() => {
    loadConfig();
  }, []);

  const loadConfig = () => {
    try {
      setLoading(true);

      // Cargar desde localStorage únicamente
      const localConfig = localStorage.getItem('configuracion_empresa');
      if (localConfig) {
        try {
          const parsedConfig = JSON.parse(localConfig);
          const mergedConfig = {
            ...defaultConfig,
            ...parsedConfig,
            // Asegurar que las configuraciones de sección existen
            configuracionTPV: { ...defaultConfig.configuracionTPV, ...parsedConfig.configuracionTPV },
            configuracionMoviles: { ...defaultConfig.configuracionMoviles, ...parsedConfig.configuracionMoviles },
            configuracionFacturas: { ...defaultConfig.configuracionFacturas, ...parsedConfig.configuracionFacturas },
            configuracionInventario: { ...defaultConfig.configuracionInventario, ...parsedConfig.configuracionInventario }
          };
          setConfig(mergedConfig);
        } catch (error) {
          console.error('Error parsing local config:', error);
          setConfig(defaultConfig);
        }
      } else {
        // Si no hay configuración, usar valores por defecto
        setConfig(defaultConfig);
      }
    } catch (error) {
      console.error('Error loading empresa config:', error);
      setConfig(defaultConfig);
    } finally {
      setLoading(false);
    }
  };

  const saveConfig = (newConfig: EmpresaConfig) => {
    try {
      setConfig(newConfig);

      // Guardar en localStorage únicamente
      localStorage.setItem('configuracion_empresa', JSON.stringify(newConfig));

      // También actualizar localStorage legacy para compatibilidad
      localStorage.setItem('configuracion', JSON.stringify(newConfig));

      toast({
        title: "Configuración guardada",
        description: "Los datos de la empresa se han actualizado correctamente",
        variant: "default"
      });

      return true;
    } catch (error) {
      console.error('Error saving empresa config:', error);
      toast({
        title: "Error",
        description: "No se pudo guardar la configuración",
        variant: "destructive"
      });
      return false;
    }
  };

  const updateField = (field: keyof EmpresaConfig, value: string) => {
    setConfig(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const resetToDefaults = () => {
    setConfig(defaultConfig);
  };

  return {
    config,
    loading,
    saveConfig,
    updateField,
    resetToDefaults,
    loadConfig
  };
}
