import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { Cloud, Download, Upload, RefreshCw, AlertCircle, CheckCircle } from 'lucide-react';
import { googleDriveService, BackupData } from '@/lib/googleDriveService';
import { supabase } from '@/integrations/supabase/client';

interface GoogleDriveBackupProps {
  isOpen: boolean;
  onClose: () => void;
}

const GoogleDriveBackup: React.FC<GoogleDriveBackupProps> = ({ isOpen, onClose }) => {
  const [isConnected, setIsConnected] = useState(false);
  const [loading, setLoading] = useState(false);
  const [backups, setBackups] = useState<any[]>([]);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    checkGoogleConnection();
  }, []);

  const checkGoogleConnection = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.provider_token) {
        setAccessToken(session.provider_token);
        setIsConnected(true);
        await googleDriveService.initializeGoogleDrive(session.provider_token);
        loadBackups();
      }
    } catch (error) {
      console.error('Error checking Google connection:', error);
    }
  };

  const connectToGoogle = async () => {
    try {
      setLoading(true);
      
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          scopes: 'https://www.googleapis.com/auth/drive.file',
          redirectTo: `${window.location.origin}`,
          queryParams: {
            access_type: 'offline',
            prompt: 'consent',
          }
        }
      });

      if (error) throw error;

      toast({
        title: "Conectando con Google Drive",
        description: "Serás redirigido para autorizar el acceso...",
      });
    } catch (error: any) {
      console.error('Error connecting to Google:', error);
      toast({
        title: "Error de conexión",
        description: error.message || "No se pudo conectar con Google Drive",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const loadBackups = async () => {
    try {
      setLoading(true);
      const result = await googleDriveService.listBackups();
      if (result.success) {
        setBackups(result.files || []);
      } else {
        throw new Error(result.error);
      }
    } catch (error: any) {
      console.error('Error loading backups:', error);
      toast({
        title: "Error",
        description: "No se pudieron cargar las copias de seguridad",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const createBackup = async () => {
    try {
      setLoading(true);
      const result = await googleDriveService.createBackup();
      
      if (result.success) {
        toast({
          title: "✅ Copia de seguridad creada",
          description: "Tus datos han sido respaldados en Google Drive",
        });
        loadBackups(); // Recargar lista
      } else {
        throw new Error(result.error);
      }
    } catch (error: any) {
      console.error('Error creating backup:', error);
      toast({
        title: "Error al crear backup",
        description: error.message || "No se pudo crear la copia de seguridad",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const restoreBackup = async (fileId: string, fileName: string) => {
    try {
      setLoading(true);
      
      // Confirmar acción
      if (!window.confirm(`¿Estás seguro de que quieres restaurar "${fileName}"? Esto sobrescribirá tus datos actuales.`)) {
        return;
      }

      const downloadResult = await googleDriveService.downloadBackup(fileId);
      if (!downloadResult.success || !downloadResult.data) {
        throw new Error(downloadResult.error || 'Error descargando backup');
      }

      const restoreResult = await googleDriveService.restoreBackup(downloadResult.data);
      if (restoreResult.success) {
        toast({
          title: "✅ Datos restaurados",
          description: "Tu copia de seguridad ha sido restaurada exitosamente",
        });
        
        // Recargar la página para mostrar los datos restaurados
        setTimeout(() => {
          window.location.reload();
        }, 2000);
      } else {
        throw new Error(restoreResult.error);
      }
    } catch (error: any) {
      console.error('Error restoring backup:', error);
      toast({
        title: "Error al restaurar",
        description: error.message || "No se pudo restaurar la copia de seguridad",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    try {
      return new Date(dateString).toLocaleDateString('es-ES', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return dateString;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Cloud className="h-5 w-5 text-blue-600" />
            Copias de Seguridad en Google Drive
          </DialogTitle>
          <DialogDescription>
            Crea y gestiona copias de seguridad de todos tus datos en Google Drive
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Estado de conexión */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                {isConnected ? (
                  <CheckCircle className="h-5 w-5 text-green-600" />
                ) : (
                  <AlertCircle className="h-5 w-5 text-orange-600" />
                )}
                Estado de Google Drive
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isConnected ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-green-600 font-medium">✅ Conectado a Google Drive</span>
                    <Button onClick={loadBackups} variant="outline" size="sm" disabled={loading}>
                      <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
                      Actualizar
                    </Button>
                  </div>
                  <Button onClick={createBackup} className="w-full" disabled={loading}>
                    <Upload className="h-4 w-4 mr-2" />
                    {loading ? 'Creando backup...' : 'Crear Nueva Copia de Seguridad'}
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  <p className="text-gray-600">
                    Conecta tu cuenta de Google para acceder a las copias de seguridad en Google Drive
                  </p>
                  <Button onClick={connectToGoogle} className="w-full" disabled={loading}>
                    <Cloud className="h-4 w-4 mr-2" />
                    {loading ? 'Conectando...' : 'Conectar con Google Drive'}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Lista de backups */}
          {isConnected && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Copias de Seguridad Disponibles</CardTitle>
                <CardDescription>
                  Haz clic en "Restaurar" para cargar una copia de seguridad
                </CardDescription>
              </CardHeader>
              <CardContent>
                {backups.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <Cloud className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>No hay copias de seguridad disponibles</p>
                    <p className="text-sm">Crea tu primera copia de seguridad arriba</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {backups.map((backup) => (
                      <div key={backup.id} className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50">
                        <div>
                          <div className="font-medium">{backup.name}</div>
                          <div className="text-sm text-gray-600">
                            {formatDate(backup.createdTime)}
                          </div>
                        </div>
                        <Button
                          onClick={() => restoreBackup(backup.id, backup.name)}
                          variant="outline"
                          size="sm"
                          disabled={loading}
                        >
                          <Download className="h-4 w-4 mr-2" />
                          Restaurar
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Información importante */}
          <Card className="border-orange-200 bg-orange-50">
            <CardContent className="pt-6">
              <div className="flex items-start gap-3">
                <AlertCircle className="h-5 w-5 text-orange-600 mt-0.5 flex-shrink-0" />
                <div className="space-y-2 text-sm">
                  <p className="font-medium text-orange-800">Información importante:</p>
                  <ul className="space-y-1 text-orange-700">
                    <li>• Las copias de seguridad incluyen todos tus datos: talleres, inventario, clientes, etc.</li>
                    <li>• Al restaurar una copia, se sobrescriben los datos actuales</li>
                    <li>• Se recomienda crear copias de seguridad regularmente</li>
                    <li>• Los datos se almacenan de forma segura en tu Google Drive privado</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default GoogleDriveBackup;
