import React, { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Wrench, AlertCircle } from 'lucide-react';
import { z } from 'zod';
import LandingPage from './LandingPage';

// Input validation schemas
const loginSchema = z.object({
  email: z.string().email('Email inválido').min(1, 'Email es requerido'),
  password: z.string().min(6, 'La contraseña debe tener al menos 6 caracteres'),
});

const signupSchema = z.object({
  email: z.string().email('Email inválido').min(1, 'Email es requerido'),
  password: z.string().min(8, 'La contraseña debe tener al menos 8 caracteres')
    .regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/, 'La contraseña debe incluir mayúsculas, minúsculas y números'),
  workshopName: z.string().min(2, 'Nombre del taller debe tener al menos 2 caracteres')
    .max(100, 'Nombre demasiado largo').trim(),
  contactPerson: z.string().min(2, 'Nombre de contacto debe tener al menos 2 caracteres')
    .max(100, 'Nombre demasiado largo').trim(),
});

interface AuthPageProps {
  onAuthSuccess: (user: any) => void;
}

const AuthPage: React.FC<AuthPageProps> = ({ onAuthSuccess }) => {
  const [showAuthForm, setShowAuthForm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [workshopName, setWorkshopName] = useState('');
  const [contactPerson, setContactPerson] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const { toast } = useToast();

  // Sanitize input to prevent XSS
  const sanitizeInput = (input: string): string => {
    return input.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
                .replace(/[<>]/g, '')
                .trim();
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrors({});

    try {
      // Validate input
      const validationResult = loginSchema.safeParse({ email, password });
      if (!validationResult.success) {
        const fieldErrors: Record<string, string> = {};
        validationResult.error.errors.forEach((error) => {
          fieldErrors[error.path[0] as string] = error.message;
        });
        setErrors(fieldErrors);
        return;
      }

      const { data, error } = await supabase.auth.signInWithPassword({
        email: sanitizeInput(email),
        password,
      });

      if (error) throw error;

      if (data.user) {
        onAuthSuccess(data.user);
        toast({
          title: "¡Bienvenido!",
          description: "Has iniciado sesión correctamente.",
        });
      }
    } catch (error: any) {
      console.error('Login error:', {
        error: error,
        message: error?.message || 'Unknown error',
        details: error?.details || 'No details',
        hint: error?.hint || 'No hint',
        code: error?.code || 'No code'
      });

      let errorMessage = "Error al iniciar sesión";

      // Manejar diferentes tipos de errores
      if (error?.name === 'AbortError') {
        errorMessage = "La conexión está tardando demasiado. Verifica tu conexión a internet.";
      } else if (error?.message?.includes('network') || error?.message?.includes('fetch')) {
        errorMessage = "Error de conexión. Verifica tu conexión a internet y vuelve a intentar.";
      } else if (error?.message) {
        errorMessage = error.message;
      }

      setErrors({ general: errorMessage });
      toast({
        title: "Error de autenticación",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrors({});

    try {
      // Validate input
      const validationResult = signupSchema.safeParse({ 
        email, 
        password, 
        workshopName, 
        contactPerson 
      });
      
      if (!validationResult.success) {
        const fieldErrors: Record<string, string> = {};
        validationResult.error.errors.forEach((error) => {
          fieldErrors[error.path[0] as string] = error.message;
        });
        setErrors(fieldErrors);
        return;
      }

      const redirectUrl = `${window.location.origin}/`;
      
      const { data, error } = await supabase.auth.signUp({
        email: sanitizeInput(email),
        password,
        options: {
          emailRedirectTo: redirectUrl,
          data: {
            workshop_name: sanitizeInput(workshopName),
            contact_person: sanitizeInput(contactPerson),
          }
        }
      });

      if (error) throw error;

      if (data.user) {
        toast({
          title: "¡Registro exitoso!",
          description: "Revisa tu email para confirmar tu cuenta.",
        });
      }
    } catch (error: any) {
      console.error('Signup error:', {
        error: error,
        message: error?.message || 'Unknown error',
        details: error?.details || 'No details',
        hint: error?.hint || 'No hint',
        code: error?.code || 'No code'
      });
      const errorMessage = error?.message || "Error al registrarse";
      setErrors({ general: errorMessage });
      toast({
        title: "Error de registro",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };



  // Show landing page by default, auth form when requested
  if (!showAuthForm) {
    return <LandingPage onGetStarted={() => setShowAuthForm(true)} />;
  }

  return (
    <div className="min-h-screen flex">
      {/* Left side - Hero section */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-blue-900 via-blue-800 to-purple-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-blue-900/50 to-transparent"></div>
        
        {/* Animated background elements */}
        <div className="absolute top-20 left-20 w-32 h-32 bg-blue-400/20 rounded-full blur-xl animate-pulse"></div>
        <div className="absolute bottom-40 right-20 w-24 h-24 bg-purple-400/20 rounded-full blur-xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-10 w-16 h-16 bg-cyan-400/20 rounded-full blur-xl animate-pulse delay-500"></div>
        
        <div className="relative z-10 flex flex-col justify-center px-12 text-white">
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-3 bg-white/10 backdrop-blur-sm rounded-xl border border-white/20">
                <Wrench className="h-8 w-8 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold">TallerPro</h1>
                <p className="text-blue-200 text-sm">Gestión Profesional</p>
              </div>
            </div>
            
            <h2 className="text-4xl font-bold mb-4 leading-tight">
              Revoluciona tu taller con tecnología de vanguardia
            </h2>
            <p className="text-xl text-blue-100 mb-8 leading-relaxed">
              La plataforma todo-en-uno que transforma la gestión de talleres de reparación. 
              Automatiza procesos, optimiza recursos y multiplica tus ganancias.
            </p>
            
            <div className="grid grid-cols-1 gap-4 mb-8">
              <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm rounded-lg p-3 border border-white/20">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <span className="text-sm">+500 talleres activos</span>
              </div>
              <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm rounded-lg p-3 border border-white/20">
                <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                <span className="text-sm">Automatización inteligente</span>
              </div>
              <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm rounded-lg p-3 border border-white/20">
                <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse"></div>
                <span className="text-sm">Soporte 24/7</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Right side - Login form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 bg-gray-50">
        <Card className="w-full max-w-lg border-0 shadow-2xl bg-white">
          <CardHeader className="text-center pb-2">
            {/* Mobile logo */}
            <div className="flex justify-center mb-6 lg:hidden">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl">
                  <Wrench className="h-8 w-8 text-white" />
                </div>
                <div className="text-left">
                  <h1 className="text-2xl font-bold text-gray-900">TallerPro</h1>
                  <p className="text-sm text-gray-600">Gestión Profesional</p>
                </div>
              </div>
            </div>
            
            <CardTitle className="text-3xl font-bold text-gray-900 mb-2">
              Bienvenido
            </CardTitle>
            <CardDescription className="text-lg text-gray-600">
              Accede a tu plataforma de gestión profesional
            </CardDescription>
          </CardHeader>

          <CardContent className="px-8 pb-8">
            <Tabs defaultValue="login" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-8 bg-gray-100 p-1 rounded-lg">
                <TabsTrigger value="login" className="rounded-md transition-all duration-200 data-[state=active]:bg-white data-[state=active]:shadow-md">Iniciar Sesión</TabsTrigger>
                <TabsTrigger value="signup" className="rounded-md transition-all duration-200 data-[state=active]:bg-white data-[state=active]:shadow-md">Registrarse</TabsTrigger>
              </TabsList>

              <TabsContent value="login" className="space-y-6">
                <form onSubmit={handleLogin} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-sm font-medium text-gray-700">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="tu@email.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className={`h-12 px-4 rounded-lg border-2 transition-all duration-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 ${errors.email ? 'border-red-300 focus:border-red-500 focus:ring-red-200' : 'border-gray-200'}`}
                      required
                    />
                    {errors.email && (
                      <div className="flex items-center gap-2 text-sm text-red-600 mt-1">
                        <AlertCircle className="h-4 w-4" />
                        {errors.email}
                      </div>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password" className="text-sm font-medium text-gray-700">Contraseña</Label>
                    <Input
                      id="password"
                      type="password"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className={`h-12 px-4 rounded-lg border-2 transition-all duration-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 ${errors.password ? 'border-red-300 focus:border-red-500 focus:ring-red-200' : 'border-gray-200'}`}
                      required
                    />
                    {errors.password && (
                      <div className="flex items-center gap-2 text-sm text-red-600 mt-1">
                        <AlertCircle className="h-4 w-4" />
                        {errors.password}
                      </div>
                    )}
                  </div>
                  
                  {errors.general && (
                    <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                      <div className="flex items-center gap-2 text-sm text-red-700">
                        <AlertCircle className="h-4 w-4" />
                        {errors.general}
                      </div>
                    </div>
                  )}
                  
                  <Button 
                    type="submit" 
                    className="w-full h-12 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold rounded-lg transition-all duration-200 transform hover:scale-[1.02] active:scale-[0.98]" 
                    disabled={loading}
                  >
                    {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    {loading ? 'Iniciando sesión...' : 'Iniciar Sesión'}
                  </Button>
                  
                  <div className="text-center">
                    <a
                      href="/forgot-password"
                      className="text-sm text-blue-600 hover:text-blue-800 hover:underline transition-colors"
                    >
                      ¿Olvidaste tu contraseña?
                    </a>
                  </div>
                </form>
              </TabsContent>

              <TabsContent value="signup" className="space-y-6">
                <form onSubmit={handleSignUp} className="space-y-5">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="workshop-name" className="text-sm font-medium text-gray-700">Nombre del Taller</Label>
                      <Input
                        id="workshop-name"
                        type="text"
                        placeholder="Mi Taller de Reparaciones"
                        value={workshopName}
                        onChange={(e) => setWorkshopName(e.target.value)}
                        className={`h-12 px-4 rounded-lg border-2 transition-all duration-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 ${errors.workshopName ? 'border-red-300 focus:border-red-500 focus:ring-red-200' : 'border-gray-200'}`}
                        required
                      />
                      {errors.workshopName && (
                        <div className="flex items-center gap-2 text-sm text-red-600 mt-1">
                          <AlertCircle className="h-4 w-4" />
                          {errors.workshopName}
                        </div>
                      )}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="contact-person" className="text-sm font-medium text-gray-700">Persona de Contacto</Label>
                      <Input
                        id="contact-person"
                        type="text"
                        placeholder="Juan Pérez"
                        value={contactPerson}
                        onChange={(e) => setContactPerson(e.target.value)}
                        className={`h-12 px-4 rounded-lg border-2 transition-all duration-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 ${errors.contactPerson ? 'border-red-300 focus:border-red-500 focus:ring-red-200' : 'border-gray-200'}`}
                        required
                      />
                      {errors.contactPerson && (
                        <div className="flex items-center gap-2 text-sm text-red-600 mt-1">
                          <AlertCircle className="h-4 w-4" />
                          {errors.contactPerson}
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="signup-email" className="text-sm font-medium text-gray-700">Email</Label>
                    <Input
                      id="signup-email"
                      type="email"
                      placeholder="tu@email.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className={`h-12 px-4 rounded-lg border-2 transition-all duration-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 ${errors.email ? 'border-red-300 focus:border-red-500 focus:ring-red-200' : 'border-gray-200'}`}
                      required
                    />
                    {errors.email && (
                      <div className="flex items-center gap-2 text-sm text-red-600 mt-1">
                        <AlertCircle className="h-4 w-4" />
                        {errors.email}
                      </div>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="signup-password" className="text-sm font-medium text-gray-700">Contraseña</Label>
                    <Input
                      id="signup-password"
                      type="password"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className={`h-12 px-4 rounded-lg border-2 transition-all duration-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 ${errors.password ? 'border-red-300 focus:border-red-500 focus:ring-red-200' : 'border-gray-200'}`}
                      required
                    />
                    {errors.password && (
                      <div className="flex items-center gap-2 text-sm text-red-600 mt-1">
                        <AlertCircle className="h-4 w-4" />
                        {errors.password}
                      </div>
                    )}
                    <p className="text-xs text-gray-500 mt-1">
                      Mínimo 8 caracteres con mayúsculas, minúsculas y números
                    </p>
                  </div>
                  
                  {errors.general && (
                    <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                      <div className="flex items-center gap-2 text-sm text-red-700">
                        <AlertCircle className="h-4 w-4" />
                        {errors.general}
                      </div>
                    </div>
                  )}
                  
                  <Button
                    type="submit"
                    className="w-full h-12 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold rounded-lg transition-all duration-200 transform hover:scale-[1.02] active:scale-[0.98]"
                    disabled={loading}
                  >
                    {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    {loading ? 'Creando cuenta...' : 'Crear Cuenta'}
                  </Button>


                </form>
              </TabsContent>
            </Tabs>

            {/* Pricing info */}
            <div className="mt-8 p-6 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl border border-blue-100">
              <h3 className="font-semibold text-sm text-gray-800 mb-3 text-center">💎 Planes de Suscripción</h3>
              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="bg-white p-3 rounded-lg border border-gray-200">
                  <div className="text-lg font-bold text-blue-600">15€</div>
                  <div className="text-xs text-gray-600">Mensual</div>
                </div>
                <div className="bg-white p-3 rounded-lg border-2 border-blue-300 relative">
                  <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 bg-blue-600 text-white text-xs px-2 py-1 rounded">Popular</div>
                  <div className="text-lg font-bold text-blue-600">60€</div>
                  <div className="text-xs text-gray-600">6 meses</div>
                  <div className="text-xs text-green-600 font-medium">Ahorra 30€</div>
                </div>
                <div className="bg-white p-3 rounded-lg border border-gray-200">
                  <div className="text-lg font-bold text-blue-600">100€</div>
                  <div className="text-xs text-gray-600">Anual</div>
                  <div className="text-xs text-green-600 font-medium">Ahorra 80€</div>
                </div>
              </div>
            </div>



            {/* Back to landing page button */}
            <div className="mt-4 text-center">
              <Button
                variant="ghost"
                onClick={() => setShowAuthForm(false)}
                className="text-sm text-gray-600 hover:text-gray-800 hover:bg-gray-100 transition-colors"
              >
                ← Volver a la página principal
              </Button>
            </div>
            
            {/* Contact info */}
            <div className="mt-4 text-center">
              <p className="text-xs text-gray-500">
                ¿Necesitas ayuda? 
                <a href="mailto:mitaller@mitallerenlinea.org" className="text-blue-600 hover:text-blue-800 hover:underline ml-1 transition-colors">
                  mitaller@mitallerenlinea.org
                </a>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>


    </div>
  );
};

export default AuthPage;
