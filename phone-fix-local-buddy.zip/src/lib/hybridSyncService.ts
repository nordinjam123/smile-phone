import { centralizedFirebaseService } from './centralizedFirebaseService';

/**
 * Servicio híbrido que mantiene compatibilidad con localStorage
 * pero sincroniza automáticamente con Firebase cuando está disponible
 */
class HybridSyncService {
  private syncInProgress = false;
  private syncQueue: Array<{ key: string; data: any; operation: 'add' | 'update' | 'delete'; id?: string }> = [];

  // Mapeo de colecciones localStorage -> Firebase
  private collectionMap: { [key: string]: string } = {
    'clientes': 'clientes',
    'inventario': 'inventario', 
    'ordenes': 'ordenes_trabajo',
    'facturas': 'facturas',
    'gastos_mercancia': 'gastos_mercancia',
    'citas': 'citas'
  };

  async getItem(key: string): Promise<any[]> {
    const firebaseCollection = this.collectionMap[key];
    
    // Si Firebase está disponible, obtener de ahí
    if (centralizedFirebaseService.isReady() && firebaseCollection) {
      try {
        const firebaseData = await centralizedFirebaseService.getUserDocuments(firebaseCollection);
        
        // Actualizar localStorage con datos de Firebase
        localStorage.setItem(key, JSON.stringify(firebaseData));
        
        return firebaseData;
      } catch (error) {
        console.warn(`Error obteniendo datos de Firebase para ${key}:`, error);
      }
    }

    // Fallback a localStorage
    const localData = localStorage.getItem(key);
    return localData ? JSON.parse(localData) : [];
  }

  async setItem(key: string, data: any[]): Promise<void> {
    // Guardar siempre en localStorage primero (para offline)
    localStorage.setItem(key, JSON.stringify(data));

    // Si Firebase está disponible, sincronizar
    if (centralizedFirebaseService.isReady()) {
      this.queueSync(key, data, 'add');
    }
  }

  async addItem(key: string, item: any): Promise<string | null> {
    const firebaseCollection = this.collectionMap[key];
    
    // Si Firebase está disponible, usar directamente
    if (centralizedFirebaseService.isReady() && firebaseCollection) {
      try {
        const { id, error } = await centralizedFirebaseService.addDocument(firebaseCollection, item);
        
        if (!error && id) {
          // Actualizar localStorage también
          const localData = await this.getItem(key);
          localData.push({ ...item, id });
          localStorage.setItem(key, JSON.stringify(localData));
          
          return id;
        }
      } catch (error) {
        console.warn(`Error agregando a Firebase para ${key}:`, error);
      }
    }

    // Fallback a localStorage con ID generado
    const localData = await this.getItem(key);
    const newId = `local_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const newItem = { ...item, id: newId };
    
    localData.push(newItem);
    localStorage.setItem(key, JSON.stringify(localData));
    
    // Encolar para sincronización posterior
    this.queueSync(key, newItem, 'add');
    
    return newId;
  }

  async updateItem(key: string, id: string, updatedItem: any): Promise<boolean> {
    const firebaseCollection = this.collectionMap[key];
    
    // Si Firebase está disponible, actualizar directamente
    if (centralizedFirebaseService.isReady() && firebaseCollection && !id.startsWith('local_')) {
      try {
        const { success } = await centralizedFirebaseService.updateDocument(firebaseCollection, id, updatedItem);
        
        if (success) {
          // Actualizar localStorage también
          const localData = await this.getItem(key);
          const index = localData.findIndex(item => item.id === id);
          if (index !== -1) {
            localData[index] = { ...localData[index], ...updatedItem };
            localStorage.setItem(key, JSON.stringify(localData));
          }
          
          return true;
        }
      } catch (error) {
        console.warn(`Error actualizando en Firebase para ${key}:`, error);
      }
    }

    // Fallback a localStorage
    const localData = await this.getItem(key);
    const index = localData.findIndex(item => item.id === id);
    
    if (index !== -1) {
      localData[index] = { ...localData[index], ...updatedItem };
      localStorage.setItem(key, JSON.stringify(localData));
      
      // Encolar para sincronización posterior
      this.queueSync(key, { ...updatedItem, id }, 'update', id);
      
      return true;
    }
    
    return false;
  }

  async deleteItem(key: string, id: string): Promise<boolean> {
    const firebaseCollection = this.collectionMap[key];
    
    // Si Firebase está disponible, eliminar directamente
    if (centralizedFirebaseService.isReady() && firebaseCollection && !id.startsWith('local_')) {
      try {
        const { success } = await centralizedFirebaseService.deleteDocument(firebaseCollection, id);
        
        if (success) {
          // Eliminar de localStorage también
          const localData = await this.getItem(key);
          const filteredData = localData.filter(item => item.id !== id);
          localStorage.setItem(key, JSON.stringify(filteredData));
          
          return true;
        }
      } catch (error) {
        console.warn(`Error eliminando de Firebase para ${key}:`, error);
      }
    }

    // Fallback a localStorage
    const localData = await this.getItem(key);
    const filteredData = localData.filter(item => item.id !== id);
    localStorage.setItem(key, JSON.stringify(filteredData));
    
    // Encolar para sincronización posterior
    this.queueSync(key, { id }, 'delete', id);
    
    return true;
  }

  private queueSync(key: string, data: any, operation: 'add' | 'update' | 'delete', id?: string) {
    this.syncQueue.push({ key, data, operation, id });
    
    // Procesar cola después de un pequeño delay
    setTimeout(() => this.processSyncQueue(), 1000);
  }

  private async processSyncQueue() {
    if (this.syncInProgress || this.syncQueue.length === 0) return;
    if (!centralizedFirebaseService.isReady()) return;

    this.syncInProgress = true;

    try {
      while (this.syncQueue.length > 0) {
        const sync = this.syncQueue.shift();
        if (!sync) continue;

        const firebaseCollection = this.collectionMap[sync.key];
        if (!firebaseCollection) continue;

        try {
          switch (sync.operation) {
            case 'add':
              await centralizedFirebaseService.addDocument(firebaseCollection, sync.data);
              break;
            case 'update':
              if (sync.id) {
                await centralizedFirebaseService.updateDocument(firebaseCollection, sync.id, sync.data);
              }
              break;
            case 'delete':
              if (sync.id) {
                await centralizedFirebaseService.deleteDocument(firebaseCollection, sync.id);
              }
              break;
          }
        } catch (error) {
          console.warn(`Error sincronizando ${sync.operation} para ${sync.key}:`, error);
          // Volver a encolar si falla
          this.syncQueue.unshift(sync);
          break;
        }
      }
    } finally {
      this.syncInProgress = false;
    }
  }

  async fullSync(): Promise<{ success: boolean; synced: number }> {
    if (!centralizedFirebaseService.isReady()) {
      return { success: false, synced: 0 };
    }

    let synced = 0;

    try {
      for (const [localKey, firebaseCollection] of Object.entries(this.collectionMap)) {
        const localData = localStorage.getItem(localKey);
        if (localData) {
          const items = JSON.parse(localData);
          
          for (const item of items) {
            // Solo sincronizar elementos que no estén ya en Firebase
            if (item.id && item.id.startsWith('local_')) {
              try {
                const { id } = await centralizedFirebaseService.addDocument(firebaseCollection, item);
                if (id) {
                  synced++;
                  
                  // Actualizar ID local con ID de Firebase
                  const updatedItems = items.map((i: any) => 
                    i.id === item.id ? { ...i, id } : i
                  );
                  localStorage.setItem(localKey, JSON.stringify(updatedItems));
                }
              } catch (error) {
                console.warn(`Error sincronizando item de ${localKey}:`, error);
              }
            }
          }
        }
      }

      return { success: true, synced };
    } catch (error) {
      console.error('Error en sincronización completa:', error);
      return { success: false, synced };
    }
  }

  isFirebaseAvailable(): boolean {
    return centralizedFirebaseService.isReady();
  }
}

export const hybridSyncService = new HybridSyncService();
