import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useHybridStorage } from '@/hooks/useHybridStorage';
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  Users, 
  Cloud, 
  HardDrive, 
  RefreshCw,
  CheckCircle,
  AlertCircle,
  Clock
} from 'lucide-react';

interface Cliente {
  id: string;
  nombre: string;
  telefono: string;
  email: string;
  direccion: string;
  tipo_documento: 'NIF' | 'CIF';
  numero_documento: string;
  created_at: string;
  updated_at: string;
}

export default function ClientesHybridExample() {
  const [searchTerm, setSearchTerm] = useState('');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingCliente, setEditingCliente] = useState<Cliente | null>(null);
  const { toast } = useToast();

  // Configuración del almacenamiento híbrido
  const storageConfig = {
    tableName: 'clientes',
    localKey: 'clientes_data',
    mode: (localStorage.getItem('storageConfig') ? 
      JSON.parse(localStorage.getItem('storageConfig')!).mode : 'hybrid') as 'local' | 'cloud' | 'hybrid',
    autoSync: true,
    syncInterval: 30 // 30 minutos
  };

  // Hook de almacenamiento híbrido
  const {
    data: clientes,
    saveData,
    syncStatus,
    isOnline,
    forceSync,
    loadData
  } = useHybridStorage<Cliente>(storageConfig);

  const [formData, setFormData] = useState({
    nombre: '',
    telefono: '',
    email: '',
    direccion: '',
    tipo_documento: 'NIF' as 'NIF' | 'CIF',
    numero_documento: ''
  });

  const resetForm = () => {
    setFormData({
      nombre: '',
      telefono: '',
      email: '',
      direccion: '',
      tipo_documento: 'NIF',
      numero_documento: ''
    });
    setEditingCliente(null);
    setIsFormOpen(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.nombre || !formData.telefono) {
      toast({
        title: "Error",
        description: "Nombre y teléfono son obligatorios",
        variant: "destructive"
      });
      return;
    }

    const now = new Date().toISOString();
    
    if (editingCliente) {
      // Actualizar cliente existente
      const updatedClientes = clientes.map(cliente =>
        cliente.id === editingCliente.id
          ? { ...cliente, ...formData, updated_at: now }
          : cliente
      );
      await saveData(updatedClientes);
      
      toast({
        title: "Cliente actualizado",
        description: `${formData.nombre} ha sido actualizado correctamente`
      });
    } else {
      // Crear nuevo cliente
      const newCliente: Cliente = {
        id: `cliente-${Date.now()}`,
        ...formData,
        created_at: now,
        updated_at: now
      };
      
      await saveData([...clientes, newCliente]);
      
      toast({
        title: "Cliente creado",
        description: `${formData.nombre} ha sido añadido correctamente`
      });
    }

    resetForm();
  };

  const handleEdit = (cliente: Cliente) => {
    setEditingCliente(cliente);
    setFormData({
      nombre: cliente.nombre,
      telefono: cliente.telefono,
      email: cliente.email || '',
      direccion: cliente.direccion || '',
      tipo_documento: cliente.tipo_documento,
      numero_documento: cliente.numero_documento
    });
    setIsFormOpen(true);
  };

  const handleDelete = async (id: string) => {
    const updatedClientes = clientes.filter(cliente => cliente.id !== id);
    await saveData(updatedClientes);
    
    toast({
      title: "Cliente eliminado",
      description: "El cliente ha sido eliminado correctamente"
    });
  };

  const filteredClientes = clientes.filter(cliente =>
    cliente.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
    cliente.telefono.includes(searchTerm) ||
    cliente.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getSyncStatusBadge = () => {
    if (syncStatus.syncing) {
      return (
        <Badge variant="secondary" className="bg-blue-100 text-blue-800">
          <RefreshCw className="w-3 h-3 mr-1 animate-spin" />
          Sincronizando...
        </Badge>
      );
    }

    if (syncStatus.error) {
      return (
        <Badge variant="destructive">
          <AlertCircle className="w-3 h-3 mr-1" />
          Error
        </Badge>
      );
    }

    if (syncStatus.pending > 0) {
      return (
        <Badge variant="secondary" className="bg-orange-100 text-orange-800">
          <Clock className="w-3 h-3 mr-1" />
          {syncStatus.pending} pendientes
        </Badge>
      );
    }

    if (syncStatus.lastSync) {
      return (
        <Badge variant="default" className="bg-green-100 text-green-800">
          <CheckCircle className="w-3 h-3 mr-1" />
          Sincronizado
        </Badge>
      );
    }

    return null;
  };

  const getStorageModeBadge = () => {
    switch (storageConfig.mode) {
      case 'local':
        return (
          <Badge variant="outline">
            <HardDrive className="w-3 h-3 mr-1" />
            Local
          </Badge>
        );
      case 'cloud':
        return (
          <Badge variant="outline">
            <Cloud className="w-3 h-3 mr-1" />
            Nube
          </Badge>
        );
      case 'hybrid':
        return (
          <Badge variant="outline">
            <RefreshCw className="w-3 h-3 mr-1" />
            Híbrido
          </Badge>
        );
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header con estado de almacenamiento */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">Clientes (Ejemplo Híbrido)</h1>
          <p className="text-slate-600">Gestión de clientes con almacenamiento híbrido</p>
        </div>
        <div className="flex items-center gap-2">
          {getStorageModeBadge()}
          {getSyncStatusBadge()}
          {!isOnline && (
            <Badge variant="destructive">
              Offline
            </Badge>
          )}
        </div>
      </div>

      {/* Estadísticas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Clientes</p>
                <p className="text-2xl font-bold">{clientes.length}</p>
              </div>
              <Users className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Modo</p>
                <p className="text-lg font-bold capitalize">{storageConfig.mode}</p>
              </div>
              {storageConfig.mode === 'hybrid' ? <RefreshCw className="h-8 w-8 text-green-600" /> :
               storageConfig.mode === 'cloud' ? <Cloud className="h-8 w-8 text-blue-600" /> :
               <HardDrive className="h-8 w-8 text-gray-600" />}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Estado</p>
                <p className="text-lg font-bold">{isOnline ? 'Online' : 'Offline'}</p>
              </div>
              <div className={`h-8 w-8 rounded-full ${isOnline ? 'bg-green-600' : 'bg-red-600'}`} />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Pendientes</p>
                <p className="text-lg font-bold text-orange-600">{syncStatus.pending}</p>
              </div>
              <Clock className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Barra de búsqueda y acciones */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar clientes..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <Button onClick={() => setIsFormOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Nuevo Cliente
              </Button>
              
              {(storageConfig.mode === 'hybrid' || storageConfig.mode === 'cloud') && (
                <Button 
                  variant="outline" 
                  onClick={forceSync}
                  disabled={syncStatus.syncing || !isOnline}
                >
                  <RefreshCw className={`w-4 h-4 mr-2 ${syncStatus.syncing ? 'animate-spin' : ''}`} />
                  Sincronizar
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Lista de clientes */}
      <div className="grid gap-4">
        {filteredClientes.length === 0 ? (
          <Card>
            <CardContent className="pt-6 text-center">
              <Users className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No hay clientes</h3>
              <p className="text-muted-foreground">
                {searchTerm ? "No se encontraron clientes con ese término" : "Crea tu primer cliente para comenzar"}
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredClientes.map((cliente) => (
            <Card key={cliente.id} className="hover:shadow-md transition-shadow">
              <CardContent className="pt-6">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold">{cliente.nombre}</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mt-2 text-sm text-muted-foreground">
                      <div>📞 {cliente.telefono}</div>
                      <div>📧 {cliente.email || 'Sin email'}</div>
                      <div>🆔 {cliente.tipo_documento}: {cliente.numero_documento}</div>
                    </div>
                    {cliente.direccion && (
                      <div className="mt-1 text-sm text-muted-foreground">📍 {cliente.direccion}</div>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEdit(cliente)}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleDelete(cliente.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Formulario modal (simplificado para el ejemplo) */}
      {isFormOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle>{editingCliente ? 'Editar Cliente' : 'Nuevo Cliente'}</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="nombre">Nombre *</Label>
                  <Input
                    id="nombre"
                    value={formData.nombre}
                    onChange={(e) => setFormData({...formData, nombre: e.target.value})}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="telefono">Teléfono *</Label>
                  <Input
                    id="telefono"
                    value={formData.telefono}
                    onChange={(e) => setFormData({...formData, telefono: e.target.value})}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                  />
                </div>
                <div className="flex gap-2">
                  <Button type="button" variant="outline" onClick={resetForm}>
                    Cancelar
                  </Button>
                  <Button type="submit">
                    {editingCliente ? 'Actualizar' : 'Crear'}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Información de sincronización */}
      {syncStatus.lastSync && (
        <Card className="bg-muted">
          <CardContent className="pt-4">
            <div className="text-sm text-muted-foreground">
              Última sincronización: {syncStatus.lastSync.toLocaleString('es-ES')}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
