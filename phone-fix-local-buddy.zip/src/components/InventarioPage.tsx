import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import { useToast } from "@/hooks/use-toast";
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  Package,
  AlertTriangle,
  TrendingDown,
  TrendingUp
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

interface Producto {
  id: string;
  nombre: string;
  categoria: string;
  marca: string;
  modelo: string;
  descripcion: string;
  stock: number;
  stockMinimo: number;
  precio: number;
  proveedor: string;
  fechaIngreso: string;
}

const categorias = [
  "Pantallas",
  "Baterías", 
  "Cargadores",
  "Cables",
  "Fundas",
  "Componentes",
  "Herramientas",
  "Otros"
];

export default function InventarioPage() {
  const [productos, setProductos] = useLocalStorage<Producto[]>("inventario", []);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCategoria, setFilterCategoria] = useState<string>("todas");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Producto | null>(null);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    nombre: "",
    categoria: "Pantallas",
    marca: "",
    modelo: "",
    descripcion: "",
    stock: "",
    stockMinimo: "",
    precio: "",
    proveedor: ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.nombre || !formData.stock || !formData.precio) {
      toast({
        title: "Error",
        description: "Por favor completa los campos obligatorios",
        variant: "destructive"
      });
      return;
    }

    const nuevoProducto: Producto = {
      id: editingProduct?.id || Date.now().toString(),
      nombre: formData.nombre,
      categoria: formData.categoria,
      marca: formData.marca,
      modelo: formData.modelo,
      descripcion: formData.descripcion,
      stock: parseInt(formData.stock),
      stockMinimo: parseInt(formData.stockMinimo) || 5,
      precio: parseFloat(formData.precio),
      proveedor: formData.proveedor,
      fechaIngreso: editingProduct?.fechaIngreso || new Date().toISOString().split('T')[0]
    };

    if (editingProduct) {
      setProductos(productos.map(producto => producto.id === editingProduct.id ? nuevoProducto : producto));
      toast({
        title: "Producto actualizado",
        description: "El producto ha sido actualizado exitosamente"
      });
    } else {
      setProductos([...productos, nuevoProducto]);
      toast({
        title: "Producto agregado",
        description: "Nuevo producto agregado al inventario"
      });
    }

    resetForm();
    setIsDialogOpen(false);
  };

  const resetForm = () => {
    setFormData({
      nombre: "",
      categoria: "Pantallas",
      marca: "",
      modelo: "",
      descripcion: "",
      stock: "",
      stockMinimo: "",
      precio: "",
      proveedor: ""
    });
    setEditingProduct(null);
  };

  const handleEdit = (producto: Producto) => {
    setEditingProduct(producto);
    setFormData({
      nombre: producto.nombre,
      categoria: producto.categoria,
      marca: producto.marca,
      modelo: producto.modelo,
      descripcion: producto.descripcion,
      stock: producto.stock.toString(),
      stockMinimo: producto.stockMinimo.toString(),
      precio: producto.precio.toString(),
      proveedor: producto.proveedor
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    setProductos(productos.filter(producto => producto.id !== id));
    toast({
      title: "Producto eliminado",
      description: "El producto ha sido eliminado del inventario"
    });
  };

  const adjustStock = (id: string, adjustment: number) => {
    setProductos(productos.map(producto => 
      producto.id === id 
        ? { ...producto, stock: Math.max(0, producto.stock + adjustment) }
        : producto
    ));
    toast({
      title: "Stock actualizado",
      description: `Stock ${adjustment > 0 ? 'aumentado' : 'reducido'} exitosamente`
    });
  };

  const filteredProductos = productos.filter(producto => {
    const matchesSearch = producto.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         producto.marca.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         producto.modelo.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategoria = filterCategoria === "todas" || producto.categoria === filterCategoria;
    return matchesSearch && matchesCategoria;
  });

  const productosStockBajo = productos.filter(p => p.stock <= p.stockMinimo);

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">Inventario</h1>
          <p className="text-slate-600">Gestiona el stock de repuestos y productos</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={resetForm}>
              <Plus className="w-4 h-4 mr-2" />
              Nuevo Producto
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingProduct ? "Editar Producto" : "Nuevo Producto"}
              </DialogTitle>
            </DialogHeader>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="nombre">Nombre del Producto *</Label>
                  <Input
                    id="nombre"
                    value={formData.nombre}
                    onChange={(e) => setFormData({...formData, nombre: e.target.value})}
                    placeholder="Ej: Pantalla LCD iPhone 12"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="categoria">Categoría</Label>
                  <Select value={formData.categoria} onValueChange={(value) => setFormData({...formData, categoria: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {categorias.map(categoria => (
                        <SelectItem key={categoria} value={categoria}>{categoria}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="marca">Marca</Label>
                  <Input
                    id="marca"
                    value={formData.marca}
                    onChange={(e) => setFormData({...formData, marca: e.target.value})}
                    placeholder="Ej: Apple, Samsung"
                  />
                </div>
                <div>
                  <Label htmlFor="modelo">Modelo</Label>
                  <Input
                    id="modelo"
                    value={formData.modelo}
                    onChange={(e) => setFormData({...formData, modelo: e.target.value})}
                    placeholder="Ej: iPhone 12, Galaxy S21"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="descripcion">Descripción</Label>
                <Textarea
                  id="descripcion"
                  value={formData.descripcion}
                  onChange={(e) => setFormData({...formData, descripcion: e.target.value})}
                  placeholder="Descripción detallada del producto"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="stock">Stock Actual *</Label>
                  <Input
                    id="stock"
                    type="number"
                    min="0"
                    value={formData.stock}
                    onChange={(e) => setFormData({...formData, stock: e.target.value})}
                    placeholder="0"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="stockMinimo">Stock Mínimo</Label>
                  <Input
                    id="stockMinimo"
                    type="number"
                    min="0"
                    value={formData.stockMinimo}
                    onChange={(e) => setFormData({...formData, stockMinimo: e.target.value})}
                    placeholder="5"
                  />
                </div>
                <div>
                  <Label htmlFor="precio">Precio *</Label>
                  <Input
                    id="precio"
                    type="number"
                    step="0.01"
                    min="0"
                    value={formData.precio}
                    onChange={(e) => setFormData({...formData, precio: e.target.value})}
                    placeholder="0.00"
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="proveedor">Proveedor</Label>
                <Input
                  id="proveedor"
                  value={formData.proveedor}
                  onChange={(e) => setFormData({...formData, proveedor: e.target.value})}
                  placeholder="Nombre del proveedor"
                />
              </div>

              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit">
                  {editingProduct ? "Actualizar" : "Agregar"} Producto
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Alertas de Stock Bajo */}
      {productosStockBajo.length > 0 && (
        <Card className="border-red-200 bg-red-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-700">
              <AlertTriangle className="w-5 h-5" />
              Productos con Stock Bajo ({productosStockBajo.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {productosStockBajo.slice(0, 3).map(producto => (
                <div key={producto.id} className="flex justify-between items-center text-sm">
                  <span>{producto.nombre}</span>
                  <Badge variant="destructive">{producto.stock} unidades</Badge>
                </div>
              ))}
              {productosStockBajo.length > 3 && (
                <p className="text-sm text-red-600">Y {productosStockBajo.length - 3} productos más...</p>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar por nombre, marca o modelo..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={filterCategoria} onValueChange={setFilterCategoria}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Filtrar por categoría" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todas">Todas las categorías</SelectItem>
                {categorias.map(categoria => (
                  <SelectItem key={categoria} value={categoria}>{categoria}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Products List */}
      <div className="grid gap-4">
        {filteredProductos.length === 0 ? (
          <Card>
            <CardContent className="pt-6 text-center">
              <Package className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No hay productos</h3>
              <p className="text-muted-foreground">
                {searchTerm || filterCategoria !== "todas" 
                  ? "No se encontraron productos con los filtros aplicados"
                  : "Agrega tu primer producto al inventario"
                }
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredProductos.map((producto) => (
            <Card key={producto.id} className="hover:shadow-md transition-shadow">
              <CardContent className="pt-6">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="text-lg font-semibold">{producto.nombre}</h3>
                      <Badge variant="outline">{producto.categoria}</Badge>
                      {producto.stock <= producto.stockMinimo && (
                        <Badge variant="destructive" className="text-xs">
                          Stock Bajo
                        </Badge>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-2 text-sm text-muted-foreground mb-3">
                      {producto.marca && (
                        <div>Marca: {producto.marca}</div>
                      )}
                      {producto.modelo && (
                        <div>Modelo: {producto.modelo}</div>
                      )}
                      {producto.proveedor && (
                        <div>Proveedor: {producto.proveedor}</div>
                      )}
                      <div>Precio: €{producto.precio}</div>
                    </div>

                    {producto.descripcion && (
                      <p className="text-sm text-muted-foreground mb-3">{producto.descripcion}</p>
                    )}

                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium">Stock:</span>
                        <div className="flex items-center gap-1">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => adjustStock(producto.id, -1)}
                            disabled={producto.stock === 0}
                          >
                            <TrendingDown className="w-3 h-3" />
                          </Button>
                          <span className={`px-3 py-1 rounded font-semibold ${
                            producto.stock <= producto.stockMinimo 
                              ? 'bg-red-100 text-red-700' 
                              : 'bg-green-100 text-green-700'
                          }`}>
                            {producto.stock}
                          </span>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => adjustStock(producto.id, 1)}
                          >
                            <TrendingUp className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Min: {producto.stockMinimo}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEdit(producto)}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDelete(producto.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}