import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { Resend } from "npm:resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface TemporaryPasswordRequest {
  email: string;
}

// Función para generar contraseña temporal
function generateTemporaryPassword(): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let password = "";
  for (let i = 0; i < 12; i++) {
    password += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return password;
}

const handler = async (req: Request): Promise<Response> => {
  console.log("send-temporary-password function called");

  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return new Response(
      JSON.stringify({ error: "Method not allowed" }),
      { 
        status: 405, 
        headers: { "Content-Type": "application/json", ...corsHeaders }
      }
    );
  }

  try {
    const { email }: TemporaryPasswordRequest = await req.json();
    console.log("Processing temporary password request for:", email);

    if (!email) {
      return new Response(
        JSON.stringify({ error: "Email is required" }),
        {
          status: 400,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    // Crear cliente de Supabase con service role
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Verificar si el usuario existe
    const { data: userData, error: userError } = await supabaseAdmin.auth.admin.listUsers();
    
    if (userError) {
      console.error("Error checking user:", userError);
      return new Response(
        JSON.stringify({ error: "Error verificando usuario" }),
        {
          status: 500,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    const user = userData.users.find(u => u.email === email);
    
    if (!user) {
      return new Response(
        JSON.stringify({ error: "Usuario no encontrado" }),
        {
          status: 404,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    // Generar contraseña temporal
    const temporaryPassword = generateTemporaryPassword();
    console.log("Generated temporary password for user:", user.id);

    // Actualizar contraseña del usuario
    const { error: updateError } = await supabaseAdmin.auth.admin.updateUserById(
      user.id,
      { 
        password: temporaryPassword,
        user_metadata: { 
          ...user.user_metadata,
          temporary_password: true,
          temporary_password_created: new Date().toISOString()
        }
      }
    );

    if (updateError) {
      console.error("Error updating user password:", updateError);
      return new Response(
        JSON.stringify({ error: "Error actualizando contraseña" }),
        {
          status: 500,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    // Enviar email con contraseña temporal
    const emailResponse = await resend.emails.send({
      from: "Sistema de Talleres <noreply@resend.dev>",
      to: [email],
      subject: "Contraseña temporal - Sistema de Talleres",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #333; text-align: center;">Contraseña Temporal</h2>
          <p>Hola,</p>
          <p>Se ha generado una contraseña temporal para tu cuenta:</p>
          <div style="background-color: #f5f5f5; padding: 20px; margin: 20px 0; text-align: center; border-radius: 5px;">
            <h3 style="margin: 0; font-family: monospace; font-size: 18px; color: #007bff;">${temporaryPassword}</h3>
          </div>
          <p><strong>Importante:</strong></p>
          <ul>
            <li>Esta contraseña es temporal y debes cambiarla al iniciar sesión</li>
            <li>Por seguridad, esta contraseña expirará en 24 horas</li>
            <li>Una vez que inicies sesión, podrás establecer una nueva contraseña permanente</li>
          </ul>
          <p>Si no solicitaste este cambio, por favor contacta con soporte inmediatamente.</p>
          <hr style="margin: 30px 0; border: none; border-top: 1px solid #eee;">
          <p style="font-size: 12px; color: #666; text-align: center;">
            Sistema de Gestión de Talleres
          </p>
        </div>
      `,
    });

    console.log("Email sent successfully:", emailResponse);

    return new Response(
      JSON.stringify({ 
        success: true,
        message: "Contraseña temporal enviada por email"
      }),
      {
        status: 200,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );

  } catch (error: any) {
    console.error("Error in send-temporary-password function:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Error interno del servidor" }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);