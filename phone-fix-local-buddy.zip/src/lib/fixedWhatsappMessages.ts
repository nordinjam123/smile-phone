// Función corregida para enviar mensajes automáticos de WhatsApp
import { sendWhatsAppMessageDesktopFirst } from './whatsappDesktopManager';
import { ensureWhatsAppIsEnabled } from './whatsappAutoConfig';
import { isWhatsAppEnabled } from './whatsappUtils';

interface OrdenData {
  id: string;
  clienteNombre: string;
  clienteTelefono: string;
  dispositivo: string;
  marca: string;
  modelo: string;
  problema?: string;
  diagnostico?: string;
  precio: number;
  estado: string;
}

// Función principal para enviar actualizaciones de estado
export async function sendFixedStatusUpdate(
  orden: OrdenData, 
  estadoAnterior: string, 
  nuevoEstado: string
): Promise<boolean> {
  try {
    // Auto-activar WhatsApp si no está configurado
    ensureWhatsAppIsEnabled();

    // Verificar que WhatsApp esté habilitado y hay teléfono
    if (!isWhatsAppEnabled() || !orden.clienteTelefono) {
      console.log('WhatsApp no habilitado o sin teléfono');
      return false;
    }

    // Generar mensaje según el nuevo estado
    const mensaje = generateStatusMessage(orden, nuevoEstado);
    
    if (!mensaje) {
      console.log('No se pudo generar mensaje para estado:', nuevoEstado);
      return false;
    }

    console.log('Enviando mensaje automático:', { 
      cliente: orden.clienteNombre, 
      telefono: orden.clienteTelefono,
      estado: nuevoEstado,
      mensaje: mensaje.substring(0, 50) + '...'
    });

    // Usar el sistema mejorado de envío
    const result = await sendWhatsAppMessageDesktopFirst(orden.clienteTelefono, mensaje);
    
    if (result.success) {
      console.log(`Mensaje automático enviado via ${result.method} para orden #${orden.id}`);
      return true;
    } else {
      console.error('Error enviando mensaje automático:', result.error);
      return false;
    }
  } catch (error) {
    console.error('Error en sendFixedStatusUpdate:', error);
    return false;
  }
}

// Generar mensaje según el estado
function generateStatusMessage(orden: OrdenData, estado: string): string {
  const dispositivo = `${orden.marca} ${orden.modelo}`.trim();
  
  switch (estado) {
    case 'en_proceso':
      return `🔧 Hola ${orden.clienteNombre}!

Tu ${dispositivo} ha sido asignado a nuestro tecnico y esta siendo revisado.

📋 Orden: #${orden.id}
⏰ Estado: EN PROCESO

${orden.diagnostico ? `🔍 Diagnostico: ${orden.diagnostico}\n\n` : ''}Te mantendremos informado del progreso.`;

    case 'completado':
      return `✅ ¡Buenas noticias ${orden.clienteNombre}!

Tu ${dispositivo} ha sido reparado exitosamente.

📋 Orden: #${orden.id}
⏰ Estado: COMPLETADO
💰 Total: €${orden.precio.toFixed(2)}

📍 Ya puedes pasar a recogerlo.

Horario: L-V 9:00-18:00`;

    case 'entregado':
      return `📦 ¡Gracias ${orden.clienteNombre}!

Tu ${dispositivo} ha sido entregado correctamente.

📋 Orden: #${orden.id}
⏰ Estado: ENTREGADO

🎉 Esperamos que disfrutes de tu dispositivo reparado!

No dudes en contactarnos si necesitas algo mas.`;

    case 'pendiente':
      return `📱 ¡Hola ${orden.clienteNombre}!

Hemos recibido tu ${dispositivo} para reparacion.

📋 Orden: #${orden.id}
⏰ Estado: RECIBIDO
🔧 Problema reportado: ${orden.problema || 'Por determinar'}

Te contactaremos pronto con el diagnostico.`;

    default:
      console.warn('Estado no reconocido para mensaje:', estado);
      return '';
  }
}

// Función para enviar mensaje personalizado
export async function sendFixedCustomMessage(
  telefono: string, 
  mensaje: string
): Promise<boolean> {
  try {
    ensureWhatsAppIsEnabled();
    
    if (!isWhatsAppEnabled() || !telefono) {
      return false;
    }

    const result = await sendWhatsAppMessageDesktopFirst(telefono, mensaje);
    
    if (result.success) {
      console.log(`Mensaje personalizado enviado via ${result.method}`);
      return true;
    } else {
      console.error('Error enviando mensaje personalizado:', result.error);
      return false;
    }
  } catch (error) {
    console.error('Error en sendFixedCustomMessage:', error);
    return false;
  }
}

// Función para enviar recordatorio
export async function sendFixedReminder(orden: OrdenData): Promise<boolean> {
  const diasTranscurridos = Math.floor(
    (Date.now() - new Date(orden.fechaIngreso || Date.now()).getTime()) / (1000 * 60 * 60 * 24)
  );

  const dispositivo = `${orden.marca} ${orden.modelo}`.trim();
  
  const mensaje = `Hola ${orden.clienteNombre}!

Recordatorio amigable: Tu ${dispositivo} esta listo para recoger desde hace ${diasTranscurridos} dias.

Orden: #${orden.id}
Estado: ${orden.estado.toUpperCase()}

Horario de recogida:
L-V 9:00-18:00

Te esperamos!`;

  return sendFixedCustomMessage(orden.clienteTelefono, mensaje);
}

// Función de prueba con mensaje real de reparación
export async function sendFixedTestMessage(): Promise<boolean> {
  const testMessage = `🔧 ¡Hola Maria!

Tu iPhone 12 ha sido asignado a nuestro tecnico y esta siendo revisado.

📋 Orden: #12345
⏰ Estado: EN PROCESO

🔍 Diagnostico: Pantalla rota, se procede al cambio

Te mantendremos informado del progreso.

📱 EJEMPLO de mensaje automatico que recibiran tus clientes.

Fecha: ${new Date().toLocaleString('es-ES')}`;

  try {
    const result = await sendWhatsAppMessageDesktopFirst('', testMessage);

    if (result.success) {
      console.log(`Mensaje de ejemplo enviado usando: ${result.method}`);
      return true;
    } else {
      console.error('Error enviando mensaje de ejemplo:', result.error);
      return false;
    }
  } catch (error) {
    console.error('Error en mensaje de ejemplo:', error);
    return false;
  }
}
