-- Insertar plantillas de facturas predeterminadas
INSERT INTO public.invoice_templates (name, template_data, is_default, user_id) VALUES 
(
  'Plantilla Moderna',
  '{
    "layout": "moderna",
    "colors": {
      "primary": "#2563eb",
      "secondary": "#64748b",
      "accent": "#f59e0b"
    },
    "header": {
      "showLogo": true,
      "companyInfo": true,
      "layout": "left-aligned"
    },
    "sections": {
      "customerInfo": true,
      "itemsTable": true,
      "totals": true,
      "terms": true
    },
    "styling": {
      "font": "Arial",
      "border": true,
      "shadows": true
    }
  }',
  true,
  null
),
(
  'Plantilla Clásica',
  '{
    "layout": "clasica",
    "colors": {
      "primary": "#1f2937",
      "secondary": "#6b7280",
      "accent": "#dc2626"
    },
    "header": {
      "showLogo": false,
      "companyInfo": true,
      "layout": "center-aligned"
    },
    "sections": {
      "customerInfo": true,
      "itemsTable": true,
      "totals": true,
      "terms": true
    },
    "styling": {
      "font": "Times New Roman",
      "border": true,
      "shadows": false
    }
  }',
  false,
  null
),
(
  'Plantilla Minimalista',
  '{
    "layout": "minimalista",
    "colors": {
      "primary": "#000000",
      "secondary": "#666666",
      "accent": "#999999"
    },
    "header": {
      "showLogo": false,
      "companyInfo": true,
      "layout": "right-aligned"
    },
    "sections": {
      "customerInfo": true,
      "itemsTable": true,
      "totals": true,
      "terms": false
    },
    "styling": {
      "font": "Helvetica",
      "border": false,
      "shadows": false
    }
  }',
  false,
  null
),
(
  'Plantilla Colorida',
  '{
    "layout": "colorida",
    "colors": {
      "primary": "#7c3aed",
      "secondary": "#a855f7",
      "accent": "#06b6d4"
    },
    "header": {
      "showLogo": true,
      "companyInfo": true,
      "layout": "left-aligned"
    },
    "sections": {
      "customerInfo": true,
      "itemsTable": true,
      "totals": true,
      "terms": true
    },
    "styling": {
      "font": "Arial",
      "border": true,
      "shadows": true
    }
  }',
  false,
  null
);