import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { ChevronUp, ChevronDown, LogIn } from 'lucide-react';

interface LateralNavigationProps {
  onLogin: () => void;
}

const LateralNavigation: React.FC<LateralNavigationProps> = ({ onLogin }) => {
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [currentSectionIndex, setCurrentSectionIndex] = useState(0);

  // Lista de secciones de la página
  const sections = [
    'hero',
    'qr-system',
    'whatsapp',
    'benefits',
    'features',
    'testimonials',
    'pricing'
  ];

  // Detectar si necesitamos mostrar el botón de scroll hacia arriba
  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 400);

      // Detectar la sección actual
      const scrollPosition = window.scrollY + window.innerHeight / 2;

      for (let i = sections.length - 1; i >= 0; i--) {
        const element = document.getElementById(sections[i]);
        if (element && element.offsetTop <= scrollPosition) {
          setCurrentSectionIndex(i);
          break;
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollUp = () => {
    if (currentSectionIndex > 0) {
      const targetSection = sections[currentSectionIndex - 1];
      const element = document.getElementById(targetSection);
      if (element) {
        element.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    } else {
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    }
  };

  const scrollDown = () => {
    if (currentSectionIndex < sections.length - 1) {
      const targetSection = sections[currentSectionIndex + 1];
      const element = document.getElementById(targetSection);
      if (element) {
        element.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    }
  };

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  return (
    <div className="fixed right-6 top-1/2 transform -translate-y-1/2 z-50">
      <div className="flex flex-col items-center space-y-3 relative">
        {/* Botón de subir */}
        <Button
          onClick={scrollUp}
          className="w-12 h-12 rounded-full bg-blue-600 hover:bg-blue-700 shadow-lg hover:shadow-xl transition-all duration-200 p-0 flex items-center justify-center relative z-10"
          title="Subir"
        >
          <ChevronUp className="h-6 w-6 pointer-events-none" />
        </Button>

        {/* Línea separadora */}
        <div className="w-0.5 h-8 bg-gradient-to-b from-blue-600 to-gray-300 pointer-events-none"></div>

        {/* Botón de bajar */}
        <Button
          onClick={scrollDown}
          className="w-12 h-12 rounded-full bg-blue-600 hover:bg-blue-700 shadow-lg hover:shadow-xl transition-all duration-200 p-0 flex items-center justify-center relative z-10"
          title="Bajar"
        >
          <ChevronDown className="h-6 w-6 pointer-events-none" />
        </Button>

        {/* Separador adicional */}
        <div className="w-0.5 h-4 bg-gray-300 pointer-events-none"></div>

        {/* Botón de login */}
        <Button
          onClick={onLogin}
          className="w-12 h-12 rounded-full bg-green-600 hover:bg-green-700 shadow-lg hover:shadow-xl transition-all duration-200 p-0 flex items-center justify-center relative z-10"
          title="Iniciar Sesión"
        >
          <LogIn className="h-5 w-5 pointer-events-none" />
        </Button>

        {/* Botón para volver arriba (solo se muestra después de scroll) */}
        {showScrollTop && (
          <div className="mt-2">
            <Button
              onClick={scrollToTop}
              className="w-10 h-10 rounded-full bg-gray-600 hover:bg-gray-700 shadow-lg hover:shadow-xl transition-all duration-200 p-0 flex items-center justify-center relative z-10"
              title="Ir al inicio"
            >
              <ChevronUp className="h-4 w-4 pointer-events-none" />
            </Button>
          </div>
        )}
      </div>

      {/* Indicador visual de página - movido más a la izquierda */}
      <div className="absolute -left-16 top-1/2 transform -translate-y-1/2 pointer-events-none">
        <div className="flex flex-col items-center space-y-2">
          <div className="w-1 h-12 bg-gradient-to-b from-blue-600 via-purple-500 to-green-500 rounded-full opacity-70"></div>
          <div className="text-xs text-gray-500 font-medium transform -rotate-90 whitespace-nowrap">
            Explora más
          </div>
        </div>
      </div>
    </div>
  );
};

export default LateralNavigation;
