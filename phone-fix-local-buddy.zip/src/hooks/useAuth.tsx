import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { User, Session } from '@supabase/supabase-js';

interface SubscriptionData {
  subscribed: boolean;
  subscription_tier?: string;
  subscription_end?: string;
  trial_start?: string;
  trial_end?: string;
  is_lifetime_free?: boolean;
  has_access?: boolean;
}

export const useAuth = () => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [subscriptionData, setSubscriptionData] = useState<SubscriptionData | null>(null);
  const [initialCheck, setInitialCheck] = useState(false);

  const checkSubscription = async (currentUser: User) => {
    try {
      // Añadir timeout para evitar que se cuelgue
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 segundos timeout

      const { data, error } = await supabase.functions.invoke('check-subscription', {
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (error) throw error;
      setSubscriptionData(data);
    } catch (error) {
      console.warn('Subscription check failed, working in offline mode:', error);

      // Modo offline: permitir acceso básico sin suscripción
      setSubscriptionData({
        subscribed: false,
        has_access: true, // Permitir acceso básico en modo offline
        subscription_tier: 'offline'
      });
    }
  };

  useEffect(() => {
    // Set up auth state listener FIRST
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        console.log('Auth state change:', event, session?.user?.id);

        setSession(session);
        setUser(session?.user ?? null);

        // Handle different auth events
        if (event === 'SIGNED_IN' && session?.user) {
          // User signed in
          checkSubscription(session.user).catch(console.warn);
        } else if (event === 'SIGNED_OUT' || !session?.user) {
          // User signed out or no session
          setSubscriptionData({
            subscribed: false,
            has_access: true,
            is_lifetime_free: true
          });
        }

        setLoading(false);
      }
    );

    // Check for existing session with timeout
    const checkInitialSession = async () => {
      try {
        const { data: { session }, error } = await supabase.auth.getSession();

        if (error) {
          console.warn('Session check failed:', error);
        }

        setSession(session);
        setUser(session?.user ?? null);

        if (session?.user) {
          checkSubscription(session.user).catch(console.warn);
        } else {
          // Set default subscription data for non-authenticated users
          setSubscriptionData({
            subscribed: false,
            has_access: true, // Allow offline access
            is_lifetime_free: true
          });
        }

        setInitialCheck(true);
        setLoading(false);
      } catch (error) {
        console.warn('Session check failed, continuing in offline mode:', error);
        setSession(null);
        setUser(null);
        setSubscriptionData({
          subscribed: false,
          has_access: true, // Allow offline access
          is_lifetime_free: true
        });
        setInitialCheck(true);
        setLoading(false);
      }
    };

    // Add small delay to prevent immediate auth error display
    setTimeout(checkInitialSession, 100);

    return () => subscription.unsubscribe();
  }, []);

  const signOut = async () => {
    try {
      setLoading(true);

      // Clear states immediately to prevent session errors
      setUser(null);
      setSession(null);
      setSubscriptionData({
        subscribed: false,
        has_access: true,
        is_lifetime_free: true
      });

      // Clear any stored auth data
      if (typeof window !== 'undefined') {
        // Clear any auth-related localStorage items
        Object.keys(localStorage).forEach(key => {
          if (key.includes('supabase') || key.includes('auth')) {
            localStorage.removeItem(key);
          }
        });
      }

      // Then sign out from Supabase with error handling
      const { error } = await supabase.auth.signOut({ scope: 'local' });

      if (error && !error.message.includes('session_not_found')) {
        console.warn('Sign out warning (but continuing):', error);
      }

    } catch (error: any) {
      console.warn('Sign out failed, but clearing local state:', error);
      // Force clear everything even if Supabase fails completely
      setUser(null);
      setSession(null);
      setSubscriptionData({
        subscribed: false,
        has_access: true,
        is_lifetime_free: true
      });
    } finally {
      setLoading(false);
      setInitialCheck(true);
    }
  };

  return {
    user,
    session,
    loading,
    subscriptionData,
    initialCheck,
    signOut,
    checkSubscription: () => user && checkSubscription(user),
  };
};
