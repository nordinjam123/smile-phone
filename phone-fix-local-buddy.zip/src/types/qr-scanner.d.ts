declare module 'qr-scanner' {
  export default class QrScanner {
    constructor(
      video: HTMLVideoElement,
      onDecode: (result: { data: string }) => void,
      options?: {
        returnDetailedScanResult?: boolean;
        highlightScanRegion?: boolean;
        highlightCodeOutline?: boolean;
        preferredCamera?: 'environment' | 'user';
      }
    );

    start(): Promise<void>;
    stop(): void;
    destroy(): void;
    
    static hasCamera(): Promise<boolean>;
  }
}
