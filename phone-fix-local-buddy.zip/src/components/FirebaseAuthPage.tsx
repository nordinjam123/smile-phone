import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { 
  Loader2, 
  Wrench, 
  AlertCircle, 
  Chrome,
  Database,
  Shield,
  Zap
} from 'lucide-react';
import { z } from 'zod';
import { firebaseService, FirebaseUser } from '@/lib/firebaseService';
import LandingPage from './LandingPage';

// Input validation schemas
const loginSchema = z.object({
  email: z.string().email('Email inválido').min(1, 'Email es requerido'),
  password: z.string().min(6, 'La contraseña debe tener al menos 6 caracteres'),
});

const signupSchema = z.object({
  email: z.string().email('Email inválido').min(1, 'Email es requerido'),
  password: z.string().min(8, 'La contraseña debe tener al menos 8 caracteres')
    .regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/, 'La contraseña debe incluir mayúsculas, minúsculas y números'),
  workshopName: z.string().min(2, 'Nombre del taller debe tener al menos 2 caracteres')
    .max(100, 'Nombre demasiado largo').trim(),
  contactPerson: z.string().min(2, 'Nombre de contacto debe tener al menos 2 caracteres')
    .max(100, 'Nombre demasiado largo').trim(),
});

interface FirebaseAuthPageProps {
  onAuthSuccess: (user: FirebaseUser) => void;
}

const FirebaseAuthPage: React.FC<FirebaseAuthPageProps> = ({ onAuthSuccess }) => {
  const [showAuthForm, setShowAuthForm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [workshopName, setWorkshopName] = useState('');
  const [contactPerson, setContactPerson] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isFirebaseReady, setIsFirebaseReady] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    // Try to load saved Firebase config
    initializeFirebase();
  }, []);

  const initializeFirebase = async () => {
    try {
      const initialized = await firebaseService.loadSavedConfig();
      setIsFirebaseReady(initialized);
      
      if (initialized) {
        // Set up auth state listener
        const unsubscribe = firebaseService.onAuthStateChanged((user) => {
          if (user) {
            onAuthSuccess(user);
          }
        });
        
        return unsubscribe;
      }
    } catch (error) {
      console.error('Error initializing Firebase:', error);
    }
  };

  // Sanitize input to prevent XSS
  const sanitizeInput = (input: string): string => {
    return input.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
                .replace(/[<>]/g, '')
                .trim();
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrors({});

    try {
      // Validate input
      const validationResult = loginSchema.safeParse({ email, password });
      if (!validationResult.success) {
        const fieldErrors: Record<string, string> = {};
        validationResult.error.errors.forEach((error) => {
          fieldErrors[error.path[0] as string] = error.message;
        });
        setErrors(fieldErrors);
        return;
      }

      const { user, error } = await firebaseService.signInWithEmail(
        sanitizeInput(email),
        password
      );

      if (error) throw new Error(error);

      if (user) {
        onAuthSuccess(user);
        toast({
          title: "¡Bienvenido!",
          description: "Has iniciado sesión correctamente con Firebase.",
        });
      }
    } catch (error: any) {
      console.error('Login error:', error);
      
      let errorMessage = "Error al iniciar sesión";
      if (error?.message) {
        errorMessage = error.message;
      }

      setErrors({ general: errorMessage });
      toast({
        title: "Error de autenticación",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrors({});

    try {
      // Validate input
      const validationResult = signupSchema.safeParse({ 
        email, 
        password, 
        workshopName, 
        contactPerson 
      });
      
      if (!validationResult.success) {
        const fieldErrors: Record<string, string> = {};
        validationResult.error.errors.forEach((error) => {
          fieldErrors[error.path[0] as string] = error.message;
        });
        setErrors(fieldErrors);
        return;
      }

      const { user, error } = await firebaseService.signUpWithEmail(
        sanitizeInput(email),
        password,
        {
          workshopName: sanitizeInput(workshopName),
          contactPerson: sanitizeInput(contactPerson),
        }
      );

      if (error) throw new Error(error);

      if (user) {
        toast({
          title: "¡Registro exitoso!",
          description: "Tu cuenta ha sido creada correctamente.",
        });
        onAuthSuccess(user);
      }
    } catch (error: any) {
      console.error('Signup error:', error);
      const errorMessage = error?.message || "Error al registrarse";
      setErrors({ general: errorMessage });
      toast({
        title: "Error de registro",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setGoogleLoading(true);
    setErrors({});

    try {
      const { user, error } = await firebaseService.signInWithGoogle();

      if (error) throw new Error(error);

      if (user) {
        onAuthSuccess(user);
        toast({
          title: "¡Bienvenido!",
          description: "Has iniciado sesión correctamente con Google.",
        });
      }
    } catch (error: any) {
      console.error('Google sign in error:', error);
      const errorMessage = error?.message || "Error al iniciar sesión con Google";
      setErrors({ general: errorMessage });
      toast({
        title: "Error de autenticación",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setGoogleLoading(false);
    }
  };

  // Show landing page by default, auth form when requested
  if (!showAuthForm) {
    return <LandingPage onGetStarted={() => setShowAuthForm(true)} />;
  }

  // Show Firebase setup message if not configured
  if (!isFirebaseReady) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50 p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <div className="p-3 bg-gradient-to-br from-orange-500 to-red-500 rounded-xl">
                <Database className="h-8 w-8 text-white" />
              </div>
            </div>
            <CardTitle className="text-2xl font-bold text-gray-900">
              🔥 Firebase Requerido
            </CardTitle>
            <CardDescription>
              Para usar la autenticación con Google, necesitas configurar Firebase primero
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
              <h4 className="font-medium text-blue-900 mb-2">¿Qué es Firebase?</h4>
              <p className="text-sm text-blue-700">
                Firebase es la plataforma de Google para desarrollo de aplicaciones. 
                Incluye autenticación, base de datos en tiempo real y más.
              </p>
            </div>
            
            <div className="space-y-2">
              <h5 className="font-medium text-gray-900">Características incluidas:</h5>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <Shield className="h-4 w-4 text-green-500" />
                  <span>Autenticación con Google y Email</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Database className="h-4 w-4 text-blue-500" />
                  <span>Base de datos Firestore en tiempo real</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Zap className="h-4 w-4 text-yellow-500" />
                  <span>Sincronización automática entre dispositivos</span>
                </div>
              </div>
            </div>

            <Button
              onClick={() => setShowAuthForm(false)}
              variant="outline"
              className="w-full"
            >
              Volver y Configurar Firebase
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex">
      {/* Left side - Hero section */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-orange-600 via-red-600 to-pink-700 relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-orange-800/50 to-transparent"></div>
        
        {/* Animated background elements */}
        <div className="absolute top-20 left-20 w-32 h-32 bg-yellow-400/20 rounded-full blur-xl animate-pulse"></div>
        <div className="absolute bottom-40 right-20 w-24 h-24 bg-pink-400/20 rounded-full blur-xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-10 w-16 h-16 bg-red-400/20 rounded-full blur-xl animate-pulse delay-500"></div>
        
        <div className="relative z-10 flex flex-col justify-center px-12 text-white">
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-3 bg-white/10 backdrop-blur-sm rounded-xl border border-white/20">
                <Database className="h-8 w-8 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold">Firebase + TallerPro</h1>
                <p className="text-orange-200 text-sm">Powered by Google Cloud</p>
              </div>
            </div>
            
            <h2 className="text-4xl font-bold mb-4 leading-tight">
              Tu taller en la nube con la tecnología de Google
            </h2>
            <p className="text-xl text-orange-100 mb-8 leading-relaxed">
              Autenticación Google nativa, sincronización en tiempo real y tu propia infraestructura Firebase.
              Todo integrado en una experiencia perfecta.
            </p>
            
            <div className="grid grid-cols-1 gap-4 mb-8">
              <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm rounded-lg p-3 border border-white/20">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <span className="text-sm">Autenticación Google instantánea</span>
              </div>
              <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm rounded-lg p-3 border border-white/20">
                <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                <span className="text-sm">Sincronización en tiempo real</span>
              </div>
              <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm rounded-lg p-3 border border-white/20">
                <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></div>
                <span className="text-sm">Tu propia infraestructura Firebase</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Right side - Login form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 bg-gray-50">
        <Card className="w-full max-w-lg border-0 shadow-2xl bg-white">
          <CardHeader className="text-center pb-2">
            {/* Mobile logo */}
            <div className="flex justify-center mb-6 lg:hidden">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-gradient-to-br from-orange-600 to-red-600 rounded-xl">
                  <Database className="h-8 w-8 text-white" />
                </div>
                <div className="text-left">
                  <h1 className="text-2xl font-bold text-gray-900">TallerPro</h1>
                  <p className="text-sm text-gray-600">Firebase Edition</p>
                </div>
              </div>
            </div>
            
            <CardTitle className="text-3xl font-bold text-gray-900 mb-2">
              Bienvenido
            </CardTitle>
            <CardDescription className="text-lg text-gray-600">
              Accede con tu cuenta Google o email
            </CardDescription>
          </CardHeader>

          <CardContent className="px-8 pb-8">
            {/* Google Sign In Button */}
            <div className="mb-6">
              <Button
                onClick={handleGoogleSignIn}
                disabled={googleLoading}
                className="w-full h-12 bg-white border-2 border-gray-200 text-gray-700 hover:bg-gray-50 hover:border-gray-300 transition-all duration-200"
              >
                {googleLoading ? (
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                ) : (
                  <Chrome className="mr-2 h-5 w-5 text-blue-500" />
                )}
                {googleLoading ? 'Conectando...' : 'Continuar con Google'}
              </Button>
            </div>

            <div className="relative mb-6">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-gray-200" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-white px-2 text-gray-500">O continúa con email</span>
              </div>
            </div>

            <Tabs defaultValue="login" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-8 bg-gray-100 p-1 rounded-lg">
                <TabsTrigger value="login" className="rounded-md transition-all duration-200 data-[state=active]:bg-white data-[state=active]:shadow-md">Iniciar Sesión</TabsTrigger>
                <TabsTrigger value="signup" className="rounded-md transition-all duration-200 data-[state=active]:bg-white data-[state=active]:shadow-md">Registrarse</TabsTrigger>
              </TabsList>

              <TabsContent value="login" className="space-y-6">
                <form onSubmit={handleLogin} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-sm font-medium text-gray-700">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="tu@email.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className={`h-12 px-4 rounded-lg border-2 transition-all duration-200 focus:border-orange-500 focus:ring-2 focus:ring-orange-200 ${errors.email ? 'border-red-300 focus:border-red-500 focus:ring-red-200' : 'border-gray-200'}`}
                      required
                    />
                    {errors.email && (
                      <div className="flex items-center gap-2 text-sm text-red-600 mt-1">
                        <AlertCircle className="h-4 w-4" />
                        {errors.email}
                      </div>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password" className="text-sm font-medium text-gray-700">Contraseña</Label>
                    <Input
                      id="password"
                      type="password"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className={`h-12 px-4 rounded-lg border-2 transition-all duration-200 focus:border-orange-500 focus:ring-2 focus:ring-orange-200 ${errors.password ? 'border-red-300 focus:border-red-500 focus:ring-red-200' : 'border-gray-200'}`}
                      required
                    />
                    {errors.password && (
                      <div className="flex items-center gap-2 text-sm text-red-600 mt-1">
                        <AlertCircle className="h-4 w-4" />
                        {errors.password}
                      </div>
                    )}
                  </div>
                  
                  {errors.general && (
                    <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                      <div className="flex items-center gap-2 text-sm text-red-700">
                        <AlertCircle className="h-4 w-4" />
                        {errors.general}
                      </div>
                    </div>
                  )}
                  
                  <Button 
                    type="submit" 
                    className="w-full h-12 bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white font-semibold rounded-lg transition-all duration-200 transform hover:scale-[1.02] active:scale-[0.98]" 
                    disabled={loading}
                  >
                    {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    {loading ? 'Iniciando sesión...' : 'Iniciar Sesión'}
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="signup" className="space-y-6">
                <form onSubmit={handleSignUp} className="space-y-5">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="workshop-name" className="text-sm font-medium text-gray-700">Nombre del Taller</Label>
                      <Input
                        id="workshop-name"
                        type="text"
                        placeholder="Mi Taller de Reparaciones"
                        value={workshopName}
                        onChange={(e) => setWorkshopName(e.target.value)}
                        className={`h-12 px-4 rounded-lg border-2 transition-all duration-200 focus:border-orange-500 focus:ring-2 focus:ring-orange-200 ${errors.workshopName ? 'border-red-300 focus:border-red-500 focus:ring-red-200' : 'border-gray-200'}`}
                        required
                      />
                      {errors.workshopName && (
                        <div className="flex items-center gap-2 text-sm text-red-600 mt-1">
                          <AlertCircle className="h-4 w-4" />
                          {errors.workshopName}
                        </div>
                      )}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="contact-person" className="text-sm font-medium text-gray-700">Persona de Contacto</Label>
                      <Input
                        id="contact-person"
                        type="text"
                        placeholder="Juan Pérez"
                        value={contactPerson}
                        onChange={(e) => setContactPerson(e.target.value)}
                        className={`h-12 px-4 rounded-lg border-2 transition-all duration-200 focus:border-orange-500 focus:ring-2 focus:ring-orange-200 ${errors.contactPerson ? 'border-red-300 focus:border-red-500 focus:ring-red-200' : 'border-gray-200'}`}
                        required
                      />
                      {errors.contactPerson && (
                        <div className="flex items-center gap-2 text-sm text-red-600 mt-1">
                          <AlertCircle className="h-4 w-4" />
                          {errors.contactPerson}
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="signup-email" className="text-sm font-medium text-gray-700">Email</Label>
                    <Input
                      id="signup-email"
                      type="email"
                      placeholder="tu@email.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className={`h-12 px-4 rounded-lg border-2 transition-all duration-200 focus:border-orange-500 focus:ring-2 focus:ring-orange-200 ${errors.email ? 'border-red-300 focus:border-red-500 focus:ring-red-200' : 'border-gray-200'}`}
                      required
                    />
                    {errors.email && (
                      <div className="flex items-center gap-2 text-sm text-red-600 mt-1">
                        <AlertCircle className="h-4 w-4" />
                        {errors.email}
                      </div>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="signup-password" className="text-sm font-medium text-gray-700">Contraseña</Label>
                    <Input
                      id="signup-password"
                      type="password"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className={`h-12 px-4 rounded-lg border-2 transition-all duration-200 focus:border-orange-500 focus:ring-2 focus:ring-orange-200 ${errors.password ? 'border-red-300 focus:border-red-500 focus:ring-red-200' : 'border-gray-200'}`}
                      required
                    />
                    {errors.password && (
                      <div className="flex items-center gap-2 text-sm text-red-600 mt-1">
                        <AlertCircle className="h-4 w-4" />
                        {errors.password}
                      </div>
                    )}
                    <p className="text-xs text-gray-500 mt-1">
                      Mínimo 8 caracteres con mayúsculas, minúsculas y números
                    </p>
                  </div>
                  
                  {errors.general && (
                    <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                      <div className="flex items-center gap-2 text-sm text-red-700">
                        <AlertCircle className="h-4 w-4" />
                        {errors.general}
                      </div>
                    </div>
                  )}
                  
                  <Button
                    type="submit"
                    className="w-full h-12 bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white font-semibold rounded-lg transition-all duration-200 transform hover:scale-[1.02] active:scale-[0.98]"
                    disabled={loading}
                  >
                    {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    {loading ? 'Creando cuenta...' : 'Crear Cuenta'}
                  </Button>
                </form>
              </TabsContent>
            </Tabs>

            {/* Firebase info */}
            <div className="mt-8 p-6 bg-gradient-to-r from-orange-50 to-red-50 rounded-xl border border-orange-100">
              <h3 className="font-semibold text-sm text-gray-800 mb-3 text-center">🔥 Powered by Firebase</h3>
              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="bg-white p-3 rounded-lg border border-gray-200">
                  <Shield className="h-6 w-6 mx-auto mb-1 text-green-500" />
                  <div className="text-xs text-gray-600">Seguro</div>
                </div>
                <div className="bg-white p-3 rounded-lg border-2 border-orange-300 relative">
                  <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 bg-orange-600 text-white text-xs px-2 py-1 rounded">Google</div>
                  <Database className="h-6 w-6 mx-auto mb-1 text-blue-500" />
                  <div className="text-xs text-gray-600">En la Nube</div>
                </div>
                <div className="bg-white p-3 rounded-lg border border-gray-200">
                  <Zap className="h-6 w-6 mx-auto mb-1 text-yellow-500" />
                  <div className="text-xs text-gray-600">Rápido</div>
                </div>
              </div>
            </div>

            {/* Back to landing page button */}
            <div className="mt-4 text-center">
              <Button
                variant="ghost"
                onClick={() => setShowAuthForm(false)}
                className="text-sm text-gray-600 hover:text-gray-800 hover:bg-gray-100 transition-colors"
              >
                ← Volver a la página principal
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default FirebaseAuthPage;
