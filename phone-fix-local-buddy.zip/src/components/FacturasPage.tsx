import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import jsPDF from "jspdf";
import QRCode from "qrcode";
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  FileText,
  Download,
  DollarSign,
  User,
  Calendar,
  Printer,
  Clock,
  MessageSquare,
  Mail,
  Upload,
  Building,
  FileImage,
  Receipt,
  ScanLine,
  QrCode
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { format } from "date-fns";
import BarcodeScanner from "./BarcodeScanner";
import QRReader from "./QRReader";
import { es } from "date-fns/locale";
import { useEmpresaConfig } from "@/hooks/useEmpresaConfig";

interface Factura {
  id: string;
  numero: string;
  cliente_nombre: string;
  cliente_cif: string;
  cliente_nif: string;
  cliente_telefono: string;
  cliente_email: string;
  cliente_direccion: string;
  cliente_tipo_documento?: "CIF" | "NIF";
  fecha: string;
  conceptos: ConceptoFactura[];
  subtotal: number;
  iva: number;
  total: number;
  estado: "borrador" | "enviada" | "pagada";
  tipo: "servicio" | "venta_moviles" | "inventario";
  notas: string;
  logo_url?: string;
  empresa_nombre: string;
  empresa_cif: string;
  empresa_direccion: string;
  empresa_telefono: string;
  empresa_email: string;
  empresa_tipo_documento?: "CIF" | "NIF";
  created_at: string;
  updated_at: string;
}

interface ConceptoFactura {
  id: string;
  descripcion: string;
  cantidad: number;
  precio: number;
  total: number;
}

const estadoColors = {
  borrador: "bg-gray-100 text-gray-800 border-gray-300",
  enviada: "bg-blue-100 text-blue-800 border-blue-300",
  pagada: "bg-green-100 text-green-800 border-green-300"
};

const estadoLabels = {
  borrador: "Borrador",
  enviada: "Enviada",
  pagada: "Pagada"
};

export default function FacturasPage() {
  const [facturas, setFacturas] = useState<Factura[]>([]);
  const [clientes] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterEstado, setFilterEstado] = useState<string>("todas");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingFactura, setEditingFactura] = useState<Factura | null>(null);
  const [loading, setLoading] = useState(true);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [moviles, setMoviles] = useState<any[]>([]);
  const [inventario, setInventario] = useState<any[]>([]);
  const [isBarcodeSearchOpen, setIsBarcodeSearchOpen] = useState(false);
  const [isQRReaderOpen, setIsQRReaderOpen] = useState(false);
  const { config: configuracionEmpresa } = useEmpresaConfig();
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    cliente_nombre: "",
    cliente_cif: "",
    cliente_nif: "",
    cliente_telefono: "",
    cliente_email: "",
    cliente_direccion: "",
    cliente_tipo_documento: "CIF" as "CIF" | "NIF",
    fecha: format(new Date(), "yyyy-MM-dd"),
    notas: "",
    estado: "borrador" as Factura["estado"],
    tipo: "servicio" as Factura["tipo"],
    empresa_nombre: "",
    empresa_cif: "",
    empresa_direccion: "",
    empresa_telefono: "",
    empresa_email: "",
    empresa_tipo_documento: "CIF" as "CIF" | "NIF",
    logo_url: ""
  });

  const [conceptos, setConceptos] = useState<ConceptoFactura[]>([
    { id: "1", descripcion: "", cantidad: 1, precio: 0, total: 0 }
  ]);

  useEffect(() => {
    fetchFacturas();
    fetchMoviles();
    fetchInventario();
    // Cargar datos de empresa desde perfil o localStorage
    loadEmpresaData();
  }, []);

  const fetchFacturas = async () => {
    try {
      const { data, error } = await supabase
        .from('facturas')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      // Transform data to match our interface
      const facturas = (data || []).map(row => ({
        ...row,
        cliente_cif: row.cliente_cif || "",
        cliente_nif: row.cliente_nif || "",
        conceptos: Array.isArray(row.conceptos) ? row.conceptos as unknown as ConceptoFactura[] : []
      })) as Factura[];
      
      setFacturas(facturas);
    } catch (error) {
      console.error('Error fetching facturas:', error);
      toast({
        title: "Error",
        description: "No se pudieron cargar las facturas",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const loadEmpresaData = async () => {
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) return;

      // Intentar cargar datos del perfil
      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.user.id)
        .single();

      if (profile) {
        setFormData(prev => ({
          ...prev,
          empresa_nombre: profile.workshop_name || "Mi Taller",
          empresa_telefono: profile.phone || "",
          empresa_direccion: profile.address || ""
        }));
      } else {
        // Datos por defecto
        setFormData(prev => ({
          ...prev,
          empresa_nombre: "Mi Taller",
        }));
      }
    } catch (error) {
      console.error('Error loading empresa data:', error);
    }
  };

  const fetchMoviles = async () => {
    try {
      const datos = localStorage.getItem('moviles');
      if (datos) {
        setMoviles(JSON.parse(datos));
      }
    } catch (error) {
      console.error('Error loading moviles:', error);
    }
  };

  const fetchInventario = async () => {
    try {
      const datos = localStorage.getItem('inventario');
      if (datos) {
        setInventario(JSON.parse(datos));
      }
    } catch (error) {
      console.error('Error loading inventario:', error);
    }
  };

  const calcularTotales = () => {
    const subtotal = conceptos.reduce((sum, concepto) => sum + concepto.total, 0);
    const iva = subtotal * 0.21; // IVA fijo al 21%
    const total = subtotal + iva;
    return { subtotal, iva, total };
  };

  const agregarConcepto = () => {
    setConceptos([...conceptos, {
      id: Date.now().toString(),
      descripcion: "",
      cantidad: 1,
      precio: 0,
      total: 0
    }]);
  };

  const agregarMovilSeleccionado = () => {
    if (moviles.length === 0) {
      toast({
        title: "Sin móviles",
        description: "No hay móviles disponibles para vender",
        variant: "destructive"
      });
      return;
    }
    
    const movil = moviles.find(m => m.vendido === false);
    if (!movil) {
      toast({
        title: "Sin móviles",
        description: "No hay móviles sin vender disponibles",
        variant: "destructive"
      });
      return;
    }

    setConceptos([...conceptos, {
      id: Date.now().toString(),
      descripcion: `${movil.marca} ${movil.modelo} (${movil.color})`,
      cantidad: 1,
      precio: movil.precioVenta || 0,
      total: movil.precioVenta || 0
    }]);
  };

  const agregarProductoSeleccionado = () => {
    if (inventario.length === 0) {
      toast({
        title: "Sin productos",
        description: "No hay productos en inventario",
        variant: "destructive"
      });
      return;
    }
    
    const producto = inventario.find(p => p.stock > 0);
    if (!producto) {
      toast({
        title: "Sin stock",
        description: "No hay productos con stock disponible",
        variant: "destructive"
      });
      return;
    }

    setConceptos([...conceptos, {
      id: Date.now().toString(),
      descripcion: `${producto.nombre} - ${producto.marca || ''} ${producto.modelo || ''}`,
      cantidad: 1,
      precio: producto.precio || 0,
      total: producto.precio || 0
    }]);
  };

  const eliminarConcepto = (id: string) => {
    setConceptos(conceptos.filter(c => c.id !== id));
  };

  const actualizarConcepto = (id: string, campo: keyof ConceptoFactura, valor: any) => {
    setConceptos(conceptos.map(concepto => {
      if (concepto.id === id) {
        const updated = { ...concepto, [campo]: valor };
        if (campo === "cantidad" || campo === "precio") {
          updated.total = updated.cantidad * updated.precio;
        }
        return updated;
      }
      return concepto;
    }));
  };

  const generarNumeroFactura = () => {
    const year = new Date().getFullYear();
    const count = facturas.length + 1;
    return `${year}-${count.toString().padStart(4, "0")}`;
  };

  const handleClienteTipoDocumentoChange = (tipo: "CIF" | "NIF") => {
    setFormData(prev => ({
      ...prev,
      cliente_tipo_documento: tipo,
      cliente_cif: "",
      cliente_nif: ""
    }));
  };

  const handleEmpresaTipoDocumentoChange = (tipo: "CIF" | "NIF") => {
    setFormData(prev => ({
      ...prev,
      empresa_tipo_documento: tipo,
      empresa_cif: ""
    }));
  };

  const handleLogoUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast({
        title: "Error",
        description: "Por favor selecciona un archivo de imagen",
        variant: "destructive"
      });
      return;
    }

    setUploadingLogo(true);
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) throw new Error('Usuario no autenticado');

      const fileName = `${user.user.id}/logo-${Date.now()}.${file.name.split('.').pop()}`;
      
      const { error: uploadError } = await supabase.storage
        .from('empresa-logos')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('empresa-logos')
        .getPublicUrl(fileName);

      setFormData(prev => ({ ...prev, logo_url: publicUrl }));
      
      toast({
        title: "Logo subido",
        description: "El logo se ha subido correctamente"
      });
    } catch (error) {
      console.error('Error uploading logo:', error);
      toast({
        title: "Error",
        description: "No se pudo subir el logo",
        variant: "destructive"
      });
    } finally {
      setUploadingLogo(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.cliente_nombre || conceptos.length === 0) {
      toast({
        title: "Error",
        description: "Por favor completa los campos obligatorios",
        variant: "destructive"
      });
      return;
    }

    const totales = calcularTotales();
    
    const { data: user } = await supabase.auth.getUser();
    if (!user.user) {
      toast({
        title: "Error",
        description: "Usuario no autenticado",
        variant: "destructive"
      });
      return;
    }

    const facturaData = {
      numero: editingFactura?.numero || generarNumeroFactura(),
      cliente_nombre: formData.cliente_nombre,
      cliente_cif: formData.cliente_tipo_documento === 'CIF' ? formData.cliente_cif : '',
      cliente_nif: formData.cliente_tipo_documento === 'NIF' ? formData.cliente_cif : formData.cliente_nif,
      cliente_telefono: formData.cliente_telefono,
      cliente_email: formData.cliente_email,
      cliente_direccion: formData.cliente_direccion,
      fecha: formData.fecha,
      conceptos: conceptos as any, // Cast to JSON for Supabase
      subtotal: totales.subtotal,
      iva: totales.iva,
      total: totales.total,
      estado: formData.estado,
      tipo: formData.tipo,
      notas: formData.notas,
      logo_url: formData.logo_url,
      empresa_nombre: formData.empresa_nombre,
      empresa_cif: formData.empresa_cif,
      empresa_direccion: formData.empresa_direccion,
      empresa_telefono: formData.empresa_telefono,
      empresa_email: formData.empresa_email,
      user_id: user.user.id
    };

    try {
      if (editingFactura) {
        const { error } = await supabase
          .from('facturas')
          .update(facturaData)
          .eq('id', editingFactura.id);

        if (error) throw error;
        
        toast({
          title: "Factura actualizada",
          description: "La factura ha sido actualizada exitosamente"
        });
      } else {
        const { error } = await supabase
          .from('facturas')
          .insert(facturaData);

        if (error) throw error;
        
        toast({
          title: "Factura creada",
          description: `Factura ${facturaData.numero} creada exitosamente`
        });
      }

      resetForm();
      setIsDialogOpen(false);
      fetchFacturas();
    } catch (error) {
      console.error('Error saving factura:', {
        error: error,
        message: error?.message || 'Unknown error',
        details: error?.details || 'No details',
        hint: error?.hint || 'No hint',
        code: error?.code || 'No code'
      });
      const errorMessage = error?.message || error?.error_description || 'Error desconocido';
      toast({
        title: "Error",
        description: `No se pudo guardar la factura: ${errorMessage}`,
        variant: "destructive"
      });
    }
  };

  const resetForm = () => {
    setFormData({
      cliente_nombre: "",
      cliente_cif: "",
      cliente_nif: "",
      cliente_telefono: "",
      cliente_email: "",
      cliente_direccion: "",
      cliente_tipo_documento: "CIF",
      fecha: format(new Date(), "yyyy-MM-dd"),
      notas: "",
      estado: "borrador",
      tipo: "servicio",
      empresa_nombre: "",
      empresa_cif: "",
      empresa_direccion: "",
      empresa_telefono: "",
      empresa_email: "",
      empresa_tipo_documento: "CIF",
      logo_url: ""
    });
    setConceptos([{ id: "1", descripcion: "", cantidad: 1, precio: 0, total: 0 }]);
    setEditingFactura(null);
  };

  const handleBarcodeSearch = (code: string) => {
    console.log("Buscando factura con código:", code);

    // Buscar factura por número, cliente o empresa
    const foundFactura = facturas.find(f =>
      f.numero.toLowerCase().includes(code.toLowerCase()) ||
      f.cliente_nombre.toLowerCase().includes(code.toLowerCase()) ||
      f.empresa_nombre?.toLowerCase().includes(code.toLowerCase())
    );

    if (foundFactura) {
      setSearchTerm(code);
      toast({
        title: "Factura encontrada",
        description: `${foundFactura.numero} - ${foundFactura.cliente_nombre}`,
        variant: "default"
      });
    } else {
      toast({
        title: "Factura no encontrada",
        description: `No se encontró ninguna factura con el código: ${code}`,
        variant: "destructive"
      });
    }

    setIsBarcodeSearchOpen(false);
  };

  const handleQRScan = (data: any) => {
    console.log("QR escaneado:", data);

    if (data.tipo === 'FACTURA') {
      // Buscar factura por ID o número
      const foundFactura = facturas.find(f =>
        f.id === data.id || f.numero === data.numero
      );

      if (foundFactura) {
        setSearchTerm(data.numero || data.id);
        toast({
          title: "Factura encontrada",
          description: `${foundFactura.numero} - ${foundFactura.cliente_nombre}`,
          variant: "default"
        });
      } else {
        toast({
          title: "Factura no encontrada",
          description: `No se encontró la factura con ID: ${data.id}`,
          variant: "destructive"
        });
      }
    } else if (data.tipo === 'TPV') {
      toast({
        title: "Ticket TPV detectado",
        description: `Ticket: ${data.id} - Cliente: ${data.cliente}`,
        variant: "default"
      });
    } else if (data.tipo === 'ORDEN_TRABAJO') {
      toast({
        title: "Orden de trabajo detectada",
        description: `Orden: ${data.id} - Cliente: ${data.cliente}`,
        variant: "default"
      });
    } else {
      toast({
        title: "Código detectado",
        description: "Tipo de código no reconocido para facturas",
        variant: "destructive"
      });
    }
  };

  const handleEdit = (factura: Factura) => {
    setEditingFactura(factura);
    setFormData({
      cliente_nombre: factura.cliente_nombre,
      cliente_cif: factura.cliente_cif || "",
      cliente_nif: factura.cliente_nif || "",
      cliente_telefono: factura.cliente_telefono || "",
      cliente_email: factura.cliente_email || "",
      cliente_direccion: factura.cliente_direccion || "",
      cliente_tipo_documento: factura.cliente_tipo_documento || (factura.cliente_cif ? "CIF" : "NIF"),
      fecha: factura.fecha,
      notas: factura.notas || "",
      estado: factura.estado,
      tipo: factura.tipo || "servicio",
      empresa_nombre: factura.empresa_nombre || "",
      empresa_cif: factura.empresa_cif || "",
      empresa_direccion: factura.empresa_direccion || "",
      empresa_telefono: factura.empresa_telefono || "",
      empresa_email: factura.empresa_email || "",
      empresa_tipo_documento: factura.empresa_tipo_documento || "CIF",
      logo_url: factura.logo_url || ""
    });
    setConceptos(factura.conceptos);
    setIsDialogOpen(true);
  };

  const handleDelete = async (id: string) => {
    try {
      const { error } = await supabase
        .from('facturas')
        .delete()
        .eq('id', id);

      if (error) throw error;
      
      toast({
        title: "Factura eliminada",
        description: "La factura ha sido eliminada"
      });
      
      fetchFacturas();
    } catch (error) {
      console.error('Error deleting factura:', error);
      toast({
        title: "Error",
        description: "No se pudo eliminar la factura",
        variant: "destructive"
      });
    }
  };

  const generarPDF = (factura: Factura) => {
    const doc = new jsPDF();
    
    // Header con gradiente azul tecnológico
    doc.setFillColor(37, 99, 235);
    doc.rect(0, 0, 210, 25, 'F');
    
    // Título principal
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(20);
    doc.text("SERVICIO TÉCNICO MÓVILES", 105, 16, { align: 'center' });
    
    // Información de la empresa
    doc.setTextColor(37, 99, 235);
    doc.setFontSize(18);
    doc.text(factura.empresa_nombre || "TechMobile Repair", 20, 45);
    
    doc.setTextColor(75, 85, 99);
    doc.setFontSize(11);
    const tipoDocEmpresa = (factura.empresa_cif && factura.empresa_cif.match(/^[A-Z]/)) ? 'CIF' : 'NIF';
    doc.text(`${tipoDocEmpresa}: ${factura.empresa_cif || ''}`, 20, 55);
    doc.text(factura.empresa_direccion || "", 20, 63);
    doc.text(`Tel: ${factura.empresa_telefono}`, 20, 71);
    doc.text(`Email: ${factura.empresa_email}`, 20, 79);

    // Marco para número de factura
    doc.setFillColor(239, 246, 255);
    doc.rect(130, 40, 70, 25, 'F');
    doc.setDrawColor(37, 99, 235);
    doc.setLineWidth(1);
    doc.rect(130, 40, 70, 25);
    
    // Número de factura
    doc.setTextColor(37, 99, 235);
    doc.setFontSize(16);
    doc.text("FACTURA", 165, 50, { align: 'center' });
    doc.setFontSize(14);
    doc.text(`Nº ${factura.numero}`, 165, 58, { align: 'center' });
    
    // Fecha
    doc.setTextColor(75, 85, 99);
    doc.setFontSize(10);
    doc.text(`Fecha: ${format(new Date(factura.fecha), "dd/MM/yyyy")}`, 140, 70);

    // Sección de cliente
    doc.setFillColor(250, 250, 250);
    doc.rect(20, 90, 170, 35, 'F');
    doc.setDrawColor(203, 213, 225);
    doc.rect(20, 90, 170, 35);
    
    doc.setTextColor(37, 99, 235);
    doc.setFontSize(12);
    doc.text("DATOS DEL CLIENTE", 25, 102);
    
    doc.setTextColor(55, 65, 81);
    doc.setFontSize(10);
    let clienteY = 110;
    doc.text(`Nombre: ${factura.cliente_nombre}`, 25, clienteY);
    if (factura.cliente_cif) {
      clienteY += 6;
      const tipoDocCliente = (factura.cliente_cif && factura.cliente_cif.match(/^[A-Z]/)) ? 'CIF' : 'NIF';
      doc.text(`${tipoDocCliente}: ${factura.cliente_cif}`, 25, clienteY);
    }
    if (factura.cliente_nif && !factura.cliente_cif) {
      clienteY += 6;
      doc.text(`NIF: ${factura.cliente_nif}`, 25, clienteY);
    }
    if (factura.cliente_telefono) {
      doc.text(`Tel: ${factura.cliente_telefono}`, 105, 110);
    }
    if (factura.cliente_email) {
      doc.text(`Email: ${factura.cliente_email}`, 105, 116);
    }
    if (factura.cliente_direccion) {
      doc.text(`Dirección: ${factura.cliente_direccion}`, 105, 122);
    }

    // Tabla de servicios
    let y = 140;
    doc.setFillColor(37, 99, 235);
    doc.rect(20, y, 170, 8, 'F');
    
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(10);
    doc.text("SERVICIOS REALIZADOS", 25, y + 6);
    doc.text("CANT", 115, y + 6);
    doc.text("PRECIO", 135, y + 6);
    doc.text("TOTAL", 165, y + 6);
    
    y += 12;
    doc.setTextColor(55, 65, 81);
    factura.conceptos.forEach((concepto, index) => {
      if (index % 2 === 0) {
        doc.setFillColor(248, 250, 252);
        doc.rect(20, y - 2, 170, 8, 'F');
      }
      
      doc.text(concepto.descripcion.substring(0, 45), 25, y + 4);
      doc.text(concepto.cantidad.toString(), 115, y + 4);
      doc.text(`€${concepto.precio.toFixed(2)}`, 135, y + 4);
      doc.text(`€${concepto.total.toFixed(2)}`, 165, y + 4);
      y += 8;
    });

    // Totales
    y += 10;
    doc.setFillColor(239, 246, 255);
    doc.rect(120, y, 70, 25, 'F');
    doc.setDrawColor(37, 99, 235);
    doc.rect(120, y, 70, 25);
    
    doc.setTextColor(75, 85, 99);
    doc.setFontSize(10);
    doc.text(`Subtotal: €${factura.subtotal.toFixed(2)}`, 125, y + 8);
    doc.text(`IVA (21%): €${factura.iva.toFixed(2)}`, 125, y + 15);
    
    doc.setTextColor(37, 99, 235);
    doc.setFontSize(12);
    doc.text(`TOTAL: €${factura.total.toFixed(2)}`, 125, y + 22);

    // Footer con notas
    if (factura.notas) {
      y += 35;
      doc.setTextColor(107, 114, 128);
      doc.setFontSize(9);
      doc.text("Notas:", 20, y);
      doc.text(factura.notas, 20, y + 6);
    }
    
    // Línea decorativa inferior
    doc.setDrawColor(37, 99, 235);
    doc.setLineWidth(2);
    doc.line(20, 280, 190, 280);
    
    // Footer
    doc.setTextColor(156, 163, 175);
    doc.setFontSize(8);
    doc.text("Especialistas en reparación de dispositivos móviles", 105, 290, { align: 'center' });

    doc.save(`factura-${factura.numero}.pdf`);
  };

  const imprimirTicket = async (factura: Factura) => {
    const doc = new jsPDF({
      format: [80, 200], // Formato fijo inicial
      unit: 'mm'
    });

    let y = 10;
    const margen = 5;
    const anchoUtil = 70;

    // Datos para el código QR
    const facturaData = {
      id: factura.id,
      numero: factura.numero,
      tipo: 'FACTURA',
      cliente: factura.cliente_nombre,
      fecha: factura.fecha,
      total: factura.total,
      estado: factura.estado
    };

    // Header del ticket
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    const empresaNombre = factura.empresa_nombre || "TechMobile Repair";
    doc.text(empresaNombre, 40, y, { align: 'center' });
    y += 8;

    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    if (factura.empresa_direccion) {
      doc.text(factura.empresa_direccion, 40, y, { align: 'center' });
      y += 5;
    }
    if (factura.empresa_telefono) {
      doc.text(`Tel: ${factura.empresa_telefono}`, 40, y, { align: 'center' });
      y += 5;
    }
    if (factura.empresa_cif) {
      // Determinar el tipo basándose en el formato del documento
      const tipoDocEmpresa = (factura.empresa_cif && factura.empresa_cif.match(/^[A-Z]/)) ? 'CIF' : 'NIF';
      doc.text(`${tipoDocEmpresa}: ${factura.empresa_cif || ''}`, 40, y, { align: 'center' });
      y += 5;
    }

    // Línea separadora
    y += 3;
    doc.setLineWidth(0.2);
    doc.line(margen, y, anchoUtil, y);
    y += 5;

    // Información de la factura
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text(`FACTURA: ${factura.numero || 'N/A'}`, margen, y);
    y += 6;

    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text(`Fecha: ${format(new Date(factura.fecha), "dd/MM/yyyy")}`, margen, y);
    y += 5;

    doc.text(`Cliente: ${factura.cliente_nombre || 'N/A'}`, margen, y);
    y += 5;

    if (factura.cliente_cif || factura.cliente_nif) {
      let tipoDoc = 'NIF';
      let documento = factura.cliente_nif;

      if (factura.cliente_cif) {
        tipoDoc = (factura.cliente_cif && factura.cliente_cif.match(/^[A-Z]/)) ? 'CIF' : 'NIF';
        documento = factura.cliente_cif;
      }

      doc.text(`${tipoDoc}: ${documento}`, margen, y);
      y += 5;
    }

    if (factura.cliente_telefono) {
      doc.text(`Tel: ${factura.cliente_telefono}`, margen, y);
      y += 5;
    }

    // Línea separadora
    y += 2;
    doc.line(margen, y, anchoUtil, y);
    y += 5;

    // Conceptos
    doc.setFontSize(8);
    doc.setFont('helvetica', 'bold');
    doc.text('CONCEPTO', margen, y);
    doc.text('CANT', 45, y);
    doc.text('PRECIO', 55, y);
    doc.text('TOTAL', 65, y);
    y += 4;

    doc.line(margen, y, anchoUtil, y);
    y += 4;

    doc.setFont('helvetica', 'normal');
    if (factura.conceptos && Array.isArray(factura.conceptos)) {
      factura.conceptos.forEach((concepto) => {
        if (concepto && concepto.descripcion) {
          const descripcion = concepto.descripcion.substring(0, 20);
          doc.text(descripcion, margen, y);
          doc.text((concepto.cantidad || 0).toString(), 45, y);
          doc.text(`€${(concepto.precio || 0).toFixed(2)}`, 55, y);
          doc.text(`€${(concepto.total || 0).toFixed(2)}`, 65, y);
          y += 4;
        }
      });
    }

    // Línea separadora
    y += 2;
    doc.line(margen, y, anchoUtil, y);
    y += 5;

    // Totales
    doc.setFontSize(8);
    doc.text('Subtotal:', margen, y);
    doc.text(`€${(factura.subtotal || 0).toFixed(2)}`, 55, y);
    y += 4;

    doc.text('IVA (21%):', margen, y);
    doc.text(`€${(factura.iva || 0).toFixed(2)}`, 55, y);
    y += 4;

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.text('TOTAL:', margen, y);
    doc.text(`€${(factura.total || 0).toFixed(2)}`, 55, y);
    y += 8;

    // Estado de pago
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    const estadoTexto = factura.estado === 'pagada' ? 'PAGADO' : factura.estado === 'enviada' ? 'PENDIENTE' : 'BORRADOR';
    doc.text(`Estado: ${estadoTexto}`, margen, y);
    y += 6;

    // Notas si existen
    if (factura.notas && factura.notas.trim()) {
      doc.line(margen, y, anchoUtil, y);
      y += 4;
      doc.text('Notas:', margen, y);
      y += 4;
      // Dividir notas en líneas cortas manualmente
      const palabras = factura.notas.split(' ');
      let lineaActual = '';
      palabras.forEach(palabra => {
        const lineaTemporal = lineaActual + (lineaActual ? ' ' : '') + palabra;
        if (lineaTemporal.length > 25) {
          if (lineaActual) {
            doc.text(lineaActual, margen, y);
            y += 4;
          }
          lineaActual = palabra;
        } else {
          lineaActual = lineaTemporal;
        }
      });
      if (lineaActual) {
        doc.text(lineaActual, margen, y);
        y += 4;
      }
      y += 2;
    }

    // Sin código QR en facturas

    // Configuración específica de facturas
    if (configuracionEmpresa.configuracionFacturas?.mostrarEnTicket) {
      y += 3;
      doc.setLineWidth(0.3);
      doc.line(margen, y, anchoUtil, y);
      y += 4;

      if (configuracionEmpresa.configuracionFacturas.textoPersonalizado) {
        doc.setFontSize(7);
        doc.setFont('helvetica', 'bold');
        doc.text(configuracionEmpresa.configuracionFacturas.textoPersonalizado, 40, y, { align: 'center' });
        y += 4;
      }

      if (configuracionEmpresa.configuracionFacturas.informacionAdicional) {
        doc.setFontSize(6);
        doc.setFont('helvetica', 'normal');
        doc.text(configuracionEmpresa.configuracionFacturas.informacionAdicional, 40, y, { align: 'center' });
        y += 4;
      }

      if (configuracionEmpresa.configuracionFacturas.terminos) {
        doc.setFontSize(6);
        doc.setFont('helvetica', 'normal');
        configuracionEmpresa.configuracionFacturas.terminos.split('\n').forEach(termino => {
          if (termino.trim()) {
            doc.text(termino.trim(), margen, y);
            y += 3;
          }
        });
        y += 2;
      }
    }

    // Footer
    y += 5;
    doc.line(margen, y, anchoUtil, y);
    y += 4;

    doc.setFontSize(7);
    doc.text('¡Gracias por su confianza!', 40, y, { align: 'center' });
    y += 4;
    doc.text('Reparación especializada de móviles', 40, y, { align: 'center' });

    // Abrir ventana de impresión directamente
    window.open(doc.output('bloburl'), '_blank');
  };

  const filteredFacturas = facturas.filter(factura => {
    const matchesSearch = factura.cliente_nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         factura.numero.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesEstado = filterEstado === "todas" || factura.estado === filterEstado;
    return matchesSearch && matchesEstado;
  });

  const totalFacturado = facturas
    .filter(f => f.estado === "pagada")
    .reduce((total, factura) => total + factura.total, 0);

  const totalPendiente = facturas
    .filter(f => f.estado === "enviada")
    .reduce((total, factura) => total + factura.total, 0);

  if (loading) {
    return <div className="p-6">Cargando facturas...</div>;
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">Facturas</h1>
          <p className="text-slate-600">Gestiona la facturación de tu negocio</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={resetForm}>
              <Plus className="w-4 h-4 mr-2" />
              Nueva Factura
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingFactura ? "Editar Factura" : "Nueva Factura"}
              </DialogTitle>
            </DialogHeader>

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Datos de la Empresa */}
              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <Building className="w-5 h-5" />
                  Datos de la Empresa
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="empresa_nombre">Nombre de la Empresa *</Label>
                    <Input
                      id="empresa_nombre"
                      value={formData.empresa_nombre}
                      onChange={(e) => setFormData({...formData, empresa_nombre: e.target.value})}
                      placeholder="Nombre de tu empresa"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="empresa_tipo_documento">Tipo de Documento *</Label>
                    <Select value={formData.empresa_tipo_documento} onValueChange={handleEmpresaTipoDocumentoChange}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="CIF">CIF</SelectItem>
                        <SelectItem value="NIF">NIF</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="empresa_cif">
                      {formData.empresa_tipo_documento === "CIF" ? "CIF" : "NIF"} *
                    </Label>
                    <Input
                      id="empresa_cif"
                      value={formData.empresa_cif}
                      onChange={(e) => setFormData({...formData, empresa_cif: e.target.value})}
                      placeholder={formData.empresa_tipo_documento === "CIF" ? "A12345678" : "12345678X"}
                      required
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                  <div>
                    <Label htmlFor="empresa_direccion">Dirección *</Label>
                    <Input
                      id="empresa_direccion"
                      value={formData.empresa_direccion}
                      onChange={(e) => setFormData({...formData, empresa_direccion: e.target.value})}
                      placeholder="Calle, número, ciudad"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="empresa_telefono">Teléfono</Label>
                    <Input
                      id="empresa_telefono"
                      value={formData.empresa_telefono}
                      onChange={(e) => setFormData({...formData, empresa_telefono: e.target.value})}
                      placeholder="Teléfono de contacto"
                    />
                  </div>
                  <div>
                    <Label htmlFor="empresa_email">Email</Label>
                    <Input
                      id="empresa_email"
                      type="email"
                      value={formData.empresa_email}
                      onChange={(e) => setFormData({...formData, empresa_email: e.target.value})}
                      placeholder="email@empresa.com"
                    />
                  </div>
                </div>
              </div>

              {/* Datos del Cliente */}
              <div className="bg-green-50 p-4 rounded-lg">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <User className="w-5 h-5" />
                  Datos del Cliente
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <Label htmlFor="cliente_nombre">Nombre del Cliente *</Label>
                    <Input
                      id="cliente_nombre"
                      value={formData.cliente_nombre}
                      onChange={(e) => setFormData({...formData, cliente_nombre: e.target.value})}
                      placeholder="Nombre del cliente"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="cliente_tipo_documento">Tipo de Documento</Label>
                    <Select value={formData.cliente_tipo_documento} onValueChange={handleClienteTipoDocumentoChange}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="CIF">CIF</SelectItem>
                        <SelectItem value="NIF">NIF</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="cliente_cif">
                      {formData.cliente_tipo_documento === "CIF" ? "CIF" : "NIF"}
                    </Label>
                    <Input
                      id="cliente_cif"
                      value={formData.cliente_cif || formData.cliente_nif}
                      onChange={(e) => setFormData({...formData, cliente_cif: e.target.value, cliente_nif: e.target.value})}
                      placeholder={formData.cliente_tipo_documento === "CIF" ? "A12345678" : "12345678X"}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                  <div>
                    <Label htmlFor="cliente_telefono">Teléfono</Label>
                    <Input
                      id="cliente_telefono"
                      value={formData.cliente_telefono}
                      onChange={(e) => setFormData({...formData, cliente_telefono: e.target.value})}
                      placeholder="Teléfono del cliente"
                    />
                  </div>
                  <div>
                    <Label htmlFor="cliente_email">Email</Label>
                    <Input
                      id="cliente_email"
                      type="email"
                      value={formData.cliente_email}
                      onChange={(e) => setFormData({...formData, cliente_email: e.target.value})}
                      placeholder="Email del cliente"
                    />
                  </div>
                  <div>
                    <Label htmlFor="cliente_direccion">Dirección</Label>
                    <Input
                      id="cliente_direccion"
                      value={formData.cliente_direccion}
                      onChange={(e) => setFormData({...formData, cliente_direccion: e.target.value})}
                      placeholder="Dirección del cliente"
                    />
                  </div>
                </div>
              </div>

              {/* Tipo, Fecha y Estado */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="tipo">Tipo de Factura *</Label>
                  <Select value={formData.tipo} onValueChange={(value: Factura["tipo"]) => setFormData({...formData, tipo: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="servicio">Servicios de Reparación</SelectItem>
                      <SelectItem value="venta_moviles">Venta de Móviles</SelectItem>
                      <SelectItem value="inventario">Venta de Inventario</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="fecha">Fecha de Factura *</Label>
                  <Input
                    id="fecha"
                    type="date"
                    value={formData.fecha}
                    onChange={(e) => setFormData({...formData, fecha: e.target.value})}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="estado">Estado</Label>
                  <Select value={formData.estado} onValueChange={(value: Factura["estado"]) => setFormData({...formData, estado: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="borrador">Borrador</SelectItem>
                      <SelectItem value="enviada">Enviada</SelectItem>
                      <SelectItem value="pagada">Pagada</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Conceptos */}
              <div>
                <div className="flex justify-between items-center mb-4">
                  <Label className="text-lg font-semibold">
                    {formData.tipo === "servicio" && "Servicios de Reparación"}
                    {formData.tipo === "venta_moviles" && "Móviles a Vender"}
                    {formData.tipo === "inventario" && "Productos de Inventario"}
                  </Label>
                  {formData.tipo === "servicio" && (
                    <Button type="button" onClick={agregarConcepto} variant="outline" size="sm">
                      <Plus className="w-4 h-4 mr-2" />
                      Agregar Servicio
                    </Button>
                  )}
                  {formData.tipo === "venta_moviles" && (
                    <Button type="button" onClick={agregarMovilSeleccionado} variant="outline" size="sm">
                      <Plus className="w-4 h-4 mr-2" />
                      Agregar Móvil
                    </Button>
                  )}
                  {formData.tipo === "inventario" && (
                    <Button type="button" onClick={agregarProductoSeleccionado} variant="outline" size="sm">
                      <Plus className="w-4 h-4 mr-2" />
                      Agregar Producto
                    </Button>
                  )}
                </div>
                
                <div className="space-y-3">
                  {conceptos.map((concepto) => (
                    <div key={concepto.id} className="grid grid-cols-1 md:grid-cols-5 gap-2 p-3 border rounded-lg">
                      <div className="md:col-span-2">
                        <Input
                          placeholder="Descripción del servicio"
                          value={concepto.descripcion}
                          onChange={(e) => actualizarConcepto(concepto.id, "descripcion", e.target.value)}
                        />
                      </div>
                      <div>
                        <Input
                          type="number"
                          min="1"
                          placeholder="Cant."
                          value={concepto.cantidad}
                          onChange={(e) => actualizarConcepto(concepto.id, "cantidad", parseInt(e.target.value) || 0)}
                        />
                      </div>
                      <div>
                        <Input
                          type="number"
                          min="0"
                          step="0.01"
                          placeholder="Precio €"
                          value={concepto.precio}
                          onChange={(e) => actualizarConcepto(concepto.id, "precio", parseFloat(e.target.value) || 0)}
                        />
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium">€{concepto.total.toFixed(2)}</span>
                        {conceptos.length > 1 && (
                          <Button
                            type="button"
                            variant="destructive"
                            size="sm"
                            onClick={() => eliminarConcepto(concepto.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Totales */}
                <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                  <div className="flex justify-end">
                    <div className="w-64 space-y-2">
                      <div className="flex justify-between">
                        <span>Subtotal:</span>
                        <span>€{calcularTotales().subtotal.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>IVA (21%):</span>
                        <span>€{calcularTotales().iva.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between font-bold text-lg border-t pt-2">
                        <span>TOTAL:</span>
                        <span>€{calcularTotales().total.toFixed(2)}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Notas */}
              <div>
                <Label htmlFor="notas">Notas Adicionales</Label>
                <Textarea
                  id="notas"
                  value={formData.notas}
                  onChange={(e) => setFormData({...formData, notas: e.target.value})}
                  placeholder="Términos y condiciones, notas adicionales..."
                  rows={3}
                />
              </div>

              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit">
                  {editingFactura ? "Actualizar" : "Crear"} Factura
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Métricas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Facturas</p>
                <p className="text-2xl font-bold">{facturas.length}</p>
              </div>
              <FileText className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Facturado</p>
                <p className="text-2xl font-bold text-green-600">€{totalFacturado.toLocaleString()}</p>
              </div>
              <DollarSign className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Pendiente</p>
                <p className="text-2xl font-bold text-orange-600">€{totalPendiente.toLocaleString()}</p>
              </div>
              <Clock className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Promedio</p>
                <p className="text-2xl font-bold text-blue-600">
                  €{facturas.length > 0 ? (facturas.reduce((sum, f) => sum + f.total, 0) / facturas.length).toLocaleString() : 0}
                </p>
              </div>
              <User className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar por cliente o número de factura..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Button
              variant="outline"
              onClick={() => setIsBarcodeSearchOpen(true)}
              className="flex items-center gap-2"
            >
              <ScanLine className="w-4 h-4" />
              Código de Barras
            </Button>
            <Button
              variant="outline"
              onClick={() => setIsQRReaderOpen(true)}
              className="flex items-center gap-2"
            >
              <QrCode className="w-4 h-4" />
              Código QR
            </Button>
            <Select value={filterEstado} onValueChange={setFilterEstado}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Filtrar por estado" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todas">Todas las facturas</SelectItem>
                <SelectItem value="borrador">Borrador</SelectItem>
                <SelectItem value="enviada">Enviada</SelectItem>
                <SelectItem value="pagada">Pagada</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Facturas List */}
      <div className="grid gap-4">
        {filteredFacturas.length === 0 ? (
          <Card>
            <CardContent className="pt-6 text-center">
              <FileText className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No hay facturas</h3>
              <p className="text-muted-foreground">
                {searchTerm || filterEstado !== "todas" 
                  ? "No se encontraron facturas con los filtros aplicados"
                  : "Crea tu primera factura para comenzar"
                }
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredFacturas.map((factura) => (
            <Card key={factura.id} className="hover:shadow-md transition-shadow">
              <CardContent className="pt-6">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="text-lg font-semibold">Factura {factura.numero}</h3>
                      <Badge className={estadoColors[factura.estado]}>
                        {estadoLabels[factura.estado]}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <User className="w-4 h-4" />
                        {factura.cliente_nombre}
                      </div>
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {format(new Date(factura.fecha), "dd/MM/yyyy")}
                      </div>
                      <div className="flex items-center gap-1">
                        <DollarSign className="w-4 h-4" />
                        €{factura.total.toFixed(2)}
                      </div>
                      <div className="flex items-center gap-1">
                        <Building className="w-4 h-4" />
                        {factura.empresa_nombre || "Sin empresa"}
                      </div>
                    </div>
                    {factura.notas && (
                      <p className="mt-2 text-sm text-gray-600">{factura.notas}</p>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => generarPDF(factura)}
                      title="Descargar PDF"
                    >
                      <Download className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => imprimirTicket(factura)}
                      title="Imprimir Ticket"
                    >
                      <Receipt className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEdit(factura)}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleDelete(factura.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Escáner para búsqueda */}
      <BarcodeScanner
        isOpen={isBarcodeSearchOpen}
        onClose={() => setIsBarcodeSearchOpen(false)}
        onScan={handleBarcodeSearch}
        title="Buscar Factura por Código de Barras"
      />

      {/* Lector QR */}
      <QRReader
        isOpen={isQRReaderOpen}
        onClose={() => setIsQRReaderOpen(false)}
        onScan={handleQRScan}
        title="Buscar por Código QR"
      />
    </div>
  );
}
