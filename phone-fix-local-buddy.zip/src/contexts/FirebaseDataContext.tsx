import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { firebaseService } from '@/lib/firebaseService';
import { useFirebaseAuth } from '@/hooks/useFirebaseAuth';

interface FirebaseDataContextType {
  // Data collections
  clientes: any[];
  inventario: any[];
  ordenes: any[];
  facturas: any[];
  gastos: any[];
  citas: any[];
  
  // Loading states
  loading: boolean;
  
  // CRUD operations
  addCliente: (cliente: any) => Promise<string | null>;
  updateCliente: (id: string, cliente: any) => Promise<boolean>;
  deleteCliente: (id: string) => Promise<boolean>;
  
  addInventario: (item: any) => Promise<string | null>;
  updateInventario: (id: string, item: any) => Promise<boolean>;
  deleteInventario: (id: string) => Promise<boolean>;
  
  addOrden: (orden: any) => Promise<string | null>;
  updateOrden: (id: string, orden: any) => Promise<boolean>;
  deleteOrden: (id: string) => Promise<boolean>;
  
  addFactura: (factura: any) => Promise<string | null>;
  updateFactura: (id: string, factura: any) => Promise<boolean>;
  deleteFactura: (id: string) => Promise<boolean>;
  
  addGasto: (gasto: any) => Promise<string | null>;
  updateGasto: (id: string, gasto: any) => Promise<boolean>;
  deleteGasto: (id: string) => Promise<boolean>;
  
  addCita: (cita: any) => Promise<string | null>;
  updateCita: (id: string, cita: any) => Promise<boolean>;
  deleteCita: (id: string) => Promise<boolean>;
  
  // Utility functions
  refreshData: () => Promise<void>;
  isOnline: boolean;
}

const FirebaseDataContext = createContext<FirebaseDataContextType | undefined>(undefined);

interface FirebaseDataProviderProps {
  children: ReactNode;
}

export const FirebaseDataProvider: React.FC<FirebaseDataProviderProps> = ({ children }) => {
  const { user, isAuthenticated, isFirebaseReady } = useFirebaseAuth();
  
  // Data states
  const [clientes, setClientes] = useState<any[]>([]);
  const [inventario, setInventario] = useState<any[]>([]);
  const [ordenes, setOrdenes] = useState<any[]>([]);
  const [facturas, setFacturas] = useState<any[]>([]);
  const [gastos, setGastos] = useState<any[]>([]);
  const [citas, setCitas] = useState<any[]>([]);
  
  const [loading, setLoading] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  useEffect(() => {
    if (isAuthenticated && isFirebaseReady) {
      setupRealtimeListeners();
    }
  }, [isAuthenticated, isFirebaseReady]);

  const setupRealtimeListeners = () => {
    // Set up real-time listeners for all collections
    const unsubscribers: (() => void)[] = [];

    unsubscribers.push(
      firebaseService.subscribeToUserDocuments('clientes', setClientes)
    );
    unsubscribers.push(
      firebaseService.subscribeToUserDocuments('inventario', setInventario)
    );
    unsubscribers.push(
      firebaseService.subscribeToUserDocuments('ordenes_trabajo', setOrdenes)
    );
    unsubscribers.push(
      firebaseService.subscribeToUserDocuments('facturas', setFacturas)
    );
    unsubscribers.push(
      firebaseService.subscribeToUserDocuments('gastos_mercancia', setGastos)
    );
    unsubscribers.push(
      firebaseService.subscribeToUserDocuments('citas', setCitas)
    );

    // Return cleanup function
    return () => {
      unsubscribers.forEach(unsubscribe => unsubscribe());
    };
  };

  const refreshData = async () => {
    if (!isAuthenticated || !isFirebaseReady) return;

    setLoading(true);
    try {
      const [
        clientesData,
        inventarioData,
        ordenesData,
        facturasData,
        gastosData,
        citasData
      ] = await Promise.all([
        firebaseService.getUserDocuments('clientes'),
        firebaseService.getUserDocuments('inventario'),
        firebaseService.getUserDocuments('ordenes_trabajo'),
        firebaseService.getUserDocuments('facturas'),
        firebaseService.getUserDocuments('gastos_mercancia'),
        firebaseService.getUserDocuments('citas')
      ]);

      setClientes(clientesData);
      setInventario(inventarioData);
      setOrdenes(ordenesData);
      setFacturas(facturasData);
      setGastos(gastosData);
      setCitas(citasData);
    } catch (error) {
      console.error('Error refreshing data:', error);
    } finally {
      setLoading(false);
    }
  };

  // CRUD operations for Clientes
  const addCliente = async (cliente: any): Promise<string | null> => {
    const { id, error } = await firebaseService.addDocument('clientes', cliente);
    if (error) {
      console.error('Error adding cliente:', error);
      return null;
    }
    return id;
  };

  const updateCliente = async (id: string, cliente: any): Promise<boolean> => {
    const { success, error } = await firebaseService.updateDocument('clientes', id, cliente);
    if (error) {
      console.error('Error updating cliente:', error);
    }
    return success;
  };

  const deleteCliente = async (id: string): Promise<boolean> => {
    const { success, error } = await firebaseService.deleteDocument('clientes', id);
    if (error) {
      console.error('Error deleting cliente:', error);
    }
    return success;
  };

  // CRUD operations for Inventario
  const addInventario = async (item: any): Promise<string | null> => {
    const { id, error } = await firebaseService.addDocument('inventario', item);
    if (error) {
      console.error('Error adding inventario:', error);
      return null;
    }
    return id;
  };

  const updateInventario = async (id: string, item: any): Promise<boolean> => {
    const { success, error } = await firebaseService.updateDocument('inventario', id, item);
    if (error) {
      console.error('Error updating inventario:', error);
    }
    return success;
  };

  const deleteInventario = async (id: string): Promise<boolean> => {
    const { success, error } = await firebaseService.deleteDocument('inventario', id);
    if (error) {
      console.error('Error deleting inventario:', error);
    }
    return success;
  };

  // CRUD operations for Ordenes
  const addOrden = async (orden: any): Promise<string | null> => {
    const { id, error } = await firebaseService.addDocument('ordenes_trabajo', orden);
    if (error) {
      console.error('Error adding orden:', error);
      return null;
    }
    return id;
  };

  const updateOrden = async (id: string, orden: any): Promise<boolean> => {
    const { success, error } = await firebaseService.updateDocument('ordenes_trabajo', id, orden);
    if (error) {
      console.error('Error updating orden:', error);
    }
    return success;
  };

  const deleteOrden = async (id: string): Promise<boolean> => {
    const { success, error } = await firebaseService.deleteDocument('ordenes_trabajo', id);
    if (error) {
      console.error('Error deleting orden:', error);
    }
    return success;
  };

  // CRUD operations for Facturas
  const addFactura = async (factura: any): Promise<string | null> => {
    const { id, error } = await firebaseService.addDocument('facturas', factura);
    if (error) {
      console.error('Error adding factura:', error);
      return null;
    }
    return id;
  };

  const updateFactura = async (id: string, factura: any): Promise<boolean> => {
    const { success, error } = await firebaseService.updateDocument('facturas', id, factura);
    if (error) {
      console.error('Error updating factura:', error);
    }
    return success;
  };

  const deleteFactura = async (id: string): Promise<boolean> => {
    const { success, error } = await firebaseService.deleteDocument('facturas', id);
    if (error) {
      console.error('Error deleting factura:', error);
    }
    return success;
  };

  // CRUD operations for Gastos
  const addGasto = async (gasto: any): Promise<string | null> => {
    const { id, error } = await firebaseService.addDocument('gastos_mercancia', gasto);
    if (error) {
      console.error('Error adding gasto:', error);
      return null;
    }
    return id;
  };

  const updateGasto = async (id: string, gasto: any): Promise<boolean> => {
    const { success, error } = await firebaseService.updateDocument('gastos_mercancia', id, gasto);
    if (error) {
      console.error('Error updating gasto:', error);
    }
    return success;
  };

  const deleteGasto = async (id: string): Promise<boolean> => {
    const { success, error } = await firebaseService.deleteDocument('gastos_mercancia', id);
    if (error) {
      console.error('Error deleting gasto:', error);
    }
    return success;
  };

  // CRUD operations for Citas
  const addCita = async (cita: any): Promise<string | null> => {
    const { id, error } = await firebaseService.addDocument('citas', cita);
    if (error) {
      console.error('Error adding cita:', error);
      return null;
    }
    return id;
  };

  const updateCita = async (id: string, cita: any): Promise<boolean> => {
    const { success, error } = await firebaseService.updateDocument('citas', id, cita);
    if (error) {
      console.error('Error updating cita:', error);
    }
    return success;
  };

  const deleteCita = async (id: string): Promise<boolean> => {
    const { success, error } = await firebaseService.deleteDocument('citas', id);
    if (error) {
      console.error('Error deleting cita:', error);
    }
    return success;
  };

  const value: FirebaseDataContextType = {
    // Data
    clientes,
    inventario,
    ordenes,
    facturas,
    gastos,
    citas,
    
    // Loading
    loading,
    
    // Clientes operations
    addCliente,
    updateCliente,
    deleteCliente,
    
    // Inventario operations
    addInventario,
    updateInventario,
    deleteInventario,
    
    // Ordenes operations
    addOrden,
    updateOrden,
    deleteOrden,
    
    // Facturas operations
    addFactura,
    updateFactura,
    deleteFactura,
    
    // Gastos operations
    addGasto,
    updateGasto,
    deleteGasto,
    
    // Citas operations
    addCita,
    updateCita,
    deleteCita,
    
    // Utilities
    refreshData,
    isOnline
  };

  return (
    <FirebaseDataContext.Provider value={value}>
      {children}
    </FirebaseDataContext.Provider>
  );
};

export const useFirebaseData = (): FirebaseDataContextType => {
  const context = useContext(FirebaseDataContext);
  if (context === undefined) {
    throw new Error('useFirebaseData must be used within a FirebaseDataProvider');
  }
  return context;
};
