// Firebase Messaging Service Worker
// Este archivo debe estar en public/ para que FCM funcione

import { initializeApp } from 'firebase/app';
import { getMessaging, onBackgroundMessage } from 'firebase/messaging';

// Configuración Firebase (debe coincidir con la del app)
const firebaseConfig = {
  apiKey: "AIzaSyDEj8BH-YQXGqV6J5LlE6pO9vGhIwX8abc",
  authDomain: "tallerpro-central.firebaseapp.com",
  projectId: "tallerpro-central",
  storageBucket: "tallerpro-central.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:abcdef123456"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const messaging = getMessaging(app);

// Handle background messages
onBackgroundMessage(messaging, (payload) => {
  console.log('📱 Background Message received:', payload);

  const notificationTitle = payload.notification?.title || 'TallerPro';
  const notificationOptions = {
    body: payload.notification?.body || 'Nueva notificación',
    icon: '/favicon.ico',
    badge: '/favicon.ico',
    tag: 'tallerpro-notification',
    data: payload.data,
    actions: [
      {
        action: 'open',
        title: 'Abrir TallerPro'
      },
      {
        action: 'close',
        title: 'Cerrar'
      }
    ]
  };

  self.registration.showNotification(notificationTitle, notificationOptions);
});

// Handle notification clicks
self.addEventListener('notificationclick', (event) => {
  console.log('🔔 Notification clicked:', event);
  
  event.notification.close();

  if (event.action === 'open' || !event.action) {
    // Open or focus TallerPro window
    event.waitUntil(
      clients.matchAll({ type: 'window' }).then((clientList) => {
        // Check if TallerPro is already open
        for (const client of clientList) {
          if (client.url.includes('tallerpro') && 'focus' in client) {
            return client.focus();
          }
        }
        
        // Open new window if not found
        if (clients.openWindow) {
          return clients.openWindow('/');
        }
      })
    );
  }
});

// Handle push events (for custom handling)
self.addEventListener('push', (event) => {
  if (event.data) {
    const payload = event.data.json();
    console.log('🚀 Push event received:', payload);
    
    // Custom handling for specific notification types
    if (payload.data?.type === 'order_completed') {
      // Show special notification for completed orders
      const options = {
        body: `✅ ${payload.notification.body}`,
        icon: '/favicon.ico',
        badge: '/favicon.ico',
        tag: 'order-completed',
        vibrate: [200, 100, 200],
        actions: [
          {
            action: 'view_order',
            title: 'Ver Orden'
          }
        ]
      };
      
      event.waitUntil(
        self.registration.showNotification(payload.notification.title, options)
      );
    }
  }
});
