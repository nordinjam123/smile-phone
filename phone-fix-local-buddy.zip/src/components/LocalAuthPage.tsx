import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { 
  Loader2, 
  Wrench, 
  AlertCircle, 

  Database,
  Shield,
  Zap,
  Settings,
  HardDrive
} from 'lucide-react';
import { z } from 'zod';
import { useLocalAuth } from '@/hooks/useLocalAuth';
import { LocalUser } from '@/lib/localAuthService';
import LandingPage from './LandingPage';

// Input validation schemas
const loginSchema = z.object({
  email: z.string().email('Email inválido').min(1, 'Email es requerido'),
  password: z.string().min(6, 'La contraseña debe tener al menos 6 caracteres'),
});

const signupSchema = z.object({
  email: z.string().email('Email inválido').min(1, 'Email es requerido'),
  password: z.string().min(6, 'La contraseña debe tener al menos 6 caracteres'),
  workshopName: z.string().min(2, 'Nombre del taller debe tener al menos 2 caracteres')
    .max(100, 'Nombre demasiado largo').trim(),
  contactPerson: z.string().min(2, 'Nombre de contacto debe tener al menos 2 caracteres')
    .max(100, 'Nombre demasiado largo').trim(),
});

interface LocalAuthPageProps {
  onAuthSuccess: (user: LocalUser) => void;
}

const LocalAuthPage: React.FC<LocalAuthPageProps> = ({ onAuthSuccess }) => {
  const [showAuthForm, setShowAuthForm] = useState(false);
  const [loading, setLoading] = useState(false);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [workshopName, setWorkshopName] = useState('');
  const [contactPerson, setContactPerson] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const { toast } = useToast();

  const { user, isAuthenticated, isLoading, signIn, signUp } = useLocalAuth();

  useEffect(() => {
    if (isAuthenticated && user) {
      onAuthSuccess(user);
    }
  }, [isAuthenticated, user, onAuthSuccess]);

  // Sanitize input to prevent XSS
  const sanitizeInput = (input: string): string => {
    return input.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
                .replace(/[<>]/g, '')
                .trim();
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrors({});

    try {
      // Validate input
      const validationResult = loginSchema.safeParse({ email, password });
      if (!validationResult.success) {
        const fieldErrors: Record<string, string> = {};
        validationResult.error.errors.forEach((error) => {
          fieldErrors[error.path[0] as string] = error.message;
        });
        setErrors(fieldErrors);
        return;
      }

      const sanitizedEmail = sanitizeInput(email);
      const { user, error } = await signIn(sanitizedEmail, password);

      if (error) throw new Error(error);

      if (user) {
        toast({
          title: "¡Bienvenido!",
          description: "Has iniciado sesión correctamente.",
        });
        onAuthSuccess(user);
      }
    } catch (error: any) {
      console.error('Login error:', error);
      const errorMessage = error?.message || "Error al iniciar sesión";
      setErrors({ general: errorMessage });
      toast({
        title: "Error de autenticación",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrors({});

    try {
      // Validate input
      const validationResult = signupSchema.safeParse({ 
        email, 
        password, 
        workshopName, 
        contactPerson 
      });
      
      if (!validationResult.success) {
        const fieldErrors: Record<string, string> = {};
        validationResult.error.errors.forEach((error) => {
          fieldErrors[error.path[0] as string] = error.message;
        });
        setErrors(fieldErrors);
        return;
      }

      const sanitizedEmail = sanitizeInput(email);
      const sanitizedWorkshopName = sanitizeInput(workshopName);
      const sanitizedContactPerson = sanitizeInput(contactPerson);

      const { user, error } = await signUp(sanitizedEmail, password, {
        workshopName: sanitizedWorkshopName,
        contactPerson: sanitizedContactPerson
      });

      if (error) throw new Error(error);

      if (user) {
        toast({
          title: "¡Registro exitoso!",
          description: "Tu cuenta ha sido creada correctamente.",
        });
        onAuthSuccess(user);
      }
    } catch (error: any) {
      console.error('Signup error:', error);
      const errorMessage = error?.message || "Error al registrarse";
      setErrors({ general: errorMessage });
      toast({
        title: "Error de registro",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };



  // Show landing page by default, auth form when requested
  if (!showAuthForm) {
    return <LandingPage onGetStarted={() => setShowAuthForm(true)} />;
  }

  // Show loading while auth initializes
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-50 to-blue-50">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <div className="p-3 bg-gradient-to-br from-green-500 to-blue-500 rounded-xl">
                <Settings className="h-8 w-8 text-white" />
              </div>
            </div>
            <CardTitle className="text-2xl font-bold text-gray-900">
              🚀 Iniciando sistema
            </CardTitle>
            <CardDescription>
              Cargando almacenamiento local...
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-center">
              <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
            </div>
            
            <div className="bg-green-50 p-4 rounded-lg border border-green-200">
              <h4 className="font-medium text-green-900 mb-2">💾 Almacenamiento Local</h4>
              <p className="text-sm text-green-700">
                Todos tus datos se guardan localmente en tu dispositivo.
              </p>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm">
                <Shield className="h-4 w-4 text-green-500" />
                <span>Autenticación segura</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <HardDrive className="h-4 w-4 text-blue-500" />
                <span>Almacenamiento local</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Database className="h-4 w-4 text-purple-500" />
                <span>Sin dependencias externas</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex">
      {/* Left side - Hero section */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-green-600 via-blue-600 to-purple-700 relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-green-800/50 to-transparent"></div>
        
        {/* Animated background elements */}
        <div className="absolute top-20 left-20 w-32 h-32 bg-blue-400/20 rounded-full blur-xl animate-pulse"></div>
        <div className="absolute bottom-40 right-20 w-24 h-24 bg-green-400/20 rounded-full blur-xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-10 w-16 h-16 bg-purple-400/20 rounded-full blur-xl animate-pulse delay-500"></div>
        
        <div className="relative z-10 flex flex-col justify-center px-12 text-white">
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-3 bg-white/10 backdrop-blur-sm rounded-xl border border-white/20">
                <HardDrive className="h-8 w-8 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold">TallerPro Local</h1>
                <p className="text-green-200 text-sm">Almacenamiento privado</p>
              </div>
            </div>
            
            <h2 className="text-4xl font-bold mb-4 leading-tight">
              Tus datos, 100% privados
            </h2>
            <p className="text-xl text-green-100 mb-8 leading-relaxed">
              Almacenamiento local seguro, autenticación profesional
              y control total de tu información.
            </p>
            
            <div className="grid grid-cols-1 gap-4 mb-8">
              <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm rounded-lg p-3 border border-white/20">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <span className="text-sm">💾 Almacenamiento local</span>
              </div>
              <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm rounded-lg p-3 border border-white/20">
                <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                <span className="text-sm">🔐 Autenticación segura</span>
              </div>
              <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm rounded-lg p-3 border border-white/20">
                <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse"></div>
                <span className="text-sm">🚀 Sin dependencias de terceros</span>
              </div>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-white/20">
              <h4 className="font-medium mb-2">🔒 Privacidad Total</h4>
              <p className="text-sm text-green-200">
                Tus datos se almacenan únicamente en tu dispositivo local.
                Privacidad y control absoluto.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Right side - Login form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 bg-gray-50">
        <Card className="w-full max-w-lg border-0 shadow-2xl bg-white">
          <CardHeader className="text-center pb-2">
            {/* Mobile logo */}
            <div className="flex justify-center mb-6 lg:hidden">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-gradient-to-br from-green-600 to-blue-600 rounded-xl">
                  <HardDrive className="h-8 w-8 text-white" />
                </div>
                <div className="text-left">
                  <h1 className="text-2xl font-bold text-gray-900">TallerPro</h1>
                  <p className="text-sm text-gray-600">Almacenamiento local</p>
                </div>
              </div>
            </div>
            
            <CardTitle className="text-3xl font-bold text-gray-900 mb-2">
              Bienvenido
            </CardTitle>
            <CardDescription className="text-lg text-gray-600">
              Accede con tu email y contraseña
            </CardDescription>
          </CardHeader>

          <CardContent className="px-8 pb-8">
            <div className="mb-6 p-3 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-xs text-blue-700 text-center">
                💡 <strong>Primera vez:</strong> Usa "Registrarse" para crear tu cuenta, después podrás usar "Iniciar Sesión"
              </p>
            </div>

            <Tabs defaultValue="login" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-8 bg-gray-100 p-1 rounded-lg">
                <TabsTrigger value="login" className="rounded-md transition-all duration-200 data-[state=active]:bg-white data-[state=active]:shadow-md">Iniciar Sesión</TabsTrigger>
                <TabsTrigger value="signup" className="rounded-md transition-all duration-200 data-[state=active]:bg-white data-[state=active]:shadow-md">Registrarse</TabsTrigger>
              </TabsList>

              <TabsContent value="login" className="space-y-6">
                <form onSubmit={handleLogin} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-sm font-medium text-gray-700">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="admin@taller.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className={`h-12 px-4 rounded-lg border-2 transition-all duration-200 focus:border-green-500 focus:ring-2 focus:ring-green-200 ${errors.email ? 'border-red-300 focus:border-red-500 focus:ring-red-200' : 'border-gray-200'}`}
                      required
                    />
                    {errors.email && (
                      <div className="flex items-center gap-2 text-sm text-red-600 mt-1">
                        <AlertCircle className="h-4 w-4" />
                        {errors.email}
                      </div>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password" className="text-sm font-medium text-gray-700">Contraseña</Label>
                    <Input
                      id="password"
                      type="password"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className={`h-12 px-4 rounded-lg border-2 transition-all duration-200 focus:border-green-500 focus:ring-2 focus:ring-green-200 ${errors.password ? 'border-red-300 focus:border-red-500 focus:ring-red-200' : 'border-gray-200'}`}
                      required
                    />
                    {errors.password && (
                      <div className="flex items-center gap-2 text-sm text-red-600 mt-1">
                        <AlertCircle className="h-4 w-4" />
                        {errors.password}
                      </div>
                    )}
                  </div>

                  {errors.general && (
                    <div className="bg-red-50 border border-red-200 p-4 rounded-lg">
                      <div className="flex items-center gap-2 text-sm text-red-600">
                        <AlertCircle className="h-4 w-4" />
                        {errors.general}
                      </div>
                    </div>
                  )}

                  <Button
                    type="submit"
                    disabled={loading}
                    className="w-full h-12 bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white font-medium rounded-lg transition-all duration-200 transform hover:scale-[1.02]"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                        Iniciando sesión...
                      </>
                    ) : (
                      'Iniciar Sesión'
                    )}
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="signup" className="space-y-6">
                <form onSubmit={handleSignup} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="workshopName" className="text-sm font-medium text-gray-700">Nombre del Taller</Label>
                      <Input
                        id="workshopName"
                        type="text"
                        placeholder="Mi Taller"
                        value={workshopName}
                        onChange={(e) => setWorkshopName(e.target.value)}
                        className={`h-12 px-4 rounded-lg border-2 transition-all duration-200 focus:border-green-500 focus:ring-2 focus:ring-green-200 ${errors.workshopName ? 'border-red-300 focus:border-red-500 focus:ring-red-200' : 'border-gray-200'}`}
                        required
                      />
                      {errors.workshopName && (
                        <div className="flex items-center gap-2 text-sm text-red-600 mt-1">
                          <AlertCircle className="h-4 w-4" />
                          {errors.workshopName}
                        </div>
                      )}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="contactPerson" className="text-sm font-medium text-gray-700">Persona de Contacto</Label>
                      <Input
                        id="contactPerson"
                        type="text"
                        placeholder="Tu nombre"
                        value={contactPerson}
                        onChange={(e) => setContactPerson(e.target.value)}
                        className={`h-12 px-4 rounded-lg border-2 transition-all duration-200 focus:border-green-500 focus:ring-2 focus:ring-green-200 ${errors.contactPerson ? 'border-red-300 focus:border-red-500 focus:ring-red-200' : 'border-gray-200'}`}
                        required
                      />
                      {errors.contactPerson && (
                        <div className="flex items-center gap-2 text-sm text-red-600 mt-1">
                          <AlertCircle className="h-4 w-4" />
                          {errors.contactPerson}
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="email-signup" className="text-sm font-medium text-gray-700">Email</Label>
                    <Input
                      id="email-signup"
                      type="email"
                      placeholder="tu@email.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className={`h-12 px-4 rounded-lg border-2 transition-all duration-200 focus:border-green-500 focus:ring-2 focus:ring-green-200 ${errors.email ? 'border-red-300 focus:border-red-500 focus:ring-red-200' : 'border-gray-200'}`}
                      required
                    />
                    {errors.email && (
                      <div className="flex items-center gap-2 text-sm text-red-600 mt-1">
                        <AlertCircle className="h-4 w-4" />
                        {errors.email}
                      </div>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="password-signup" className="text-sm font-medium text-gray-700">Contraseña</Label>
                    <Input
                      id="password-signup"
                      type="password"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className={`h-12 px-4 rounded-lg border-2 transition-all duration-200 focus:border-green-500 focus:ring-2 focus:ring-green-200 ${errors.password ? 'border-red-300 focus:border-red-500 focus:ring-red-200' : 'border-gray-200'}`}
                      required
                    />
                    {errors.password && (
                      <div className="flex items-center gap-2 text-sm text-red-600 mt-1">
                        <AlertCircle className="h-4 w-4" />
                        {errors.password}
                      </div>
                    )}
                  </div>

                  {errors.general && (
                    <div className="bg-red-50 border border-red-200 p-4 rounded-lg">
                      <div className="flex items-center gap-2 text-sm text-red-600">
                        <AlertCircle className="h-4 w-4" />
                        {errors.general}
                      </div>
                    </div>
                  )}

                  <Button
                    type="submit"
                    disabled={loading}
                    className="w-full h-12 bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white font-medium rounded-lg transition-all duration-200 transform hover:scale-[1.02]"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                        Creando cuenta...
                      </>
                    ) : (
                      'Crear Cuenta'
                    )}
                  </Button>
                </form>
              </TabsContent>
            </Tabs>

            {/* Local Storage info */}
            <div className="mt-8 p-6 bg-gradient-to-r from-green-50 to-blue-50 rounded-xl border border-green-100">
              <h3 className="font-semibold text-sm text-gray-800 mb-3 text-center">💾 Almacenamiento Local Incluido</h3>
              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="bg-white p-3 rounded-lg border border-gray-200">
                  <Shield className="h-6 w-6 mx-auto mb-1 text-green-500" />
                  <div className="text-xs text-gray-600">Privado</div>
                </div>
                <div className="bg-white p-3 rounded-lg border-2 border-green-300 relative">
                  <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 bg-green-600 text-white text-xs px-2 py-1 rounded">Local</div>
                  <HardDrive className="h-6 w-6 mx-auto mb-1 text-blue-500" />
                  <div className="text-xs text-gray-600">Rápido</div>
                </div>
                <div className="bg-white p-3 rounded-lg border border-gray-200">
                  <Database className="h-6 w-6 mx-auto mb-1 text-purple-500" />
                  <div className="text-xs text-gray-600">Seguro</div>
                </div>
              </div>
            </div>

            {/* Back to landing page button */}
            <div className="mt-4 text-center">
              <Button
                variant="ghost"
                onClick={() => setShowAuthForm(false)}
                className="text-sm text-gray-600 hover:text-gray-800 hover:bg-gray-100 transition-colors"
              >
                ← Volver a la página principal
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default LocalAuthPage;
