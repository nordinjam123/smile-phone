import React, { useEffect, useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { 
  Cloud, 
  Upload, 
  CheckCircle, 
  AlertTriangle,
  RefreshCw
} from 'lucide-react';
import { cloudSyncService } from '@/lib/cloudSyncService';
import { useAuth } from '@/hooks/useAuth';

interface AutoMigrationWrapperProps {
  children: React.ReactNode;
}

const AutoMigrationWrapper: React.FC<AutoMigrationWrapperProps> = ({ children }) => {
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [showMigrationDialog, setShowMigrationDialog] = useState(false);
  const [migrationStatus, setMigrationStatus] = useState({
    isRunning: false,
    progress: 0,
    completed: false,
    migrated: 0,
    errors: [] as string[]
  });

  // Check if migration is needed when user logs in
  useEffect(() => {
    if (user) {
      checkIfMigrationNeeded();
    }
  }, [user]);

  const checkIfMigrationNeeded = () => {
    // Check if there's local data and no recent cloud sync
    const lastSync = localStorage.getItem('lastCloudSync');
    const hasLocalData = checkForLocalData();
    
    // If there's local data and no recent sync (or first time), offer migration
    if (hasLocalData && (!lastSync || isOlderThan24Hours(lastSync))) {
      setShowMigrationDialog(true);
    }
  };

  const checkForLocalData = (): boolean => {
    const dataKeys = [
      'ordenes', 'clientes', 'inventario', 'inventario_piezas', 
      'inventario_mercancia', 'productos_mercancia', 'gastos_mercancia',
      'ventas_tpv', 'movimientos_restock', 'citas', 'facturas'
    ];

    return dataKeys.some(key => {
      const data = localStorage.getItem(key);
      if (!data) return false;
      try {
        const parsed = JSON.parse(data);
        return Array.isArray(parsed) && parsed.length > 0;
      } catch {
        return false;
      }
    });
  };

  const isOlderThan24Hours = (dateStr: string): boolean => {
    const date = new Date(dateStr);
    const now = new Date();
    const diffHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);
    return diffHours > 24;
  };

  const handleMigration = async () => {
    setMigrationStatus({
      isRunning: true,
      progress: 0,
      completed: false,
      migrated: 0,
      errors: []
    });

    try {
      // Simulate progress
      const progressInterval = setInterval(() => {
        setMigrationStatus(prev => ({
          ...prev,
          progress: Math.min(prev.progress + 15, 90)
        }));
      }, 300);

      const result = await cloudSyncService.migrateAllLocalDataToCloud();
      
      clearInterval(progressInterval);
      
      setMigrationStatus({
        isRunning: false,
        progress: 100,
        completed: true,
        migrated: result.migrated,
        errors: result.errors
      });

      if (result.success) {
        toast({
          title: "✅ Migración completada",
          description: `${result.migrated} elementos transferidos a la nube`,
        });
        
        // Auto close after success
        setTimeout(() => {
          setShowMigrationDialog(false);
        }, 3000);
      } else {
        toast({
          title: "Migración con errores",
          description: `${result.migrated} elementos transferidos. Revisa los detalles.`,
          variant: "destructive",
        });
      }
    } catch (error: any) {
      setMigrationStatus({
        isRunning: false,
        progress: 0,
        completed: false,
        migrated: 0,
        errors: [error.message]
      });
      
      toast({
        title: "Error en la migración",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleSkipMigration = () => {
    // Set a recent sync time to avoid showing the dialog again today
    localStorage.setItem('lastCloudSync', new Date().toISOString());
    setShowMigrationDialog(false);
    
    toast({
      title: "Migración omitida",
      description: "Puedes migrar tus datos más tarde desde el dashboard",
    });
  };

  return (
    <>
      {children}
      
      <Dialog open={showMigrationDialog} onOpenChange={setShowMigrationDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Cloud className="h-5 w-5 text-blue-600" />
              Sincronizar con la nube
            </DialogTitle>
            <DialogDescription>
              Detectamos datos locales en tu dispositivo. ¿Quieres sincronizarlos con la nube?
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {!migrationStatus.isRunning && !migrationStatus.completed && (
              <div className="space-y-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-medium text-blue-900 mb-2">¿Por qué sincronizar?</h4>
                  <ul className="text-sm text-blue-700 space-y-1">
                    <li>• Accede a tus datos desde cualquier dispositivo</li>
                    <li>• Backup automático en la nube</li>
                    <li>• Sincronización en tiempo real</li>
                    <li>• Mayor seguridad de tus datos</li>
                  </ul>
                </div>

                <div className="flex gap-2">
                  <Button onClick={handleMigration} className="flex-1">
                    <Upload className="h-4 w-4 mr-2" />
                    Sincronizar
                  </Button>
                  <Button variant="outline" onClick={handleSkipMigration}>
                    Más tarde
                  </Button>
                </div>
              </div>
            )}

            {migrationStatus.isRunning && (
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <RefreshCw className="h-4 w-4 animate-spin text-blue-600" />
                  <span>Sincronizando datos...</span>
                </div>
                <Progress value={migrationStatus.progress} className="w-full" />
                <p className="text-sm text-gray-600 text-center">
                  Transfiriendo tus datos a la nube de forma segura
                </p>
              </div>
            )}

            {migrationStatus.completed && (
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-green-700">
                  <CheckCircle className="h-5 w-5" />
                  <span className="font-medium">
                    ¡Sincronización completada!
                  </span>
                </div>
                
                <div className="bg-green-50 p-3 rounded-lg">
                  <p className="text-sm text-green-700">
                    {migrationStatus.migrated} elementos transferidos exitosamente. 
                    Ahora puedes acceder a tus datos desde cualquier lugar.
                  </p>
                </div>

                {migrationStatus.errors.length > 0 && (
                  <div className="bg-orange-50 p-3 rounded-lg">
                    <div className="flex items-center gap-2 text-orange-700 mb-2">
                      <AlertTriangle className="h-4 w-4" />
                      <span className="text-sm font-medium">Advertencias:</span>
                    </div>
                    <div className="text-xs text-orange-600">
                      {migrationStatus.errors.slice(0, 3).map((error, index) => (
                        <div key={index}>• {error}</div>
                      ))}
                    </div>
                  </div>
                )}

                <Button onClick={() => setShowMigrationDialog(false)} className="w-full">
                  Continuar
                </Button>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default AutoMigrationWrapper;
