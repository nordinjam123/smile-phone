import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  Wrench,
  Smartphone,
  ShoppingCart,
  Calculator,
  MessageSquare,
  QrCode,
  BarChart3,
  Clock,
  Shield,
  Star,
  Check,
  ArrowRight,
  Play,
  Menu,
  X,
  Zap,
  Users,
  CreditCard,
  FileText,
  Settings,
  TrendingUp,
  Package,
  Wifi,
  WifiOff,
  Timer,
  LogIn
} from "lucide-react";
import { useTranslation } from "@/lib/i18n/useTranslation";
import LateralNavigation from "./LateralNavigation";


interface LandingPageProps {
  onGetStarted: () => void;
}

export default function LandingPage({ onGetStarted }: LandingPageProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isDemoOpen, setIsDemoOpen] = useState(false);
  const { t } = useTranslation();

  const features = [
    {
      icon: Wrench,
      title: t.landing.repairManagement,
      description: t.landing.repairManagementDesc,
      color: "bg-blue-500"
    },
    {
      icon: ShoppingCart,
      title: t.landing.integratedPOS,
      description: t.landing.integratedPOSDesc,
      color: "bg-green-500"
    },
    {
      icon: Smartphone,
      title: t.landing.mobileInventory,
      description: t.landing.mobileInventoryDesc,
      color: "bg-purple-500"
    },
    {
      icon: MessageSquare,
      title: t.landing.whatsappIntegrated,
      description: t.landing.whatsappIntegratedDesc,
      color: "bg-green-600"
    },
    {
      icon: BarChart3,
      title: t.landing.financialBalance,
      description: t.landing.financialBalanceDesc,
      color: "bg-orange-500"
    },
    {
      icon: Calculator,
      title: t.landing.expenseControl,
      description: t.landing.expenseControlDesc,
      color: "bg-red-500"
    },
    {
      icon: QrCode,
      title: t.landing.ticketQR,
      description: t.landing.ticketQRDesc,
      color: "bg-indigo-500"
    },
    {
      icon: FileText,
      title: t.landing.completeBilling,
      description: t.landing.completeBillingDesc,
      color: "bg-teal-500"
    }
  ];

  const testimonials = [
    {
      name: "Carlos Rodríguez",
      business: t.landing.testimonialsBusiness1,
      rating: 5,
      comment: t.landing.testimonialsComment1
    },
    {
      name: "María González",
      business: t.landing.testimonialsBusiness2,
      rating: 5,
      comment: t.landing.testimonialsComment2
    },
    {
      name: "David López",
      business: t.landing.testimonialsBusiness3,
      rating: 5,
      comment: t.landing.testimonialsComment3
    }
  ];

  const pricingPlans = [
    {
      name: t.landing.monthlyPlan,
      price: t.landing.monthlyPrice,
      period: t.landing.monthlyPeriod,
      description: t.landing.monthlyDesc,
      features: [t.landing.allFeatures, "Soporte técnico", t.landing.updatesIncluded, "Sin permanencia", "Cancela cuando quieras"],
      recommended: false
    },
    {
      name: "Plan Semestral",
      price: "60€",
      period: "/6 meses",
      description: "Ahorra 30€ (10€/mes)",
      features: [t.landing.allFeatures, "Soporte prioritario", t.landing.updatesIncluded, "33% de descuento", t.landing.freeSetup],
      recommended: true
    },
    {
      name: t.landing.annualPlan,
      price: t.landing.annualPrice,
      period: t.landing.annualPeriod,
      description: t.landing.annualDesc,
      features: [t.landing.allFeatures, t.landing.prioritySupport, t.landing.updatesIncluded, t.landing.discount, t.landing.freeSetup],
      recommended: false
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b nav-blur">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-blue-600 rounded-lg">
                <Wrench className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">{t.landing.appName}</span>
            </div>
            
            {/* Desktop Menu */}
            <div className="hidden md:flex items-center space-x-8">
              <a href="#features" className="text-gray-600 hover:text-blue-600 transition-colors">{t.landing.features}</a>
              <a href="#pricing" className="text-gray-600 hover:text-blue-600 transition-colors">{t.landing.pricing}</a>
              <a href="#testimonials" className="text-gray-600 hover:text-blue-600 transition-colors">{t.landing.testimonials}</a>
              <Button onClick={onGetStarted} variant="outline" className="mr-2">
                Iniciar Sesión
              </Button>
              <Button onClick={onGetStarted} className="bg-blue-600 hover:bg-blue-700">
                {t.landing.getStarted}
              </Button>
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden flex items-center gap-2">

              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </Button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden border-t bg-white">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <a href="#features" className="block px-3 py-2 text-gray-600">{t.landing.features}</a>
              <a href="#pricing" className="block px-3 py-2 text-gray-600">{t.landing.pricing}</a>
              <a href="#testimonials" className="block px-3 py-2 text-gray-600">{t.landing.testimonials}</a>
              <Button onClick={onGetStarted} variant="outline" className="w-full mt-2 mb-2">
                Iniciar Sesión
              </Button>
              <Button onClick={onGetStarted} className="w-full bg-blue-600 hover:bg-blue-700">
                {t.landing.getStarted}
              </Button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="hero" className="relative bg-gradient-to-br from-blue-50 via-white to-purple-50 pt-20 pb-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge className="mb-4 bg-blue-100 text-blue-800 hover:bg-blue-100">
                <Wrench className="w-4 h-4 mr-1" />
                {t.landing.completeManagement}
              </Badge>
              <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
                {t.landing.heroTitle}
                <span className="text-blue-600"> {t.landing.heroTitleHighlight}</span> {t.landing.heroTitleEnd}
              </h1>
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                {t.landing.heroDescription}
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <Button
                  onClick={onGetStarted}
                  size="lg"
                  className="bg-blue-600 hover:bg-blue-700 text-lg px-8 py-4"
                >
                  {t.landing.startFree}
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="text-lg px-8 py-4"
                  onClick={() => setIsDemoOpen(true)}
                >
                  <Play className="mr-2 h-5 w-5" />
                  {t.landing.watchDemo}
                </Button>
              </div>

              <div className="flex items-center gap-6 text-sm text-gray-600">
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-green-500" />
                  Sin permanencia
                </div>
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-green-500" />
                  Soporte 24/7
                </div>
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-green-500" />
                  100% Local
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="relative z-10 bg-white rounded-2xl shadow-2xl p-6">
                <div className="mb-4 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                    <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  </div>
                  <Badge variant="secondary">Dashboard</Badge>
                </div>
                
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <Wrench className="h-8 w-8 text-blue-600 mb-2" />
                      <div className="text-2xl font-bold text-gray-900">127</div>
                      <div className="text-sm text-gray-600">Reparaciones</div>
                    </div>
                    <div className="bg-green-50 p-4 rounded-lg">
                      <TrendingUp className="h-8 w-8 text-green-600 mb-2" />
                      <div className="text-2xl font-bold text-gray-900">€2,450</div>
                      <div className="text-sm text-gray-600">Este mes</div>
                    </div>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium">Ventas del día</span>
                      <span className="text-green-600 text-sm">+12%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-blue-600 h-2 rounded-full" style={{ width: '68%' }}></div>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Floating cards */}
              <div className="absolute -top-4 -right-4 bg-green-500 text-white p-3 rounded-lg shadow-lg z-20 floating">
                <MessageSquare className="h-6 w-6 mb-1" />
                <div className="text-xs">WhatsApp</div>
                <div className="text-xs opacity-90">Conectado</div>
              </div>
              
              <div className="absolute -bottom-6 -left-6 bg-white p-3 rounded-lg shadow-lg border z-20 floating" style={{ animationDelay: '1s' }}>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-xs font-medium">Sistema Online</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Sección Publicitaria QR */}
      <section id="qr-system" className="py-16 bg-gradient-to-r from-indigo-50 to-purple-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge className="mb-4 bg-indigo-100 text-indigo-800">
                <QrCode className="w-4 h-4 mr-1" />
                Sistema QR Avanzado
              </Badge>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">
                Identificación QR Inteligente
                <span className="text-indigo-600"> para cada reparación</span>
              </h2>
              <p className="text-lg text-gray-600 mb-8">
                Cada móvil recibe una etiqueta QR única que permite seguimiento instantáneo.
                El cliente obtiene un ticket de resguardo y nunca más habrá confusiones.
              </p>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center">
                    <QrCode className="h-4 w-4 text-indigo-600" />
                  </div>
                  <span className="font-medium">Etiqueta QR resistente en cada dispositivo</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center">
                    <FileText className="h-4 w-4 text-indigo-600" />
                  </div>
                  <span className="font-medium">Ticket de resguardo impreso para el cliente</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center">
                    <Smartphone className="h-4 w-4 text-indigo-600" />
                  </div>
                  <span className="font-medium">Búsqueda instantánea con código QR</span>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="bg-white rounded-2xl shadow-xl p-6 transform rotate-3">
                <div className="text-center mb-4">
                  <QrCode className="h-16 w-16 mx-auto text-indigo-600 mb-2" />
                  <h4 className="font-bold text-gray-900">Sistema QR</h4>
                </div>
                <div className="space-y-3 text-sm">
                  <div className="bg-gray-50 p-3 rounded">
                    <strong>Cliente:</strong> María García
                  </div>
                  <div className="bg-gray-50 p-3 rounded">
                    <strong>Dispositivo:</strong> iPhone 12
                  </div>
                  <div className="bg-gray-50 p-3 rounded">
                    <strong>QR:</strong> #TRP-001234
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Sección WhatsApp Integrado */}
      <section id="whatsapp" className="py-16 bg-green-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <div className="bg-white rounded-2xl shadow-xl p-6">
                <div className="bg-green-500 rounded-t-lg p-4 text-white">
                  <div className="flex items-center gap-2 mb-2">
                    <MessageSquare className="h-5 w-5" />
                    <span className="font-medium">WhatsApp Business</span>
                  </div>
                </div>
                <div className="p-4 space-y-3">
                  <div className="bg-green-100 p-3 rounded-lg">
                    <p className="text-sm">✅ ¡Buenas noticias María!</p>
                    <p className="text-sm">Tu iPhone 12 ha sido reparado exitosamente.</p>
                    <p className="text-sm">📋 Orden: #12345</p>
                    <p className="text-sm">💰 Total: €50.00</p>
                    <p className="text-sm">📍 Ya puedes pasar a recogerlo.</p>
                  </div>
                  <div className="bg-gray-100 p-3 rounded-lg">
                    <p className="text-sm">📱 ¡Perfecto! ¿A qué hora puedo pasar?</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="order-1 lg:order-2">
              <Badge className="mb-4 bg-green-100 text-green-800">
                <MessageSquare className="w-4 h-4 mr-1" />
                WhatsApp Automático
              </Badge>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">
                Comunicación automática
                <span className="text-green-600"> con WhatsApp</span>
              </h2>
              <p className="text-lg text-gray-600 mb-8">
                Mantén a tus clientes informados automáticamente. Mensajes de estado,
                presupuestos, avisos de finalización y más, todo desde WhatsApp.
              </p>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                    <Check className="h-4 w-4 text-green-600" />
                  </div>
                  <span className="font-medium">Mensajes automáticos de estado</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                    <Clock className="h-4 w-4 text-green-600" />
                  </div>
                  <span className="font-medium">Notificaciones de presupuestos</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                    <MessageSquare className="h-4 w-4 text-green-600" />
                  </div>
                  <span className="font-medium">Avisos de reparación completada</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Sección Precios y Beneficios */}
      <section id="benefits" className="py-16 bg-gradient-to-r from-blue-50 to-cyan-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <Badge className="mb-4 bg-blue-100 text-blue-800">
              <Calculator className="w-4 h-4 mr-1" />
              Control de Precios y Beneficios
            </Badge>
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Controla cada céntimo de tu negocio
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Gestión automática de precios, cálculo de beneficios y análisis completo de rentabilidad
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            <div className="bg-white rounded-xl shadow-lg p-6">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <Calculator className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                Cálculo Automático de Precios
              </h3>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-green-500" />
                  Precio de piezas + mano de obra
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-green-500" />
                  Márgenes configurables
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-green-500" />
                  Presupuestos automáticos
                </li>
              </ul>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-6">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                <BarChart3 className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                Análisis de Beneficios
              </h3>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-green-500" />
                  Beneficio por reparación
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-green-500" />
                  Rentabilidad mensual
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-green-500" />
                  Comparativas períodos
                </li>
              </ul>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-6">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                <TrendingUp className="h-6 w-6 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                Optimización de Ingresos
              </h3>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-green-500" />
                  Identificar servicios más rentables
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-green-500" />
                  Control de gastos operativos
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-green-500" />
                  Sugerencias de precios
                </li>
              </ul>
            </div>
          </div>

          <div className="mt-12 bg-white rounded-2xl shadow-xl p-8">
            <div className="grid lg:grid-cols-2 gap-8 items-center">
              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">
                  Ejemplo de cálculo automático
                </h3>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between border-b pb-2">
                    <span>Pantalla iPhone 12:</span>
                    <span>€80.00</span>
                  </div>
                  <div className="flex justify-between border-b pb-2">
                    <span>Mano de obra:</span>
                    <span>€25.00</span>
                  </div>
                  <div className="flex justify-between border-b pb-2">
                    <span>Margen (20%):</span>
                    <span>€21.00</span>
                  </div>
                  <div className="flex justify-between font-bold text-lg border-t pt-2">
                    <span>Total al cliente:</span>
                    <span className="text-green-600">€126.00</span>
                  </div>
                  <div className="flex justify-between font-bold text-green-600">
                    <span>Beneficio neto:</span>
                    <span>€46.00</span>
                  </div>
                </div>
              </div>
              <div className="text-center">
                <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Calculator className="h-12 w-12 text-green-600" />
                </div>
                <p className="text-gray-600">
                  <strong>Automatiza</strong> todos los cálculos y
                  <strong> maximiza</strong> tus beneficios
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-purple-100 text-purple-800 hover:bg-purple-100">
              Funcionalidades Completas
            </Badge>
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Todo lo que necesitas para gestionar tu taller
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Una suite completa de herramientas diseñadas específicamente para talleres de reparación de móviles y tecnología
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="group hover:shadow-lg transition-all duration-300 border-0 shadow-md card-hover">
                <CardContent className="p-6">
                  <div className={`w-12 h-12 ${feature.color} rounded-lg flex items-center justify-center mb-4 feature-icon`}>
                    <feature.icon className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
                  <p className="text-gray-600 text-sm leading-relaxed">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Ticket de Resguardo Section */}
          <div className="mt-20 bg-white rounded-2xl shadow-xl p-8 lg:p-12">
            <div className="text-center mb-12">
              <Badge className="mb-4 bg-indigo-100 text-indigo-800 hover:bg-indigo-100">
                {t.landing.ticketSystemTitle}
              </Badge>
              <h3 className="text-3xl font-bold text-gray-900 mb-4">
                {t.landing.ticketSystemDesc}
              </h3>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                {t.landing.ticketDescription}
              </p>
            </div>

            <div className="grid lg:grid-cols-2 gap-12 items-center">
              {/* Visual del ticket para el cliente */}
              <div className="space-y-6">
                <div className="text-center">
                  <h4 className="text-xl font-semibold text-gray-900 mb-4">El cliente recibe:</h4>
                </div>

                {/* Mockup del ticket */}
                <div className="bg-gray-50 rounded-lg p-6 border-2 border-dashed border-gray-300 max-w-sm mx-auto">
                  <div className="bg-white rounded-lg shadow-lg p-6 transform rotate-2">
                    <div className="text-center mb-4">
                      <div className="w-16 h-16 bg-indigo-100 rounded-lg mx-auto mb-2 flex items-center justify-center">
                        <Wrench className="h-8 w-8 text-indigo-600" />
                      </div>
                      <h5 className="font-bold text-gray-900">TICKET DE RESGUARDO</h5>
                      <p className="text-sm text-gray-600">Tu Taller</p>
                    </div>

                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Orden:</span>
                        <span className="font-mono">#12345</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Cliente:</span>
                        <span>María García</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Dispositivo:</span>
                        <span>iPhone 12</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Problema:</span>
                        <span>Pantalla rota</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Fecha:</span>
                        <span>15/01/2024</span>
                      </div>
                    </div>

                    <div className="mt-4 pt-4 border-t border-gray-200">
                      <div className="flex justify-center">
                        <div className="w-16 h-16 bg-gray-900 rounded flex items-center justify-center">
                          <QrCode className="h-12 w-12 text-white" />
                        </div>
                      </div>
                      <p className="text-xs text-center text-gray-500 mt-2">
                        Código de identificación
                      </p>
                    </div>
                  </div>
                </div>

                <div className="text-center">
                  <p className="text-sm text-gray-600">
                    ✓ Recibo completo con todos los detalles<br/>
                    ✓ Código QR para buscar la reparación<br/>
                    ✓ Información de contacto del taller
                  </p>
                </div>
              </div>

              {/* Visual de la etiqueta en el móvil */}
              <div className="space-y-6">
                <div className="text-center">
                  <h4 className="text-xl font-semibold text-gray-900 mb-4">El móvil queda identificado:</h4>
                </div>

                {/* Mockup del móvil con etiqueta */}
                <div className="relative max-w-xs mx-auto">
                  {/* Móvil */}
                  <div className="bg-gray-900 rounded-3xl p-2 shadow-2xl">
                    <div className="bg-gray-800 rounded-2xl h-64 relative overflow-hidden">
                      <div className="absolute inset-0 bg-gradient-to-br from-blue-900 to-purple-900"></div>
                      <div className="absolute bottom-4 left-4 right-4">
                        <div className="text-white text-xs opacity-75">iPhone 12</div>
                        <div className="text-white text-sm">Pantalla apagada</div>
                      </div>
                    </div>
                  </div>

                  {/* Etiqueta QR pegada */}
                  <div className="absolute -top-2 -right-2 bg-white rounded-lg shadow-lg p-2 border-2 border-red-500 transform rotate-12">
                    <div className="w-12 h-12 bg-gray-900 rounded flex items-center justify-center">
                      <QrCode className="h-8 w-8 text-white" />
                    </div>
                    <div className="text-xs text-center mt-1 font-mono">#12345</div>
                  </div>

                  {/* Flecha indicativa */}
                  <div className="absolute -right-8 top-4">
                    <div className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                      QR
                    </div>
                  </div>
                </div>

                <div className="text-center">
                  <p className="text-sm text-gray-600">
                    ✓ Identificación rápida del dispositivo<br/>
                    ✓ Número de orden claramente visible<br/>
                    ✓ Localización instantánea
                  </p>
                </div>
              </div>
            </div>

            {/* Beneficios del sistema */}
            <div className="mt-12 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl p-8">
              <h4 className="text-xl font-semibold text-gray-900 mb-6 text-center">
                ¿Por qué este sistema es perfecto para tu taller?
              </h4>

              <div className="grid md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="w-12 h-12 bg-green-100 rounded-lg mx-auto mb-3 flex items-center justify-center">
                    <Check className="h-6 w-6 text-green-600" />
                  </div>
                  <h5 className="font-semibold text-gray-900 mb-2">Sin Confusiones</h5>
                  <p className="text-sm text-gray-600">
                    Cada móvil está perfectamente identificado. Nunca más confundir dispositivos.
                  </p>
                </div>

                <div className="text-center">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg mx-auto mb-3 flex items-center justify-center">
                    <Timer className="h-6 w-6 text-blue-600" />
                  </div>
                  <h5 className="font-semibold text-gray-900 mb-2">Ahorra Tiempo</h5>
                  <p className="text-sm text-gray-600">
                    Localiza cualquier dispositivo al instante escaneando el código QR.
                  </p>
                </div>

                <div className="text-center">
                  <div className="w-12 h-12 bg-purple-100 rounded-lg mx-auto mb-3 flex items-center justify-center">
                    <Star className="h-6 w-6 text-purple-600" />
                  </div>
                  <h5 className="font-semibold text-gray-900 mb-2">Profesional</h5>
                  <p className="text-sm text-gray-600">
                    Los clientes ven que tu taller es organizado y profesional.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Additional feature highlights */}
          <div className="mt-20 grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Características Avanzadas</h3>
              <div className="grid sm:grid-cols-2 gap-6">
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                    <WifiOff className="h-4 w-4 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">{t.landing.localStorageTitle}</h4>
                    <p className="text-sm text-gray-600">{t.landing.localStorageDesc}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-8 h-8 bg-yellow-100 rounded-lg flex items-center justify-center">
                    <Settings className="h-4 w-4 text-yellow-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Configuración Local</h4>
                    <p className="text-sm text-gray-600">Toda la configuración se almacena localmente. Tu taller funciona independientemente.</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                    <Smartphone className="h-4 w-4 text-green-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">App Móvil Nativa</h4>
                    <p className="text-sm text-gray-600">Disponible para Android, trabaja desde cualquier lugar</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                    <Shield className="h-4 w-4 text-purple-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Privacidad Total</h4>
                    <p className="text-sm text-gray-600">Tus datos nunca salen de tu dispositivo. Control absoluto de tu información.</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center">
                    <Users className="h-4 w-4 text-orange-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Multi-usuario</h4>
                    <p className="text-sm text-gray-600">Diferentes niveles de acceso para tu equipo</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl p-6 text-white">
              <h3 className="text-xl font-bold mb-4">¿Por qué elegir TallerPro?</h3>
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 flex-shrink-0" />
                  <span className="text-sm">Diseñado específicamente para talleres</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 flex-shrink-0" />
                  <span className="text-sm">Ahorra 3+ horas diarias de trabajo</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 flex-shrink-0" />
                  <span className="text-sm">Incrementa ventas hasta un 40%</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 flex-shrink-0" />
                  <span className="text-sm">Soporte técnico especializado</span>
                </div>
              </div>
              
              <Button 
                onClick={onGetStarted}
                className="w-full mt-6 bg-white text-blue-600 hover:bg-gray-100"
              >
                Comenzar Prueba Gratuita
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
              <Star className="w-4 h-4 mr-1" />
              {t.landing.testimonials}
            </Badge>
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              {t.landing.testimonialsTitle}
            </h2>
            <p className="text-xl text-gray-600">
              Descubre cómo {t.landing.appName} ha transformado negocios como el tuyo
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="border-0 shadow-lg testimonial-card">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-gray-600 mb-4 italic">"{testimonial.comment}"</p>
                  <div>
                    <div className="font-semibold text-gray-900">{testimonial.name}</div>
                    <div className="text-sm text-gray-500">{testimonial.business}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-green-100 text-green-800 hover:bg-green-100">
              <CreditCard className="w-4 h-4 mr-1" />
              {t.landing.pricingTitle}
            </Badge>
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              {t.landing.pricingSubtitle}
            </h2>
            <p className="text-xl text-gray-600">
              Sin costes ocultos. Sin permanencia. Cancela cuando quieras.
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {pricingPlans.map((plan, index) => (
              <Card key={index} className={`relative ${plan.recommended ? 'ring-2 ring-blue-500 shadow-xl pricing-glow' : 'shadow-lg'} border-0`}>
                {plan.recommended && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-blue-500 text-white px-4 py-1">
                      {t.landing.recommended}
                    </Badge>
                  </div>
                )}
                <CardContent className="p-8">
                  <div className="text-center">
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">{plan.name}</h3>
                    <div className="mb-4">
                      <span className="text-4xl font-bold text-gray-900">{plan.price}</span>
                      <span className="text-gray-600">{plan.period}</span>
                    </div>
                    <p className="text-gray-600 mb-6">{plan.description}</p>
                  </div>

                  <div className="space-y-3 mb-8">
                    {plan.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                        <span className="text-sm text-gray-600">{feature}</span>
                      </div>
                    ))}
                  </div>

                  <Button 
                    onClick={onGetStarted}
                    className={`w-full ${plan.recommended ? 'bg-blue-600 hover:bg-blue-700' : 'bg-gray-900 hover:bg-gray-800'}`}
                  >
                    Comenzar Ahora
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <p className="text-gray-600 mb-4">
              ¿Necesitas un plan personalizado para tu cadena de talleres?
            </p>
            <Button variant="outline" onClick={onGetStarted}>
              Contactar Ventas
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
            ¿Listo para transformar tu taller?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Únete a más de 500 talleres que ya han optimizado su negocio con TallerPro. 
            Comienza tu prueba gratuita hoy mismo.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              onClick={onGetStarted}
              size="lg" 
              className="bg-white text-blue-600 hover:bg-gray-100 text-lg px-8 py-4"
            >
              Comenzar Prueba Gratuita
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="border-white text-white hover:bg-white hover:text-blue-600 text-lg px-8 py-4"
              onClick={() => setIsDemoOpen(true)}
            >
              <Play className="mr-2 h-5 w-5" />
              Ver Demo Completo
            </Button>
          </div>

          <div className="mt-8 flex items-center justify-center gap-8 text-blue-100">
            <div className="flex items-center gap-2">
              <Check className="h-4 w-4" />
              <span className="text-sm">Prueba 7 días gratis</span>
            </div>
            <div className="flex items-center gap-2">
              <Check className="h-4 w-4" />
              <span className="text-sm">Soporte incluido</span>
            </div>
            <div className="flex items-center gap-2">
              <Check className="h-4 w-4" />
              <span className="text-sm">Sin permanencia</span>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="p-2 bg-blue-600 rounded-lg">
                  <Wrench className="h-6 w-6 text-white" />
                </div>
                <span className="text-xl font-bold">TallerPro</span>
              </div>
              <p className="text-gray-400 mb-4">
                La plataforma más completa para la gestión de talleres de reparación de dispositivos móviles.
              </p>
              <p className="text-gray-400 text-sm">
                ¿Necesitas ayuda? 
                <a href="mailto:mitaller@mitallerenlinea.org" className="text-blue-400 hover:underline ml-1">
                  mitaller@mitallerenlinea.org
                </a>
              </p>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Producto</h3>
              <div className="space-y-2 text-gray-400">
                <div>Características</div>
                <div>Precios</div>
                <div>Demo</div>
                <div>Actualizaciones</div>
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Soporte</h3>
              <div className="space-y-2 text-gray-400">
                <div>Centro de Ayuda</div>
                <div>Documentación</div>
                <div>Contacto</div>
                <div>Estado del Sistema</div>
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Empresa</h3>
              <div className="space-y-2 text-gray-400">
                <div>Acerca de</div>
                <div>Blog</div>
                <div>Términos</div>
                <div>Privacidad</div>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 TallerPro. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>

      {/* Navegación lateral */}
      <LateralNavigation onLogin={onGetStarted} />

      {/* Demo Modal */}
      <Dialog open={isDemoOpen} onOpenChange={setIsDemoOpen}>
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-center text-gray-900">
              Demostración de TallerPro
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            {/* Estadísticas */}
            <div className="bg-blue-50 border border-blue-200 p-6 rounded-lg">
              <h3 className="text-lg font-semibold text-center mb-4 text-gray-900">
                Beneficios reportados por nuestros usuarios
              </h3>
              <div className="grid md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">2-3h</div>
                  <div className="text-sm text-gray-600">Ahorro diario promedio</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">85%</div>
                  <div className="text-sm text-gray-600">Reducción de errores</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">30%</div>
                  <div className="text-sm text-gray-600">Más reparaciones/día</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">4.3/5</div>
                  <div className="text-sm text-gray-600">Valoración promedio</div>
                </div>
              </div>
            </div>

            {/* Comparativa de tiempo */}
            <div className="bg-gray-50 p-6 rounded-lg">
              <h3 className="text-lg font-semibold text-center mb-4">
                Comparativa: Gestión Manual vs TallerPro
              </h3>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold mb-3 text-gray-700">Gestión Manual:</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Control de reparaciones:</span>
                      <span className="font-medium">45 min/día</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Gestión de inventario:</span>
                      <span className="font-medium">30 min/día</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Comunicación con clientes:</span>
                      <span className="font-medium">25 min/día</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Facturación y cobros:</span>
                      <span className="font-medium">20 min/día</span>
                    </div>
                    <div className="border-t pt-2 flex justify-between font-semibold text-orange-600">
                      <span>Total tiempo administrativo:</span>
                      <span>2h/día</span>
                    </div>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-3 text-blue-600">Con TallerPro:</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Control automatizado:</span>
                      <span className="font-medium">5 min/día</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Inventario con códigos QR:</span>
                      <span className="font-medium">10 min/día</span>
                    </div>
                    <div className="flex justify-between">
                      <span>WhatsApp automático:</span>
                      <span className="font-medium">0 min/día</span>
                    </div>
                    <div className="flex justify-between">
                      <span>TPV integrado:</span>
                      <span className="font-medium">5 min/día</span>
                    </div>
                    <div className="border-t pt-2 flex justify-between font-semibold text-green-600">
                      <span>Total optimizado:</span>
                      <span>20 min/día</span>
                    </div>
                  </div>
                  <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                    <div className="text-center">
                      <div className="text-lg font-semibold text-green-700">1h 40min ahorrados/día</div>
                      <div className="text-sm text-gray-600">Más tiempo para reparaciones</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Testimonios */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-white border border-gray-200 p-5 rounded-lg">
                <div className="flex items-center mb-3">
                  <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center text-white font-semibold text-sm">
                    CR
                  </div>
                  <div className="ml-3">
                    <h4 className="font-semibold">Carlos R.</h4>
                    <p className="text-sm text-gray-600">TecnoMovil - Madrid</p>
                  </div>
                </div>
                <p className="text-sm text-gray-700 mb-3">
                  "Desde que uso TallerPro he reducido significativamente el tiempo de gestión. Los clientes reciben las notificaciones automáticamente y esto ha mejorado mucho la comunicación."
                </p>
                <div className="text-sm text-blue-600 font-medium">
                  +25 reparaciones más por mes
                </div>
              </div>

              <div className="bg-white border border-gray-200 p-5 rounded-lg">
                <div className="flex items-center mb-3">
                  <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center text-white font-semibold text-sm">
                    MG
                  </div>
                  <div className="ml-3">
                    <h4 className="font-semibold">María G.</h4>
                    <p className="text-sm text-gray-600">MovilFix - Barcelona</p>
                  </div>
                </div>
                <p className="text-sm text-gray-700 mb-3">
                  "El control de inventario con códigos QR es muy útil. Ya no pierdo tiempo buscando piezas y los presupuestos salen automáticamente calculados."
                </p>
                <div className="text-sm text-green-600 font-medium">
                  Mayor control del inventario
                </div>
              </div>
            </div>

            {/* Funcionalidades principales */}
            <div className="bg-gray-50 p-6 rounded-lg">
              <h3 className="text-lg font-semibold text-center mb-6 text-gray-900">
                Principales funcionalidades
              </h3>
              <div className="grid md:grid-cols-3 gap-4">
                <div className="bg-white p-4 rounded-lg border border-gray-200">
                  <div className="w-full h-24 bg-blue-100 rounded-lg mb-3 flex items-center justify-center">
                    <Wrench className="w-8 h-8 text-blue-600" />
                  </div>
                  <h4 className="font-medium text-sm mb-2">Gestión de Reparaciones</h4>
                  <p className="text-xs text-gray-600">
                    Control completo del flujo de trabajo con estados automatizados
                  </p>
                </div>
                <div className="bg-white p-4 rounded-lg border border-gray-200">
                  <div className="w-full h-24 bg-green-100 rounded-lg mb-3 flex items-center justify-center">
                    <ShoppingCart className="w-8 h-8 text-green-600" />
                  </div>
                  <h4 className="font-medium text-sm mb-2">TPV y Facturación</h4>
                  <p className="text-xs text-gray-600">
                    Sistema de cobros integrado con generación automática de facturas
                  </p>
                </div>
                <div className="bg-white p-4 rounded-lg border border-gray-200">
                  <div className="w-full h-24 bg-purple-100 rounded-lg mb-3 flex items-center justify-center">
                    <MessageSquare className="w-8 h-8 text-purple-600" />
                  </div>
                  <h4 className="font-medium text-sm mb-2">WhatsApp Automático</h4>
                  <p className="text-xs text-gray-600">
                    Notificaciones automáticas sobre el estado de las reparaciones
                  </p>
                </div>
              </div>
            </div>

            {/* Incluido en el servicio */}
            <div className="bg-blue-50 border border-blue-200 p-6 rounded-lg">
              <h3 className="text-lg font-semibold text-center mb-4 text-gray-900">
                Incluido en tu suscripción
              </h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-white p-4 rounded-lg border border-gray-200">
                  <div className="flex items-center mb-2">
                    <Check className="w-5 h-5 text-green-600 mr-2" />
                    <span className="font-medium text-sm">Prueba 7 días gratis</span>
                  </div>
                  <p className="text-xs text-gray-600">Nuestro equipo te ayuda a configurar el sistema</p>
                </div>
                <div className="bg-white p-4 rounded-lg border border-gray-200">
                  <div className="flex items-center mb-2">
                    <Check className="w-5 h-5 text-green-600 mr-2" />
                    <span className="font-medium text-sm">Soporte técnico</span>
                  </div>
                  <p className="text-xs text-gray-600">Asistencia para resolver cualquier duda</p>
                </div>
              </div>
            </div>

            {/* Información del servicio */}
            <div className="bg-gray-50 border border-gray-200 p-6 rounded-lg">
              <h3 className="text-lg font-semibold text-center mb-4">
                Detalles del servicio
              </h3>
              <div className="grid md:grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Check className="w-6 h-6 text-blue-600" />
                  </div>
                  <h4 className="font-medium text-sm">Periodo de prueba</h4>
                  <p className="text-xs text-gray-600">15 días para evaluar el sistema</p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Settings className="w-6 h-6 text-green-600" />
                  </div>
                  <h4 className="font-medium text-sm">Configuración incluida</h4>
                  <p className="text-xs text-gray-600">Te ayudamos a configurar el sistema</p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Shield className="w-6 h-6 text-purple-600" />
                  </div>
                  <h4 className="font-medium text-sm">Datos protegidos</h4>
                  <p className="text-xs text-gray-600">Backup diario automático</p>
                </div>
              </div>
            </div>

            {/* Llamada a la acción */}
            <div className="bg-blue-600 text-white p-6 rounded-lg text-center">
              <h3 className="text-xl font-bold mb-3">
                ¿Te interesa probar TallerPro?
              </h3>
              <p className="text-sm mb-4 opacity-90">
                Descubre cómo puede optimizar la gestión de tu taller
              </p>

              <div className="space-y-3">
                <Button
                  onClick={onGetStarted}
                  size="lg"
                  className="bg-white text-blue-600 hover:bg-gray-100 font-semibold px-8 py-3"
                >
                  Comenzar periodo de prueba
                </Button>

                <div className="text-sm">
                  Desde €15/mes tras el periodo de prueba
                </div>

                <div className="flex items-center justify-center gap-4 text-xs opacity-90">
                  <div className="flex items-center gap-1">
                    <Check className="w-3 h-3" />
                    <span>Sin permanencia</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Check className="w-3 h-3" />
                    <span>Cancela cuando quieras</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
