import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { 
  Cloud, 
  Database, 
  Settings, 
  CheckCircle, 
  AlertTriangle, 
  ExternalLink,
  Copy,
  RefreshCw,
  Upload,
  Download
} from 'lucide-react';
import { customStorageService, STORAGE_PROVIDERS, CustomStorageConfig } from '@/lib/customStorageService';
import { firebaseService, FirebaseConfig } from '@/lib/firebaseService';

const CustomStorageConfigComponent: React.FC = () => {
  const [selectedProvider, setSelectedProvider] = useState('supabase');
  const [config, setConfig] = useState<CustomStorageConfig>({
    provider: 'supabase',
    isActive: false,
    createdAt: new Date().toISOString(),
    status: 'pending'
  });
  const [isLoading, setIsLoading] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; error?: string } | null>(null);
  const [migrationProgress, setMigrationProgress] = useState(0);
  const [showSQLInstructions, setShowSQLInstructions] = useState(false);
  
  const { toast } = useToast();

  useEffect(() => {
    loadExistingConfig();
  }, []);

  const loadExistingConfig = async () => {
    const existingConfig = await customStorageService.loadStorageConfig();
    if (existingConfig) {
      setConfig(existingConfig);
      setSelectedProvider(existingConfig.provider);
    }
  };

  const handleConfigChange = (field: string, value: string) => {
    setConfig(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const testConnection = async () => {
    setIsLoading(true);
    setTestResult(null);

    try {
      let result;

      if (selectedProvider === 'firebase') {
        // Test Firebase connection
        if (!config.firebaseConfig) {
          throw new Error('Configuración Firebase requerida');
        }

        try {
          const firebaseConfig = JSON.parse(config.firebaseConfig);
          const initResult = await firebaseService.initialize(firebaseConfig);

          if (initResult) {
            result = await firebaseService.testConnection();
          } else {
            result = { success: false, error: 'Error inicializando Firebase' };
          }
        } catch (parseError: any) {
          result = { success: false, error: 'Configuración JSON inválida: ' + parseError.message };
        }
      } else {
        // Test other providers
        result = await customStorageService.testConnection(config);
      }

      setTestResult(result);

      if (result.success) {
        toast({
          title: "✅ Conexión exitosa",
          description: selectedProvider === 'firebase'
            ? "Firebase configurado correctamente - Autenticación y base de datos listos"
            : "Tu almacenamiento personalizado está configurado correctamente",
        });
      } else {
        toast({
          title: "❌ Error de conexión",
          description: result.error,
          variant: "destructive",
        });
      }
    } catch (error: any) {
      setTestResult({ success: false, error: error.message });
      toast({
        title: "Error de prueba",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const saveConfiguration = async () => {
    setIsLoading(true);
    
    try {
      const updatedConfig = {
        ...config,
        provider: selectedProvider,
        isActive: true,
        status: 'connected' as const,
        lastTested: new Date().toISOString()
      };
      
      const success = await customStorageService.saveStorageConfig(updatedConfig);
      
      if (success) {
        setConfig(updatedConfig);
        toast({
          title: "✅ Configuración guardada",
          description: "Tu almacenamiento personalizado está activo",
        });
      } else {
        throw new Error('Error saving configuration');
      }
    } catch (error: any) {
      toast({
        title: "Error guardando configuración",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const migrateData = async () => {
    setIsLoading(true);
    setMigrationProgress(0);

    try {
      // Simulate migration progress
      const progressInterval = setInterval(() => {
        setMigrationProgress(prev => Math.min(prev + 10, 90));
      }, 200);

      let result;

      if (selectedProvider === 'firebase') {
        // Firebase migration
        result = await firebaseService.migrateFromLocalStorage();
      } else {
        // Other providers migration
        const sourceData = {
          clientes: JSON.parse(localStorage.getItem('clientes') || '[]'),
          inventario: JSON.parse(localStorage.getItem('inventario') || '[]'),
          ordenes_trabajo: JSON.parse(localStorage.getItem('ordenes') || '[]'),
          facturas: JSON.parse(localStorage.getItem('facturas') || '[]'),
          gastos_mercancia: JSON.parse(localStorage.getItem('gastos_mercancia') || '[]'),
          citas: JSON.parse(localStorage.getItem('citas') || '[]')
        };

        await customStorageService.initializeCustomStorage();
        result = await customStorageService.migrateToCustomStorage(sourceData);
      }

      clearInterval(progressInterval);
      setMigrationProgress(100);

      if (result.success) {
        toast({
          title: "✅ Migración completada",
          description: `${result.migrated} elementos migrados a ${selectedProvider === 'firebase' ? 'Firebase' : 'tu almacenamiento personalizado'}`,
        });
      } else {
        toast({
          title: "⚠️ Migración con errores",
          description: `${result.migrated} elementos migrados, ${result.errors.length} errores`,
          variant: "destructive",
        });
      }
    } catch (error: any) {
      toast({
        title: "Error en migración",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
      setMigrationProgress(0);
    }
  };

  const copySQL = () => {
    const sqlScript = `-- SQL Script para configurar TallerPro en tu base de datos personalizada
-- Ejecuta este script en tu instancia de PostgreSQL/Supabase

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create tables (the customStorageService will handle this automatically)
-- But you can run this manually if needed:

-- Resto del SQL... (se mostraría el SQL completo aquí)
`;
    
    navigator.clipboard.writeText(sqlScript);
    toast({
      title: "SQL copiado",
      description: "Script copiado al portapapeles",
    });
  };

  const currentProvider = STORAGE_PROVIDERS.find(p => p.id === selectedProvider);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Almacenamiento Personalizado
          </CardTitle>
          <CardDescription>
            Configura tu propia infraestructura de base de datos y paga directamente al proveedor de tu elección
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* Provider Selection */}
          <div className="space-y-4">
            <h3 className="font-medium">Selecciona tu proveedor de almacenamiento:</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {STORAGE_PROVIDERS.map((provider) => (
                <Card 
                  key={provider.id}
                  className={`cursor-pointer transition-all duration-200 ${
                    selectedProvider === provider.id 
                      ? 'ring-2 ring-blue-500 bg-blue-50' 
                      : 'hover:shadow-md'
                  }`}
                  onClick={() => setSelectedProvider(provider.id)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-2xl">{provider.icon}</span>
                      <div>
                        <h4 className="font-medium">{provider.name}</h4>
                        <Badge variant="outline" className="text-xs">
                          {provider.estimatedCost}
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600 mb-3">{provider.description}</p>
                    <div className="space-y-1">
                      {provider.features.slice(0, 3).map((feature, index) => (
                        <div key={index} className="flex items-center gap-1 text-xs text-gray-500">
                          <CheckCircle className="h-3 w-3 text-green-500" />
                          {feature}
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Configuration Form */}
      {currentProvider && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              Configurar {currentProvider.name}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="config" className="w-full">
              <TabsList>
                <TabsTrigger value="config">Configuración</TabsTrigger>
                <TabsTrigger value="instructions">Instrucciones</TabsTrigger>
                <TabsTrigger value="features">Características</TabsTrigger>
              </TabsList>

              <TabsContent value="config" className="space-y-4">
                {selectedProvider === 'supabase' && (
                  <>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="supabase-url">URL de Supabase</Label>
                        <Input
                          id="supabase-url"
                          placeholder="https://tu-proyecto.supabase.co"
                          value={config.supabaseUrl || ''}
                          onChange={(e) => handleConfigChange('supabaseUrl', e.target.value)}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="supabase-key">Clave Anon/Public</Label>
                        <Input
                          id="supabase-key"
                          type="password"
                          placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                          value={config.supabaseKey || ''}
                          onChange={(e) => handleConfigChange('supabaseKey', e.target.value)}
                        />
                      </div>
                    </div>
                  </>
                )}

                {selectedProvider === 'aws' && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="aws-access">AWS Access Key</Label>
                      <Input
                        id="aws-access"
                        value={config.awsAccessKey || ''}
                        onChange={(e) => handleConfigChange('awsAccessKey', e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="aws-secret">AWS Secret Key</Label>
                      <Input
                        id="aws-secret"
                        type="password"
                        value={config.awsSecretKey || ''}
                        onChange={(e) => handleConfigChange('awsSecretKey', e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="aws-region">Región AWS</Label>
                      <Input
                        id="aws-region"
                        placeholder="us-east-1"
                        value={config.awsRegion || ''}
                        onChange={(e) => handleConfigChange('awsRegion', e.target.value)}
                      />
                    </div>
                  </div>
                )}

                {selectedProvider === 'firebase' && (
                  <div className="space-y-4">
                    <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                      <h4 className="font-medium text-blue-900 mb-2">🔥 Configuración Firebase</h4>
                      <p className="text-sm text-blue-700 mb-3">
                        Copia y pega la configuración completa de tu proyecto Firebase aquí:
                      </p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="firebase-config">Configuración Firebase (JSON)</Label>
                      <Textarea
                        id="firebase-config"
                        placeholder={`{
  "apiKey": "AIzaSy...",
  "authDomain": "tu-proyecto.firebaseapp.com",
  "projectId": "tu-proyecto",
  "storageBucket": "tu-proyecto.appspot.com",
  "messagingSenderId": "123456789",
  "appId": "1:123:web:abc123"
}`}
                        value={config.firebaseConfig || ''}
                        onChange={(e) => handleConfigChange('firebaseConfig', e.target.value)}
                        className="min-h-[200px] font-mono text-sm"
                      />
                    </div>

                    <div className="bg-amber-50 p-4 rounded-lg border border-amber-200">
                      <h5 className="font-medium text-amber-900 mb-2">⚠️ Pasos importantes:</h5>
                      <ul className="text-sm text-amber-800 space-y-1">
                        <li>• Activa Authentication &gt; Email/Password y Google</li>
                        <li>• Activa Firestore Database</li>
                        <li>• Configura reglas de seguridad apropiadas</li>
                        <li>• Asegúrate de tener permisos de administrador</li>
                      </ul>
                    </div>
                  </div>
                )}

                <div className="flex gap-2">
                  <Button 
                    onClick={testConnection}
                    disabled={isLoading}
                    variant="outline"
                  >
                    {isLoading ? (
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    ) : (
                      <Database className="h-4 w-4 mr-2" />
                    )}
                    Probar Conexión
                  </Button>
                  
                  {testResult?.success && (
                    <Button onClick={saveConfiguration} disabled={isLoading}>
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Guardar Configuración
                    </Button>
                  )}
                </div>

                {testResult && (
                  <Alert className={testResult.success ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'}>
                    <AlertDescription className={testResult.success ? 'text-green-700' : 'text-red-700'}>
                      {testResult.success ? '✅ Conexión exitosa' : `❌ ${testResult.error}`}
                    </AlertDescription>
                  </Alert>
                )}
              </TabsContent>

              <TabsContent value="instructions" className="space-y-4">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Instrucciones de configuración:</h4>
                  <pre className="text-sm whitespace-pre-wrap text-gray-700">
                    {currentProvider.setupInstructions}
                  </pre>
                </div>
                
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => setShowSQLInstructions(!showSQLInstructions)}>
                    <Database className="h-4 w-4 mr-2" />
                    {showSQLInstructions ? 'Ocultar' : 'Mostrar'} Script SQL
                  </Button>
                  
                  {showSQLInstructions && (
                    <Button variant="outline" onClick={copySQL}>
                      <Copy className="h-4 w-4 mr-2" />
                      Copiar SQL
                    </Button>
                  )}
                </div>

                {showSQLInstructions && (
                  <div className="bg-gray-900 text-gray-100 p-4 rounded-lg text-sm font-mono">
                    <p>-- Script SQL se generará automáticamente al conectar</p>
                    <p>-- O puedes usar la función de auto-configuración</p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="features" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {currentProvider.features.map((feature, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-sm">{feature}</span>
                    </div>
                  ))}
                </div>
                
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-medium text-blue-900 mb-2">💰 Coste estimado: {currentProvider.estimatedCost}</h4>
                  <p className="text-sm text-blue-700">
                    Este coste es directamente con el proveedor. No hay costes adicionales de TallerPro.
                  </p>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      )}

      {/* Migration Section */}
      {config.isActive && testResult?.success && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="h-5 w-5" />
              Migrar Datos Existentes
            </CardTitle>
            <CardDescription>
              Transfiere tus datos actuales a tu almacenamiento personalizado
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {migrationProgress > 0 && (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Migrando datos...</span>
                  <span>{migrationProgress}%</span>
                </div>
                <Progress value={migrationProgress} />
              </div>
            )}
            
            <div className="flex gap-2">
              <Button onClick={migrateData} disabled={isLoading}>
                <Upload className="h-4 w-4 mr-2" />
                {isLoading ? 'Migrando...' : 'Migrar Datos'}
              </Button>
              
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Descargar Backup
              </Button>
            </div>

            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <strong>Importante:</strong> Una vez migrado, todos tus datos se almacenarán en tu infraestructura personalizada.
                Asegúrate de tener backups configurados en tu proveedor.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default CustomStorageConfigComponent;
