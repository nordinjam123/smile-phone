import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  CheckCircle,
  XCircle,
  AlertTriangle,
  RefreshCw,
  ExternalLink,
  Copy
} from 'lucide-react';
import { centralizedFirebaseService } from '@/lib/centralizedFirebaseService';

const FirebaseDiagnostic: React.FC = () => {
  const [status, setStatus] = useState({
    initialization: 'checking',
    authentication: 'checking',
    firestore: 'checking',
    googleSignIn: 'checking'
  });
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const firestoreRules = `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Permitir acceso completo para usuarios autenticados
    match /{collection}/{document} {
      allow read, write: if request.auth != null &&
        (resource == null ||
         !('workspaceId' in resource.data) ||
         resource.data.workspaceId == request.auth.uid);
    }

    // Usuarios pueden gestionar sus perfiles
    match /users/{userId} {
      allow read, write: if request.auth != null &&
        request.auth.uid == userId;
    }

    // Test de conexión
    match /test/{document} {
      allow read: if request.auth != null;
    }

    // Colecciones específicas
    match /clientes/{document} {
      allow read, write: if request.auth != null;
    }
    match /inventario/{document} {
      allow read, write: if request.auth != null;
    }
    match /ordenes_trabajo/{document} {
      allow read, write: if request.auth != null;
    }
    match /facturas/{document} {
      allow read, write: if request.auth != null;
    }
    match /gastos_mercancia/{document} {
      allow read, write: if request.auth != null;
    }
    match /citas/{document} {
      allow read, write: if request.auth != null;
    }
  }
}`;

  const copyRulesToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(firestoreRules);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Error copying to clipboard:', err);
    }
  };

  const runDiagnostic = async () => {
    setLoading(true);
    const newStatus = { ...status };

    // Test 1: Firebase Initialization
    try {
      const isReady = centralizedFirebaseService.isReady();
      newStatus.initialization = isReady ? 'success' : 'error';
    } catch (error) {
      newStatus.initialization = 'error';
    }

    // Test 2: Connection Test
    try {
      const connectionTest = await centralizedFirebaseService.testConnection();
      newStatus.firestore = connectionTest.success ? 'success' : 'error';
    } catch (error) {
      newStatus.firestore = 'error';
    }

    // Test 3: Authentication Methods (simulation)
    newStatus.authentication = 'warning'; // Needs manual verification
    newStatus.googleSignIn = 'warning'; // Needs manual verification

    setStatus(newStatus);
    setLoading(false);
  };

  useEffect(() => {
    runDiagnostic();
  }, []);

  const getStatusIcon = (state: string) => {
    switch (state) {
      case 'success': return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'error': return <XCircle className="h-5 w-5 text-red-500" />;
      case 'warning': return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      default: return <RefreshCw className="h-5 w-5 text-gray-400 animate-spin" />;
    }
  };

  const getStatusBadge = (state: string) => {
    switch (state) {
      case 'success': return <Badge className="bg-green-100 text-green-800">✅ OK</Badge>;
      case 'error': return <Badge className="bg-red-100 text-red-800">❌ Error</Badge>;
      case 'warning': return <Badge className="bg-yellow-100 text-yellow-800">⚠️ Requiere acción</Badge>;
      default: return <Badge className="bg-gray-100 text-gray-800">🔄 Verificando...</Badge>;
    }
  };

  return (
    <Card className="max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>🔧 Diagnóstico del Sistema</span>
          <Button 
            onClick={runDiagnostic} 
            disabled={loading}
            size="sm"
            variant="outline"
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Verificar
          </Button>
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Tests Results */}
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div className="flex items-center gap-3">
              {getStatusIcon(status.initialization)}
              <div>
                <h4 className="font-medium">Inicialización Firebase</h4>
                <p className="text-sm text-gray-600">Conexión básica y configuración</p>
              </div>
            </div>
            {getStatusBadge(status.initialization)}
          </div>

          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div className="flex items-center gap-3">
              {getStatusIcon(status.firestore)}
              <div>
                <h4 className="font-medium">Base de Datos (Firestore)</h4>
                <p className="text-sm text-gray-600">Permisos y reglas de acceso</p>
              </div>
            </div>
            {getStatusBadge(status.firestore)}
          </div>

          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div className="flex items-center gap-3">
              {getStatusIcon(status.authentication)}
              <div>
                <h4 className="font-medium">Email/Password Authentication</h4>
                <p className="text-sm text-gray-600">Método de autenticación básico</p>
              </div>
            </div>
            {getStatusBadge(status.authentication)}
          </div>

          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div className="flex items-center gap-3">
              {getStatusIcon(status.googleSignIn)}
              <div>
                <h4 className="font-medium">Google Sign-In</h4>
                <p className="text-sm text-gray-600">Autenticación con Google</p>
              </div>
            </div>
            {getStatusBadge(status.googleSignIn)}
          </div>
        </div>

        {/* Action Items */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">🛠️ Acciones Requeridas</h3>
          
          {(status.authentication === 'warning' || status.googleSignIn === 'warning') && (
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <div className="space-y-2">
                  <p><strong>Configura los métodos de autenticación en Firebase Console:</strong></p>
                  <ol className="list-decimal list-inside space-y-1 text-sm">
                    <li>Ve a <strong>Authentication → Sign-in method</strong></li>
                    <li>Habilita <strong>Email/Password</strong> ✅</li>
                    <li>Habilita <strong>Google</strong> ✅</li>
                    <li>Configura tu email como soporte del proyecto</li>
                  </ol>
                  <Button 
                    size="sm" 
                    className="mt-2"
                    onClick={() => window.open('https://console.firebase.google.com/project/mitaller-91992/authentication/providers', '_blank')}
                  >
                    <ExternalLink className="h-4 w-4 mr-2" />
                    Abrir Firebase Console
                  </Button>
                </div>
              </AlertDescription>
            </Alert>
          )}

          {status.firestore === 'error' && (
            <Alert className="border-red-200 bg-red-50">
              <XCircle className="h-4 w-4 text-red-600" />
              <AlertDescription>
                <div className="space-y-2">
                  <p><strong>Configura las reglas de Firestore:</strong></p>
                  <ol className="list-decimal list-inside space-y-1 text-sm">
                    <li>Ve a <strong>Firestore Database → Rules</strong></li>
                    <li>Reemplaza el contenido con las reglas correctas</li>
                    <li>Click <strong>Publish</strong></li>
                  </ol>
                  <div className="mt-2 p-3 bg-gray-100 rounded text-xs font-mono max-h-64 overflow-y-auto">
                    {`rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Permitir acceso completo para usuarios autenticados
    match /{collection}/{document} {
      allow read, write: if request.auth != null &&
        (resource == null ||
         !('workspaceId' in resource.data) ||
         resource.data.workspaceId == request.auth.uid);
    }

    // Usuarios pueden gestionar sus perfiles
    match /users/{userId} {
      allow read, write: if request.auth != null &&
        request.auth.uid == userId;
    }

    // Test de conexión
    match /test/{document} {
      allow read: if request.auth != null;
    }

    // Colecciones específicas
    match /clientes/{document} {
      allow read, write: if request.auth != null;
    }
    match /inventario/{document} {
      allow read, write: if request.auth != null;
    }
    match /ordenes_trabajo/{document} {
      allow read, write: if request.auth != null;
    }
    match /facturas/{document} {
      allow read, write: if request.auth != null;
    }
    match /gastos_mercancia/{document} {
      allow read, write: if request.auth != null;
    }
    match /citas/{document} {
      allow read, write: if request.auth != null;
    }
  }
}`}
                  </div>
                  <Button 
                    size="sm" 
                    className="mt-2"
                    onClick={() => window.open('https://console.firebase.google.com/project/mitaller-91992/firestore/rules', '_blank')}
                  >
                    <ExternalLink className="h-4 w-4 mr-2" />
                    Abrir Reglas Firestore
                  </Button>
                </div>
              </AlertDescription>
            </Alert>
          )}

          {status.initialization === 'error' && (
            <Alert className="border-red-200 bg-red-50">
              <XCircle className="h-4 w-4 text-red-600" />
              <AlertDescription>
                <p><strong>Error de configuración Firebase:</strong> Verifica que las credenciales estén correctas en el código.</p>
              </AlertDescription>
            </Alert>
          )}
        </div>

        {/* Current Configuration */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <h4 className="font-medium mb-2">📋 Configuración Actual</h4>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-gray-600">Proyecto:</span>
              <span className="ml-2 font-mono">mitaller-91992</span>
            </div>
            <div>
              <span className="text-gray-600">Región:</span>
              <span className="ml-2">us-central1</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default FirebaseDiagnostic;
