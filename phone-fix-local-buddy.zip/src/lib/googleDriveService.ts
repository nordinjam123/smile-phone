import { supabase } from '@/integrations/supabase/client';

export interface BackupData {
  talleres: any[];
  inventario: any[];
  mercancia: any[];
  gastos: any[];
  clientes: any[];
  presupuestos: any[];
  createdAt: string;
  userId: string;
}

class GoogleDriveService {
  private googleAuth: any = null;
  private driveApi: any = null;

  async initializeGoogleDrive(accessToken: string) {
    try {
      // We'll use the browser's fetch API to interact with Google Drive REST API
      this.googleAuth = { accessToken };
      return true;
    } catch (error) {
      console.error('Error initializing Google Drive:', error);
      return false;
    }
  }

  async createBackup(): Promise<{ success: boolean; fileId?: string; error?: string }> {
    try {
      if (!this.googleAuth) {
        throw new Error('Google Drive not initialized');
      }

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error('Usuario no autenticado');
      }

      // Obtener todos los datos del usuario
      const [
        { data: talleres },
        { data: inventario },
        { data: mercancia },
        { data: gastos },
        { data: clientes },
        { data: presupuestos }
      ] = await Promise.all([
        supabase.from('talleres').select('*').eq('user_id', user.id),
        supabase.from('inventario').select('*').eq('user_id', user.id),
        supabase.from('mercancia').select('*').eq('user_id', user.id),
        supabase.from('gastos').select('*').eq('user_id', user.id),
        supabase.from('clientes').select('*').eq('user_id', user.id),
        supabase.from('presupuestos').select('*').eq('user_id', user.id)
      ]);

      const backupData: BackupData = {
        talleres: talleres || [],
        inventario: inventario || [],
        mercancia: mercancia || [],
        gastos: gastos || [],
        clientes: clientes || [],
        presupuestos: presupuestos || [],
        createdAt: new Date().toISOString(),
        userId: user.id
      };

      const fileName = `tallerpro_backup_${new Date().toISOString().split('T')[0]}.json`;
      const fileContent = JSON.stringify(backupData, null, 2);

      // Crear archivo en Google Drive usando REST API
      const metadata = {
        name: fileName,
        parents: ['appDataFolder'], // Usar carpeta específica de la app
        description: 'TallerPro - Copia de seguridad automática'
      };

      const form = new FormData();
      form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
      form.append('file', new Blob([fileContent], { type: 'application/json' }));

      const response = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.googleAuth.accessToken}`,
        },
        body: form
      });

      if (!response.ok) {
        throw new Error(`Error creating backup: ${response.statusText}`);
      }

      const result = await response.json();
      return { success: true, fileId: result.id };
    } catch (error: any) {
      console.error('Error creating backup:', error);
      return { success: false, error: error.message };
    }
  }

  async listBackups(): Promise<{ success: boolean; files?: any[]; error?: string }> {
    try {
      if (!this.googleAuth) {
        throw new Error('Google Drive not initialized');
      }

      const response = await fetch(
        `https://www.googleapis.com/drive/v3/files?q=name contains 'tallerpro_backup_' and parents in 'appDataFolder'&orderBy=createdTime desc`,
        {
          headers: {
            'Authorization': `Bearer ${this.googleAuth.accessToken}`,
          }
        }
      );

      if (!response.ok) {
        throw new Error(`Error listing backups: ${response.statusText}`);
      }

      const result = await response.json();
      return { success: true, files: result.files || [] };
    } catch (error: any) {
      console.error('Error listing backups:', error);
      return { success: false, error: error.message };
    }
  }

  async downloadBackup(fileId: string): Promise<{ success: boolean; data?: BackupData; error?: string }> {
    try {
      if (!this.googleAuth) {
        throw new Error('Google Drive not initialized');
      }

      const response = await fetch(
        `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`,
        {
          headers: {
            'Authorization': `Bearer ${this.googleAuth.accessToken}`,
          }
        }
      );

      if (!response.ok) {
        throw new Error(`Error downloading backup: ${response.statusText}`);
      }

      const backupContent = await response.text();
      const backupData: BackupData = JSON.parse(backupContent);
      
      return { success: true, data: backupData };
    } catch (error: any) {
      console.error('Error downloading backup:', error);
      return { success: false, error: error.message };
    }
  }

  async restoreBackup(backupData: BackupData): Promise<{ success: boolean; error?: string }> {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error('Usuario no autenticado');
      }

      // Verificar que el backup pertenece al usuario actual
      if (backupData.userId !== user.id) {
        throw new Error('Este backup no pertenece al usuario actual');
      }

      // Restaurar datos en orden (considerando dependencias)
      const restorePromises = [];

      if (backupData.talleres?.length > 0) {
        restorePromises.push(
          supabase.from('talleres').upsert(backupData.talleres.map(item => ({
            ...item,
            user_id: user.id
          })))
        );
      }

      if (backupData.clientes?.length > 0) {
        restorePromises.push(
          supabase.from('clientes').upsert(backupData.clientes.map(item => ({
            ...item,
            user_id: user.id
          })))
        );
      }

      if (backupData.inventario?.length > 0) {
        restorePromises.push(
          supabase.from('inventario').upsert(backupData.inventario.map(item => ({
            ...item,
            user_id: user.id
          })))
        );
      }

      if (backupData.mercancia?.length > 0) {
        restorePromises.push(
          supabase.from('mercancia').upsert(backupData.mercancia.map(item => ({
            ...item,
            user_id: user.id
          })))
        );
      }

      if (backupData.gastos?.length > 0) {
        restorePromises.push(
          supabase.from('gastos').upsert(backupData.gastos.map(item => ({
            ...item,
            user_id: user.id
          })))
        );
      }

      if (backupData.presupuestos?.length > 0) {
        restorePromises.push(
          supabase.from('presupuestos').upsert(backupData.presupuestos.map(item => ({
            ...item,
            user_id: user.id
          })))
        );
      }

      await Promise.all(restorePromises);
      return { success: true };
    } catch (error: any) {
      console.error('Error restoring backup:', error);
      return { success: false, error: error.message };
    }
  }
}

export const googleDriveService = new GoogleDriveService();
