import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { 
  Bell, 
  BellOff, 
  Send, 
  CheckCircle, 
  AlertCircle,
  Settings,
  Smartphone,
  MessageSquare,
  Calendar,
  Package
} from 'lucide-react';
import { centralizedFirebaseService } from '@/lib/centralizedFirebaseService';

const FCMNotifications: React.FC = () => {
  const [fcmEnabled, setFcmEnabled] = useState(false);
  const [fcmToken, setFcmToken] = useState<string | null>(null);
  const [testTitle, setTestTitle] = useState('🔧 Prueba TallerPro');
  const [testMessage, setTestMessage] = useState('Esta es una notificación de prueba desde tu taller');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    checkFCMStatus();
  }, []);

  const checkFCMStatus = () => {
    const isReady = centralizedFirebaseService.isFCMReady();
    const token = centralizedFirebaseService.getFCMToken();
    
    setFcmEnabled(isReady);
    setFcmToken(token);
  };

  const requestPermission = async () => {
    if (!('Notification' in window)) {
      toast({
        title: "No soportado",
        description: "Tu navegador no soporta notificaciones",
        variant: "destructive",
      });
      return;
    }

    if (Notification.permission === 'denied') {
      toast({
        title: "Permisos denegados",
        description: "Las notificaciones están bloqueadas. Actívalas en la configuración del navegador.",
        variant: "destructive",
      });
      return;
    }

    try {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        // Refresh Firebase to get token
        setTimeout(checkFCMStatus, 1000);
        toast({
          title: "✅ Notificaciones activadas",
          description: "Ahora recibirás notificaciones de tu taller",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudieron activar las notificaciones",
        variant: "destructive",
      });
    }
  };

  const sendTestNotification = async () => {
    if (!fcmEnabled) {
      toast({
        title: "FCM no habilitado",
        description: "Primero activa las notificaciones",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      // For demo, we'll create a local notification
      if ('serviceWorker' in navigator) {
        const registration = await navigator.serviceWorker.ready;
        await registration.showNotification(testTitle, {
          body: testMessage,
          icon: '/favicon.ico',
          badge: '/favicon.ico',
          tag: 'test-notification',
          vibrate: [200, 100, 200]
        });
        
        toast({
          title: "🔔 Notificación enviada",
          description: "Deberías ver la notificación ahora",
        });
      }
    } catch (error) {
      toast({
        title: "Error enviando notificación",
        description: "Verifica que las notificaciones estén habilitadas",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const notificationTypes = [
    {
      icon: CheckCircle,
      title: "Reparación Completada",
      description: "Cuando una orden de trabajo se marca como completada",
      color: "text-green-500"
    },
    {
      icon: MessageSquare,
      title: "Nueva Orden",
      description: "Cuando se recibe una nueva orden de trabajo",
      color: "text-blue-500"
    },
    {
      icon: Calendar,
      title: "Recordatorio de Cita",
      description: "30 minutos antes de una cita programada",
      color: "text-purple-500"
    },
    {
      icon: Package,
      title: "Stock Bajo",
      description: "Cuando un producto tiene stock por debajo del mínimo",
      color: "text-orange-500"
    }
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-3 mb-4">
          <div className="p-3 bg-gradient-to-br from-blue-500 to-purple-500 rounded-xl">
            <Bell className="h-8 w-8 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              Notificaciones Push FCM
            </h1>
            <p className="text-lg text-gray-600">
              Mantente al día con tu taller en tiempo real
            </p>
          </div>
        </div>
      </div>

      {/* Status Card */}
      <Card className={`border-2 ${fcmEnabled ? 'border-green-200 bg-green-50' : 'border-amber-200 bg-amber-50'}`}>
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            {fcmEnabled ? (
              <Bell className="h-6 w-6 text-green-600" />
            ) : (
              <BellOff className="h-6 w-6 text-amber-600" />
            )}
            Estado de Notificaciones
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <Badge className={fcmEnabled ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'}>
                {fcmEnabled ? '✅ Activas' : '⚠️ Inactivas'}
              </Badge>
              <p className="text-sm text-gray-600 mt-2">
                {fcmEnabled 
                  ? 'Las notificaciones están configuradas y funcionando'
                  : 'Activa las notificaciones para recibir alertas automáticas'
                }
              </p>
              {fcmToken && (
                <p className="text-xs text-gray-500 mt-1 font-mono">
                  Token: {fcmToken.slice(0, 30)}...
                </p>
              )}
            </div>
            {!fcmEnabled && (
              <Button onClick={requestPermission} className="bg-blue-600 hover:bg-blue-700">
                <Bell className="h-4 w-4 mr-2" />
                Activar Notificaciones
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Test Notifications */}
      {fcmEnabled && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Send className="h-5 w-5" />
              Probar Notificaciones
            </CardTitle>
            <CardDescription>
              Envía una notificación de prueba para verificar que todo funciona
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="test-title">Título</Label>
                <Input
                  id="test-title"
                  value={testTitle}
                  onChange={(e) => setTestTitle(e.target.value)}
                  placeholder="Título de la notificación"
                />
              </div>
              <div className="space-y-2">
                <Label>Vista Previa</Label>
                <div className="p-3 bg-gray-100 rounded-lg border">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 bg-blue-500 rounded-sm flex items-center justify-center">
                      <span className="text-white text-xs">T</span>
                    </div>
                    <div>
                      <div className="font-medium text-sm">{testTitle}</div>
                      <div className="text-xs text-gray-600">{testMessage}</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="test-message">Mensaje</Label>
              <Textarea
                id="test-message"
                value={testMessage}
                onChange={(e) => setTestMessage(e.target.value)}
                placeholder="Contenido de la notificación"
                rows={3}
              />
            </div>

            <Button 
              onClick={sendTestNotification}
              disabled={loading}
              className="w-full"
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Enviando...
                </>
              ) : (
                <>
                  <Send className="h-4 w-4 mr-2" />
                  Enviar Notificación de Prueba
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Notification Types */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Tipos de Notificaciones Automáticas
          </CardTitle>
          <CardDescription>
            Notificaciones que se envían automáticamente según eventos del taller
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {notificationTypes.map((type, index) => (
              <div key={index} className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
                <type.icon className={`h-6 w-6 ${type.color} flex-shrink-0 mt-0.5`} />
                <div>
                  <h4 className="font-medium text-gray-900">{type.title}</h4>
                  <p className="text-sm text-gray-600">{type.description}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Setup Instructions */}
      <Card className="bg-blue-50 border-blue-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-blue-900">
            <Smartphone className="h-5 w-5" />
            Configuración Adicional
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              <strong>VAPID Key requerida:</strong> Para que FCM funcione completamente, necesitas configurar tu VAPID key en las variables de entorno como <code>VITE_FIREBASE_VAPID_KEY</code>
            </AlertDescription>
          </Alert>

          <div className="space-y-2">
            <h4 className="font-medium">Para obtener tu VAPID Key:</h4>
            <ol className="text-sm space-y-1 list-decimal list-inside text-gray-700">
              <li>Ve a Firebase Console → Configuración del proyecto</li>
              <li>Pestaña "Cloud Messaging"</li>
              <li>En "Configuración web" → "Generar par de claves"</li>
              <li>Copia la clave y agrégala como <code>VITE_FIREBASE_VAPID_KEY</code></li>
            </ol>
          </div>

          <div className="bg-white p-4 rounded-lg border">
            <h4 className="font-medium mb-2">💰 Costo con tus 300€ de Google Cloud:</h4>
            <ul className="text-sm space-y-1 text-gray-700">
              <li>• Hasta 1,000,000 mensajes/mes: <strong>GRATIS</strong></li>
              <li>• Después: $0.50 por 1M mensajes adicionales</li>
              <li>• Para 100+ talleres: <strong>€0-2/mes máximo</strong></li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default FCMNotifications;
