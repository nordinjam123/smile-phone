import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  DollarSign,
  ExternalLink,
  Book,
  Zap,
  Shield,
  CheckCircle,
  Cloud,
  Database,
  Users
} from 'lucide-react';
import GoogleCloudSetupGuide from './GoogleCloudSetupGuide';

const ConfiguracionFirebaseGoogle: React.FC = () => {
  const [showGuide, setShowGuide] = React.useState(false);

  const benefits = [
    {
      icon: DollarSign,
      title: "300€ Gratis de Google",
      description: "Suficiente para servir cientos de talleres durante meses",
      color: "text-green-500"
    },
    {
      icon: Database,
      title: "Firebase Enterprise",
      description: "Base de datos en tiempo real con escalabilidad automática",
      color: "text-blue-500"
    },
    {
      icon: Shield,
      title: "Seguridad Google-Level",
      description: "Autenticación OAuth, reglas de seguridad y backup automático",
      color: "text-purple-500"
    },
    {
      icon: Users,
      title: "Sin Costo para Clientes",
      description: "Tus talleres usan tu infraestructura sin pagar extra",
      color: "text-orange-500"
    }
  ];

  const features = [
    "✅ Autenticación Google nativa",
    "✅ Sincronización en tiempo real",
    "✅ Aislamiento automático de datos",
    "✅ Backup y escalabilidad automática",
    "✅ Analytics y métricas incluidas",
    "✅ Infraestructura enterprise de Google"
  ];

  if (showGuide) {
    return (
      <div>
        <div className="mb-6">
          <Button 
            variant="outline" 
            onClick={() => setShowGuide(false)}
            className="mb-4"
          >
            ← Volver a configuración
          </Button>
        </div>
        <GoogleCloudSetupGuide />
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-3 mb-4">
          <div className="p-3 bg-gradient-to-br from-green-500 to-blue-500 rounded-xl">
            <Cloud className="h-8 w-8 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              Configuración Firebase con Google Cloud
            </h1>
            <p className="text-lg text-gray-600">
              Aprovecha tus 300€ gratis para infraestructura enterprise
            </p>
          </div>
        </div>
      </div>

      {/* Status Alert */}
      <Alert className="bg-amber-50 border-amber-200">
        <Zap className="h-4 w-4 text-amber-600" />
        <AlertDescription className="text-amber-800">
          <strong>¿Tienes 300€ de créditos Google Cloud?</strong> Perfecto! Te ayudaremos a configurar Firebase para que tus clientes tengan la mejor experiencia sin costos adicionales.
        </AlertDescription>
      </Alert>

      {/* Benefits Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {benefits.map((benefit, index) => (
          <Card key={index} className="text-center hover:shadow-md transition-shadow">
            <CardContent className="pt-6">
              <benefit.icon className={`h-12 w-12 mx-auto mb-4 ${benefit.color}`} />
              <h3 className="font-semibold mb-2">{benefit.title}</h3>
              <p className="text-sm text-gray-600">{benefit.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Main Action */}
      <Card className="border-2 border-blue-200 bg-gradient-to-r from-blue-50 to-green-50">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl text-blue-900">
            🚀 Configurar Firebase con tus Créditos
          </CardTitle>
          <CardDescription className="text-lg">
            Guía paso a paso para aprovechar al máximo tus 300€ de Google Cloud
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold mb-3">🎯 Lo que conseguirás:</h4>
              <ul className="space-y-2">
                {features.map((feature, idx) => (
                  <li key={idx} className="text-sm flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0" />
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-3">💰 Estimación de costos:</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>100 talleres activos:</span>
                  <Badge variant="outline">€2-5/mes</Badge>
                </div>
                <div className="flex justify-between">
                  <span>500 talleres activos:</span>
                  <Badge variant="outline">€10-25/mes</Badge>
                </div>
                <div className="flex justify-between">
                  <span>1000+ talleres activos:</span>
                  <Badge variant="outline">€25-50/mes</Badge>
                </div>
                <div className="border-t pt-2 font-medium">
                  <div className="flex justify-between">
                    <span>Con 300€ te durarán:</span>
                    <Badge className="bg-green-100 text-green-800">6-30 meses</Badge>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="text-center space-y-4">
            <Button 
              size="lg"
              onClick={() => setShowGuide(true)}
              className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white px-8 py-3"
            >
              <Zap className="h-5 w-5 mr-2" />
              Empezar Configuración Paso a Paso
            </Button>
            <p className="text-sm text-gray-600">
              Te guiaremos a través de cada paso para configurar Firebase optimizado
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Documentation Links */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Book className="h-5 w-5 text-blue-600" />
              Documentación Completa
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600 mb-4">
              Guía detallada con screenshots y ejemplos para configurar Firebase desde cero.
            </p>
            <Button variant="outline" className="w-full">
              <ExternalLink className="h-4 w-4 mr-2" />
              Ver GOOGLE_CLOUD_300_EUROS_SETUP.md
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-green-600" />
              Seguridad y Mejores Prácticas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600 mb-4">
              Aprende sobre reglas de seguridad, aislamiento de datos y monitoreo de costos.
            </p>
            <Button variant="outline" className="w-full">
              <ExternalLink className="h-4 w-4 mr-2" />
              Ver Guía de Seguridad
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Quick Links */}
      <Card className="bg-gray-50">
        <CardHeader>
          <CardTitle>🔗 Enlaces Rápidos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.open('https://console.cloud.google.com', '_blank')}
            >
              <ExternalLink className="h-4 w-4 mr-1" />
              Google Cloud
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.open('https://console.firebase.google.com', '_blank')}
            >
              <ExternalLink className="h-4 w-4 mr-1" />
              Firebase Console
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.open('https://firebase.google.com/docs', '_blank')}
            >
              <ExternalLink className="h-4 w-4 mr-1" />
              Docs Firebase
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.open('https://cloud.google.com/billing/docs', '_blank')}
            >
              <ExternalLink className="h-4 w-4 mr-1" />
              Billing Docs
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Support */}
      <Alert>
        <Shield className="h-4 w-4" />
        <AlertDescription>
          <strong>¿Necesitas ayuda?</strong> Si tienes problemas durante la configuración, revisa los logs del navegador (F12) o consulta la documentación detallada. El sistema está diseñado para ser robusto y fácil de configurar.
        </AlertDescription>
      </Alert>
    </div>
  );
};

export default ConfiguracionFirebaseGoogle;
