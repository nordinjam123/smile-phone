import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

type StorageMode = 'local' | 'cloud' | 'hybrid';

interface HybridStorageConfig {
  tableName: string;
  localKey: string;
  mode: StorageMode;
  autoSync: boolean;
  syncInterval: number; // minutos
}

interface SyncStatus {
  lastSync: Date | null;
  pending: number;
  syncing: boolean;
  error: string | null;
}

export function useHybridStorage<T extends { id: string; updated_at?: string }>(
  config: HybridStorageConfig
) {
  const [data, setData] = useState<T[]>([]);
  const [syncStatus, setSyncStatus] = useState<SyncStatus>({
    lastSync: null,
    pending: 0,
    syncing: false,
    error: null
  });
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const { toast } = useToast();

  // Detectar estado de conexión
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Cargar datos según el modo configurado
  const loadData = useCallback(async () => {
    try {
      if (config.mode === 'local') {
        // Solo localStorage
        const localData = localStorage.getItem(config.localKey);
        if (localData) {
          setData(JSON.parse(localData));
        }
      } else if (config.mode === 'cloud') {
        // Solo nube (requiere conexión)
        if (isOnline) {
          const { data: cloudData, error } = await supabase
            .from(config.tableName)
            .select('*')
            .order('updated_at', { ascending: false });

          if (error) throw error;
          setData(cloudData || []);
        } else {
          setSyncStatus(prev => ({ 
            ...prev, 
            error: 'Sin conexión: no se pueden cargar datos de la nube' 
          }));
        }
      } else {
        // Modo híbrido
        await loadHybridData();
      }
    } catch (error) {
      console.error('Error loading data:', error);
      setSyncStatus(prev => ({ 
        ...prev, 
        error: error instanceof Error ? error.message : 'Error desconocido' 
      }));
    }
  }, [config, isOnline]);

  // Cargar datos en modo híbrido
  const loadHybridData = useCallback(async () => {
    const localData = localStorage.getItem(config.localKey);
    const parsedLocal: T[] = localData ? JSON.parse(localData) : [];

    if (isOnline) {
      try {
        const { data: cloudData, error } = await supabase
          .from(config.tableName)
          .select('*')
          .order('updated_at', { ascending: false });

        if (error) throw error;

        // Merge datos local y nube (prioridad a los más recientes)
        const mergedData = mergeData(parsedLocal, cloudData || []);
        setData(mergedData);
        
        // Actualizar localStorage con datos merged
        localStorage.setItem(config.localKey, JSON.stringify(mergedData));
        
        setSyncStatus(prev => ({ 
          ...prev, 
          lastSync: new Date(),
          error: null 
        }));
      } catch (error) {
        console.error('Error syncing from cloud:', error);
        // Usar datos locales si falla la nube
        setData(parsedLocal);
        setSyncStatus(prev => ({ 
          ...prev, 
          error: 'Error sincronizando desde la nube, usando datos locales' 
        }));
      }
    } else {
      // Sin conexión, usar datos locales
      setData(parsedLocal);
    }
  }, [config, isOnline]);

  // Merge inteligente de datos local y nube
  const mergeData = (local: T[], cloud: T[]): T[] => {
    const merged = new Map<string, T>();

    // Añadir datos locales
    local.forEach(item => merged.set(item.id, item));

    // Añadir/actualizar con datos de nube (más recientes)
    cloud.forEach(item => {
      const existing = merged.get(item.id);
      if (!existing || 
          (item.updated_at && existing.updated_at && 
           new Date(item.updated_at) > new Date(existing.updated_at))) {
        merged.set(item.id, item);
      }
    });

    return Array.from(merged.values());
  };

  // Guardar datos
  const saveData = useCallback(async (newData: T[]) => {
    try {
      // Siempre guardar localmente primero
      localStorage.setItem(config.localKey, JSON.stringify(newData));
      setData(newData);

      if (config.mode === 'cloud' || (config.mode === 'hybrid' && isOnline)) {
        // Sincronizar con la nube
        await syncToCloud(newData);
      } else if (config.mode === 'hybrid' && !isOnline) {
        // Marcar como pendiente de sincronización
        setSyncStatus(prev => ({ 
          ...prev, 
          pending: prev.pending + 1 
        }));
      }
    } catch (error) {
      console.error('Error saving data:', error);
      setSyncStatus(prev => ({ 
        ...prev, 
        error: error instanceof Error ? error.message : 'Error guardando datos' 
      }));
    }
  }, [config, isOnline]);

  // Sincronizar a la nube
  const syncToCloud = useCallback(async (dataToSync: T[]) => {
    if (!isOnline) return;

    setSyncStatus(prev => ({ ...prev, syncing: true }));

    try {
      // Obtener usuario actual
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Usuario no autenticado');

      // Preparar datos para insertar/actualizar
      const dataWithUserAndTimestamp = dataToSync.map(item => ({
        ...item,
        user_id: user.id,
        updated_at: new Date().toISOString()
      }));

      // Usar upsert para insertar o actualizar
      const { error } = await supabase
        .from(config.tableName)
        .upsert(dataWithUserAndTimestamp, { 
          onConflict: 'id',
          ignoreDuplicates: false 
        });

      if (error) throw error;

      setSyncStatus(prev => ({ 
        ...prev, 
        lastSync: new Date(),
        pending: 0,
        syncing: false,
        error: null 
      }));

      toast({
        title: "Datos sincronizados",
        description: "Los datos se han guardado en la nube correctamente",
        variant: "default"
      });

    } catch (error) {
      console.error('Error syncing to cloud:', error);
      setSyncStatus(prev => ({ 
        ...prev, 
        syncing: false,
        error: error instanceof Error ? error.message : 'Error sincronizando' 
      }));

      toast({
        title: "Error de sincronización",
        description: "No se pudieron sincronizar los datos con la nube",
        variant: "destructive"
      });
    }
  }, [isOnline, config.tableName, toast]);

  // Forzar sincronización manual
  const forceSync = useCallback(async () => {
    if (!isOnline) {
      toast({
        title: "Sin conexión",
        description: "No es posible sincronizar sin conexión a internet",
        variant: "destructive"
      });
      return;
    }

    await loadHybridData();
    
    if (config.mode === 'hybrid') {
      await syncToCloud(data);
    }
  }, [isOnline, loadHybridData, syncToCloud, data, config.mode, toast]);

  // Auto-sincronización
  useEffect(() => {
    if (config.autoSync && config.mode === 'hybrid' && isOnline) {
      const interval = setInterval(() => {
        forceSync();
      }, config.syncInterval * 60 * 1000);

      return () => clearInterval(interval);
    }
  }, [config.autoSync, config.mode, config.syncInterval, isOnline, forceSync]);

  // Cargar datos al inicializar
  useEffect(() => {
    loadData();
  }, [loadData]);

  return {
    data,
    saveData,
    syncStatus,
    isOnline,
    forceSync,
    loadData
  };
}
