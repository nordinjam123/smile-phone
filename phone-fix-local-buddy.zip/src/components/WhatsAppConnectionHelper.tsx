import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Smartphone, 
  Monitor, 
  QrCode, 
  CheckCircle, 
  ExternalLink,
  Wifi,
  AlertTriangle
} from 'lucide-react';

interface WhatsAppConnectionHelperProps {
  onConnected?: () => void;
}

const WhatsAppConnectionHelper: React.FC<WhatsAppConnectionHelperProps> = ({ 
  onConnected 
}) => {
  const [step, setStep] = useState(1);
  const [isConnecting, setIsConnecting] = useState(false);

  const openWhatsAppWeb = () => {
    setIsConnecting(true);
    window.open('https://web.whatsapp.com', '_blank', 'width=1200,height=800');
    setStep(2);
    setTimeout(() => setIsConnecting(false), 3000);
  };

  const confirmConnection = () => {
    setStep(3);
    onConnected?.();
  };

  const steps = [
    {
      number: 1,
      title: "Abrir WhatsApp Web",
      description: "Primero necesitamos abrir WhatsApp Web en una nueva ventana",
      action: (
        <Button 
          onClick={openWhatsAppWeb}
          disabled={isConnecting}
          className="w-full"
        >
          <Monitor className="h-4 w-4 mr-2" />
          {isConnecting ? 'Abriendo...' : 'Abrir WhatsApp Web'}
        </Button>
      )
    },
    {
      number: 2,
      title: "Escanear código QR",
      description: "En la nueva ventana, escanea el código QR con tu teléfono",
      action: (
        <div className="space-y-3">
          <Alert className="border-blue-200 bg-blue-50">
            <Smartphone className="h-4 w-4 text-blue-600" />
            <AlertDescription className="text-blue-800">
              <strong>En tu teléfono:</strong><br/>
              1. Abre WhatsApp<br/>
              2. Ve a Configuración → Dispositivos vinculados<br/>
              3. Pulsa "Vincular un dispositivo"<br/>
              4. Escanea el código QR de la pantalla
            </AlertDescription>
          </Alert>
          <Button 
            onClick={confirmConnection}
            variant="outline"
            className="w-full"
          >
            <CheckCircle className="h-4 w-4 mr-2" />
            Ya he escaneado el código QR
          </Button>
        </div>
      )
    },
    {
      number: 3,
      title: "¡Conectado!",
      description: "WhatsApp Web está conectado y listo para enviar mensajes",
      action: (
        <Alert className="border-green-200 bg-green-50">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-800">
            <strong>✅ ¡Perfecto!</strong><br/>
            WhatsApp Web está conectado. Los mensajes automáticos se enviarán correctamente.
          </AlertDescription>
        </Alert>
      )
    }
  ];

  const currentStep = steps[step - 1];

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <QrCode className="h-5 w-5" />
          Conectar WhatsApp Web
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Indicador de progreso */}
        <div className="flex items-center justify-between">
          {steps.map((s, index) => (
            <div key={s.number} className="flex items-center">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                step > s.number ? 'bg-green-500 text-white' :
                step === s.number ? 'bg-blue-500 text-white' :
                'bg-gray-200 text-gray-500'
              }`}>
                {step > s.number ? <CheckCircle className="h-4 w-4" /> : s.number}
              </div>
              {index < steps.length - 1 && (
                <div className={`w-16 h-0.5 mx-2 ${
                  step > s.number ? 'bg-green-500' : 'bg-gray-200'
                }`} />
              )}
            </div>
          ))}
        </div>

        {/* Paso actual */}
        <div className="text-center space-y-4">
          <div>
            <h3 className="text-lg font-semibold">{currentStep.title}</h3>
            <p className="text-gray-600">{currentStep.description}</p>
          </div>
          
          {currentStep.action}
        </div>

        {/* Información adicional */}
        {step === 1 && (
          <div className="space-y-3">
            <Alert className="border-yellow-200 bg-yellow-50">
              <AlertTriangle className="h-4 w-4 text-yellow-600" />
              <AlertDescription className="text-yellow-800">
                <strong>Requisitos:</strong><br/>
                • Tu teléfono debe estar conectado a internet<br/>
                • WhatsApp debe estar instalado en tu teléfono<br/>
                • Necesitas acceso físico a tu teléfono para escanear
              </AlertDescription>
            </Alert>
          </div>
        )}

        {step === 2 && (
          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="font-medium mb-2">💡 Consejos:</h4>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>• Asegúrate de que tu teléfono tenga buena conexión</li>
              <li>• Mantén WhatsApp Web abierto en esta ventana</li>
              <li>• Si el código QR no aparece, recarga la página</li>
              <li>• Una vez conectado, puedes cerrar la ventana de WhatsApp Web</li>
            </ul>
          </div>
        )}

        {/* Enlaces útiles */}
        <div className="border-t pt-4">
          <h4 className="text-sm font-medium text-gray-700 mb-2">Enlaces útiles:</h4>
          <div className="flex flex-wrap gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.open('https://web.whatsapp.com', '_blank')}
            >
              <ExternalLink className="h-3 w-3 mr-1" />
              WhatsApp Web
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.open('https://faq.whatsapp.com/web/download-and-installation/how-to-use-whatsapp-web', '_blank')}
            >
              <ExternalLink className="h-3 w-3 mr-1" />
              Ayuda oficial
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default WhatsAppConnectionHelper;
