import { initializeApp, FirebaseApp } from 'firebase/app';
import { 
  getAuth, 
  Auth, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword,
  signInWithPopup,
  GoogleAuthProvider,
  signOut,
  onAuthStateChanged,
  User
} from 'firebase/auth';
import {
  getFirestore,
  Firestore,
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  addDoc,
  onSnapshot
} from 'firebase/firestore';

// CONFIGURACIÓN CENTRALIZADA - TU INSTANCIA REAL DE FIREBASE
const CENTRALIZED_FIREBASE_CONFIG = {
  apiKey: "AIzaSyDj-ia2nQFHf1X4hEduntX3rRbbRNix5vI",
  authDomain: "mitaller-91992.firebaseapp.com",
  projectId: "mitaller-91992",
  storageBucket: "mitaller-91992.firebasestorage.app",
  messagingSenderId: "347112144896",
  appId: "1:347112144896:web:373eb9ea0f0632fa0858e5",
  measurementId: "G-B0RD7R716T"
};

export interface FirebaseUser {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
}

class CentralizedFirebaseService {
  private app: FirebaseApp | null = null;
  private auth: Auth | null = null;
  private db: Firestore | null = null;
  private googleProvider: GoogleAuthProvider;
  private initialized = false;

  constructor() {
    this.googleProvider = new GoogleAuthProvider();
    this.googleProvider.addScope('profile');
    this.googleProvider.addScope('email');
    
    // Auto-inicializar con la configuración centralizada
    this.initialize();
  }

  private async initialize(): Promise<void> {
    if (this.initialized) return;

    try {
      // Usar la configuración centralizada del administrador
      this.app = initializeApp(CENTRALIZED_FIREBASE_CONFIG);
      this.auth = getAuth(this.app);
      this.db = getFirestore(this.app);
      this.initialized = true;
      
      console.log('✅ Firebase centralizado inicializado correctamente');
      console.log('🔧 Proyecto:', this.app.options.projectId);
    } catch (error) {
      console.error('❌ Error inicializando Firebase centralizado:', error);
      console.error('💡 Verifica la configuración Firebase en centralizedFirebaseService.ts');
      console.error('📖 O configura las variables de entorno VITE_FIREBASE_*');
    }
  }

  isReady(): boolean {
    const ready = this.initialized && this.app !== null && this.auth !== null && this.db !== null;
    if (!ready && import.meta.env.DEV) {
      console.warn('🔧 Firebase no está listo. Verifica la configuración.');
    }
    return ready;
  }

  // Authentication methods
  async signInWithEmail(email: string, password: string): Promise<{ user: FirebaseUser | null; error: string | null }> {
    if (!this.auth) {
      return { user: null, error: 'Firebase no está inicializado' };
    }

    try {
      const userCredential = await signInWithEmailAndPassword(this.auth, email, password);
      const user = this.mapFirebaseUser(userCredential.user);
      return { user, error: null };
    } catch (error: any) {
      return { user: null, error: this.getErrorMessage(error) };
    }
  }

  async signUpWithEmail(email: string, password: string, additionalData?: any): Promise<{ user: FirebaseUser | null; error: string | null }> {
    if (!this.auth || !this.db) {
      return { user: null, error: 'Firebase no está inicializado' };
    }

    try {
      const userCredential = await createUserWithEmailAndPassword(this.auth, email, password);
      const user = this.mapFirebaseUser(userCredential.user);
      
      // Create user profile document with workspace isolation
      if (additionalData) {
        await this.createUserProfile(userCredential.user.uid, {
          email,
          ...additionalData,
          createdAt: new Date().toISOString(),
          // Cada usuario tiene su propio "workspace" dentro de la misma instancia
          workspaceId: userCredential.user.uid
        });
      }
      
      return { user, error: null };
    } catch (error: any) {
      return { user: null, error: this.getErrorMessage(error) };
    }
  }

  async signInWithGoogle(): Promise<{ user: FirebaseUser | null; error: string | null }> {
    if (!this.auth) {
      return { user: null, error: 'Firebase no está inicializado' };
    }

    try {
      const result = await signInWithPopup(this.auth, this.googleProvider);
      const user = this.mapFirebaseUser(result.user);
      
      // Create or update user profile with workspace
      await this.createUserProfile(result.user.uid, {
        email: result.user.email,
        displayName: result.user.displayName,
        photoURL: result.user.photoURL,
        provider: 'google',
        lastLogin: new Date().toISOString(),
        workspaceId: result.user.uid
      });
      
      return { user, error: null };
    } catch (error: any) {
      return { user: null, error: this.getErrorMessage(error) };
    }
  }

  async signOut(): Promise<{ success: boolean; error: string | null }> {
    if (!this.auth) {
      return { success: false, error: 'Firebase no está inicializado' };
    }

    try {
      await signOut(this.auth);
      return { success: true, error: null };
    } catch (error: any) {
      return { success: false, error: this.getErrorMessage(error) };
    }
  }

  onAuthStateChanged(callback: (user: FirebaseUser | null) => void): () => void {
    if (!this.auth) {
      return () => {};
    }

    return onAuthStateChanged(this.auth, (user) => {
      callback(user ? this.mapFirebaseUser(user) : null);
    });
  }

  getCurrentUser(): FirebaseUser | null {
    if (!this.auth?.currentUser) {
      return null;
    }
    return this.mapFirebaseUser(this.auth.currentUser);
  }

  // Database methods with workspace isolation
  async createUserProfile(uid: string, data: any): Promise<boolean> {
    if (!this.db) return false;

    try {
      await setDoc(doc(this.db, 'users', uid), data, { merge: true });
      return true;
    } catch (error) {
      console.error('Error creating user profile:', error);
      return false;
    }
  }

  async getUserProfile(uid: string): Promise<any | null> {
    if (!this.db) return null;

    try {
      const docRef = doc(this.db, 'users', uid);
      const docSnap = await getDoc(docRef);
      return docSnap.exists() ? { id: docSnap.id, ...docSnap.data() } : null;
    } catch (error) {
      console.error('Error getting user profile:', error);
      return null;
    }
  }

  // Generic CRUD operations with automatic workspace isolation
  async addDocument(collectionName: string, data: any): Promise<{ id: string | null; error: string | null }> {
    if (!this.db || !this.auth?.currentUser) {
      return { id: null, error: 'Firebase no está inicializado o usuario no autenticado' };
    }

    try {
      // Añadir workspaceId automáticamente para aislamiento
      const docData = {
        ...data,
        workspaceId: this.auth.currentUser.uid, // Clave de aislamiento
        userId: this.auth.currentUser.uid,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      const docRef = await addDoc(collection(this.db, collectionName), docData);
      return { id: docRef.id, error: null };
    } catch (error: any) {
      return { id: null, error: this.getErrorMessage(error) };
    }
  }

  async updateDocument(collectionName: string, docId: string, data: any): Promise<{ success: boolean; error: string | null }> {
    if (!this.db) {
      return { success: false, error: 'Firebase no está inicializado' };
    }

    try {
      const updateData = {
        ...data,
        updatedAt: new Date().toISOString()
      };
      
      await updateDoc(doc(this.db, collectionName, docId), updateData);
      return { success: true, error: null };
    } catch (error: any) {
      return { success: false, error: this.getErrorMessage(error) };
    }
  }

  async deleteDocument(collectionName: string, docId: string): Promise<{ success: boolean; error: string | null }> {
    if (!this.db) {
      return { success: false, error: 'Firebase no está inicializado' };
    }

    try {
      await deleteDoc(doc(this.db, collectionName, docId));
      return { success: true, error: null };
    } catch (error: any) {
      return { success: false, error: this.getErrorMessage(error) };
    }
  }

  async getDocument(collectionName: string, docId: string): Promise<any | null> {
    if (!this.db) return null;

    try {
      const docRef = doc(this.db, collectionName, docId);
      const docSnap = await getDoc(docRef);
      return docSnap.exists() ? { id: docSnap.id, ...docSnap.data() } : null;
    } catch (error) {
      console.error('Error getting document:', error);
      return null;
    }
  }

  // Obtener documentos del workspace del usuario actual solamente
  async getUserDocuments(collectionName: string): Promise<any[]> {
    if (!this.db || !this.auth?.currentUser) return [];

    try {
      const q = query(
        collection(this.db, collectionName),
        where('workspaceId', '==', this.auth.currentUser.uid), // Solo documentos del workspace del usuario
        orderBy('createdAt', 'desc')
      );
      
      const querySnapshot = await getDocs(q);
      return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    } catch (error) {
      console.error('Error getting user documents:', error);
      return [];
    }
  }

  // Real-time listeners con aislamiento de workspace
  subscribeToUserDocuments(collectionName: string, callback: (documents: any[]) => void): () => void {
    if (!this.db || !this.auth?.currentUser) {
      return () => {};
    }

    const q = query(
      collection(this.db, collectionName),
      where('workspaceId', '==', this.auth.currentUser.uid), // Solo del workspace del usuario
      orderBy('createdAt', 'desc')
    );

    return onSnapshot(q, (querySnapshot) => {
      const documents = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      callback(documents);
    }, (error) => {
      console.error('Error in real-time listener:', error);
    });
  }

  // Data migration from localStorage with workspace isolation
  async migrateFromLocalStorage(): Promise<{ success: boolean; migrated: number; errors: string[] }> {
    if (!this.isReady()) {
      return { success: false, migrated: 0, errors: ['Firebase no está inicializado'] };
    }

    const errors: string[] = [];
    let migrated = 0;

    const collectionMappings = {
      'clientes': 'clientes',
      'inventario': 'inventario',
      'ordenes': 'ordenes_trabajo',
      'facturas': 'facturas',
      'gastos_mercancia': 'gastos_mercancia',
      'citas': 'citas'
    };

    try {
      for (const [localKey, collectionName] of Object.entries(collectionMappings)) {
        const localData = localStorage.getItem(localKey);
        if (localData) {
          try {
            const items = JSON.parse(localData);
            if (Array.isArray(items)) {
              for (const item of items) {
                const { id, error } = await this.addDocument(collectionName, item);
                if (error) {
                  errors.push(`Error migrando ${localKey}: ${error}`);
                } else {
                  migrated++;
                }
              }
            }
          } catch (error: any) {
            errors.push(`Error procesando ${localKey}: ${error.message}`);
          }
        }
      }

      return { success: errors.length === 0, migrated, errors };
    } catch (error: any) {
      return { success: false, migrated, errors: [error.message] };
    }
  }

  // Helper methods
  private mapFirebaseUser(user: User): FirebaseUser {
    return {
      uid: user.uid,
      email: user.email,
      displayName: user.displayName,
      photoURL: user.photoURL
    };
  }

  private getErrorMessage(error: any): string {
    switch (error.code) {
      case 'auth/user-not-found':
        return 'Usuario no encontrado';
      case 'auth/wrong-password':
        return 'Contraseña incorrecta';
      case 'auth/email-already-in-use':
        return 'El email ya está en uso';
      case 'auth/weak-password':
        return 'La contraseña es muy débil';
      case 'auth/invalid-email':
        return 'Email inválido';
      case 'auth/popup-closed-by-user':
        return 'Ventana de autenticación cerrada por el usuario';
      case 'auth/cancelled-popup-request':
        return 'Solicitud de autenticación cancelada';
      default:
        return error.message || 'Error desconocido';
    }
  }



  // Test connection
  async testConnection(): Promise<{ success: boolean; error?: string }> {
    if (!this.isReady()) {
      return { success: false, error: 'Firebase no está inicializado' };
    }

    try {
      // Test database connection by reading a test document
      const testDoc = doc(this.db!, 'test', 'connection');
      await getDoc(testDoc);
      return { success: true };
    } catch (error: any) {
      return { success: false, error: this.getErrorMessage(error) };
    }
  }
}

export const centralizedFirebaseService = new CentralizedFirebaseService();
