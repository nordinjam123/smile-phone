import { useState, useEffect } from 'react';
import { useLocalData } from '@/contexts/LocalDataContext';
import { LocalData } from '@/lib/localStorageService';

// Adapter hook to maintain compatibility with existing components
// that use useLocalStorage but now work with LocalDataContext

export function useLocalStorageAdapter<T>(key: string, initialValue: T[] = [] as T[]) {
  const [data, setData] = useState<T[]>(initialValue);
  const localDataContext = useLocalData();

  // Map collection names to LocalData methods
  const getCollectionMethods = (collectionKey: string) => {
    switch (collectionKey) {
      case 'clientes':
        return {
          data: localDataContext.clientes,
          add: localDataContext.addCliente,
          update: localDataContext.updateCliente,
          delete: localDataContext.deleteCliente
        };
      case 'inventario':
        return {
          data: localDataContext.inventario,
          add: localDataContext.addInventario,
          update: localDataContext.updateInventario,
          delete: localDataContext.deleteInventario
        };
      case 'ordenes':
        return {
          data: localDataContext.ordenes,
          add: localDataContext.addOrden,
          update: localDataContext.updateOrden,
          delete: localDataContext.deleteOrden
        };
      case 'facturas':
        return {
          data: localDataContext.facturas,
          add: localDataContext.addFactura,
          update: localDataContext.updateFactura,
          delete: localDataContext.deleteFactura
        };
      case 'gastos_mercancia':
        return {
          data: localDataContext.gastos,
          add: localDataContext.addGasto,
          update: localDataContext.updateGasto,
          delete: localDataContext.deleteGasto
        };
      case 'citas':
        return {
          data: localDataContext.citas,
          add: localDataContext.addCita,
          update: localDataContext.updateCita,
          delete: localDataContext.deleteCita
        };
      default:
        return {
          data: [],
          add: async () => null,
          update: async () => false,
          delete: async () => false
        };
    }
  };

  const methods = getCollectionMethods(key);

  useEffect(() => {
    // Convert LocalData to the expected format (remove internal fields)
    const convertedData = methods.data.map((item: LocalData) => {
      const { userId, createdAt, updatedAt, ...rest } = item;
      return rest as T;
    });
    setData(convertedData);
  }, [methods.data]);

  const addItem = async (item: Omit<T, 'id'>): Promise<string | null> => {
    const id = await methods.add(item);
    return id;
  };

  const updateItem = async (id: string, updates: Partial<T>): Promise<boolean> => {
    return await methods.update(id, updates);
  };

  const deleteItem = async (id: string): Promise<boolean> => {
    return await methods.delete(id);
  };

  const setItems = async (newItems: T[]): Promise<void> => {
    // For bulk operations, we'll handle this differently
    // This maintains compatibility but isn't efficient for large datasets
    console.warn('setItems is deprecated with LocalData. Use individual add/update/delete operations.');
  };

  return [
    data,
    setItems,
    addItem,
    updateItem,
    deleteItem
  ] as const;
}

// Backward compatibility export
export const useLocalStorage = useLocalStorageAdapter;
