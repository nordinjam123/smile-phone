import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Globe, 
  Smartphone, 
  Monitor, 
  Tablet, 
  Shield, 
  Clock, 
  Database,
  CheckCircle
} from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';

const DataAccessInfo: React.FC = () => {
  const { user } = useAuth();

  if (!user) {
    return null;
  }

  return (
    <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-blue-900">
          <Globe className="h-5 w-5" />
          Acceso Universal a tus Datos
        </CardTitle>
        <CardDescription>
          Todos tus datos están sincronizados en la nube y disponibles desde cualquier lugar
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Device Access */}
        <div>
          <h4 className="font-medium text-gray-900 mb-3">Accede desde cualquier dispositivo:</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="flex flex-col items-center p-3 bg-white rounded-lg border border-blue-100">
              <Monitor className="h-6 w-6 text-blue-600 mb-2" />
              <span className="text-xs text-center">Computadora</span>
            </div>
            <div className="flex flex-col items-center p-3 bg-white rounded-lg border border-blue-100">
              <Smartphone className="h-6 w-6 text-blue-600 mb-2" />
              <span className="text-xs text-center">Móvil</span>
            </div>
            <div className="flex flex-col items-center p-3 bg-white rounded-lg border border-blue-100">
              <Tablet className="h-6 w-6 text-blue-600 mb-2" />
              <span className="text-xs text-center">Tablet</span>
            </div>
            <div className="flex flex-col items-center p-3 bg-white rounded-lg border border-blue-100">
              <Globe className="h-6 w-6 text-blue-600 mb-2" />
              <span className="text-xs text-center">Cualquier lugar</span>
            </div>
          </div>
        </div>

        {/* Data Types */}
        <div>
          <h4 className="font-medium text-gray-900 mb-3">Información almacenada en la nube:</h4>
          <div className="grid grid-cols-2 gap-2">
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>Órdenes de reparación</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>Base de datos de clientes</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>Inventario completo</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>Historial de ventas</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>Gastos y finanzas</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>Configuración del taller</span>
            </div>
          </div>
        </div>

        {/* Security & Features */}
        <div className="flex flex-wrap gap-2">
          <Badge variant="outline" className="flex items-center gap-1">
            <Shield className="h-3 w-3" />
            Datos seguros
          </Badge>
          <Badge variant="outline" className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            Sincronización automática
          </Badge>
          <Badge variant="outline" className="flex items-center gap-1">
            <Database className="h-3 w-3" />
            Backup automático
          </Badge>
        </div>

        {/* Access Instructions */}
        <div className="bg-white p-4 rounded-lg border border-blue-100">
          <h4 className="font-medium text-gray-900 mb-2">¿Cómo acceder desde otro dispositivo?</h4>
          <ol className="text-sm text-gray-600 space-y-1">
            <li>1. Ve a la URL de TallerPro desde cualquier navegador</li>
            <li>2. Inicia sesión con tu email: <span className="font-mono bg-gray-100 px-1 rounded">{user.email}</span></li>
            <li>3. Introduce tu contraseña</li>
            <li>4. ¡Todos tus datos estarán disponibles automáticamente!</li>
          </ol>
        </div>

        {/* Current Session Info */}
        <div className="text-xs text-gray-500 text-center">
          Sesión actual: {user.email} • Datos sincronizados en tiempo real
        </div>
      </CardContent>
    </Card>
  );
};

export default DataAccessInfo;
