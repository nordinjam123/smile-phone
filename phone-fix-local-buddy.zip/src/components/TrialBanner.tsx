import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Clock, Crown, Calendar } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';

interface TrialBannerProps {
  onUpgrade: () => void;
}

const TrialBanner: React.FC<TrialBannerProps> = ({ onUpgrade }) => {
  const { subscriptionData } = useAuth();

  // Don't show banner if user is subscribed or has lifetime access
  if (!subscriptionData || subscriptionData.subscribed || subscriptionData.is_lifetime_free) {
    return null;
  }

  const isInTrial = subscriptionData.trial_start && subscriptionData.trial_end;
  const trialEnd = subscriptionData.trial_end ? new Date(subscriptionData.trial_end) : null;
  const now = new Date();
  const hasAccess = subscriptionData.has_access;

  // Calculate days remaining
  let daysRemaining = 0;
  if (trialEnd && trialEnd > now) {
    const diffTime = trialEnd.getTime() - now.getTime();
    daysRemaining = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  }

  if (!hasAccess && (!isInTrial || daysRemaining <= 0)) {
    // Trial expired or never started - show subscription required
    return (
      <Card className="border-red-200 bg-red-50 mb-6">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-red-100 rounded-full">
                <Clock className="h-5 w-5 text-red-600" />
              </div>
              <div>
                <h3 className="font-semibold text-red-800">¡Tu prueba gratuita ha terminado!</h3>
                <p className="text-sm text-red-600">
                  Suscríbete ahora para continuar usando todas las funcionalidades profesionales de TallerPro.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge className="bg-green-100 text-green-800 border-green-300">
                Desde 15€/mes
              </Badge>
              <Button onClick={onUpgrade} className="bg-red-600 hover:bg-red-700">
                <Crown className="h-4 w-4 mr-2" />
                Suscribirse
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (hasAccess && isInTrial && daysRemaining > 0) {
    // In trial period - show remaining days
    return (
      <Card className="border-green-200 bg-gradient-to-r from-green-50 to-emerald-50 mb-6">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-100 rounded-full">
                <Calendar className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-semibold text-green-800">🎉 Prueba Gratuita Activa</h3>
                  <Badge variant="outline" className="border-green-300 text-green-700">
                    {daysRemaining} día{daysRemaining !== 1 ? 's' : ''} restante{daysRemaining !== 1 ? 's' : ''}
                  </Badge>
                </div>
                <p className="text-sm text-green-600">
                  Disfruta acceso completo a todas las funcionalidades durante tu prueba de 7 días.
                  ¡Sin compromisos ni datos bancarios!
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge className="bg-blue-100 text-blue-800 border-blue-300">
                Después 15€/mes
              </Badge>
              <Button onClick={onUpgrade} variant="outline" className="border-green-300 text-green-700 hover:bg-green-100">
                <Crown className="h-4 w-4 mr-2" />
                Ver Planes
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  // New user - offer free trial
  return (
    <Card className="border-blue-200 bg-gradient-to-r from-blue-50 to-indigo-50 mb-6">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-100 rounded-full">
              <Crown className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <h3 className="font-semibold text-blue-800">¡Prueba TallerPro GRATIS por 7 días!</h3>
              <p className="text-sm text-blue-600">
                🚀 Acceso completo a todas las funcionalidades profesionales.
                Sin tarjeta de crédito ni compromisos.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge className="bg-green-100 text-green-800 border-green-300">
              7 días GRATIS
            </Badge>
            <Button onClick={onUpgrade} className="bg-blue-600 hover:bg-blue-700">
              <Crown className="h-4 w-4 mr-2" />
              Comenzar Prueba
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default TrialBanner;
