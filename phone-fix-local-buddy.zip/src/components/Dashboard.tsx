import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Wrench, 
  Users, 
  Package, 
  DollarSign,
  Clock,
  CheckCircle,
  AlertTriangle,
  TrendingUp,
  Plus
} from "lucide-react";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import TrialBanner from "./TrialBanner";
import LocalBackupManager from "./LocalBackupManager";

import { useAuth } from "@/hooks/useAuth";
import { useTranslation, useFormatMessage } from "@/lib/i18n/useTranslation";

interface DashboardProps {
  onSectionChange: (section: string) => void;
}

export default function Dashboard({ onSectionChange }: DashboardProps) {
  const [ordenes] = useLocalStorage("ordenes", []);
  const [clientes] = useLocalStorage("clientes", []);
  const [inventario] = useLocalStorage("inventario", []);
  const { subscriptionData } = useAuth();
  const { t } = useTranslation();
  const { formatMessage } = useFormatMessage();

  const ordenesAbiertas = ordenes.filter((orden: any) => orden.estado === "pendiente").length;
  const ordenesEnProceso = ordenes.filter((orden: any) => orden.estado === "en_proceso").length;
  const ordenesCompletadas = ordenes.filter((orden: any) => orden.estado === "completado").length;
  const totalIngresos = ordenes
    .filter((orden: any) => orden.estado === "completado")
    .reduce((total: number, orden: any) => total + (orden.precio || 0), 0);

  const productosAgotados = inventario.filter((item: any) => item.stock <= 5).length;

  return (
    <div className="p-6 space-y-6">
      <TrialBanner onUpgrade={() => onSectionChange("suscripcion")} />
      
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">{t.dashboard.welcome}</h1>
          <p className="text-slate-600 mt-2">
            {t.dashboard.description}
          </p>
        </div>
        <Button 
          onClick={() => onSectionChange("ordenes")}
          className="bg-primary hover:bg-primary/90"
        >
          <Plus className="w-4 h-4 mr-2" />
          {t.dashboard.newOrder}
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="border-l-4 border-l-blue-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t.dashboard.openOrders}</CardTitle>
            <Clock className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{ordenesAbiertas}</div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-yellow-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t.dashboard.inProgress}</CardTitle>
            <Wrench className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{ordenesEnProceso}</div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t.dashboard.completed}</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{ordenesCompletadas}</div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-purple-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{t.dashboard.totalRevenue}</CardTitle>
            <DollarSign className="h-4 w-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">€{totalIngresos.toLocaleString()}</div>
          </CardContent>
        </Card>
      </div>

      {/* Local Backup Manager */}
      <LocalBackupManager />

      {/* Quick Actions & Info */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5" />
              {t.dashboard.quickActions}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button 
              variant="outline" 
              className="w-full justify-start"
              onClick={() => onSectionChange("ordenes")}
            >
              <Wrench className="w-4 h-4 mr-2" />
              {t.dashboard.newRepairOrder}
            </Button>
            <Button 
              variant="outline" 
              className="w-full justify-start"
              onClick={() => onSectionChange("clientes")}
            >
              <Users className="w-4 h-4 mr-2" />
              {t.dashboard.addClient}
            </Button>
            <Button 
              variant="outline" 
              className="w-full justify-start"
              onClick={() => onSectionChange("inventario")}
            >
              <Package className="w-4 h-4 mr-2" />
              {t.dashboard.manageInventory}
            </Button>
          </CardContent>
        </Card>

        {/* Status Overview */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5" />
              {t.dashboard.businessStatus}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm">{t.dashboard.totalClients}</span>
              <span className="font-semibold">{clientes.length}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">{t.dashboard.inventoryProducts}</span>
              <span className="font-semibold">{inventario.length}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">{t.dashboard.lowStockProducts}</span>
              <span className={`font-semibold ${productosAgotados > 0 ? 'text-red-600' : 'text-green-600'}`}>
                {productosAgotados}
              </span>
            </div>
            {productosAgotados > 0 && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-sm text-red-700">
                  {formatMessage(t.dashboard.lowStockWarning, { count: productosAgotados })}
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>




    </div>
  );
}
