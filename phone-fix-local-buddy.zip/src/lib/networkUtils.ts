// Utilidades para manejo de red y conectividad

export function isNetworkError(error: any): boolean {
  const errorMessage = error?.message?.toLowerCase() || '';
  const errorName = error?.name?.toLowerCase() || '';
  
  return (
    errorName === 'aborterror' ||
    errorName === 'typeerror' ||
    errorMessage.includes('failed to fetch') ||
    errorMessage.includes('network') ||
    errorMessage.includes('connection') ||
    errorMessage.includes('timeout') ||
    errorMessage.includes('cors') ||
    error?.code === 'NETWORK_ERROR'
  );
}

export function isSupabaseUnavailable(error: any): boolean {
  const errorMessage = error?.message?.toLowerCase() || '';
  
  return (
    errorMessage.includes('functionsfetcherror') ||
    errorMessage.includes('failed to send a request to the edge function') ||
    errorMessage.includes('edge function') ||
    isNetworkError(error)
  );
}

export function getNetworkErrorMessage(error: any): string {
  if (error?.name === 'AbortError') {
    return 'La operación ha tardado demasiado. Verifica tu conexión.';
  }
  
  if (error?.message?.includes('Failed to fetch')) {
    return 'Error de conexión. Verifica tu conexión a internet.';
  }
  
  if (error?.message?.includes('FunctionsFetchError')) {
    return 'Servicio temporalmente no disponible. La aplicación funcionará en modo offline.';
  }
  
  if (isNetworkError(error)) {
    return 'Problemas de conectividad detectados. Algunas funciones pueden no estar disponibles.';
  }
  
  return error?.message || 'Error desconocido';
}

export async function checkConnectivity(): Promise<boolean> {
  try {
    // Intentar hacer una petición simple a un endpoint confiable
    const response = await fetch('https://httpbin.org/status/200', {
      method: 'HEAD',
      mode: 'no-cors',
      signal: AbortSignal.timeout(5000)
    });
    return true;
  } catch (error) {
    console.warn('Connectivity check failed:', error);
    return false;
  }
}

export function createTimeoutController(timeoutMs: number = 10000): AbortController {
  const controller = new AbortController();
  setTimeout(() => controller.abort(), timeoutMs);
  return controller;
}

// Hook para usar en componentes que necesiten detectar estado de red
export function useNetworkStatus() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [lastChecked, setLastChecked] = useState<Date>(new Date());

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Verificar conectividad cada 30 segundos si está offline
    const interval = setInterval(async () => {
      if (!isOnline) {
        const connected = await checkConnectivity();
        if (connected !== isOnline) {
          setIsOnline(connected);
          setLastChecked(new Date());
        }
      }
    }, 30000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(interval);
    };
  }, [isOnline]);

  return { isOnline, lastChecked };
}

// Wrapper para operaciones que pueden fallar por red
export async function withNetworkFallback<T>(
  operation: () => Promise<T>,
  fallback: T,
  timeoutMs: number = 10000
): Promise<T> {
  try {
    const controller = createTimeoutController(timeoutMs);
    
    // Si la operación es una función que acepta AbortSignal, pasárselo
    if (operation.length > 0) {
      return await (operation as any)(controller.signal);
    } else {
      return await operation();
    }
  } catch (error) {
    if (isNetworkError(error) || isSupabaseUnavailable(error)) {
      console.warn('Operation failed due to network issues, using fallback:', getNetworkErrorMessage(error));
      return fallback;
    }
    throw error; // Re-lanzar si no es un error de red
  }
}
