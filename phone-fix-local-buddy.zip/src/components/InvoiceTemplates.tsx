import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { FileText, Palette, Plus, Edit, Trash2, Copy } from 'lucide-react';

interface InvoiceTemplate {
  id: string;
  name: string;
  template_data: any;
  is_default: boolean;
  created_at: string;
}

interface InvoiceTemplatesProps {
  onSelectTemplate: (template: InvoiceTemplate) => void;
}

const InvoiceTemplates: React.FC<InvoiceTemplatesProps> = ({ onSelectTemplate }) => {
  const [templates, setTemplates] = useState<InvoiceTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchTemplates();
  }, []);

  const fetchTemplates = async () => {
    try {
      // Fetch global templates (user_id is null) and user templates
      const { data, error } = await supabase
        .from('invoice_templates')
        .select('*')
        .or('user_id.is.null,user_id.eq.' + (await supabase.auth.getUser()).data.user?.id)
        .order('is_default', { ascending: false });

      if (error) throw error;
      setTemplates(data || []);
    } catch (error: any) {
      toast({
        title: "Error",
        description: "No se pudieron cargar las plantillas",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSelectTemplate = (template: InvoiceTemplate) => {
    onSelectTemplate(template);
    toast({
      title: "Plantilla seleccionada",
      description: `Usando plantilla: ${template.name}`,
    });
  };

  const handleDuplicateTemplate = async (template: InvoiceTemplate) => {
    try {
      const user = await supabase.auth.getUser();
      if (!user.data.user) return;

      const { error } = await supabase.from('invoice_templates').insert({
        name: `${template.name} (Copia)`,
        template_data: template.template_data,
        user_id: user.data.user.id,
        is_default: false
      });

      if (error) throw error;

      await fetchTemplates();
      toast({
        title: "Plantilla duplicada",
        description: "Plantilla copiada a tus plantillas personales",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: "No se pudo duplicar la plantilla",
        variant: "destructive",
      });
    }
  };

  const handleCreateTemplate = async () => {
    try {
      const user = await supabase.auth.getUser();
      if (!user.data.user) return;

      const newTemplate = {
        name: "Nueva Plantilla",
        template_data: {
          layout: "personalizada",
          colors: {
            primary: "#2563eb",
            secondary: "#64748b",
            accent: "#f59e0b"
          },
          header: {
            showLogo: true,
            companyInfo: true,
            layout: "left-aligned"
          },
          sections: {
            customerInfo: true,
            itemsTable: true,
            totals: true,
            terms: true
          },
          styling: {
            font: "Arial",
            border: true,
            shadows: false
          }
        },
        user_id: user.data.user.id,
        is_default: false
      };

      const { error } = await supabase.from('invoice_templates').insert(newTemplate);

      if (error) throw error;

      await fetchTemplates();
      toast({
        title: "Plantilla creada",
        description: "Nueva plantilla personalizada creada",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: "No se pudo crear la plantilla",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-48">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          <h3 className="text-lg font-semibold">Plantillas de Factura</h3>
        </div>
        <Button onClick={handleCreateTemplate} size="sm">
          <Plus className="h-4 w-4 mr-2" />
          Nueva Plantilla
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {templates.map((template) => (
          <Card 
            key={template.id} 
            className="cursor-pointer hover:shadow-md transition-all duration-200 group"
          >
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">{template.name}</CardTitle>
                {template.is_default && (
                  <Badge variant="default" className="text-xs">
                    Predeterminada
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Palette className="h-4 w-4" />
                <span>
                  Diseño: {template.template_data?.layout || 'Básico'}
                </span>
              </div>
              
              <div className="flex gap-2">
                <Button
                  onClick={() => handleSelectTemplate(template)}
                  className="flex-1"
                  size="sm"
                >
                  Usar Plantilla
                </Button>
                <Button
                  onClick={() => handleDuplicateTemplate(template)}
                  variant="outline"
                  size="sm"
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {templates.length === 0 && (
        <div className="text-center py-8">
          <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg font-semibold mb-2">No hay plantillas disponibles</h3>
          <p className="text-muted-foreground">
            Las plantillas predeterminadas se cargarán automáticamente
          </p>
        </div>
      )}
    </div>
  );
};

export default InvoiceTemplates;