import React from 'react';

interface SimpleIconProps {
  className?: string;
  size?: number;
}

// Icono principal de WhatsApp usando emoji
export const SimpleWhatsAppIcon: React.FC<SimpleIconProps> = ({ 
  className = "w-6 h-6", 
  size 
}) => (
  <div 
    className={`${className} flex items-center justify-center bg-green-500 text-white rounded-full font-bold text-sm`}
    style={size ? { width: size, height: size, fontSize: size * 0.6 } : {}}
  >
    💬
  </div>
);

// Icono de estado con emoji
export const SimpleWhatsAppStatusIcon: React.FC<SimpleIconProps & { 
  status: 'connected' | 'disconnected' | 'connecting' 
}> = ({ 
  className = "w-4 h-4", 
  size,
  status 
}) => {
  const getEmoji = () => {
    switch (status) {
      case 'connected': return '✅';
      case 'disconnected': return '❌';
      case 'connecting': return '🔄';
      default: return '❓';
    }
  };

  const getColor = () => {
    switch (status) {
      case 'connected': return 'text-green-600';
      case 'disconnected': return 'text-red-600';
      case 'connecting': return 'text-yellow-600';
      default: return 'text-gray-600';
    }
  };

  return (
    <div className={`inline-flex items-center gap-1 ${getColor()}`}>
      <span 
        className={className}
        style={size ? { fontSize: size } : {}}
      >
        {getEmoji()}
      </span>
      <span className="text-xs font-medium">
        {status === 'connected' && 'Conectado'}
        {status === 'disconnected' && 'Desconectado'}
        {status === 'connecting' && 'Conectando...'}
      </span>
    </div>
  );
};

// Badge simple de estado
export const SimpleWhatsAppBadge: React.FC<{
  status: 'active' | 'inactive' | 'error' | 'connecting';
  children: React.ReactNode;
  className?: string;
}> = ({ status, children, className = "" }) => {
  const getStatusStyles = () => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'inactive':
        return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'error':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'connecting':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getEmoji = () => {
    switch (status) {
      case 'active': return '💬';
      case 'inactive': return '📱';
      case 'error': return '⚠️';
      case 'connecting': return '🔄';
      default: return '💬';
    }
  };

  return (
    <div className={`inline-flex items-center gap-1 px-2 py-1 rounded-full border text-xs font-medium ${getStatusStyles()} ${className}`}>
      <span>{getEmoji()}</span>
      {children}
    </div>
  );
};

// Icono de teléfono con indicador de WhatsApp
export const SimpleWhatsAppPhoneIcon: React.FC<SimpleIconProps> = ({ 
  className = "w-5 h-5", 
  size 
}) => (
  <div className="relative inline-block">
    <span 
      className={className}
      style={size ? { fontSize: size } : {}}
    >
      📞
    </span>
    <span className="absolute -top-1 -right-1 text-xs">💬</span>
  </div>
);

// Icono de chat/conversación
export const SimpleWhatsAppChatIcon: React.FC<SimpleIconProps> = ({ 
  className = "w-5 h-5", 
  size 
}) => (
  <span 
    className={className}
    style={size ? { fontSize: size } : {}}
  >
    💬
  </span>
);

// Icono de notificación
export const SimpleWhatsAppNotificationIcon: React.FC<SimpleIconProps & { 
  hasNotification?: boolean 
}> = ({ 
  className = "w-5 h-5", 
  size,
  hasNotification = false 
}) => (
  <div className="relative inline-block">
    <SimpleWhatsAppIcon className={className} size={size} />
    {hasNotification && (
      <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full flex items-center justify-center">
        <span className="text-white text-xs font-bold">!</span>
      </div>
    )}
  </div>
);

// Fallback muy simple usando solo texto
export const SimpleWhatsAppFallback: React.FC<{ 
  text?: string; 
  className?: string;
}> = ({ 
  text = "WA", 
  className = "w-6 h-6" 
}) => (
  <div className={`${className} bg-green-500 text-white rounded-full flex items-center justify-center text-xs font-bold`}>
    {text}
  </div>
);

// Indicador de método de envío
export const WhatsAppMethodIndicator: React.FC<{
  method: 'desktop' | 'web' | 'mobile' | 'clipboard';
  className?: string;
}> = ({ method, className = "" }) => {
  const getMethodInfo = () => {
    switch (method) {
      case 'desktop':
        return { emoji: '🖥️', name: 'Desktop', color: 'text-blue-600' };
      case 'web':
        return { emoji: '🌐', name: 'Web', color: 'text-green-600' };
      case 'mobile':
        return { emoji: '📱', name: 'Móvil', color: 'text-purple-600' };
      case 'clipboard':
        return { emoji: '📋', name: 'Clipboard', color: 'text-orange-600' };
      default:
        return { emoji: '❓', name: 'Desconocido', color: 'text-gray-600' };
    }
  };

  const info = getMethodInfo();

  return (
    <div className={`inline-flex items-center gap-1 ${info.color} ${className}`}>
      <span>{info.emoji}</span>
      <span className="text-xs font-medium">{info.name}</span>
    </div>
  );
};

// Componente que muestra todos los métodos disponibles
export const WhatsAppMethodsDisplay: React.FC<{
  methods: Array<{
    type: 'desktop' | 'web' | 'mobile' | 'clipboard';
    available: boolean;
    name: string;
    priority: number;
  }>;
  className?: string;
}> = ({ methods, className = "" }) => {
  return (
    <div className={`space-y-2 ${className}`}>
      <h4 className="text-sm font-medium text-gray-700">Métodos disponibles:</h4>
      <div className="space-y-1">
        {methods.map((method, index) => (
          <div 
            key={method.type} 
            className={`flex items-center justify-between p-2 rounded-lg ${
              method.available ? 'bg-green-50 border border-green-200' : 'bg-gray-50 border border-gray-200'
            }`}
          >
            <div className="flex items-center gap-2">
              <WhatsAppMethodIndicator method={method.type} />
              <span className={`text-sm ${method.available ? 'text-green-800' : 'text-gray-500'}`}>
                {method.name}
              </span>
            </div>
            <div className="flex items-center gap-1">
              <span className="text-xs text-gray-500">#{method.priority}</span>
              <span className="text-xs">
                {method.available ? '✅' : '❌'}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
