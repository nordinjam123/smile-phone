import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import { useToast } from "@/hooks/use-toast";
import { sendOrderReceivedMessage, sendOrderInProgressMessage, sendOrderCompletedMessage, sendOrderDeliveredMessage, sendCustomMessage, isWhatsAppEnabled, sendReminderMessage } from "@/lib/whatsappUtils";
import { sendFixedStatusUpdate, sendFixedCustomMessage, sendFixedReminder, sendFixedTestMessage } from "@/lib/fixedWhatsappMessages";
import { ensureWhatsAppIsEnabled } from "@/lib/whatsappAutoConfig";
import FixedWhatsAppDiagnostic from "./FixedWhatsAppDiagnostic";

import {
  Plus,
  Search,
  Edit,
  Trash2,
  Eye,
  Smartphone,
  Calendar,
  Clock,
  User,
  Phone,
  MessageSquare,
  QrCode,
  CheckCircle,
  PlayCircle,
  Package,
  Send,
  ArrowRight,
  Zap
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import QRReader from "./QRReader";
import { useEmpresaConfig } from "@/hooks/useEmpresaConfig";

interface Orden {
  id: string;
  clienteNombre: string;
  clienteTelefono: string;
  dispositivo: string;
  marca: string;
  modelo: string;
  problema: string;
  diagnostico: string;
  coste: number;
  precio: number;
  estado: "pendiente" | "en_proceso" | "completado" | "entregado";
  fechaIngreso: string;
  fechaEstimada: string;
  fechaCompletado?: string;
}

const estadoColors = {
  pendiente: "bg-yellow-100 text-yellow-800 border-yellow-300",
  en_proceso: "bg-blue-100 text-blue-800 border-blue-300",
  completado: "bg-green-100 text-green-800 border-green-300",
  entregado: "bg-gray-100 text-gray-800 border-gray-300"
};

const estadoLabels = {
  pendiente: "Pendiente",
  en_proceso: "En Proceso",
  completado: "Completado",
  entregado: "Entregado"
};

export default function OrdenesTrabajoPage() {
  const [ordenes, setOrdenes] = useLocalStorage<Orden[]>("ordenes", []);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterEstado, setFilterEstado] = useState<string>("todos");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingOrder, setEditingOrder] = useState<Orden | null>(null);

  const [isQRReaderOpen, setIsQRReaderOpen] = useState(false);
  const [showWhatsAppDiagnostic, setShowWhatsAppDiagnostic] = useState(false);
  const { config: empresaConfig } = useEmpresaConfig();
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    clienteNombre: "",
    clienteTelefono: "",
    dispositivo: "smartphone",
    marca: "",
    modelo: "",
    problema: "",
    diagnostico: "",
    coste: "",
    precio: "",
    estado: "pendiente" as Orden["estado"],
    fechaEstimada: ""
  });

  // Función para enviar actualizaciones de estado por WhatsApp
  const sendStatusUpdate = async (orden: Orden, estadoAnterior: string, nuevoEstado: string) => {
    // Auto-activar WhatsApp si no está configurado
    ensureWhatsAppIsEnabled();

    if (!isWhatsAppEnabled() || !orden.clienteTelefono) return false;

    let mensaje = '';
    const dispositivo = `${orden.marca} ${orden.modelo}`;

    switch (nuevoEstado) {
      case 'en_proceso':
        mensaje = `Hola ${orden.clienteNombre}!\n\nTu ${dispositivo} ha sido asignado a nuestro tecnico y esta siendo revisado.\n\nOrden: #${orden.id}\nEstado: EN PROCESO\n\nTe mantendremos informado del progreso.`;
        break;
      case 'completado':
        mensaje = `✅ ¡Buenas noticias ${orden.clienteNombre}!\n\nTu ${dispositivo} ha sido reparado exitosamente.\n\n📋 Orden: #${orden.id}\n⏰ Estado: COMPLETADO\n💰 Total: €${orden.precio.toFixed(2)}\n\n📍 Ya puedes pasar a recogerlo.\n\nHorario: L-V 9:00-18:00`;
        break;
      case 'entregado':
        mensaje = `📦 Gracias ${orden.clienteNombre}!\n\nTu ${dispositivo} ha sido entregado correctamente.\n\n📋 Orden: #${orden.id}\n⏰ Estado: ENTREGADO\n\n¡Esperamos que disfrutes de tu dispositivo reparado!\n\nNo dudes en contactarnos si necesitas algo más.`;
        break;
      default:
        return false;
    }

    if (orden.diagnostico && nuevoEstado === 'en_proceso') {
      mensaje += `\n\n🔍 Diagnóstico: ${orden.diagnostico}`;
    }

    // CAMBIO: Usar función corregida
    return await sendFixedStatusUpdate({
      id: orden.id,
      clienteNombre: orden.clienteNombre,
      clienteTelefono: orden.clienteTelefono,
      dispositivo: orden.dispositivo,
      marca: orden.marca,
      modelo: orden.modelo,
      problema: orden.problema,
      diagnostico: orden.diagnostico,
      precio: orden.precio,
      estado: nuevoEstado
    }, estadoAnterior, nuevoEstado);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.clienteNombre || !formData.problema) {
      toast({
        title: "Error",
        description: "Por favor completa los campos obligatorios",
        variant: "destructive"
      });
      return;
    }

    const nuevaOrden: Orden = {
      id: editingOrder?.id || Date.now().toString(),
      clienteNombre: formData.clienteNombre,
      clienteTelefono: formData.clienteTelefono,
      dispositivo: formData.dispositivo,
      marca: formData.marca,
      modelo: formData.modelo,
      problema: formData.problema,
      diagnostico: formData.diagnostico,
      coste: parseFloat(formData.coste) || 0,
      precio: parseFloat(formData.precio) || 0,
      estado: formData.estado,
      fechaIngreso: editingOrder?.fechaIngreso || new Date().toISOString().split('T')[0],
      fechaEstimada: formData.fechaEstimada,
      fechaCompletado: formData.estado === "completado" ? new Date().toISOString().split('T')[0] : editingOrder?.fechaCompletado
    };

    if (editingOrder) {
      setOrdenes(ordenes.map(orden => orden.id === editingOrder.id ? nuevaOrden : orden));

      // Detectar cambios de estado para enviar notificaciones automáticas
      const estadoAnterior = editingOrder.estado;
      const nuevoEstado = nuevaOrden.estado;

      if (estadoAnterior !== nuevoEstado) {
        // Enviar notificación de cambio de estado
        sendStatusUpdate(nuevaOrden, estadoAnterior, nuevoEstado).then(sent => {
          if (sent) {
            toast({
              title: "✅ Orden actualizada",
              description: `Estado cambiado a "${estadoLabels[nuevoEstado]}" y mensaje WhatsApp enviado`,
              variant: "default"
            });
          } else {
            toast({
              title: "Orden actualizada",
              description: `Estado cambiado a "${estadoLabels[nuevoEstado]}"`,
              variant: "default"
            });
          }
        });
      } else if (editingOrder.diagnostico !== nuevaOrden.diagnostico && nuevaOrden.diagnostico) {
        // Si se actualiza el diagnóstico, enviar notificación
        const mensaje = `🔍 ${nuevaOrden.clienteNombre}, hemos actualizado el diagnóstico de tu ${nuevaOrden.marca} ${nuevaOrden.modelo}:\n\n📋 Orden: #${nuevaOrden.id}\n🔧 Diagnóstico: ${nuevaOrden.diagnostico}\n\nTe mantendremos informado del progreso.`;

        sendCustomMessage(nuevaOrden.clienteTelefono, mensaje).then(sent => {
          if (sent) {
            toast({
              title: "Diagnóstico actualizado",
              description: "Diagnóstico actualizado y notificación WhatsApp enviada",
              variant: "default"
            });
          } else {
            toast({
              title: "Diagnóstico actualizado",
              description: "El diagnóstico ha sido actualizado exitosamente"
            });
          }
        });
      } else {
        toast({
          title: "Orden actualizada",
          description: "La orden de trabajo ha sido actualizada exitosamente"
        });
      }
    } else {
      setOrdenes([...ordenes, nuevaOrden]);

      // Enviar mensaje de WhatsApp para nueva orden
      sendOrderReceivedMessage({
        cliente: nuevaOrden.clienteNombre,
        telefono: nuevaOrden.clienteTelefono,
        id: nuevaOrden.id,
        dispositivo: nuevaOrden.dispositivo,
        marca: nuevaOrden.marca,
        modelo: nuevaOrden.modelo,
        descripcionProblema: nuevaOrden.problema,
        fechaRecepcion: nuevaOrden.fechaIngreso
      }).then(sent => {
        if (sent) {
          toast({
            title: "✅ Orden creada",
            description: "Nueva orden creada y mensaje de WhatsApp enviado",
            variant: "default"
          });
        } else {
          toast({
            title: "Orden creada",
            description: "Nueva orden de trabajo creada exitosamente"
          });
        }
      });
    }

    resetForm();
    setIsDialogOpen(false);
  };

  const resetForm = () => {
    setFormData({
      clienteNombre: "",
      clienteTelefono: "",
      dispositivo: "smartphone",
      marca: "",
      modelo: "",
      problema: "",
      diagnostico: "",
      coste: "",
      precio: "",
      estado: "pendiente",
      fechaEstimada: ""
    });
    setEditingOrder(null);
  };

  const handleEdit = (orden: Orden) => {
    setEditingOrder(orden);
    setFormData({
      clienteNombre: orden.clienteNombre,
      clienteTelefono: orden.clienteTelefono,
      dispositivo: orden.dispositivo,
      marca: orden.marca,
      modelo: orden.modelo,
      problema: orden.problema,
      diagnostico: orden.diagnostico,
      coste: orden.coste.toString(),
      precio: orden.precio.toString(),
      estado: orden.estado,
      fechaEstimada: orden.fechaEstimada
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    setOrdenes(ordenes.filter(orden => orden.id !== id));
    toast({
      title: "Orden eliminada",
      description: "La orden de trabajo ha sido eliminada"
    });
  };

  // Función para cambio rápido de estado
  const cambiarEstadoRapido = async (orden: Orden, nuevoEstado: Orden["estado"]) => {
    const estadoAnterior = orden.estado;
    const ordenActualizada = {
      ...orden,
      estado: nuevoEstado,
      fechaCompletado: nuevoEstado === "completado" ? new Date().toISOString().split('T')[0] : orden.fechaCompletado
    };

    setOrdenes(ordenes.map(o => o.id === orden.id ? ordenActualizada : o));

    // Enviar notificación automática si hay cambio de estado
    if (estadoAnterior !== nuevoEstado) {
      const sent = await sendStatusUpdate(ordenActualizada, estadoAnterior, nuevoEstado);
      if (sent) {
        toast({
          title: `✅ Estado actualizado`,
          description: `Cambiado a "${estadoLabels[nuevoEstado]}" y WhatsApp enviado`,
          variant: "default"
        });
      } else {
        toast({
          title: "Estado actualizado",
          description: `Cambiado a "${estadoLabels[nuevoEstado]}"`,
          variant: "default"
        });
      }
    }
  };

  // Función para enviar mensaje personalizado
  const enviarMensajePersonalizado = async (orden: Orden) => {
    const mensaje = `Hola ${orden.clienteNombre} 👋\n\n📱 Respecto a tu ${orden.marca} ${orden.modelo}:\n\n📋 Orden: #${orden.id}\n⏰ Estado actual: ${estadoLabels[orden.estado]}\n\n¿Necesitas alguna información adicional? Estamos aquí para ayudarte.`;

    const sent = await sendCustomMessage(orden.clienteTelefono, mensaje);
    if (sent) {
      toast({
        title: "✅ Mensaje enviado",
        description: "Se ha abierto WhatsApp Web con el mensaje",
        variant: "default"
      });
    }
  };

  // Función para enviar recordatorio de recogida
  const enviarRecordatorio = async (orden: Orden) => {
    const sent = await sendReminderMessage({
      cliente: orden.clienteNombre,
      telefono: orden.clienteTelefono,
      id: orden.id,
      dispositivo: `${orden.marca} ${orden.modelo}`,
      fechaRecepcion: orden.fechaIngreso
    });

    if (sent) {
      toast({
        title: "✅ Recordatorio enviado",
        description: "Se ha enviado un recordatorio de recogida por WhatsApp",
        variant: "default"
      });
    }
  };

  // Calcular días transcurridos desde la recepción
  const calcularDiasTranscurridos = (fechaIngreso: string): number => {
    const fecha = new Date(fechaIngreso);
    const hoy = new Date();
    const diferencia = hoy.getTime() - fecha.getTime();
    return Math.floor(diferencia / (1000 * 60 * 60 * 24));
  };

  const handleGenerarTicketDirecto = async (orden: any) => {
    const jsPDF = (await import('jspdf')).default;
    const QRCode = (await import('qrcode')).default;

    // Usar configuración centralizada de empresa
    const configuracion = empresaConfig;

    // Generar QR codes
    let qrCodeUrl = "";
    let qrMovilUrl = "";

    try {
      const ordenData = {
        id: orden.id,
        tipo: 'ORDEN_TRABAJO',
        cliente: orden.clienteNombre,
        dispositivo: orden.dispositivo,
        marca: orden.marca,
        modelo: orden.modelo,
        fecha: orden.fechaIngreso,
        precio: orden.precio,
        empresa: {
          nombre: configuracion.nombreEmpresa,
          telefono: configuracion.telefono,
          email: configuracion.email
        }
      };

      qrCodeUrl = await QRCode.toDataURL(JSON.stringify(ordenData), {
        width: 128,
        margin: 2,
        color: { dark: '#000000', light: '#FFFFFF' },
        errorCorrectionLevel: 'M'
      });

      const movilData = {
        cliente: orden.clienteNombre,
        telefono: orden.clienteTelefono,
        dispositivo: orden.dispositivo,
        marca: orden.marca,
        modelo: orden.modelo,
        imei: orden.imei || '',
        orden_id: orden.id,
        tipo: 'IDENTIFICACION_MOVIL',
        empresa: configuracion.nombreEmpresa,
        empresa_telefono: configuracion.telefono
      };

      qrMovilUrl = await QRCode.toDataURL(JSON.stringify(movilData), {
        width: 96,
        margin: 1,
        color: { dark: '#000000', light: '#FFFFFF' },
        errorCorrectionLevel: 'H'
      });

      console.log('QRs generados:', {
        qrPrincipal: qrCodeUrl ? 'Generado' : 'Error',
        qrMovil: qrMovilUrl ? 'Generado' : 'Error'
      });
    } catch (error) {
      console.error('Error generando QR codes:', error);
    }

    // Generar PDF con altura dinámica suficiente para ambos QRs
    // Altura base + QR principal + etiqueta móvil + márgenes
    const baseHeight = 200; // Contenido base
    const qrHeight = qrCodeUrl ? 40 : 0; // QR principal
    const etiquetaHeight = qrMovilUrl ? 35 : 0; // Etiqueta móvil
    const dynamicHeight = baseHeight + qrHeight + etiquetaHeight;

    const doc = new jsPDF({
      format: [80, dynamicHeight],
      unit: 'mm'
    });

    let y = 10;
    const margen = 5;
    const anchoUtil = 70;

    // Header con datos de la empresa
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text(configuracion.nombreEmpresa || 'TECHREPAIR PRO', 40, y, { align: 'center' });
    y += 8;

    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    if (configuracion.telefono && configuracion.telefono.trim()) {
      doc.text(`Tel: ${configuracion.telefono}`, 40, y, { align: 'center' });
      y += 5;
    }
    if (configuracion.direccion && configuracion.direccion.trim()) {
      doc.text(`${configuracion.direccion}`, 40, y, { align: 'center' });
      y += 5;
    }
    if (configuracion.email && configuracion.email.trim()) {
      doc.text(`Email: ${configuracion.email}`, 40, y, { align: 'center' });
      y += 5;
    }
    if (configuracion.cif && configuracion.cif.trim()) {
      doc.text(`${configuracion.tipoDocumento || 'CIF'}: ${configuracion.cif}`, 40, y, { align: 'center' });
      y += 5;
    }

    // Línea separadora
    y += 3;
    doc.setLineWidth(0.5);
    doc.line(margen, y, anchoUtil, y);
    y += 7;

    // Título
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text('ORDEN DE REPARACIÓN', 40, y, { align: 'center' });
    y += 8;

    // Información de la orden
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text(`Nº Orden: ${orden.id}`, margen, y);
    y += 5;
    doc.text(`Fecha: ${new Date(orden.fechaIngreso).toLocaleDateString('es-ES')}`, margen, y);
    y += 8;

    // Datos del cliente
    doc.setFont('helvetica', 'bold');
    doc.text('DATOS DEL CLIENTE', margen, y);
    y += 5;
    doc.setFont('helvetica', 'normal');
    doc.text(`Cliente: ${orden.clienteNombre}`, margen, y);
    y += 4;
    doc.text(`Teléfono: ${orden.clienteTelefono}`, margen, y);
    y += 4;
    if (orden.clienteEmail) {
      doc.text(`Email: ${orden.clienteEmail}`, margen, y);
      y += 4;
    }
    y += 4;

    // Datos del dispositivo
    doc.setFont('helvetica', 'bold');
    doc.text('DATOS DEL DISPOSITIVO', margen, y);
    y += 5;
    doc.setFont('helvetica', 'normal');
    doc.text(`Tipo: ${orden.dispositivo}`, margen, y);
    y += 4;
    doc.text(`Marca: ${orden.marca}`, margen, y);
    y += 4;
    doc.text(`Modelo: ${orden.modelo}`, margen, y);
    y += 4;
    if (orden.imei) {
      doc.text(`IMEI: ${orden.imei}`, margen, y);
      y += 4;
    }
    y += 4;

    // Problema reportado
    doc.setFont('helvetica', 'bold');
    doc.text('PROBLEMA REPORTADO', margen, y);
    y += 5;
    doc.setFont('helvetica', 'normal');

    const palabras = orden.problema.split(' ');
    let lineaActual = '';
    palabras.forEach(palabra => {
      const lineaTemporal = lineaActual + (lineaActual ? ' ' : '') + palabra;
      if (lineaTemporal.length > 35) {
        if (lineaActual) {
          doc.text(lineaActual, margen, y);
          y += 4;
        }
        lineaActual = palabra;
      } else {
        lineaActual = lineaTemporal;
      }
    });
    if (lineaActual) {
      doc.text(lineaActual, margen, y);
      y += 4;
    }
    y += 4;

    // Precio si existe
    if (orden.precio && orden.precio > 0) {
      doc.setFont('helvetica', 'bold');
      doc.text('PRECIO DE REPARACIÓN', margen, y);
      y += 5;
      doc.setFontSize(12);
      doc.text(`TOTAL: €${orden.precio.toFixed(2)}`, margen, y);
      y += 8;
      doc.setFontSize(8);
    }

    // QR principal
    if (qrCodeUrl) {
      y += 5;
      try {
        doc.addImage(qrCodeUrl, 'PNG', 25, y, 30, 30);
        y += 35;
      } catch (error) {
        console.error('Error añadiendo QR principal:', error);
      }
    }

    // Términos y condiciones (después del primer QR)
    y += 5;
    doc.setLineWidth(0.5);
    doc.setDrawColor(0, 0, 0);
    doc.line(margen, y, anchoUtil, y);
    y += 5;

    doc.setFontSize(7);
    doc.setFont('helvetica', 'bold');
    doc.text('TÉRMINOS Y CONDICIONES:', margen, y);
    y += 5;

    // Configuración específica de móviles
    if (configuracion.configuracionMoviles?.mostrarEnTicket) {
      y += 3;
      doc.setLineWidth(0.3);
      doc.line(margen, y, anchoUtil, y);
      y += 4;

      if (configuracion.configuracionMoviles.textoPersonalizado) {
        doc.setFontSize(7);
        doc.setFont('helvetica', 'bold');
        doc.text(configuracion.configuracionMoviles.textoPersonalizado, 40, y, { align: 'center' });
        y += 5;
      }

      if (configuracion.configuracionMoviles.informacionAdicional) {
        doc.setFontSize(6);
        doc.setFont('helvetica', 'normal');
        doc.text(configuracion.configuracionMoviles.informacionAdicional, 40, y, { align: 'center' });
        y += 4;
      }

      if (configuracion.configuracionMoviles.terminos) {
        doc.setFontSize(6);
        doc.setFont('helvetica', 'normal');
        configuracion.configuracionMoviles.terminos.split('\n').forEach(termino => {
          if (termino.trim()) {
            doc.text(termino.trim(), margen, y);
            y += 3;
          }
        });
        y += 2;
      }
    }

    // Términos generales
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6);
    configuracion.terminosTicket.split('\n').forEach(termino => {
      if (termino.trim()) {
        doc.text(termino.trim(), margen, y);
        y += 3;
      }
    });

    y += 5;
    doc.setFont('helvetica', 'bold');
    doc.text(`¡Gracias por confiar en ${configuracion.nombreEmpresa}!`, 40, y, { align: 'center' });

    // Etiqueta del móvil con QR
    if (qrMovilUrl) {
      y += 10; // Más espacio antes de la etiqueta
      // Línea de corte superior
      doc.setLineWidth(0.5);
      doc.setDrawColor(150, 150, 150);
      for (let i = margen; i < anchoUtil; i += 3) {
        doc.line(i, y, i + 1.5, y);
      }
      doc.setFontSize(6);
      doc.setFont('helvetica', 'normal');
      doc.text('RECORTAR - ETIQUETA MOVIL', 40, y - 1, { align: 'center' });
      y += 5;

      // Marco de la etiqueta
      doc.setDrawColor(0, 0, 0);
      doc.setLineWidth(1);
      for (let i = 0; i < anchoUtil; i += 3) {
        doc.line(margen + i, y, margen + i + 1.5, y);
        doc.line(margen + i, y + 20, margen + i + 1.5, y + 20);
      }
      for (let i = 0; i < 20; i += 3) {
        doc.line(margen, y + i, margen, y + i + 1.5);
        doc.line(anchoUtil, y + i, anchoUtil, y + i + 1.5);
      }

      // Contenido de la etiqueta (sin título)
      doc.setFontSize(6);
      doc.setFont('helvetica', 'normal');
      doc.text(`${orden.clienteNombre.substring(0, 15)}`, margen + 2, y + 5);
      doc.text(`${orden.clienteTelefono}`, margen + 2, y + 8);
      doc.text(`${orden.marca} ${orden.modelo}`, margen + 2, y + 11);
      doc.text(`#${orden.id}`, margen + 2, y + 14);

      // QR pequeño de la etiqueta
      try {
        doc.addImage(qrMovilUrl, 'PNG', 52, y + 5, 12, 12);
      } catch (error) {
        console.error('Error añadiendo QR móvil:', error);
      }

      y += 25;

      // Línea de corte inferior
      doc.setLineWidth(0.5);
      doc.setDrawColor(150, 150, 150);
      for (let i = margen; i < anchoUtil; i += 3) {
        doc.line(i, y, i + 1.5, y);
      }
    }

    // Abrir en nueva ventana
    window.open(doc.output('bloburl'), '_blank');
  };

  const handleQRScan = (data: any) => {
    console.log("QR escaneado:", data);

    if (data.tipo === 'ORDEN_TRABAJO') {
      // Buscar orden por ID
      const foundOrden = ordenes.find(o => o.id === data.id);

      if (foundOrden) {
        setSearchTerm(data.cliente || data.id);
        toast({
          title: "Orden encontrada",
          description: `Orden ${foundOrden.id} - Cliente: ${foundOrden.clienteNombre}`,
          variant: "default"
        });
      } else {
        toast({
          title: "Orden no encontrada",
          description: `No se encontró la orden con ID: ${data.id}`,
          variant: "destructive"
        });
      }
    } else if (data.tipo === 'FACTURA') {
      // Buscar orden por cliente de la factura
      const ordenesPorCliente = ordenes.filter(o =>
        o.clienteNombre.toLowerCase().includes(data.cliente.toLowerCase())
      );

      if (ordenesPorCliente.length > 0) {
        setSearchTerm(data.cliente);
        toast({
          title: "Órdenes encontradas",
          description: `${ordenesPorCliente.length} orden(es) para ${data.cliente}`,
          variant: "default"
        });
      } else {
        toast({
          title: "No se encontraron órdenes",
          description: `No hay órdenes para el cliente: ${data.cliente}`,
          variant: "destructive"
        });
      }
    } else if (data.tipo === 'TPV') {
      // Buscar órdenes por cliente del TPV
      if (data.cliente && data.cliente !== 'Cliente general') {
        const ordenesPorCliente = ordenes.filter(o =>
          o.clienteNombre.toLowerCase().includes(data.cliente.toLowerCase())
        );

        if (ordenesPorCliente.length > 0) {
          setSearchTerm(data.cliente);
          toast({
            title: "Órdenes encontradas",
            description: `${ordenesPorCliente.length} orden(es) para ${data.cliente}`,
            variant: "default"
          });
        } else {
          toast({
            title: "No se encontraron órdenes",
            description: `No hay órdenes para el cliente: ${data.cliente}`,
            variant: "destructive"
          });
        }
      } else {
        toast({
          title: "Sin datos de cliente",
          description: "El ticket TPV no contiene información de cliente específica",
          variant: "destructive"
        });
      }
    } else {
      toast({
        title: "Código detectado",
        description: "Tipo de código no reconocido para órdenes de trabajo",
        variant: "destructive"
      });
    }
  };

  const filteredOrdenes = ordenes.filter(orden => {
    const matchesSearch = orden.clienteNombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         orden.marca.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         orden.modelo.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesEstado = filterEstado === "todos" || orden.estado === filterEstado;
    return matchesSearch && matchesEstado;
  });

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">Órdenes de Trabajo</h1>
          <p className="text-slate-600">Gestiona todas las reparaciones de tu taller</p>

          {/* Estado de WhatsApp */}
          <div className="flex items-center gap-2 mt-2">
            {isWhatsAppEnabled() ? (
              <div className="flex items-center gap-1 text-green-600 bg-green-50 px-2 py-1 rounded-md text-sm">
                <Zap className="w-4 h-4" />
                <span>WhatsApp activo - Mensajes automáticos habilitados</span>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1 text-amber-600 bg-amber-50 px-2 py-1 rounded-md text-sm">
                  <MessageSquare className="w-4 h-4" />
                  <span>WhatsApp inactivo - Los mensajes automáticos no se enviarán</span>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setShowWhatsAppDiagnostic(true)}
                  className="border-amber-300 text-amber-700 hover:bg-amber-50"
                >
                  🔧 Solucionar
                </Button>
              </div>
            )}
          </div>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={resetForm}>
              <Plus className="w-4 h-4 mr-2" />
              Nueva Orden
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingOrder ? "Editar Orden de Trabajo" : "Nueva Orden de Trabajo"}
              </DialogTitle>
            </DialogHeader>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="clienteNombre">Cliente *</Label>
                  <Input
                    id="clienteNombre"
                    value={formData.clienteNombre}
                    onChange={(e) => setFormData({...formData, clienteNombre: e.target.value})}
                    placeholder="Nombre del cliente"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="clienteTelefono">Teléfono</Label>
                  <Input
                    id="clienteTelefono"
                    value={formData.clienteTelefono}
                    onChange={(e) => setFormData({...formData, clienteTelefono: e.target.value})}
                    placeholder="Número de teléfono"
                  />
                </div>
              </div>


              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="dispositivo">Tipo de Dispositivo</Label>
                  <Select value={formData.dispositivo} onValueChange={(value) => setFormData({...formData, dispositivo: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="smartphone">Smartphone</SelectItem>
                      <SelectItem value="tablet">Tablet</SelectItem>
                      <SelectItem value="laptop">Laptop</SelectItem>
                      <SelectItem value="otro">Otro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="marca">Marca</Label>
                  <Input
                    id="marca"
                    value={formData.marca}
                    onChange={(e) => setFormData({...formData, marca: e.target.value})}
                    placeholder="Ej: Samsung, Apple"
                  />
                </div>
                <div>
                  <Label htmlFor="modelo">Modelo</Label>
                  <Input
                    id="modelo"
                    value={formData.modelo}
                    onChange={(e) => setFormData({...formData, modelo: e.target.value})}
                    placeholder="Ej: Galaxy S21, iPhone 12"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="problema">Problema Reportado *</Label>
                <Textarea
                  id="problema"
                  value={formData.problema}
                  onChange={(e) => setFormData({...formData, problema: e.target.value})}
                  placeholder="Describe el problema reportado por el cliente"
                  required
                />
              </div>

              <div>
                <Label htmlFor="diagnostico">Diagnóstico</Label>
                <Textarea
                  id="diagnostico"
                  value={formData.diagnostico}
                  onChange={(e) => setFormData({...formData, diagnostico: e.target.value})}
                  placeholder="Diagnóstico técnico del problema"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <Label htmlFor="coste">Coste de Reparación</Label>
                  <Input
                    id="coste"
                    type="number"
                    value={formData.coste}
                    onChange={(e) => setFormData({...formData, coste: e.target.value})}
                    placeholder="0.00"
                  />
                </div>
                <div>
                  <Label htmlFor="precio">Precio al Cliente</Label>
                  <Input
                    id="precio"
                    type="number"
                    value={formData.precio}
                    onChange={(e) => setFormData({...formData, precio: e.target.value})}
                    placeholder="0.00"
                  />
                </div>
                <div>
                  <Label htmlFor="estado">Estado</Label>
                  <Select value={formData.estado} onValueChange={(value: Orden["estado"]) => setFormData({...formData, estado: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pendiente">Pendiente</SelectItem>
                      <SelectItem value="en_proceso">En Proceso</SelectItem>
                      <SelectItem value="completado">Completado</SelectItem>
                      <SelectItem value="entregado">Entregado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="fechaEstimada">Fecha Estimada</Label>
                  <Input
                    id="fechaEstimada"
                    type="date"
                    value={formData.fechaEstimada}
                    onChange={(e) => setFormData({...formData, fechaEstimada: e.target.value})}
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit">
                  {editingOrder ? "Actualizar" : "Crear"} Orden
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          {/* Estadísticas de WhatsApp */}
          {isWhatsAppEnabled() && (
            <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <MessageSquare className="w-5 h-5 text-green-600" />
                  <span className="font-medium text-green-800">Estado de WhatsApp</span>
                </div>
                <div className="flex gap-4 text-sm text-green-700">
                  <span>Con teléfono: {ordenes.filter(o => o.clienteTelefono).length}</span>
                  <span>Sin teléfono: {ordenes.filter(o => !o.clienteTelefono).length}</span>
                  <span>Total órdenes: {ordenes.length}</span>
                </div>
              </div>
            </div>
          )}

          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar por cliente, marca o modelo..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Button
              variant="outline"
              onClick={() => setIsQRReaderOpen(true)}
              className="flex items-center gap-2"
            >
              <QrCode className="w-4 h-4" />
              Buscar por QR
            </Button>
            <Select value={filterEstado} onValueChange={setFilterEstado}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Filtrar por estado" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos los estados</SelectItem>
                <SelectItem value="pendiente">Pendiente</SelectItem>
                <SelectItem value="en_proceso">En Proceso</SelectItem>
                <SelectItem value="completado">Completado</SelectItem>
                <SelectItem value="entregado">Entregado</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Orders List */}
      <div className="grid gap-4">
        {filteredOrdenes.length === 0 ? (
          <Card>
            <CardContent className="pt-6 text-center">
              <Smartphone className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No hay órdenes</h3>
              <p className="text-muted-foreground">
                {searchTerm || filterEstado !== "todos" 
                  ? "No se encontraron órdenes con los filtros aplicados"
                  : "Crea tu primera orden de trabajo para comenzar"
                }
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredOrdenes.map((orden) => (
            <Card key={orden.id} className="hover:shadow-md transition-shadow">
              <CardContent className="pt-6">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="text-lg font-semibold">{orden.clienteNombre}</h3>
                      <Badge className={estadoColors[orden.estado]}>
                        {estadoLabels[orden.estado]}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Smartphone className="w-4 h-4" />
                        {orden.marca} {orden.modelo}
                      </div>
                      <div className="flex items-center gap-1">
                        <Phone className="w-4 h-4" />
                        {orden.clienteTelefono || "Sin teléfono"}
                      </div>
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        Ingreso: {orden.fechaIngreso}
                        {(() => {
                          const dias = calcularDiasTranscurridos(orden.fechaIngreso);
                          if (dias > 7) {
                            return <span className="ml-1 text-red-600 font-semibold">({dias} días)</span>;
                          } else if (dias > 3) {
                            return <span className="ml-1 text-orange-600 font-semibold">({dias} días)</span>;
                          } else {
                            return <span className="ml-1 text-gray-500">({dias} días)</span>;
                          }
                        })()}
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        Estimada: {orden.fechaEstimada || "Sin fecha"}
                      </div>
                    </div>
                    <p className="mt-2 text-sm">{orden.problema}</p>
                    <div className="mt-2 flex gap-4 text-sm">
                      {orden.coste > 0 && (
                         <p className="text-red-600">Coste: €{orden.coste.toLocaleString()}</p>
                       )}
                       {orden.precio > 0 && (
                         <p className="font-semibold text-green-600">Precio: €{orden.precio.toLocaleString()}</p>
                       )}
                       {orden.coste > 0 && orden.precio > 0 && (
                         <p className="font-bold text-blue-600">Beneficio: €{(orden.precio - orden.coste).toLocaleString()}</p>
                      )}
                    </div>
                  </div>
                  <div className="flex flex-col gap-2">
                    {/* Indicador de WhatsApp */}
                    <div className="flex items-center gap-1 text-xs">
                      {isWhatsAppEnabled() && orden.clienteTelefono ? (
                        <div className="flex items-center gap-1 text-green-600">
                          <MessageSquare className="w-3 h-3" />
                          <span>WhatsApp: Activo</span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1 text-gray-400">
                          <MessageSquare className="w-3 h-3" />
                          <span>WhatsApp: {!orden.clienteTelefono ? 'Sin teléfono' : 'Inactivo'}</span>
                        </div>
                      )}
                    </div>

                    {/* Botones de cambio rápido de estado */}
                    <div className="flex flex-wrap gap-1">
                      {orden.estado === 'pendiente' && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => cambiarEstadoRapido(orden, 'en_proceso')}
                          className="text-blue-600 hover:bg-blue-50"
                          title="Marcar como En Proceso (envía WhatsApp automático)"
                        >
                          <PlayCircle className="w-3 h-3 mr-1" />
                          Iniciar
                        </Button>
                      )}

                      {orden.estado === 'en_proceso' && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => cambiarEstadoRapido(orden, 'completado')}
                          className="text-green-600 hover:bg-green-50"
                          title="Marcar como Completado (envía WhatsApp automático)"
                        >
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Completar
                        </Button>
                      )}

                      {orden.estado === 'completado' && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => cambiarEstadoRapido(orden, 'entregado')}
                          className="text-purple-600 hover:bg-purple-50"
                          title="Marcar como Entregado (envía WhatsApp automático)"
                        >
                          <Package className="w-3 h-3 mr-1" />
                          Entregar
                        </Button>
                      )}
                    </div>

                    {/* Botones de acción */}
                    <div className="flex gap-1">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleGenerarTicketDirecto(orden)}
                        className="text-blue-600"
                        title="Ver/Imprimir Ticket de Resguardo"
                      >
                        <Eye className="w-4 h-4" />
                      </Button>

                      {orden.clienteTelefono && isWhatsAppEnabled() && (
                        <>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => enviarMensajePersonalizado(orden)}
                            className="text-green-600"
                            title="Enviar mensaje personalizado por WhatsApp"
                          >
                            <Send className="w-4 h-4" />
                          </Button>

                          {orden.estado === 'completado' && calcularDiasTranscurridos(orden.fechaIngreso) > 3 && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => enviarRecordatorio(orden)}
                              className="text-orange-600"
                              title="Enviar recordatorio de recogida"
                            >
                              <Clock className="w-4 h-4" />
                            </Button>
                          )}
                        </>
                      )}

                      {orden.clienteTelefono && !isWhatsAppEnabled() && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            const mensaje = `Hola ${orden.clienteNombre}, tu ${orden.dispositivo} ${orden.marca} ${orden.modelo} está *${estadoLabels[orden.estado]}*. ${orden.diagnostico ? `Diagnóstico: ${orden.diagnostico}` : ''}`;
                            window.open(`https://wa.me/${orden.clienteTelefono.replace(/\D/g, '')}?text=${encodeURIComponent(mensaje)}`, '_blank');
                          }}
                          className="text-green-600"
                          title="Abrir WhatsApp (modo manual)"
                        >
                          <MessageSquare className="w-4 h-4" />
                        </Button>
                      )}

                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEdit(orden)}
                        title="Editar orden"
                      >
                        <Edit className="w-4 h-4" />
                      </Button>

                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDelete(orden.id)}
                        title="Eliminar orden"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* El ticket ahora se abre directamente en nueva ventana */}

      {/* Lector QR */}
      <QRReader
        isOpen={isQRReaderOpen}
        onClose={() => setIsQRReaderOpen(false)}
        onScan={handleQRScan}
        title="Buscar Cliente por Código QR"
      />

      {/* Diagnóstico de WhatsApp */}
      <Dialog open={showWhatsAppDiagnostic} onOpenChange={setShowWhatsAppDiagnostic}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>🔧 Diagnóstico y Reparación de WhatsApp</DialogTitle>
          </DialogHeader>
          <FixedWhatsAppDiagnostic />
        </DialogContent>
      </Dialog>
    </div>
  );
}
