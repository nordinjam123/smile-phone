import { useState, useMemo, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Calculator,
  PieChart,
  BarChart3,
  FileText,
  Package,
  Target,
  Calendar,
  Smartphone,
  Wrench,
  ShoppingCart,
  CreditCard,
  Eye,
  TrendingRight,
  Percent,
  Users,
  Clock,
  Award,
  Activity,
  AlertTriangle,
  Receipt,
  Settings,
  Building,
  UserCheck
} from "lucide-react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer, 
  PieChart as RechartsPieChart, 
  Cell, 
  BarChart, 
  Bar, 
  Pie,
  AreaChart,
  Area,
  ComposedChart
} from "recharts";

interface Orden {
  id: string;
  clienteNombre: string;
  dispositivo: string;
  marca: string;
  modelo: string;
  problema: string;
  coste: number;
  precio: number;
  estado: "pendiente" | "en_proceso" | "completado" | "entregado";
  fechaIngreso: string;
  fechaCompletado?: string;
}

interface Gasto {
  id: string;
  concepto: string;
  categoria: string;
  total: number;
  fecha: string;
}

interface GastoMercancia {
  id: string;
  tipo_producto: string;
  descripcion: string;
  proveedor: string;
  cantidad: number;
  precio_unitario: number;
  total: number;
  fecha: string;
  categoria: string;
  notas?: string;
}

interface Movil {
  id: string;
  marca: string;
  modelo: string;
  precioCompra: number;
  precioVenta?: number;
  vendido: boolean;
  fechaVenta?: string;
}

interface Cliente {
  id: string;
  nombre: string;
  telefono: string;
  email: string;
  direccion: string;
  fechaRegistro: string;
  totalReparaciones: number;
}

interface Factura {
  id: string;
  numero: string;
  cliente_nombre: string;
  total: number;
  fecha: string;
  estado: string;
}

interface Cita {
  id: string;
  cliente: string;
  fecha: string;
  hora: string;
  servicio: string;
  estado: string;
}

interface ProductoPieza {
  id: string;
  nombre: string;
  categoria: string;
  stock: number;
  stockMinimo: number;
  precio: number;
  proveedor: string;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82ca9d', '#ffc658', '#ff7300'];

export default function EnhancedBalancePage() {
  const [ordenes] = useLocalStorage<Orden[]>("ordenes", []);
  const [moviles] = useLocalStorage<Movil[]>("moviles", []);
  const [gastos] = useLocalStorage<Gasto[]>("gastos_mercancia", []);
  const [gastosMercancia, setGastosMercancia] = useState<GastoMercancia[]>([]);
  const [clientes] = useLocalStorage<Cliente[]>("clientes", []);
  const [facturas] = useLocalStorage<Factura[]>("facturas", []);
  const [citas] = useLocalStorage<Cita[]>("citas", []);
  const [inventarioPiezas] = useLocalStorage<ProductoPieza[]>("inventario_piezas", []);
  const [timeRange, setTimeRange] = useState<"semana" | "mes" | "trimestre" | "año">("mes");
  const [viewMode, setViewMode] = useState<"general" | "reparaciones" | "moviles" | "gastos" | "clientes" | "inventario">("general");

  // Cargar gastos de mercancía desde Supabase
  useEffect(() => {
    const cargarGastosMercancia = async () => {
      try {
        // En un entorno real, aquí cargarías desde Supabase
        // Por ahora usamos localStorage como fallback
        const gastosSupabase = localStorage.getItem('gastos_supabase');
        if (gastosSupabase) {
          setGastosMercancia(JSON.parse(gastosSupabase));
        }
      } catch (error) {
        console.warn('Error cargando gastos de mercancía:', error);
      }
    };
    cargarGastosMercancia();
  }, []);

  // Función para obtener fechas del período
  const getDateRange = (range: string) => {
    const today = new Date();
    const start = new Date(today);
    switch (range) {
      case "semana":
        start.setDate(today.getDate() - 7);
        break;
      case "mes":
        start.setMonth(today.getMonth() - 1);
        break;
      case "trimestre":
        start.setMonth(today.getMonth() - 3);
        break;
      case "año":
        start.setFullYear(today.getFullYear() - 1);
        break;
    }
    return { start, end: today };
  };

  // Métricas calculadas con useMemo para optimización
  const metrics = useMemo(() => {
    const { start, end } = getDateRange(timeRange);
    
    // Filtrar datos por período
    const ordenesCompletadas = ordenes.filter(orden => 
      (orden.estado === "completado" || orden.estado === "entregado") &&
      new Date(orden.fechaCompletado || orden.fechaIngreso) >= start
    );

    const movilesVendidos = moviles.filter(movil => 
      movil.vendido && 
      movil.fechaVenta && 
      new Date(movil.fechaVenta) >= start
    );

    const gastosPeriodo = gastos.filter(gasto =>
      new Date(gasto.fecha) >= start
    );

    const gastosMercanciaPeriodo = gastosMercancia.filter(gasto =>
      new Date(gasto.fecha) >= start
    );

    // Cálculos de reparaciones
    const ingresosReparaciones = ordenesCompletadas.reduce((sum, orden) => sum + orden.precio, 0);
    const costesReparaciones = ordenesCompletadas.reduce((sum, orden) => sum + orden.coste, 0);
    const beneficioReparaciones = ingresosReparaciones - costesReparaciones;

    // Cálculos de móviles
    const ingresosMoviles = movilesVendidos.reduce((sum, movil) => sum + (movil.precioVenta || 0), 0);
    const costesMoviles = movilesVendidos.reduce((sum, movil) => sum + movil.precioCompra, 0);
    const beneficioMoviles = ingresosMoviles - costesMoviles;

    // Gastos totales (combinando ambos tipos)
    const totalGastos = gastosPeriodo.reduce((sum, gasto) => sum + gasto.total, 0) +
                       gastosMercanciaPeriodo.reduce((sum, gasto) => sum + gasto.total, 0);

    // Gastos por tipo
    const gastosOperativos = gastosPeriodo.reduce((sum, gasto) => sum + gasto.total, 0);
    const gastosMercanciasTotal = gastosMercanciaPeriodo.reduce((sum, gasto) => sum + gasto.total, 0);

    // Totales
    const totalIngresos = ingresosReparaciones + ingresosMoviles;
    const totalCostes = costesReparaciones + costesMoviles + totalGastos;
    const totalBeneficio = totalIngresos - totalCostes;
    const margenBeneficio = totalIngresos > 0 ? ((totalBeneficio / totalIngresos) * 100) : 0;

    // Métricas adicionales
    const cantidadReparaciones = ordenesCompletadas.length;
    const cantidadMoviles = movilesVendidos.length;
    const ticketMedioReparaciones = cantidadReparaciones > 0 ? ingresosReparaciones / cantidadReparaciones : 0;
    const ticketMedioMoviles = cantidadMoviles > 0 ? ingresosMoviles / cantidadMoviles : 0;

    // Métricas de clientes
    const clientesTotales = clientes.length;
    const clientesNuevos = clientes.filter(cliente =>
      new Date(cliente.fechaRegistro) >= start
    ).length;
    const clientesRecurrentes = clientes.filter(cliente =>
      cliente.totalReparaciones > 1
    ).length;

    // Métricas de facturas
    const facturasPendientes = facturas.filter(factura =>
      factura.estado === 'pendiente' && new Date(factura.fecha) >= start
    ).length;
    const facturasCompletadas = facturas.filter(factura =>
      factura.estado === 'pagada' && new Date(factura.fecha) >= start
    ).length;
    const totalFacturado = facturas.filter(factura =>
      factura.estado === 'pagada' && new Date(factura.fecha) >= start
    ).reduce((sum, factura) => sum + factura.total, 0);

    // Métricas de citas
    const citasPendientes = citas.filter(cita =>
      cita.estado === 'programada' && new Date(cita.fecha) >= start
    ).length;
    const citasCompletadas = citas.filter(cita =>
      cita.estado === 'completada' && new Date(cita.fecha) >= start
    ).length;

    // Métricas de inventario
    const productosStockBajo = inventarioPiezas.filter(producto =>
      producto.stock <= producto.stockMinimo
    ).length;
    const valorTotalInventario = inventarioPiezas.reduce((sum, producto) =>
      sum + (producto.precio * producto.stock), 0
    );
    const productosAgotados = inventarioPiezas.filter(producto =>
      producto.stock === 0
    ).length;

    return {
      ingresosReparaciones,
      costesReparaciones,
      beneficioReparaciones,
      ingresosMoviles,
      costesMoviles,
      beneficioMoviles,
      totalGastos,
      totalIngresos,
      totalCostes,
      totalBeneficio,
      margenBeneficio,
      cantidadReparaciones,
      cantidadMoviles,
      ticketMedioReparaciones,
      ticketMedioMoviles,
      ordenesCompletadas,
      movilesVendidos,
      gastosPeriodo,
      gastosMercanciaPeriodo,
      gastosOperativos,
      gastosMercanciasTotal,
      clientesTotales,
      clientesNuevos,
      clientesRecurrentes,
      facturasPendientes,
      facturasCompletadas,
      totalFacturado,
      citasPendientes,
      citasCompletadas,
      productosStockBajo,
      valorTotalInventario,
      productosAgotados
    };
  }, [ordenes, moviles, gastos, timeRange]);

  // Datos para gráfico de tendencias
  const trendData = useMemo(() => {
    const days = timeRange === "semana" ? 7 : timeRange === "mes" ? 30 : timeRange === "trimestre" ? 90 : 365;
    const data = [];
    const today = new Date();

    for (let i = days; i >= 0; i -= Math.max(1, Math.floor(days / 12))) {
      const date = new Date(today);
      date.setDate(today.getDate() - i);
      
      const ordenesDia = ordenes.filter(orden => {
        const fechaOrden = new Date(orden.fechaCompletado || orden.fechaIngreso);
        return fechaOrden.toDateString() === date.toDateString() && 
               (orden.estado === "completado" || orden.estado === "entregado");
      });

      const movilesDia = moviles.filter(movil => {
        return movil.vendido && movil.fechaVenta && 
               new Date(movil.fechaVenta).toDateString() === date.toDateString();
      });

      const gastosDia = gastos.filter(gasto => {
        return new Date(gasto.fecha).toDateString() === date.toDateString();
      });

      const ingresos = ordenesDia.reduce((sum, orden) => sum + orden.precio, 0) +
                      movilesDia.reduce((sum, movil) => sum + (movil.precioVenta || 0), 0);
      
      const costes = ordenesDia.reduce((sum, orden) => sum + orden.coste, 0) +
                     movilesDia.reduce((sum, movil) => sum + movil.precioCompra, 0) +
                     gastosDia.reduce((sum, gasto) => sum + gasto.total, 0);

      data.push({
        fecha: date.toLocaleDateString('es-ES', { day: '2-digit', month: '2-digit' }),
        ingresos,
        costes,
        beneficio: ingresos - costes,
        reparaciones: ordenesDia.length,
        moviles: movilesDia.length
      });
    }

    return data;
  }, [ordenes, moviles, gastos, timeRange]);

  // Datos para gráfico de pastel de ingresos
  const incomeData = [
    { name: 'Reparaciones', value: metrics.ingresosReparaciones, color: '#0088FE' },
    { name: 'Móviles', value: metrics.ingresosMoviles, color: '#00C49F' }
  ].filter(item => item.value > 0);

  // Datos para gráfico de gastos por categoría (combinando ambos tipos)
  const expenseData = useMemo(() => {
    const categorias = new Map();

    // Gastos operativos
    metrics.gastosPeriodo.forEach(gasto => {
      const categoria = gasto.categoria || 'Gastos Operativos';
      categorias.set(categoria, (categorias.get(categoria) || 0) + gasto.total);
    });

    // Gastos de mercancía
    metrics.gastosMercanciaPeriodo.forEach(gasto => {
      const categoria = gasto.categoria || 'Mercancía';
      categorias.set(categoria, (categorias.get(categoria) || 0) + gasto.total);
    });

    return Array.from(categorias.entries()).map(([name, value], index) => ({
      name,
      value,
      color: COLORS[index % COLORS.length]
    }));
  }, [metrics.gastosPeriodo, metrics.gastosMercanciaPeriodo]);

  // Componente de métrica
  const MetricCard = ({ 
    title, 
    value, 
    change, 
    icon: Icon, 
    color = "blue",
    format = "currency",
    subtitle
  }: any) => (
    <Card className="relative overflow-hidden">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-gray-600">{title}</CardTitle>
        <Icon className={`h-4 w-4 text-${color}-600`} />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">
          {format === "currency" 
            ? `€${value.toFixed(2)}` 
            : format === "percentage"
            ? `${value.toFixed(1)}%`
            : value.toLocaleString()
          }
        </div>
        {subtitle && (
          <p className="text-xs text-gray-500 mt-1">{subtitle}</p>
        )}
        {change !== undefined && (
          <div className={`flex items-center text-xs mt-1 ${
            change >= 0 ? 'text-green-600' : 'text-red-600'
          }`}>
            {change >= 0 ? <TrendingUp className="h-3 w-3 mr-1" /> : <TrendingDown className="h-3 w-3 mr-1" />}
            {Math.abs(change).toFixed(1)}% vs período anterior
          </div>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto overflow-x-hidden">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Balance Financiero</h1>
          <p className="text-gray-600">Análisis completo de la rentabilidad de tu taller</p>
        </div>
        
        <div className="flex gap-4">
          <Select value={viewMode} onValueChange={setViewMode}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="general">Vista General</SelectItem>
              <SelectItem value="reparaciones">Reparaciones</SelectItem>
              <SelectItem value="moviles">Móviles</SelectItem>
              <SelectItem value="gastos">Gastos y Mercancía</SelectItem>
              <SelectItem value="clientes">Clientes</SelectItem>
              <SelectItem value="inventario">Inventario</SelectItem>
            </SelectContent>
          </Select>

          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="semana">7 días</SelectItem>
              <SelectItem value="mes">30 días</SelectItem>
              <SelectItem value="trimestre">3 meses</SelectItem>
              <SelectItem value="año">1 año</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Métricas principales */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Ingresos Totales"
          value={metrics.totalIngresos}
          icon={TrendingUp}
          color="green"
          subtitle={`${metrics.cantidadReparaciones + metrics.cantidadMoviles} operaciones`}
        />
        
        <MetricCard
          title="Costes Totales"
          value={metrics.totalCostes}
          icon={TrendingDown}
          color="red"
          subtitle="Incluye todos los gastos"
        />
        
        <MetricCard
          title="Beneficio Neto"
          value={metrics.totalBeneficio}
          icon={DollarSign}
          color={metrics.totalBeneficio >= 0 ? "green" : "red"}
          subtitle={`Margen: ${metrics.margenBeneficio.toFixed(1)}%`}
        />
        
        <MetricCard
          title="Margen de Beneficio"
          value={metrics.margenBeneficio}
          icon={Percent}
          color={metrics.margenBeneficio >= 20 ? "green" : metrics.margenBeneficio >= 10 ? "yellow" : "red"}
          format="percentage"
          subtitle={metrics.margenBeneficio >= 20 ? "Excelente" : metrics.margenBeneficio >= 10 ? "Bueno" : "Mejorable"}
        />
      </div>

      {/* Métricas específicas por sector */}
      {viewMode === "general" && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <MetricCard
              title="Ingresos Reparaciones"
              value={metrics.ingresosReparaciones}
              icon={Wrench}
              color="blue"
              subtitle={`${metrics.cantidadReparaciones} reparaciones`}
            />

            <MetricCard
              title="Ticket Medio Reparaciones"
              value={metrics.ticketMedioReparaciones}
              icon={Calculator}
              color="blue"
              subtitle="Por reparación"
            />

            <MetricCard
              title="Ingresos Móviles"
              value={metrics.ingresosMoviles}
              icon={Smartphone}
              color="purple"
              subtitle={`${metrics.cantidadMoviles} móviles vendidos`}
            />

            <MetricCard
              title="Ticket Medio Móviles"
              value={metrics.ticketMedioMoviles}
              icon={Calculator}
              color="purple"
              subtitle="Por móvil vendido"
            />
          </div>

          {/* Métricas de clientes y operaciones */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <MetricCard
              title="Clientes Totales"
              value={metrics.clientesTotales}
              icon={Users}
              color="green"
              format="number"
              subtitle={`${metrics.clientesNuevos} nuevos en período`}
            />

            <MetricCard
              title="Clientes Recurrentes"
              value={metrics.clientesRecurrentes}
              icon={UserCheck}
              color="green"
              format="number"
              subtitle="Con múltiples reparaciones"
            />

            <MetricCard
              title="Facturas Completadas"
              value={metrics.facturasCompletadas}
              icon={Receipt}
              color="blue"
              format="number"
              subtitle={`€${metrics.totalFacturado.toFixed(2)} facturado`}
            />

            <MetricCard
              title="Citas Pendientes"
              value={metrics.citasPendientes}
              icon={Calendar}
              color="orange"
              format="number"
              subtitle={`${metrics.citasCompletadas} completadas`}
            />
          </div>

          {/* Métricas de inventario */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <MetricCard
              title="Valor Total Inventario"
              value={metrics.valorTotalInventario}
              icon={Package}
              color="indigo"
              subtitle="Valor total en stock"
            />

            <MetricCard
              title="Productos Stock Bajo"
              value={metrics.productosStockBajo}
              icon={AlertTriangle}
              color="red"
              format="number"
              subtitle="Requieren reposición"
            />

            <MetricCard
              title="Productos Agotados"
              value={metrics.productosAgotados}
              icon={Package}
              color="red"
              format="number"
              subtitle="Sin stock disponible"
            />

            <MetricCard
              title="Rotación de Inventario"
              value={metrics.cantidadReparaciones > 0 ? ((metrics.valorTotalInventario / metrics.ingresosReparaciones) * 100) : 0}
              icon={Activity}
              color="blue"
              format="percentage"
              subtitle="Eficiencia de inventario"
            />
          </div>
        </>
      )}

      {viewMode === "reparaciones" && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricCard
            title="Ingresos Reparaciones"
            value={metrics.ingresosReparaciones}
            icon={Wrench}
            color="blue"
            subtitle={`${metrics.cantidadReparaciones} reparaciones`}
          />

          <MetricCard
            title="Ticket Medio"
            value={metrics.ticketMedioReparaciones}
            icon={Calculator}
            color="blue"
            subtitle="Por reparación"
          />

          <MetricCard
            title="Beneficio Reparaciones"
            value={metrics.beneficioReparaciones}
            icon={DollarSign}
            color={metrics.beneficioReparaciones >= 0 ? "green" : "red"}
            subtitle="Después de costes"
          />

          <MetricCard
            title="Margen Reparaciones"
            value={metrics.ingresosReparaciones > 0 ? ((metrics.beneficioReparaciones / metrics.ingresosReparaciones) * 100) : 0}
            icon={Percent}
            color="blue"
            format="percentage"
            subtitle="% de beneficio"
          />
        </div>
      )}

      {viewMode === "moviles" && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricCard
            title="Ingresos Móviles"
            value={metrics.ingresosMoviles}
            icon={Smartphone}
            color="purple"
            subtitle={`${metrics.cantidadMoviles} móviles vendidos`}
          />

          <MetricCard
            title="Ticket Medio Móviles"
            value={metrics.ticketMedioMoviles}
            icon={Calculator}
            color="purple"
            subtitle="Por móvil vendido"
          />

          <MetricCard
            title="Beneficio Móviles"
            value={metrics.beneficioMoviles}
            icon={DollarSign}
            color={metrics.beneficioMoviles >= 0 ? "green" : "red"}
            subtitle="Después de costes"
          />

          <MetricCard
            title="Margen Móviles"
            value={metrics.ingresosMoviles > 0 ? ((metrics.beneficioMoviles / metrics.ingresosMoviles) * 100) : 0}
            icon={Percent}
            color="purple"
            format="percentage"
            subtitle="% de beneficio"
          />
        </div>
      )}

      {viewMode === "clientes" && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricCard
            title="Clientes Totales"
            value={metrics.clientesTotales}
            icon={Users}
            color="green"
            format="number"
            subtitle="Base de clientes total"
          />

          <MetricCard
            title="Clientes Nuevos"
            value={metrics.clientesNuevos}
            icon={UserCheck}
            color="blue"
            format="number"
            subtitle={`En los últimos ${timeRange === 'semana' ? '7 días' : timeRange === 'mes' ? '30 días' : timeRange === 'trimestre' ? '3 meses' : '1 año'}`}
          />

          <MetricCard
            title="Clientes Recurrentes"
            value={metrics.clientesRecurrentes}
            icon={Award}
            color="green"
            format="number"
            subtitle="Con múltiples reparaciones"
          />

          <MetricCard
            title="Tasa de Retención"
            value={metrics.clientesTotales > 0 ? ((metrics.clientesRecurrentes / metrics.clientesTotales) * 100) : 0}
            icon={Percent}
            color="green"
            format="percentage"
            subtitle="% clientes que repiten"
          />
        </div>
      )}

      {viewMode === "gastos" && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <MetricCard
              title="Gastos Totales"
              value={metrics.totalGastos}
              icon={TrendingDown}
              color="red"
              subtitle="Operativos + Mercancía"
            />

            <MetricCard
              title="Gastos Operativos"
              value={metrics.gastosOperativos}
              icon={Building}
              color="orange"
              subtitle="Alquiler, servicios, etc."
            />

            <MetricCard
              title="Gastos de Mercancía"
              value={metrics.gastosMercanciasTotal}
              icon={ShoppingCart}
              color="purple"
              subtitle="Compras de stock"
            />

            <MetricCard
              title="Ratio Gastos/Ingresos"
              value={metrics.totalIngresos > 0 ? ((metrics.totalGastos / metrics.totalIngresos) * 100) : 0}
              icon={Percent}
              color={metrics.totalGastos / metrics.totalIngresos > 0.8 ? "red" : metrics.totalGastos / metrics.totalIngresos > 0.6 ? "orange" : "green"}
              format="percentage"
              subtitle="% de gastos sobre ingresos"
            />
          </div>

          {/* Desglose detallado de gastos */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Gastos Operativos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {metrics.gastosPeriodo.slice(0, 5).map((gasto, index) => (
                    <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <div>
                        <div className="font-medium text-sm">{gasto.concepto}</div>
                        <div className="text-xs text-gray-500">{gasto.categoria}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold">€{gasto.total.toFixed(2)}</div>
                        <div className="text-xs text-gray-500">{new Date(gasto.fecha).toLocaleDateString('es-ES')}</div>
                      </div>
                    </div>
                  ))}
                  {metrics.gastosPeriodo.length === 0 && (
                    <div className="text-center text-gray-500 py-4">No hay gastos operativos en este período</div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Gastos de Mercancía</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {metrics.gastosMercanciaPeriodo.slice(0, 5).map((gasto, index) => (
                    <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <div>
                        <div className="font-medium text-sm">{gasto.tipo_producto}</div>
                        <div className="text-xs text-gray-500">{gasto.proveedor} - {gasto.cantidad} uds</div>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold">€{gasto.total.toFixed(2)}</div>
                        <div className="text-xs text-gray-500">{new Date(gasto.fecha).toLocaleDateString('es-ES')}</div>
                      </div>
                    </div>
                  ))}
                  {metrics.gastosMercanciaPeriodo.length === 0 && (
                    <div className="text-center text-gray-500 py-4">No hay gastos de mercancía en este período</div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </>
      )}

      {viewMode === "inventario" && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricCard
            title="Valor Total Inventario"
            value={metrics.valorTotalInventario}
            icon={Package}
            color="indigo"
            subtitle="Inversión total en stock"
          />

          <MetricCard
            title="Productos Stock Bajo"
            value={metrics.productosStockBajo}
            icon={AlertTriangle}
            color="orange"
            format="number"
            subtitle="Por debajo del mínimo"
          />

          <MetricCard
            title="Productos Agotados"
            value={metrics.productosAgotados}
            icon={Package}
            color="red"
            format="number"
            subtitle="Sin stock disponible"
          />

          <MetricCard
            title="Eficiencia Inventario"
            value={metrics.valorTotalInventario > 0 ? ((metrics.ingresosReparaciones / metrics.valorTotalInventario) * 100) : 0}
            icon={Activity}
            color="blue"
            format="percentage"
            subtitle="Ratio ingresos/inventario"
          />
        </div>
      )}

      {/* Gráficos principales */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Tendencia temporal */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Tendencia de Ingresos vs Costes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <ComposedChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="fecha" />
                <YAxis />
                <Tooltip 
                  formatter={(value: any, name: string) => [
                    `€${value.toFixed(2)}`, 
                    name === 'ingresos' ? 'Ingresos' : 
                    name === 'costes' ? 'Costes' : 'Beneficio'
                  ]}
                />
                <Legend />
                <Area 
                  type="monotone" 
                  dataKey="beneficio" 
                  fill="#10b981" 
                  stroke="#10b981" 
                  fillOpacity={0.3}
                  name="Beneficio"
                />
                <Bar dataKey="ingresos" fill="#3b82f6" name="Ingresos" />
                <Line type="monotone" dataKey="costes" stroke="#ef4444" strokeWidth={2} name="Costes" />
              </ComposedChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Distribución de ingresos */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PieChart className="h-5 w-5" />
              Distribución de Ingresos
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <RechartsPieChart>
                <Pie
                  data={incomeData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {incomeData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: any) => [`€${value.toFixed(2)}`, 'Ingresos']} />
              </RechartsPieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Análisis de gastos */}
      {expenseData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ShoppingCart className="h-5 w-5" />
              Análisis de Gastos por Categoría
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <ResponsiveContainer width="100%" height={300}>
                <RechartsPieChart>
                  <Pie
                    data={expenseData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {expenseData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: any) => [`€${value.toFixed(2)}`, 'Gasto']} />
                </RechartsPieChart>
              </ResponsiveContainer>
              
              <div className="space-y-3">
                <h4 className="font-semibold">Desglose de Gastos</h4>
                {expenseData.map((expense, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div 
                        className="w-4 h-4 rounded-full" 
                        style={{ backgroundColor: expense.color }}
                      />
                      <span className="font-medium">{expense.name}</span>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold">€{expense.value.toFixed(2)}</div>
                      <div className="text-xs text-gray-500">
                        {((expense.value / metrics.totalGastos) * 100).toFixed(1)}%
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Resumen ejecutivo */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="h-5 w-5" />
            Resumen Ejecutivo
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-3">
              <h4 className="font-semibold text-green-600">Fortalezas</h4>
              <div className="space-y-2">
                {metrics.margenBeneficio > 20 && (
                  <Badge className="bg-green-100 text-green-800">Excelente margen de beneficio</Badge>
                )}
                {metrics.cantidadReparaciones > 10 && (
                  <Badge className="bg-blue-100 text-blue-800">Alto volumen de reparaciones</Badge>
                )}
                {metrics.ticketMedioReparaciones > 50 && (
                  <Badge className="bg-purple-100 text-purple-800">Buen ticket medio</Badge>
                )}
              </div>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-semibold text-orange-600">Oportunidades</h4>
              <div className="space-y-2">
                {metrics.cantidadMoviles < 5 && (
                  <Badge className="bg-orange-100 text-orange-800">Incrementar venta de móviles</Badge>
                )}
                {metrics.margenBeneficio < 15 && (
                  <Badge className="bg-yellow-100 text-yellow-800">Optimizar costes</Badge>
                )}
                {metrics.ticketMedioReparaciones < 40 && (
                  <Badge className="bg-blue-100 text-blue-800">Mejorar precios servicios</Badge>
                )}
              </div>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-semibold text-red-600">Alertas</h4>
              <div className="space-y-2">
                {metrics.totalBeneficio < 0 && (
                  <Badge className="bg-red-100 text-red-800">Pérdidas en el período</Badge>
                )}
                {metrics.margenBeneficio < 5 && (
                  <Badge className="bg-red-100 text-red-800">Margen muy bajo</Badge>
                )}
                {metrics.totalGastos > metrics.totalIngresos * 0.8 && (
                  <Badge className="bg-red-100 text-red-800">Gastos elevados</Badge>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
