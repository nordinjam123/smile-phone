import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import {
  Cloud,
  CloudOff,
  RefreshCw,
  CheckCircle,
  AlertTriangle,
  Upload,
  Database,
  Wifi,
  WifiOff,
  Download,
  FileDown,
  FileUp,
  HardDrive,
  Monitor
} from 'lucide-react';
import { cloudSyncService, SyncStatus } from '@/lib/cloudSyncService';
import { useAuth } from '@/hooks/useAuth';

const CloudSyncStatus: React.FC = () => {
  const [syncStatus, setSyncStatus] = useState<SyncStatus>(cloudSyncService.getStatus());
  const [migrationStatus, setMigrationStatus] = useState<{
    isRunning: boolean;
    progress: number;
    migrated: number;
    errors: string[];
  }>({
    isRunning: false,
    progress: 0,
    migrated: 0,
    errors: []
  });
  const [showMigrationDialog, setShowMigrationDialog] = useState(false);
  
  const { user } = useAuth();
  const { toast } = useToast();

  // Función para exportar todos los datos
  const handleExportData = () => {
    try {
      const data = {
        ordenes: JSON.parse(localStorage.getItem('ordenes') || '[]'),
        clientes: JSON.parse(localStorage.getItem('clientes') || '[]'),
        inventario: JSON.parse(localStorage.getItem('inventario') || '[]'),
        inventario_piezas: JSON.parse(localStorage.getItem('inventario_piezas') || '[]'),
        moviles: JSON.parse(localStorage.getItem('moviles') || '[]'),
        facturas: JSON.parse(localStorage.getItem('facturas') || '[]'),
        gastos_mercancia: JSON.parse(localStorage.getItem('gastos_mercancia') || '[]'),
        citas: JSON.parse(localStorage.getItem('citas') || '[]'),
        configuracion: JSON.parse(localStorage.getItem('configuracion') || '{}'),
        exportDate: new Date().toISOString(),
        version: '1.0'
      };

      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `techrepair-backup-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      toast({
        title: "✅ Copia de seguridad creada",
        description: "Archivo descargado correctamente. Guárdalo en un lugar seguro.",
      });
    } catch (error) {
      toast({
        title: "Error al exportar",
        description: "No se pudo crear la copia de seguridad",
        variant: "destructive",
      });
    }
  };

  // Función para importar datos
  const handleImportData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const data = JSON.parse(content);

        // Verificar estructura del archivo
        if (!data.version || !data.exportDate) {
          throw new Error('Archivo de copia de seguridad no válido');
        }

        // Confirmar importación
        if (confirm('¿Estás seguro de que quieres importar estos datos? Esto sobrescribirá todos los datos actuales.')) {
          // Importar cada sección
          Object.keys(data).forEach(key => {
            if (key !== 'exportDate' && key !== 'version') {
              localStorage.setItem(key, JSON.stringify(data[key]));
            }
          });

          toast({
            title: "✅ Datos importados",
            description: "Recarga la página para ver los datos importados",
          });

          // Recargar página después de 2 segundos
          setTimeout(() => {
            window.location.reload();
          }, 2000);
        }
      } catch (error) {
        toast({
          title: "Error al importar",
          description: "El archivo no es válido o está corrupto",
          variant: "destructive",
        });
      }
    };
    reader.readAsText(file);

    // Limpiar input
    event.target.value = '';
  };

  useEffect(() => {
    const unsubscribe = cloudSyncService.onStatusChange(setSyncStatus);
    return unsubscribe;
  }, []);

  const handleMigrateToCloud = async () => {
    if (!user) {
      toast({
        title: "Error",
        description: "Debes iniciar sesión para migrar tus datos",
        variant: "destructive",
      });
      return;
    }

    setMigrationStatus({
      isRunning: true,
      progress: 0,
      migrated: 0,
      errors: []
    });

    try {
      // Simulate progress
      const progressInterval = setInterval(() => {
        setMigrationStatus(prev => ({
          ...prev,
          progress: Math.min(prev.progress + 10, 90)
        }));
      }, 200);

      const result = await cloudSyncService.migrateAllLocalDataToCloud();
      
      clearInterval(progressInterval);
      
      setMigrationStatus({
        isRunning: false,
        progress: 100,
        migrated: result.migrated,
        errors: result.errors
      });

      if (result.success) {
        toast({
          title: "✅ Migración completada",
          description: `Se migraron ${result.migrated} elementos a la nube`,
        });
      } else {
        toast({
          title: "Migración completada con errores",
          description: `Se migraron ${result.migrated} elementos. ${result.errors.length} errores encontrados.`,
          variant: "destructive",
        });
      }
    } catch (error: any) {
      setMigrationStatus({
        isRunning: false,
        progress: 0,
        migrated: 0,
        errors: [error.message]
      });
      
      toast({
        title: "Error en la migración",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleForceSync = async () => {
    const success = await cloudSyncService.autoSync();
    
    if (success) {
      toast({
        title: "Sincronización completada",
        description: "Tus datos están actualizados",
      });
    } else {
      toast({
        title: "Error de sincronización",
        description: "No se pudo sincronizar con la nube",
        variant: "destructive",
      });
    }
  };

  const formatLastSync = (lastSync: string | null) => {
    if (!lastSync) return 'Nunca';
    
    const date = new Date(lastSync);
    const now = new Date();
    const diffMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffMinutes < 1) return 'Hace un momento';
    if (diffMinutes < 60) return `Hace ${diffMinutes} minutos`;
    if (diffMinutes < 1440) return `Hace ${Math.floor(diffMinutes / 60)} horas`;
    return date.toLocaleDateString();
  };

  if (!user) {
    return (
      <Card className="border-blue-200 bg-blue-50">
        <CardContent className="p-4">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <HardDrive className="h-5 w-5 text-blue-600" />
              <div>
                <p className="font-medium text-blue-800">Almacenamiento Local Activo</p>
                <p className="text-sm text-blue-600">Datos guardados en tu navegador</p>
              </div>
            </div>

            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
              <div className="flex items-start gap-2">
                <Monitor className="h-4 w-4 text-yellow-600 mt-0.5" />
                <div>
                  <p className="font-medium text-yellow-800 text-sm">¿Quieres acceder desde otro dispositivo?</p>
                  <p className="text-xs text-yellow-700 mt-1">
                    Crea una copia de seguridad para transferir todos tus datos a otro ordenador o dispositivo.
                  </p>
                </div>
              </div>
            </div>

            <div className="flex gap-2">
              <Button onClick={handleExportData} size="sm" className="flex-1">
                <FileDown className="h-4 w-4 mr-2" />
                Exportar Datos
              </Button>

              <div className="flex-1">
                <input
                  type="file"
                  accept=".json"
                  onChange={handleImportData}
                  style={{ display: 'none' }}
                  id="import-file"
                />
                <Button
                  onClick={() => document.getElementById('import-file')?.click()}
                  variant="outline"
                  size="sm"
                  className="w-full"
                >
                  <FileUp className="h-4 w-4 mr-2" />
                  Importar Datos
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {/* Status Badge */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {syncStatus.isOnline ? (
                <div className="flex items-center gap-2">
                  <Wifi className="h-4 w-4 text-green-600" />
                  <span className="text-green-700 font-medium">Online</span>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <WifiOff className="h-4 w-4 text-red-600" />
                  <span className="text-red-700 font-medium">Offline</span>
                </div>
              )}
              
              {syncStatus.syncing && (
                <div className="flex items-center gap-2">
                  <RefreshCw className="h-4 w-4 animate-spin text-blue-600" />
                  <span className="text-blue-700 text-sm">Sincronizando...</span>
                </div>
              )}
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleForceSync}
                disabled={!syncStatus.isOnline || syncStatus.syncing}
              >
                <RefreshCw className={`h-4 w-4 mr-2 ${syncStatus.syncing ? 'animate-spin' : ''}`} />
                Sincronizar
              </Button>

              <Dialog open={showMigrationDialog} onOpenChange={setShowMigrationDialog}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Database className="h-4 w-4 mr-2" />
                    Migrar a la nube
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Migrar datos a la nube</DialogTitle>
                    <DialogDescription>
                      Transfiere todos tus datos locales a la nube para acceder desde cualquier lugar
                    </DialogDescription>
                  </DialogHeader>

                  <div className="space-y-4">
                    {migrationStatus.isRunning && (
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <RefreshCw className="h-4 w-4 animate-spin text-blue-600" />
                          <span>Migrando datos...</span>
                        </div>
                        <Progress value={migrationStatus.progress} className="w-full" />
                      </div>
                    )}

                    {migrationStatus.progress === 100 && (
                      <div className="space-y-3">
                        <div className="flex items-center gap-2 text-green-700">
                          <CheckCircle className="h-5 w-5" />
                          <span className="font-medium">
                            Migración completada: {migrationStatus.migrated} elementos transferidos
                          </span>
                        </div>

                        {migrationStatus.errors.length > 0 && (
                          <div className="space-y-2">
                            <div className="flex items-center gap-2 text-orange-700">
                              <AlertTriangle className="h-4 w-4" />
                              <span className="text-sm font-medium">Errores encontrados:</span>
                            </div>
                            <div className="bg-orange-50 p-3 rounded-lg text-sm">
                              {migrationStatus.errors.map((error, index) => (
                                <div key={index} className="text-orange-700">• {error}</div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    {!migrationStatus.isRunning && migrationStatus.progress === 0 && (
                      <div className="space-y-3">
                        <p className="text-sm text-gray-600">
                          Esta acción transferirá todos tus datos locales (órdenes, clientes, inventario, etc.) 
                          a la nube para que puedas acceder desde cualquier dispositivo.
                        </p>
                        
                        <div className="bg-blue-50 p-3 rounded-lg">
                          <p className="text-sm text-blue-700">
                            <strong>Importante:</strong> Los datos existentes en la nube se actualizarán con 
                            la información local más reciente.
                          </p>
                        </div>

                        <Button onClick={handleMigrateToCloud} className="w-full">
                          <Upload className="h-4 w-4 mr-2" />
                          Iniciar migración
                        </Button>
                      </div>
                    )}
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <div className="mt-3 text-sm text-gray-600">
            <div className="flex items-center justify-between">
              <span>Última sincronización: {formatLastSync(syncStatus.lastSync)}</span>
              {syncStatus.pendingChanges > 0 && (
                <Badge variant="outline" className="text-orange-600 border-orange-300">
                  {syncStatus.pendingChanges} cambios pendientes
                </Badge>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Info */}
      <div className="grid grid-cols-2 gap-4">
        <Card>
          <CardContent className="p-3">
            <div className="flex items-center gap-2">
              <HardDrive className="h-4 w-4 text-blue-600" />
              <div>
                <p className="text-sm font-medium">Almacenamiento</p>
                <p className="text-xs text-gray-600">100% local (navegador)</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-3">
            <div className="flex items-center gap-2">
              <FileDown className="h-4 w-4 text-green-600" />
              <div>
                <p className="text-sm font-medium">Copia de seguridad</p>
                <p className="text-xs text-gray-600">Exporta para otros dispositivos</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CloudSyncStatus;
