import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { cloudSyncService } from '@/lib/cloudSyncService';
import { Wrench, Database, AlertTriangle, CheckCircle } from 'lucide-react';

const MigrationDebugger: React.FC = () => {
  const [debugInfo, setDebugInfo] = useState<any[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const { toast } = useToast();

  const checkLocalData = () => {
    const dataKeys = [
      'ordenes', 'clientes', 'inventario', 'inventario_piezas', 
      'inventario_mercancia', 'productos_mercancia', 'gastos_mercancia',
      'ventas_tpv', 'movimientos_restock', 'citas', 'facturas'
    ];

    const results = dataKeys.map(key => {
      const data = localStorage.getItem(key);
      let parsed = null;
      let count = 0;
      let sample = null;

      if (data) {
        try {
          parsed = JSON.parse(data);
          if (Array.isArray(parsed)) {
            count = parsed.length;
            sample = parsed[0];
          }
        } catch (e) {
          // Invalid JSON
        }
      }

      return {
        key,
        hasData: !!data,
        isArray: Array.isArray(parsed),
        count,
        sample
      };
    });

    setDebugInfo(results);
  };

  const testMigration = async () => {
    setIsRunning(true);
    try {
      console.log('🚀 Starting test migration...');
      const result = await cloudSyncService.migrateAllLocalDataToCloud();

      console.log('Migration result:', result);

      if (result.success) {
        toast({
          title: "✅ Test migration successful",
          description: `Migrated ${result.migrated} items`,
        });
      } else {
        toast({
          title: "⚠️ Migration completed with errors",
          description: `${result.migrated} items migrated, ${result.errors.length} errors found.`,
          variant: "destructive",
        });

        // Show first few errors in detail
        result.errors.slice(0, 3).forEach((error, index) => {
          console.error(`Error ${index + 1}:`, error);
        });
      }

      // Show detailed results
      console.group('📋 Migration Summary');
      console.log('Success:', result.success);
      console.log('Migrated items:', result.migrated);
      console.log('Total errors:', result.errors.length);
      if (result.errors.length > 0) {
        console.log('Errors:', result.errors);
      }
      console.groupEnd();

    } catch (error: any) {
      console.error('Migration test failed:', error);
      toast({
        title: "❌ Migration test failed",
        description: error.message || 'Unknown error occurred',
        variant: "destructive",
      });
    } finally {
      setIsRunning(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Wrench className="h-5 w-5" />
          Migration Debugger
        </CardTitle>
        <CardDescription>
          Debug and test the cloud migration system
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Button onClick={checkLocalData} variant="outline">
            <Database className="h-4 w-4 mr-2" />
            Check Local Data
          </Button>
          <Button onClick={testMigration} disabled={isRunning}>
            {isRunning ? 'Running...' : 'Test Migration'}
          </Button>
        </div>

        {debugInfo.length > 0 && (
          <div className="space-y-2">
            <h4 className="font-medium">Local Data Summary:</h4>
            <div className="grid grid-cols-1 gap-2">
              {debugInfo.map((info) => (
                <div key={info.key} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-sm">{info.key}</span>
                    {info.hasData ? (
                      <Badge variant="outline" className="text-green-600 border-green-300">
                        <CheckCircle className="h-3 w-3 mr-1" />
                        {info.count} items
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="text-gray-500">
                        No data
                      </Badge>
                    )}
                  </div>
                  
                  {info.sample && (
                    <details className="text-xs">
                      <summary className="cursor-pointer text-blue-600">Sample</summary>
                      <pre className="mt-1 p-2 bg-gray-100 rounded text-xs overflow-auto max-w-xs">
                        {JSON.stringify(info.sample, null, 2)}
                      </pre>
                    </details>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="text-xs text-gray-500">
          <p>Open browser console to see detailed migration logs</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default MigrationDebugger;
