import { useState, useEffect, useCallback } from 'react';
import { cloudSyncService } from '@/lib/cloudSyncService';
import { useAuth } from './useAuth';

export function useCloudStorage<T>(key: string, initialValue: T) {
  const { user } = useAuth();
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      // Get from local storage first (for immediate UI)
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.error(`Error reading localStorage key "${key}":`, error);
      return initialValue;
    }
  });

  const [isLoading, setIsLoading] = useState(false);
  const [lastSynced, setLastSynced] = useState<string | null>(null);

  // Load data from cloud when user logs in
  useEffect(() => {
    if (user) {
      loadFromCloud();
    }
  }, [user, key]);

  const loadFromCloud = useCallback(async () => {
    if (!user) return;
    
    setIsLoading(true);
    try {
      const cloudData = await cloudSyncService.loadDataFromCloud(key);
      if (cloudData && cloudData.length > 0) {
        setStoredValue(cloudData as T);
        setLastSynced(new Date().toISOString());
      }
    } catch (error) {
      console.error(`Error loading ${key} from cloud:`, error);
    } finally {
      setIsLoading(false);
    }
  }, [user, key]);

  const saveToCloud = useCallback(async (value: T) => {
    if (!user || !Array.isArray(value)) return false;
    
    try {
      const success = await cloudSyncService.saveToCloud(key, value);
      if (success) {
        setLastSynced(new Date().toISOString());
      }
      return success;
    } catch (error) {
      console.error(`Error saving ${key} to cloud:`, error);
      return false;
    }
  }, [user, key]);

  // Enhanced setValue function that saves to both local and cloud
  const setValue = useCallback(async (value: T | ((val: T) => T)) => {
    try {
      // Calculate new value
      const valueToStore = value instanceof Function ? value(storedValue) : value;
      
      // Update local state immediately for responsive UI
      setStoredValue(valueToStore);
      
      // Save to localStorage for offline access
      window.localStorage.setItem(key, JSON.stringify(valueToStore));
      
      // Save to cloud if user is logged in
      if (user) {
        saveToCloud(valueToStore);
      }
    } catch (error) {
      console.error(`Error setting storage key "${key}":`, error);
    }
  }, [key, storedValue, user, saveToCloud]);

  // Force sync with cloud
  const syncWithCloud = useCallback(async () => {
    if (!user) return false;
    await loadFromCloud();
    return true;
  }, [user, loadFromCloud]);

  return {
    value: storedValue,
    setValue,
    isLoading,
    lastSynced,
    syncWithCloud
  };
}

// Helper hook for arrays (most common use case)
export function useCloudArray<T>(key: string, initialValue: T[] = []) {
  const { value, setValue, isLoading, lastSynced, syncWithCloud } = useCloudStorage(key, initialValue);
  
  const addItem = useCallback((item: T) => {
    setValue(prev => [...(prev as T[]), item]);
  }, [setValue]);

  const updateItem = useCallback((id: string, updates: Partial<T>) => {
    setValue(prev => 
      (prev as T[]).map(item => 
        (item as any).id === id ? { ...item, ...updates } : item
      )
    );
  }, [setValue]);

  const removeItem = useCallback((id: string) => {
    setValue(prev => (prev as T[]).filter(item => (item as any).id !== id));
  }, [setValue]);

  const clearAll = useCallback(() => {
    setValue([]);
  }, [setValue]);

  return {
    items: value as T[],
    setItems: setValue,
    addItem,
    updateItem,
    removeItem,
    clearAll,
    isLoading,
    lastSynced,
    syncWithCloud
  };
}
