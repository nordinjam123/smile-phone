-- Agregar campo color_factura para personalizar el color de las facturas
ALTER TABLE public.facturas 
ADD COLUMN color_factura text DEFAULT '#3B82F6';