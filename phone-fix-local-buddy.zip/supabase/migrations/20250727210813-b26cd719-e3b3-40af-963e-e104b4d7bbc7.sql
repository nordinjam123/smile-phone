-- Crear tabla para almacenar facturas
CREATE TABLE public.facturas (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  numero TEXT NOT NULL,
  cliente_nombre TEXT NOT NULL,
  cliente_telefono TEXT,
  cliente_email TEXT,
  cliente_direccion TEXT,
  fecha DATE NOT NULL,
  fecha_vencimiento DATE,
  conceptos JSONB NOT NULL DEFAULT '[]',
  subtotal DECIMAL(10,2) NOT NULL DEFAULT 0,
  iva DECIMAL(10,2) NOT NULL DEFAULT 0,
  total DECIMAL(10,2) NOT NULL DEFAULT 0,
  estado TEXT NOT NULL DEFAULT 'borrador' CHECK (estado IN ('borrador', 'enviada', 'pagada', 'vencida')),
  notas TEXT,
  logo_url TEXT,
  empresa_nombre TEXT,
  empresa_cif TEXT,
  empresa_direccion TEXT,
  empresa_telefono TEXT,
  empresa_email TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE public.facturas ENABLE ROW LEVEL SECURITY;

-- Políticas para facturas
CREATE POLICY "Los usuarios pueden ver sus propias facturas" 
ON public.facturas 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Los usuarios pueden crear sus propias facturas" 
ON public.facturas 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Los usuarios pueden actualizar sus propias facturas" 
ON public.facturas 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Los usuarios pueden eliminar sus propias facturas" 
ON public.facturas 
FOR DELETE 
USING (auth.uid() = user_id);

-- Trigger para actualizar updated_at
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_facturas_updated_at
BEFORE UPDATE ON public.facturas
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Crear bucket para logos de empresa
INSERT INTO storage.buckets (id, name, public) VALUES ('empresa-logos', 'empresa-logos', true);

-- Políticas para el bucket de logos
CREATE POLICY "Los usuarios pueden ver los logos" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'empresa-logos');

CREATE POLICY "Los usuarios pueden subir sus propios logos" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'empresa-logos' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Los usuarios pueden actualizar sus propios logos" 
ON storage.objects 
FOR UPDATE 
USING (bucket_id = 'empresa-logos' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Los usuarios pueden eliminar sus propios logos" 
ON storage.objects 
FOR DELETE 
USING (bucket_id = 'empresa-logos' AND auth.uid()::text = (storage.foldername(name))[1]);