import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import jsPDF from "jspdf";
import QRCode from "qrcode";
import {
  Plus,
  Minus,
  Search,
  ShoppingCart,
  Trash2,
  CreditCard,
  Banknote,
  Receipt,
  Calculator,
  Package,
  X,
  Check,
  Building,
  ScanLine,
  History,
  RefreshCw,
  Calendar,
  TrendingUp,
  Eye,
  RotateCcw,
  Filter,
  Minimize2,
  Maximize2,
  Home,
  Grid3X3,
  DollarSign,
  ShoppingBag,
  Users,
  Clock,
  Zap,
  LogOut,
  ArrowLeft,
  AlertCircle
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format } from "date-fns";
import BarcodeScanner from "./BarcodeScanner";
import { useEmpresaConfig } from "@/hooks/useEmpresaConfig";

interface ProductoMercancia {
  id: string;
  nombre: string;
  descripcion: string;
  categoria: string;
  precio: number;
  precioCoste?: number;
  stock: number;
  stock_minimo: number;
  proveedor: string;
  codigoBarras?: string;
}

interface ItemCarrito {
  producto: ProductoMercancia;
  cantidad: number;
  precio: number;
  total: number;
}

interface Cliente {
  nombre: string;
  telefono: string;
  email: string;
  direccion: string;
  tipoDocumento: "CIF" | "NIF";
  numeroDocumento: string;
}

const categoriasMercancia = [
  "Protectores y Cristales",
  "Audio y Auriculares", 
  "Cargadores y Cables",
  "Fundas y Accesorios",
  "Repuestos Externos",
  "Bebidas",
  "Snacks",
  "Dulces",
  "Cigarrillos",
  "Otros"
];

export default function TPVPage({ onExit }: { onExit?: () => void }) {
  // Estados principales
  const [productos, setProductos] = useState<ProductoMercancia[]>([]);
  const [carrito, setCarrito] = useState<ItemCarrito[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [categoriaFiltro, setCategoriaFiltro] = useState<string>("todas");
  const [cliente, setCliente] = useState<Cliente>({
    nombre: "Cliente General",
    telefono: "",
    email: "",
    direccion: "",
    tipoDocumento: "NIF",
    numeroDocumento: ""
  });
  
  // Estados de interfaz
  const [isMinimized, setIsMinimized] = useState(false);
  const [descuentoGlobal, setDescuentoGlobal] = useState(0);
  const [metodoPago, setMetodoPago] = useState<"efectivo" | "tarjeta">("efectivo");
  const [pagoRecibido, setPagoRecibido] = useState("");
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false);
  const [isAddProductDialogOpen, setIsAddProductDialogOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [isBarcodeSearchOpen, setIsBarcodeSearchOpen] = useState(false);
  const [ventas, setVentas] = useState<any[]>([]);
  const [showHistorialVentas, setShowHistorialVentas] = useState(false);
  const [filtroFecha, setFiltroFecha] = useState<'hoy' | 'mes' | 'todos'>('hoy');
  const [ventaSeleccionada, setVentaSeleccionada] = useState<any>(null);
  const [showDevolucion, setShowDevolucion] = useState(false);
  const [tipoDocumento, setTipoDocumento] = useState<'ticket' | 'factura'>('ticket');
  const [datosFacturacion, setDatosFacturacion] = useState({
    razonSocial: '',
    nif: '',
    direccion: '',
    codigoPostal: '',
    ciudad: '',
    provincia: ''
  });
  
  const { config: configuracionEmpresa } = useEmpresaConfig();
  const { toast } = useToast();

  // Estados para producto nuevo
  const [newProductForm, setNewProductForm] = useState({
    nombre: "",
    categoria: "Otros",
    precio: "",
    stock: "",
    codigoBarras: ""
  });

  // Cargar datos
  useEffect(() => {
    cargarProductos();
    cargarVentas();
  }, []);

  const cargarProductos = () => {
    try {
      const productosLocal = localStorage.getItem('productos_mercancia');
      if (productosLocal) {
        setProductos(JSON.parse(productosLocal));
      }
    } catch (error) {
      console.error('Error cargando productos:', error);
    } finally {
      setLoading(false);
    }
  };

  const cargarVentas = () => {
    try {
      const ventasLocal = localStorage.getItem('ventas_tpv');
      if (ventasLocal) {
        setVentas(JSON.parse(ventasLocal));
      }
    } catch (error) {
      console.error('Error cargando ventas:', error);
    }
  };

  // Estados para restock
  const [showRestockDialog, setShowRestockDialog] = useState(false);
  const [productoRestock, setProductoRestock] = useState<ProductoMercancia | null>(null);
  const [nuevoStock, setNuevoStock] = useState("");
  const [nuevoPrecio, setNuevoPrecio] = useState("");
  const [nuevoPrecioCoste, setNuevoPrecioCoste] = useState("");

  // Funciones del carrito
  const agregarAlCarrito = (producto: ProductoMercancia) => {
    if (producto.stock <= 0) {
      // Ofrecer restock cuando el stock es 0
      setProductoRestock(producto);
      setNuevoStock("10"); // Stock por defecto
      setNuevoPrecio((producto.precio * 1.21).toFixed(2)); // Precio con IVA incluido
      setNuevoPrecioCoste((producto.precioCoste || producto.precio * 0.7).toFixed(2)); // Precio de coste estimado
      setShowRestockDialog(true);
      return;
    }

    const itemExistente = carrito.find(item => item.producto.id === producto.id);

    if (itemExistente) {
      if (itemExistente.cantidad >= producto.stock) {
        toast({
          title: "Stock insuficiente",
          description: `Solo hay ${producto.stock} unidades disponibles. ¿Quieres añadir más stock?`,
          variant: "destructive",
          action: (
            <Button variant="outline" size="sm" onClick={() => {
              setProductoRestock(producto);
              setNuevoStock("10");
              setNuevoPrecio((producto.precio * 1.21).toFixed(2));
              setNuevoPrecioCoste((producto.precioCoste || producto.precio * 0.7).toFixed(2));
              setShowRestockDialog(true);
            }}>
              Restock
            </Button>
          )
        });
        return;
      }

      setCarrito(carrito.map(item =>
        item.producto.id === producto.id
          ? { ...item, cantidad: item.cantidad + 1, total: (item.cantidad + 1) * item.precio }
          : item
      ));
    } else {
      setCarrito([...carrito, {
        producto,
        cantidad: 1,
        precio: producto.precio,
        total: producto.precio
      }]);
    }

    toast({
      title: "Producto agregado",
      description: `${producto.nombre} agregado al carrito`,
      variant: "default"
    });
  };

  // Función para procesar restock
  const procesarRestock = () => {
    if (!productoRestock || !nuevoStock || !nuevoPrecio || !nuevoPrecioCoste) {
      toast({
        title: "Datos incompletos",
        description: "Por favor completa stock, precio de venta y precio de coste",
        variant: "destructive"
      });
      return;
    }

    const stockNum = parseInt(nuevoStock);
    const precioNum = parseFloat(nuevoPrecio);
    const precioCosteNum = parseFloat(nuevoPrecioCoste);

    if (stockNum <= 0 || precioNum <= 0 || precioCosteNum <= 0) {
      toast({
        title: "Valores inválidos",
        description: "Stock, precio de venta y precio de coste deben ser mayores a 0",
        variant: "destructive"
      });
      return;
    }

    if (precioCosteNum >= precioNum) {
      toast({
        title: "Precios inválidos",
        description: "El precio de coste debe ser menor al precio de venta",
        variant: "destructive"
      });
      return;
    }

    // Actualizar producto con nuevo stock y precios (sin IVA para almacenamiento)
    const precioSinIVA = precioNum / 1.21;
    const productosActualizados = productos.map(p =>
      p.id === productoRestock.id
        ? { ...p, stock: p.stock + stockNum, precio: precioSinIVA, precioCoste: precioCosteNum }
        : p
    );

    // Registrar el movimiento de restock en el balance
    const movimientoRestock = {
      id: `restock-${Date.now()}`,
      tipo: 'restock',
      fecha: new Date().toISOString(),
      producto: productoRestock.nombre,
      cantidad: stockNum,
      precioCoste: precioCosteNum,
      precioVenta: precioSinIVA,
      totalCoste: precioCosteNum * stockNum,
      margen: ((precioSinIVA - precioCosteNum) / precioSinIVA) * 100
    };

    // Guardar movimiento para el balance
    const movimientosExistentes = JSON.parse(localStorage.getItem('movimientos_restock') || '[]');
    movimientosExistentes.push(movimientoRestock);
    localStorage.setItem('movimientos_restock', JSON.stringify(movimientosExistentes));

    setProductos(productosActualizados);
    localStorage.setItem('productos_mercancia', JSON.stringify(productosActualizados));

    // Agregar producto al carrito automáticamente
    const productoActualizado = productosActualizados.find(p => p.id === productoRestock.id);
    if (productoActualizado) {
      setCarrito([...carrito, {
        producto: productoActualizado,
        cantidad: 1,
        precio: productoActualizado.precio,
        total: productoActualizado.precio
      }]);
    }

    setShowRestockDialog(false);
    setProductoRestock(null);
    setNuevoStock("");
    setNuevoPrecio("");
    setNuevoPrecioCoste("");

    toast({
      title: "Restock completado",
      description: `${stockNum} unidades añadidas. Producto agregado al carrito.`,
      variant: "default"
    });
  };

  const actualizarCantidad = (productoId: string, nuevaCantidad: number) => {
    if (nuevaCantidad <= 0) {
      eliminarDelCarrito(productoId);
      return;
    }

    const producto = productos.find(p => p.id === productoId);
    if (producto && nuevaCantidad > producto.stock) {
      toast({
        title: "Stock insuficiente",
        description: `Solo hay ${producto.stock} unidades disponibles`,
        variant: "destructive"
      });
      return;
    }

    setCarrito(carrito.map(item =>
      item.producto.id === productoId
        ? { ...item, cantidad: nuevaCantidad, total: nuevaCantidad * item.precio }
        : item
    ));
  };

  const eliminarDelCarrito = (productoId: string) => {
    setCarrito(carrito.filter(item => item.producto.id !== productoId));
  };

  const limpiarCarrito = () => {
    setCarrito([]);
    setCliente({
      nombre: "Cliente General",
      telefono: "",
      email: "",
      direccion: "",
      tipoDocumento: "NIF",
      numeroDocumento: ""
    });
    setDescuentoGlobal(0);
    setPagoRecibido("");
    setTipoDocumento('ticket');
    setDatosFacturacion({
      razonSocial: '',
      nif: '',
      direccion: '',
      codigoPostal: '',
      ciudad: '',
      provincia: ''
    });
  };

  // Función para procesar devoluciones
  const procesarDevolucion = (venta: any, productosDevolucion: any[]) => {
    // Actualizar stock devolviendo productos
    const productosActualizados = productos.map(producto => {
      const productoDevuelto = productosDevolucion.find(pd => pd.nombre === producto.nombre);
      if (productoDevuelto) {
        return { ...producto, stock: producto.stock + productoDevuelto.cantidad };
      }
      return producto;
    });

    setProductos(productosActualizados);
    localStorage.setItem('productos_mercancia', JSON.stringify(productosActualizados));

    // Marcar venta como devuelta (parcial o total)
    const ventasLocal = JSON.parse(localStorage.getItem('ventas_tpv') || '[]');
    const totalDevuelto = productosDevolucion.reduce((sum, p) => sum + (p.precio * p.cantidad), 0);

    const ventasActualizadas = ventasLocal.map((v: any) => {
      if (v.id === venta.id) {
        return {
          ...v,
          estado: totalDevuelto >= v.total ? 'devuelta_total' : 'devuelta_parcial',
          productosDevueltos: [...(v.productosDevueltos || []), ...productosDevolucion],
          montoDevuelto: (v.montoDevuelto || 0) + totalDevuelto,
          fechaDevolucion: new Date().toISOString()
        };
      }
      return v;
    });

    localStorage.setItem('ventas_tpv', JSON.stringify(ventasActualizadas));
    cargarVentas();

    // Generar ticket de devolución
    generarTicketDevolucion(venta, productosDevolucion, totalDevuelto);

    toast({
      title: "Devolución procesada",
      description: `Devolución de €${totalDevuelto.toFixed(2)} completada`,
      variant: "default"
    });
  };

  // Cálculos con IVA incluido
  const calcularTotales = () => {
    // Los precios ya incluyen IVA, así que calculamos hacia atrás
    const totalConIVA = carrito.reduce((sum, item) => sum + (item.total * 1.21), 0);
    const descuentoConIVA = (totalConIVA * descuentoGlobal) / 100;
    const totalConDescuento = totalConIVA - descuentoConIVA;

    // Separar base imponible e IVA
    const baseImponible = totalConDescuento / 1.21;
    const iva = totalConDescuento - baseImponible;

    return {
      subtotal: baseImponible,
      descuento: descuentoConIVA,
      iva: iva,
      total: totalConDescuento
    };
  };

  // Crear producto rápido
  const crearProductoRapido = () => {
    if (!newProductForm.nombre || !newProductForm.precio) {
      toast({
        title: "Campos requeridos",
        description: "Nombre y precio son obligatorios",
        variant: "destructive"
      });
      return;
    }

    const nuevoProducto: ProductoMercancia = {
      id: Date.now().toString(),
      nombre: newProductForm.nombre,
      descripcion: "",
      categoria: newProductForm.categoria,
      precio: parseFloat(newProductForm.precio),
      stock: parseInt(newProductForm.stock) || 1,
      stock_minimo: 1,
      proveedor: "TPV Rápido",
      codigoBarras: newProductForm.codigoBarras
    };

    const productosActualizados = [...productos, nuevoProducto];
    setProductos(productosActualizados);
    localStorage.setItem('productos_mercancia', JSON.stringify(productosActualizados));

    // Agregarlo automáticamente al carrito
    agregarAlCarrito(nuevoProducto);

    // Limpiar formulario
    setNewProductForm({
      nombre: "",
      categoria: "Otros",
      precio: "",
      stock: "",
      codigoBarras: ""
    });

    setIsAddProductDialogOpen(false);

    toast({
      title: "Producto creado",
      description: "Producto creado y agregado al carrito",
      variant: "default"
    });
  };

  // Procesar venta
  const procesarVenta = () => {
    if (carrito.length === 0) {
      toast({
        title: "Carrito vacío",
        description: "Agrega productos antes de procesar la venta",
        variant: "destructive"
      });
      return;
    }

    const { total } = calcularTotales();
    const pagoNum = parseFloat(pagoRecibido) || 0;

    if (metodoPago === "efectivo" && pagoNum < total) {
      toast({
        title: "Pago insuficiente",
        description: `Faltan €${(total - pagoNum).toFixed(2)}`,
        variant: "destructive"
      });
      return;
    }

    // Actualizar stock de productos
    const productosActualizados = productos.map(producto => {
      const itemCarrito = carrito.find(item => item.producto.id === producto.id);
      if (itemCarrito) {
        return { ...producto, stock: producto.stock - itemCarrito.cantidad };
      }
      return producto;
    });

    setProductos(productosActualizados);
    localStorage.setItem('productos_mercancia', JSON.stringify(productosActualizados));

    // Crear registro de venta
    const ventaLocal = {
      id: `venta-tpv-${Date.now()}`,
      fecha: format(new Date(), "yyyy-MM-dd"),
      hora: format(new Date(), "HH:mm:ss"),
      cliente: cliente.nombre,
      productos: carrito.map(item => ({
        nombre: item.producto.nombre,
        cantidad: item.cantidad,
        precio: item.precio,
        total: item.total
      })),
      subtotal: calcularTotales().subtotal,
      descuento: calcularTotales().descuento,
      iva: calcularTotales().iva,
      total: calcularTotales().total,
      metodoPago,
      pagoRecibido: metodoPago === "efectivo" ? pagoNum : total,
      cambio: metodoPago === "efectivo" ? pagoNum - total : 0,
      estado: "completada"
    };

    // Guardar venta
    const ventasExistentes = JSON.parse(localStorage.getItem('ventas_tpv') || '[]');
    ventasExistentes.push(ventaLocal);
    localStorage.setItem('ventas_tpv', JSON.stringify(ventasExistentes));
    
    // Generar ticket o factura según selección
    if (tipoDocumento === 'factura') {
      generarFactura(ventaLocal, datosFacturacion);
    } else {
      generarTicket(ventaLocal);
    }

    // Limpiar todo
    limpiarCarrito();
    setIsPaymentDialogOpen(false);

    toast({
      title: tipoDocumento === 'factura' ? "Factura generada" : "Venta procesada",
      description: `${tipoDocumento === 'factura' ? 'Factura' : 'Venta'} por €${total.toFixed(2)} completada`,
      variant: "default"
    });

    cargarVentas();
  };

  // Generar factura completa en formato ticket
  const generarFactura = async (venta: any, datosFacturacion: any) => {
    const doc = new jsPDF({
      format: [80, 200],
      unit: 'mm'
    });

    let y = 10;
    const margen = 5;

    // Header empresa
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text(configuracionEmpresa.nombreEmpresa || 'MI ABARROTES', 40, y, { align: 'center' });
    y += 8;

    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    if (configuracionEmpresa.telefono) {
      doc.text(`Tel: ${configuracionEmpresa.telefono}`, 40, y, { align: 'center' });
      y += 4;
    }
    if (configuracionEmpresa.direccion) {
      doc.text(configuracionEmpresa.direccion, 40, y, { align: 'center' });
      y += 4;
    }
    if (configuracionEmpresa.cif) {
      doc.text(`${configuracionEmpresa.tipoDocumento || 'CIF'}: ${configuracionEmpresa.cif}`, 40, y, { align: 'center' });
      y += 4;
    }

    // Línea separadora
    y += 3;
    doc.line(margen, y, 75, y);
    y += 5;

    // Título factura
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text('FACTURA', 40, y, { align: 'center' });
    y += 8;

    // Número de factura
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    const numeroFactura = `F-${Date.now().toString().slice(-6)}`;
    doc.text(`Nº: ${numeroFactura}`, margen, y);
    y += 4;
    doc.text(`Fecha: ${venta.fecha} ${venta.hora}`, margen, y);
    y += 8;

    // Datos del cliente
    doc.setFont('helvetica', 'bold');
    doc.text('FACTURAR A:', margen, y);
    y += 5;

    doc.setFont('helvetica', 'normal');
    doc.text(datosFacturacion.razonSocial || venta.cliente, margen, y);
    y += 4;
    if (datosFacturacion.nif) {
      doc.text(`NIF/CIF: ${datosFacturacion.nif}`, margen, y);
      y += 4;
    }
    if (datosFacturacion.direccion) {
      doc.text(datosFacturacion.direccion, margen, y);
      y += 4;
    }
    if (datosFacturacion.codigoPostal && datosFacturacion.ciudad) {
      doc.text(`${datosFacturacion.codigoPostal} ${datosFacturacion.ciudad}`, margen, y);
      y += 4;
    }
    if (datosFacturacion.provincia) {
      doc.text(datosFacturacion.provincia, margen, y);
      y += 4;
    }

    // Línea separadora
    y += 3;
    doc.line(margen, y, 75, y);
    y += 5;

    // Productos
    doc.setFontSize(8);
    doc.setFont('helvetica', 'bold');
    doc.text('PRODUCTOS', margen, y);
    y += 5;

    doc.setFont('helvetica', 'normal');
    venta.productos.forEach((producto: any) => {
      // Nombre del producto
      doc.text(producto.nombre, margen, y);
      y += 4;

      // Cantidad x precio = total
      doc.text(`${producto.cantidad} x €${producto.precio.toFixed(2)} = €${producto.total.toFixed(2)}`, margen + 2, y);
      y += 6;
    });

    // Línea separadora
    y += 2;
    doc.line(margen, y, 75, y);
    y += 5;

    // Totales
    doc.setFont('helvetica', 'normal');
    doc.text(`Subtotal: €${venta.subtotal.toFixed(2)}`, margen, y);
    y += 4;
    if (venta.descuento > 0) {
      doc.text(`Descuento: €${venta.descuento.toFixed(2)}`, margen, y);
      y += 4;
    }
    doc.text(`Base imponible: €${(venta.subtotal - venta.descuento).toFixed(2)}`, margen, y);
    y += 4;
    doc.text(`IVA (21%): €${venta.iva.toFixed(2)}`, margen, y);
    y += 6;

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.text(`TOTAL: €${venta.total.toFixed(2)}`, 40, y, { align: 'center' });
    y += 8;

    // Método de pago
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.text(`Pago: ${venta.metodoPago === 'efectivo' ? 'Efectivo' : 'Tarjeta'}`, margen, y);
    y += 6;

    // Línea separadora final
    doc.line(margen, y, 75, y);
    y += 5;

    // Mensaje final
    doc.text('Gracias por su compra', 40, y, { align: 'center' });

    window.open(doc.output('bloburl'), '_blank');
  };

  // Generar ticket
  const generarTicket = async (venta: any) => {
    const doc = new jsPDF({
      format: [80, 200],
      unit: 'mm'
    });

    let y = 10;
    const margen = 5;

    // Header
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text(configuracionEmpresa.nombreEmpresa || 'MI ABARROTES', 40, y, { align: 'center' });
    y += 8;

    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    if (configuracionEmpresa.telefono) {
      doc.text(`Tel: ${configuracionEmpresa.telefono}`, 40, y, { align: 'center' });
      y += 4;
    }
    if (configuracionEmpresa.direccion) {
      doc.text(configuracionEmpresa.direccion, 40, y, { align: 'center' });
      y += 4;
    }

    // Línea separadora
    y += 3;
    doc.line(margen, y, 75, y);
    y += 5;

    // Información de venta
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text('TICKET DE VENTA', 40, y, { align: 'center' });
    y += 8;

    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text(`Ticket: ${venta.id}`, margen, y);
    y += 4;
    doc.text(`Fecha: ${venta.fecha} ${venta.hora}`, margen, y);
    y += 4;
    doc.text(`Cliente: ${venta.cliente}`, margen, y);
    y += 8;

    // Productos
    doc.setFont('helvetica', 'bold');
    doc.text('PRODUCTOS', margen, y);
    y += 5;

    doc.setFont('helvetica', 'normal');
    venta.productos.forEach((producto: any) => {
      const linea = `${producto.cantidad}x ${producto.nombre}`;
      doc.text(linea, margen, y);
      doc.text(`€${producto.total.toFixed(2)}`, 70, y, { align: 'right' });
      y += 4;
    });

    // Totales
    y += 3;
    doc.line(margen, y, 75, y);
    y += 5;

    doc.text(`Subtotal: €${venta.subtotal.toFixed(2)}`, margen, y);
    y += 4;
    if (venta.descuento > 0) {
      doc.text(`Descuento: €${venta.descuento.toFixed(2)}`, margen, y);
      y += 4;
    }
    doc.text(`IVA (21%): €${venta.iva.toFixed(2)}`, margen, y);
    y += 4;

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.text(`TOTAL: €${venta.total.toFixed(2)}`, margen, y);
    y += 6;

    // Pago
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.text(`Pago (${venta.metodoPago}): €${venta.pagoRecibido.toFixed(2)}`, margen, y);
    y += 4;
    if (venta.cambio > 0) {
      doc.text(`Cambio: €${venta.cambio.toFixed(2)}`, margen, y);
      y += 4;
    }

    // Footer
    y += 5;
    doc.line(margen, y, 75, y);
    y += 5;

    doc.setFontSize(7);
    doc.text('¡Gracias por su compra!', 40, y, { align: 'center' });
    y += 4;
    doc.text('Vuelva pronto', 40, y, { align: 'center' });

    window.open(doc.output('bloburl'), '_blank');
  };

  // Generar ticket de devolución
  const generarTicketDevolucion = async (ventaOriginal: any, productosDevueltos: any[], totalDevuelto: number) => {
    const doc = new jsPDF({
      format: [80, 150],
      unit: 'mm'
    });

    let y = 10;
    const margen = 5;

    // Header
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text(configuracionEmpresa.nombreEmpresa || 'MI ABARROTES', 40, y, { align: 'center' });
    y += 8;

    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    if (configuracionEmpresa.telefono) {
      doc.text(`Tel: ${configuracionEmpresa.telefono}`, 40, y, { align: 'center' });
      y += 4;
    }

    // Título
    y += 5;
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text('TICKET DE DEVOLUCIÓN', 40, y, { align: 'center' });
    y += 8;

    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text(`Ticket original: ${ventaOriginal.id}`, margen, y);
    y += 4;
    doc.text(`Fecha devolución: ${new Date().toLocaleDateString('es-ES')}`, margen, y);
    y += 4;
    doc.text(`Cliente: ${ventaOriginal.cliente}`, margen, y);
    y += 8;

    // Productos devueltos
    doc.setFont('helvetica', 'bold');
    doc.text('PRODUCTOS DEVUELTOS', margen, y);
    y += 5;

    doc.setFont('helvetica', 'normal');
    productosDevueltos.forEach((producto: any) => {
      doc.text(`${producto.cantidad}x ${producto.nombre}`, margen, y);
      doc.text(`€${(producto.precio * producto.cantidad).toFixed(2)}`, 70, y, { align: 'right' });
      y += 4;
    });

    y += 3;
    doc.line(margen, y, 75, y);
    y += 5;

    doc.setFont('helvetica', 'bold');
    doc.text(`TOTAL DEVUELTO: €${totalDevuelto.toFixed(2)}`, margen, y);

    y += 10;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.text('Conserve este ticket como justificante', 40, y, { align: 'center' });

    window.open(doc.output('bloburl'), '_blank');
  };

  // Filtrar productos
  const productosFiltrados = productos.filter(producto => {
    const matchesSearch = producto.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         producto.categoria.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (producto.codigoBarras && producto.codigoBarras.includes(searchTerm));
    
    const matchesCategory = categoriaFiltro === "todas" || producto.categoria === categoriaFiltro;
    
    return matchesSearch && matchesCategory;
  });

  const { subtotal, descuento, iva, total } = calcularTotales();

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <p className="text-lg">Cargando TPV...</p>
        </div>
      </div>
    );
  }

  // Vista minimizada
  if (isMinimized) {
    return (
      <div className="fixed bottom-4 right-4 bg-blue-600 text-white rounded-lg shadow-lg z-50">
        <div className="flex items-center gap-2 p-3">
          <ShoppingCart className="w-5 h-5" />
          <span className="font-medium">TPV Abarrotes</span>
          {carrito.length > 0 && (
            <Badge variant="secondary" className="bg-white text-blue-600">
              {carrito.length}
            </Badge>
          )}
          <Button
            size="sm"
            variant="ghost"
            onClick={() => setIsMinimized(false)}
            className="text-white hover:bg-blue-700 p-1"
            title="Maximizar TPV"
          >
            <Maximize2 className="w-4 h-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => {
              if (carrito.length > 0) {
                if (window.confirm('¿Estás seguro de salir del TPV? Se perderá la venta actual.')) {
                  onExit?.();
                }
              } else {
                onExit?.();
              }
            }}
            className="text-white hover:bg-red-600 p-1"
            title="Salir del TPV"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>
    );
  }

  // Vista completa
  return (
    <div className="fixed top-16 left-0 right-0 bottom-0 bg-gray-50 z-40 overflow-hidden">



      {/* Header fijo del TPV */}
      <div className="bg-white border-b border-gray-200 px-6 py-6 shadow-md">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            {/* Botón de salir prominente */}
            <Button
              onClick={() => {
                if (carrito.length > 0) {
                  if (window.confirm('¿Estás seguro de salir del TPV? Se perderá la venta actual.')) {
                    onExit?.();
                  }
                } else {
                  onExit?.();
                }
              }}
              className="gap-2 font-bold text-white shadow-lg px-6 py-3 h-14 text-lg"
              style={{
                backgroundColor: '#dc2626',
                color: 'white',
                border: 'none'
              }}
            >
              <ArrowLeft className="w-6 h-6" />
              SALIR DEL TPV
            </Button>

            <div className="flex items-center gap-3">
              <ShoppingBag className="w-10 h-10 text-blue-600" />
              <div>
                <h1 className="text-3xl font-bold text-gray-900">TPV ABARROTES</h1>
                <p className="text-lg text-gray-500">Terminal Punto de Venta</p>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {/* Estadísticas rápidas */}
            <div className="flex items-center gap-4 text-sm text-gray-600">
              <div className="flex items-center gap-1">
                <Package className="w-4 h-4" />
                <span>{productos.length} productos</span>
              </div>
              <div className="flex items-center gap-1">
                <ShoppingCart className="w-4 h-4" />
                <span>{carrito.length} en carrito</span>
              </div>
              <div className="flex items-center gap-1">
                <DollarSign className="w-4 h-4" />
                <span>€{total.toFixed(2)}</span>
              </div>
            </div>

            {/* Botones de acción */}
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowHistorialVentas(true)}
              className="gap-1"
            >
              <History className="w-4 h-4" />
              Historial
            </Button>

            <Button
              variant="default"
              size="sm"
              onClick={() => {
                // Mostrar directamente el historial con enfoque en devoluciones
                setShowHistorialVentas(true);
                toast({
                  title: "💡 Devoluciones",
                  description: "Busca la venta y haz clic en el botón DEVOLVER (naranja)",
                  variant: "default"
                });
              }}
              className="gap-2 text-white bg-orange-600 hover:bg-orange-700 border-orange-600 px-4 py-2 font-medium"
            >
              <RotateCcw className="w-4 h-4" />
              DEVOLUCIONES
            </Button>

            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsMinimized(true)}
              className="gap-1"
            >
              <Minimize2 className="w-4 h-4" />
              Minimizar
            </Button>


          </div>
        </div>
      </div>

      {/* Contenido principal */}
      <div className="flex h-[calc(100vh-180px)]">
        {/* Panel izquierdo - Productos */}
        <div className="flex-1 flex flex-col bg-white">
          {/* Búsqueda y filtros */}
          <div className="p-4 border-b border-gray-200">
            <div className="flex gap-3 mb-3">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Buscar productos, categorías o código de barras..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 h-12 text-lg"
                />
              </div>
              <Button
                variant="outline"
                size="lg"
                onClick={() => setIsBarcodeSearchOpen(true)}
                className="gap-2"
              >
                <ScanLine className="w-5 h-5" />
                Escanear
              </Button>
            </div>
            
            <div className="flex gap-2">
              <Select value={categoriaFiltro} onValueChange={setCategoriaFiltro}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Todas las categorías" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todas">Todas las categorías</SelectItem>
                  {categoriasMercancia.map(categoria => (
                    <SelectItem key={categoria} value={categoria}>
                      {categoria}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Dialog open={isAddProductDialogOpen} onOpenChange={setIsAddProductDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="gap-2">
                    <Plus className="w-4 h-4" />
                    Producto Rápido
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>Crear Producto Rápido</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="nombre">Nombre *</Label>
                      <Input
                        id="nombre"
                        value={newProductForm.nombre}
                        onChange={(e) => setNewProductForm({...newProductForm, nombre: e.target.value})}
                        placeholder="Ej: Coca Cola 500ml"
                      />
                    </div>
                    <div>
                      <Label htmlFor="categoria">Categoría</Label>
                      <Select value={newProductForm.categoria} onValueChange={(value) => setNewProductForm({...newProductForm, categoria: value})}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {categoriasMercancia.map(categoria => (
                            <SelectItem key={categoria} value={categoria}>
                              {categoria}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Label htmlFor="precio">Precio *</Label>
                        <Input
                          id="precio"
                          type="number"
                          step="0.01"
                          value={newProductForm.precio}
                          onChange={(e) => setNewProductForm({...newProductForm, precio: e.target.value})}
                          placeholder="0.00"
                        />
                      </div>
                      <div>
                        <Label htmlFor="stock">Stock</Label>
                        <Input
                          id="stock"
                          type="number"
                          value={newProductForm.stock}
                          onChange={(e) => setNewProductForm({...newProductForm, stock: e.target.value})}
                          placeholder="1"
                        />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="codigoBarras">Código de Barras</Label>
                      <Input
                        id="codigoBarras"
                        value={newProductForm.codigoBarras}
                        onChange={(e) => setNewProductForm({...newProductForm, codigoBarras: e.target.value})}
                        placeholder="Opcional"
                      />
                    </div>
                    <div className="flex gap-2">
                      <Button onClick={() => setIsAddProductDialogOpen(false)} variant="outline" className="flex-1">
                        Cancelar
                      </Button>
                      <Button onClick={crearProductoRapido} className="flex-1">
                        Crear y Agregar
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          {/* Grid de productos */}
          <div className="flex-1 overflow-auto p-4">
            {productosFiltrados.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-64 text-gray-500">
                <Package className="w-16 h-16 mb-4" />
                <p className="text-lg font-medium">No hay productos</p>
                <p className="text-sm">
                  {searchTerm || categoriaFiltro !== "todas" 
                    ? "Ajusta los filtros o busca otro término"
                    : "Crea tu primer producto para comenzar"
                  }
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6 gap-4">
                {productosFiltrados.map((producto) => (
                  <Card 
                    key={producto.id} 
                    className="cursor-pointer hover:shadow-lg transition-all duration-200 hover:scale-105"
                    onClick={() => agregarAlCarrito(producto)}
                  >
                    <CardContent className="p-4">
                      <div className="aspect-square bg-gradient-to-br from-blue-100 to-purple-100 rounded-lg mb-3 flex items-center justify-center">
                        <Package className="w-8 h-8 text-blue-600" />
                      </div>
                      
                      <h3 className="font-semibold text-sm line-clamp-2 mb-2">
                        {producto.nombre}
                      </h3>
                      
                      <div className="space-y-1">
                        <div className="flex items-center justify-between">
                          <div className="text-right">
                            <span className="text-lg font-bold text-green-600">
                              €{(producto.precio * 1.21).toFixed(2)}
                            </span>
                            <p className="text-xs text-gray-500">IVA incl.</p>
                          </div>
                          <Badge
                            variant={
                              producto.stock <= 0 ? "destructive" :
                              producto.stock <= producto.stock_minimo ? "secondary" : "default"
                            }
                            className="text-xs"
                          >
                            Stock: {producto.stock}
                          </Badge>
                        </div>

                        <p className="text-xs text-gray-500">{producto.categoria}</p>

                        {producto.stock <= 0 ? (
                          <Badge variant="outline" className="w-full justify-center text-orange-600 border-orange-200">
                            <Plus className="w-3 h-3 mr-1" />
                            Añadir Stock
                          </Badge>
                        ) : producto.stock <= producto.stock_minimo ? (
                          <Badge variant="secondary" className="w-full justify-center">
                            Stock Bajo
                          </Badge>
                        ) : null}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Panel derecho - Carrito */}
        <div className="w-96 bg-white border-l border-gray-200 flex flex-col h-full max-h-[calc(100vh-180px)]">
          {/* Header del carrito */}
          <div className="p-4 border-b border-gray-200 flex-shrink-0">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <ShoppingCart className="w-5 h-5" />
                Carrito de Compras
              </h2>
              {carrito.length > 0 && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={limpiarCarrito}
                  className="text-red-600 hover:bg-red-50"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              )}
            </div>
            
            {/* Tipo de documento */}
            <div className="space-y-2">
              <Label className="text-xs">Tipo de documento</Label>
              <div className="flex gap-2">
                <Button
                  variant={tipoDocumento === 'ticket' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setTipoDocumento('ticket')}
                  className="flex-1"
                >
                  Ticket
                </Button>
                <Button
                  variant={tipoDocumento === 'factura' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setTipoDocumento('factura')}
                  className="flex-1"
                >
                  Factura
                </Button>
              </div>
            </div>

            {/* Cliente */}
            <div>
              <Label htmlFor="clienteNombre" className="text-xs">
                {tipoDocumento === 'factura' ? 'Razón Social' : 'Cliente'}
              </Label>
              <Input
                id="clienteNombre"
                value={cliente.nombre}
                onChange={(e) => setCliente({...cliente, nombre: e.target.value})}
                placeholder={tipoDocumento === 'factura' ? 'Razón Social' : 'Nombre del cliente'}
                className="h-8 text-sm"
              />
            </div>

            {/* Datos adicionales para factura */}
            {tipoDocumento === 'factura' && (
              <div className="space-y-2 p-3 bg-blue-50 rounded-lg border border-blue-200">
                <Label className="text-xs font-semibold text-blue-800">📋 Datos de facturación</Label>

                <div>
                  <Label htmlFor="nifFactura" className="text-xs">NIF/CIF</Label>
                  <Input
                    id="nifFactura"
                    value={datosFacturacion.nif}
                    onChange={(e) => setDatosFacturacion({...datosFacturacion, nif: e.target.value})}
                    placeholder="NIF/CIF"
                    className="h-7 text-sm"
                  />
                </div>

                <div>
                  <Label htmlFor="direccionFactura" className="text-xs">Dirección</Label>
                  <Input
                    id="direccionFactura"
                    value={datosFacturacion.direccion}
                    onChange={(e) => setDatosFacturacion({...datosFacturacion, direccion: e.target.value})}
                    placeholder="Dirección completa"
                    className="h-7 text-sm"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label htmlFor="cpFactura" className="text-xs">CP</Label>
                    <Input
                      id="cpFactura"
                      value={datosFacturacion.codigoPostal}
                      onChange={(e) => setDatosFacturacion({...datosFacturacion, codigoPostal: e.target.value})}
                      placeholder="CP"
                      className="h-7 text-sm"
                    />
                  </div>
                  <div>
                    <Label htmlFor="ciudadFactura" className="text-xs">Ciudad</Label>
                    <Input
                      id="ciudadFactura"
                      value={datosFacturacion.ciudad}
                      onChange={(e) => setDatosFacturacion({...datosFacturacion, ciudad: e.target.value})}
                      placeholder="Ciudad"
                      className="h-7 text-sm"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Items del carrito */}
          <div className="flex-1 overflow-auto p-4">
            {carrito.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-gray-500">
                <ShoppingCart className="w-12 h-12 mb-3" />
                <p className="font-medium">Carrito vacío</p>
                <p className="text-sm text-center">Haz clic en los productos para agregarlos</p>
              </div>
            ) : (
              <div className="space-y-3">
                {carrito.map((item) => (
                  <div key={item.producto.id} className="bg-gray-50 rounded-lg p-3">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-medium text-sm line-clamp-2">{item.producto.nombre}</h4>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => eliminarDelCarrito(item.producto.id)}
                        className="text-red-600 hover:bg-red-50 p-1"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => actualizarCantidad(item.producto.id, item.cantidad - 1)}
                          className="h-7 w-7 p-0"
                        >
                          <Minus className="w-3 h-3" />
                        </Button>
                        
                        <span className="w-8 text-center font-medium">{item.cantidad}</span>
                        
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => actualizarCantidad(item.producto.id, item.cantidad + 1)}
                          className="h-7 w-7 p-0"
                        >
                          <Plus className="w-3 h-3" />
                        </Button>
                      </div>
                      
                      <div className="text-right">
                        <p className="text-sm text-gray-600">€{(item.precio * 1.21).toFixed(2)} c/u</p>
                        <p className="text-xs text-gray-500">IVA incl.</p>
                        <p className="font-semibold text-green-600">€{(item.total * 1.21).toFixed(2)}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Footer del carrito - Totales y pago */}
          {carrito.length > 0 && (
            <div className="border-t-2 border-green-200 p-4 space-y-4 flex-shrink-0 bg-gradient-to-t from-green-50 to-white shadow-lg">
              {/* Descuento */}
              <div>
                <Label htmlFor="descuento" className="text-xs">Descuento (%)</Label>
                <Input
                  id="descuento"
                  type="number"
                  min="0"
                  max="100"
                  value={descuentoGlobal}
                  onChange={(e) => setDescuentoGlobal(parseFloat(e.target.value) || 0)}
                  className="h-8 text-sm"
                />
              </div>

              {/* Totales */}
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Base imponible:</span>
                  <span>€{subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>IVA (21%):</span>
                  <span>€{iva.toFixed(2)}</span>
                </div>
                {descuento > 0 && (
                  <div className="flex justify-between text-red-600">
                    <span>Descuento:</span>
                    <span>-€{descuento.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-lg border-t pt-2">
                  <span>TOTAL (IVA incl.):</span>
                  <span className="text-green-600">€{total.toFixed(2)}</span>
                </div>
              </div>

              {/* Indicador de modo factura */}
              {tipoDocumento === 'factura' && (
                <div className="p-3 bg-blue-50 border-2 border-blue-300 rounded-lg">
                  <div className="flex items-center gap-2 text-blue-800">
                    <Receipt className="w-5 h-5" />
                    <span className="text-sm font-bold">📄 FACTURA ACTIVA</span>
                  </div>
                  <p className="text-xs text-blue-700 mt-1">
                    ✅ Al cobrar se generará factura con datos fiscales completos
                  </p>
                </div>
              )}

              {/* Botón de pago */}
              <Dialog open={isPaymentDialogOpen} onOpenChange={setIsPaymentDialogOpen}>
                <DialogTrigger asChild>
                  <Button
                    size="lg"
                    className="w-full gap-2 h-20 text-2xl font-bold bg-green-600 hover:bg-green-700 shadow-2xl animate-pulse border-2 border-green-400"
                    style={{
                      backgroundColor: '#16a34a',
                      color: 'white',
                      boxShadow: '0 0 20px rgba(34, 197, 94, 0.5)',
                      position: 'sticky',
                      bottom: '0',
                      zIndex: 50
                    }}
                  >
                    <CreditCard className="w-8 h-8" />
                    COBRAR €{total.toFixed(2)}
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>Procesar Pago</DialogTitle>
                  </DialogHeader>
                  
                  <div className="space-y-4">
                    <div className="text-center p-4 bg-gray-50 rounded-lg">
                      <p className="text-2xl font-bold text-green-600">€{total.toFixed(2)}</p>
                      <p className="text-sm text-gray-600">Total a cobrar</p>
                    </div>

                    <div>
                      <Label>Método de Pago</Label>
                      <Select value={metodoPago} onValueChange={(value: "efectivo" | "tarjeta") => setMetodoPago(value)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="efectivo">
                            <div className="flex items-center gap-2">
                              <Banknote className="w-4 h-4" />
                              Efectivo
                            </div>
                          </SelectItem>
                          <SelectItem value="tarjeta">
                            <div className="flex items-center gap-2">
                              <CreditCard className="w-4 h-4" />
                              Tarjeta
                            </div>
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {metodoPago === "efectivo" && (
                      <div>
                        <Label htmlFor="pagoRecibido">Dinero Recibido</Label>
                        <Input
                          id="pagoRecibido"
                          type="number"
                          step="0.01"
                          value={pagoRecibido}
                          onChange={(e) => setPagoRecibido(e.target.value)}
                          placeholder="0.00"
                          className="text-lg"
                        />
                        {parseFloat(pagoRecibido) > total && (
                          <p className="text-sm text-green-600 mt-1">
                            Cambio: €{(parseFloat(pagoRecibido) - total).toFixed(2)}
                          </p>
                        )}
                      </div>
                    )}

                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        onClick={() => setIsPaymentDialogOpen(false)}
                        className="flex-1"
                      >
                        Cancelar
                      </Button>
                      <Button
                        onClick={procesarVenta}
                        className="flex-1"
                        disabled={metodoPago === "efectivo" && parseFloat(pagoRecibido) < total}
                      >
                        <Check className="w-4 h-4 mr-2" />
                        Confirmar
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          )}
        </div>
      </div>

      {/* Scanner de códigos de barras */}
      <BarcodeScanner
        isOpen={isBarcodeSearchOpen}
        onClose={() => setIsBarcodeSearchOpen(false)}
        onScan={(codigo) => {
          const producto = productos.find(p => p.codigoBarras === codigo);
          if (producto) {
            agregarAlCarrito(producto);
            setIsBarcodeSearchOpen(false);
          } else {
            toast({
              title: "Producto no encontrado",
              description: "No se encontró un producto con este código de barras",
              variant: "destructive"
            });
          }
        }}
      />

      {/* Historial de ventas */}
      <Dialog open={showHistorialVentas} onOpenChange={setShowHistorialVentas}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <History className="w-5 h-5" />
              Historial de Ventas y Devoluciones
            </DialogTitle>
            <div className="text-sm text-orange-600 bg-orange-50 p-3 rounded-lg mt-2">
              <div className="flex items-center gap-2">
                <RotateCcw className="w-4 h-4" />
                <span className="font-medium">💡 Para procesar devoluciones:</span>
              </div>
              <p className="mt-1">Busca la venta que quieres devolver y haz clic en el botón naranja <strong>"DEVOLVER"</strong></p>
            </div>
          </DialogHeader>

          <div className="space-y-4">
            {/* Filtros de fecha */}
            <div className="flex gap-2">
              <Select value={filtroFecha} onValueChange={(value: 'hoy' | 'mes' | 'todos') => setFiltroFecha(value)}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="hoy">Hoy</SelectItem>
                  <SelectItem value="mes">Este mes</SelectItem>
                  <SelectItem value="todos">Todas</SelectItem>
                </SelectContent>
              </Select>
              
              <Button variant="outline" onClick={cargarVentas}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Actualizar
              </Button>
            </div>

            {/* Lista de ventas */}
            <div className="space-y-2 max-h-96 overflow-auto">
              {/* Mensaje cuando no hay ventas */}
              {ventas.length === 0 && (
                <div className="text-center py-12">
                  <div className="mb-6">
                    <RotateCcw className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-gray-700 mb-2">
                      No hay ventas registradas
                    </h3>
                    <p className="text-gray-500 mb-4">
                      Para procesar devoluciones, primero necesitas realizar algunas ventas.
                    </p>
                  </div>

                  <div className="bg-blue-50 p-4 rounded-lg mx-4">
                    <h4 className="font-semibold text-blue-800 mb-2">¿Cómo procesar devoluciones?</h4>
                    <ol className="text-sm text-blue-700 text-left space-y-1">
                      <li>1. Realiza una venta usando el TPV</li>
                      <li>2. Ve al "Historial de Ventas"</li>
                      <li>3. Busca la venta a devolver</li>
                      <li>4. Haz clic en el botón naranja "DEVOLVER"</li>
                      <li>5. Selecciona productos y cantidades</li>
                      <li>6. Confirma la devolución</li>
                    </ol>
                  </div>
                </div>
              )}
              {ventas.filter(venta => {
                const fechaVenta = new Date(venta.fecha);
                const hoy = new Date();
                
                switch (filtroFecha) {
                  case 'hoy':
                    return fechaVenta.toDateString() === hoy.toDateString();
                  case 'mes':
                    return fechaVenta.getMonth() === hoy.getMonth() && fechaVenta.getFullYear() === hoy.getFullYear();
                  case 'todos':
                    return true;
                  default:
                    return true;
                }
              }).map((venta) => (
                <Card key={venta.id} className="p-3">
                  <div className="flex justify-between items-center">
                    <div className="flex-1">
                      <p className="font-medium">{venta.id}</p>
                      <p className="text-sm text-gray-600">{venta.fecha} {venta.hora}</p>
                      <p className="text-sm">{venta.cliente}</p>
                      {venta.montoDevuelto > 0 && (
                        <p className="text-xs text-orange-600">
                          Devuelto: €{venta.montoDevuelto.toFixed(2)}
                        </p>
                      )}
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-green-600">€{venta.total.toFixed(2)}</p>
                      <p className="text-sm text-gray-600">{venta.metodoPago}</p>
                      <div className="flex items-center gap-2">
                        <Badge variant={
                          venta.estado === 'completada' ? 'default' :
                          venta.estado === 'devuelta_total' ? 'destructive' :
                          venta.estado === 'devuelta_parcial' ? 'secondary' : 'default'
                        }>
                          {venta.estado === 'devuelta_total' ? 'Devuelta' :
                           venta.estado === 'devuelta_parcial' ? 'Dev. Parcial' :
                           venta.estado || 'Completada'}
                        </Badge>

                        {/* Botón de devolución */}
                        {(venta.estado === 'completada' || venta.estado === 'devuelta_parcial') && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setVentaSeleccionada(venta);
                              setShowDevolucion(true);
                            }}
                            className="text-white bg-orange-600 hover:bg-orange-700 border-orange-600 px-3 py-1 font-medium"
                            title="Procesar devolución"
                          >
                            <RotateCcw className="w-4 h-4 mr-1" />
                            DEVOLVER
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>

            {/* Resumen de ventas */}
            <Card className="p-4 bg-blue-50">
              <h3 className="font-semibold mb-2">Resumen del Período</h3>
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div>
                  <p className="text-gray-600">Total Ventas</p>
                  <p className="font-bold text-lg">
                    €{ventas.filter(venta => {
                      const fechaVenta = new Date(venta.fecha);
                      const hoy = new Date();
                      
                      switch (filtroFecha) {
                        case 'hoy':
                          return fechaVenta.toDateString() === hoy.toDateString();
                        case 'mes':
                          return fechaVenta.getMonth() === hoy.getMonth() && fechaVenta.getFullYear() === hoy.getFullYear();
                        case 'todos':
                          return true;
                        default:
                          return true;
                      }
                    }).reduce((sum, venta) => sum + venta.total, 0).toFixed(2)}
                  </p>
                </div>
                <div>
                  <p className="text-gray-600">Cantidad</p>
                  <p className="font-bold text-lg">
                    {ventas.filter(venta => {
                      const fechaVenta = new Date(venta.fecha);
                      const hoy = new Date();
                      
                      switch (filtroFecha) {
                        case 'hoy':
                          return fechaVenta.toDateString() === hoy.toDateString();
                        case 'mes':
                          return fechaVenta.getMonth() === hoy.getMonth() && fechaVenta.getFullYear() === hoy.getFullYear();
                        case 'todos':
                          return true;
                        default:
                          return true;
                      }
                    }).length}
                  </p>
                </div>
                <div>
                  <p className="text-gray-600">Promedio</p>
                  <p className="font-bold text-lg">
                    €{(() => {
                      const ventasFiltradas = ventas.filter(venta => {
                        const fechaVenta = new Date(venta.fecha);
                        const hoy = new Date();
                        
                        switch (filtroFecha) {
                          case 'hoy':
                            return fechaVenta.toDateString() === hoy.toDateString();
                          case 'mes':
                            return fechaVenta.getMonth() === hoy.getMonth() && fechaVenta.getFullYear() === hoy.getFullYear();
                          case 'todos':
                            return true;
                          default:
                            return true;
                        }
                      });
                      
                      const total = ventasFiltradas.reduce((sum, venta) => sum + venta.total, 0);
                      return ventasFiltradas.length > 0 ? (total / ventasFiltradas.length).toFixed(2) : '0.00';
                    })()}
                  </p>
                </div>
              </div>
            </Card>
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal de devolución */}
      <Dialog open={showDevolucion} onOpenChange={setShowDevolucion}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <RotateCcw className="w-5 h-5" />
              Procesar Devolución
            </DialogTitle>
          </DialogHeader>

          {ventaSeleccionada && (
            <div className="space-y-4">
              <div className="p-4 bg-gray-50 rounded-lg">
                <h3 className="font-semibold mb-2">Información de la venta</h3>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p><strong>Ticket:</strong> {ventaSeleccionada.id}</p>
                    <p><strong>Cliente:</strong> {ventaSeleccionada.cliente}</p>
                  </div>
                  <div>
                    <p><strong>Fecha:</strong> {ventaSeleccionada.fecha}</p>
                    <p><strong>Total:</strong> €{ventaSeleccionada.total.toFixed(2)}</p>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="font-semibold mb-2">Productos a devolver</h3>
                <div className="space-y-2">
                  {ventaSeleccionada.productos.map((producto: any, index: number) => {
                    const yaDevuelto = ventaSeleccionada.productosDevueltos?.find((pd: any) => pd.nombre === producto.nombre)?.cantidad || 0;
                    const disponibleDevolucion = producto.cantidad - yaDevuelto;

                    return disponibleDevolucion > 0 ? (
                      <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex-1">
                          <p className="font-medium">{producto.nombre}</p>
                          <p className="text-sm text-gray-600">
                            Precio: €{producto.precio.toFixed(2)} | Vendidos: {producto.cantidad}
                            {yaDevuelto > 0 && ` | Ya devueltos: ${yaDevuelto}`}
                          </p>
                        </div>

                        <div className="flex items-center gap-2">
                          <Label className="text-xs">Devolver:</Label>
                          <Input
                            type="number"
                            min="0"
                            max={disponibleDevolucion}
                            defaultValue="0"
                            className="w-16 h-8 text-center"
                            id={`devolucion-${index}`}
                          />
                          <span className="text-xs text-gray-500">/{disponibleDevolucion}</span>
                        </div>
                      </div>
                    ) : null;
                  })}
                </div>
              </div>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => setShowDevolucion(false)}
                  className="flex-1"
                >
                  Cancelar
                </Button>
                <Button
                  onClick={() => {
                    // Procesar devolución
                    const productosDevolucion: any[] = [];

                    ventaSeleccionada.productos.forEach((producto: any, index: number) => {
                      const input = document.getElementById(`devolucion-${index}`) as HTMLInputElement;
                      const cantidadDevolver = parseInt(input?.value || '0');

                      if (cantidadDevolver > 0) {
                        productosDevolucion.push({
                          nombre: producto.nombre,
                          precio: producto.precio,
                          cantidad: cantidadDevolver
                        });
                      }
                    });

                    if (productosDevolucion.length > 0) {
                      procesarDevolucion(ventaSeleccionada, productosDevolucion);
                      setShowDevolucion(false);
                      setVentaSeleccionada(null);
                    } else {
                      toast({
                        title: "Sin productos",
                        description: "Selecciona al menos un producto para devolver",
                        variant: "destructive"
                      });
                    }
                  }}
                  className="flex-1"
                >
                  <Check className="w-4 h-4 mr-2" />
                  Procesar Devolución
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Modal de restock */}
      <Dialog open={showRestockDialog} onOpenChange={setShowRestockDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Package className="w-5 h-5" />
              Añadir Stock - {productoRestock?.nombre}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <AlertCircle className="w-5 h-5 text-orange-600" />
                <span className="font-medium text-orange-800">Stock agotado</span>
              </div>
              <p className="text-sm text-orange-700">
                Este producto no tiene stock disponible. Puedes añadir más unidades aquí.
              </p>
            </div>

            <div>
              <Label htmlFor="nuevoStock">Cantidad a añadir *</Label>
              <Input
                id="nuevoStock"
                type="number"
                min="1"
                value={nuevoStock}
                onChange={(e) => setNuevoStock(e.target.value)}
                placeholder="Ej: 10"
                className="text-lg"
              />
            </div>

            <div>
              <Label htmlFor="nuevoPrecio">Precio de venta (IVA incluido) *</Label>
              <Input
                id="nuevoPrecio"
                type="number"
                step="0.01"
                min="0.01"
                value={nuevoPrecio}
                onChange={(e) => setNuevoPrecio(e.target.value)}
                placeholder="Ej: 12.10"
                className="text-lg"
              />
              <p className="text-xs text-gray-500 mt-1">
                El precio se guarda sin IVA. Precio sin IVA: €{nuevoPrecio ? (parseFloat(nuevoPrecio) / 1.21).toFixed(2) : '0.00'}
              </p>
            </div>

            <div>
              <Label htmlFor="nuevoPrecioCoste">Precio de coste *</Label>
              <Input
                id="nuevoPrecioCoste"
                type="number"
                step="0.01"
                min="0.01"
                value={nuevoPrecioCoste}
                onChange={(e) => setNuevoPrecioCoste(e.target.value)}
                placeholder="Ej: 8.50"
                className="text-lg"
              />
              <p className="text-xs text-gray-500 mt-1">
                Precio al que compraste el producto
              </p>
            </div>

            <div className="bg-blue-50 p-3 rounded-lg">
              <h4 className="font-semibold text-blue-800 mb-1">Resumen:</h4>
              <ul className="text-sm text-blue-700 space-y-1">
                <li>• Se añadirán {nuevoStock || '0'} unidades</li>
                <li>• Precio venta: €{nuevoPrecio || '0.00'} (con IVA)</li>
                <li>• Precio coste: €{nuevoPrecioCoste || '0.00'}</li>
                <li>• Margen: {(nuevoPrecio && nuevoPrecioCoste) ? (((parseFloat(nuevoPrecio) / 1.21 - parseFloat(nuevoPrecioCoste)) / (parseFloat(nuevoPrecio) / 1.21)) * 100).toFixed(1) : '0.0'}%</li>
                <li>• El producto se agregará automáticamente al carrito</li>
              </ul>
            </div>

            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => {
                  setShowRestockDialog(false);
                  setProductoRestock(null);
                  setNuevoStock("");
                  setNuevoPrecio("");
                  setNuevoPrecioCoste("");
                }}
                className="flex-1"
              >
                Cancelar
              </Button>
              <Button
                onClick={procesarRestock}
                className="flex-1 bg-green-600 hover:bg-green-700"
                disabled={!nuevoStock || !nuevoPrecio || !nuevoPrecioCoste}
              >
                <Plus className="w-4 h-4 mr-2" />
                Añadir Stock
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
