-- Agregar campos CIF y NIF para clientes en facturas
ALTER TABLE public.facturas 
ADD COLUMN cliente_cif text,
ADD COLUMN cliente_nif text;

-- Eliminar el campo fecha_vencimiento ya que no se requiere
ALTER TABLE public.facturas 
DROP COLUMN fecha_vencimiento;