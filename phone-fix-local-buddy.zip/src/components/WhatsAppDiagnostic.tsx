import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  CheckCircle,
  XCircle,
  AlertTriangle,
  RefreshCw,
  Settings,
  Wrench,
  Download,
  Monitor
} from 'lucide-react';
import { SimpleWhatsAppIcon, SimpleWhatsAppStatusIcon, SimpleWhatsAppBadge, WhatsAppMethodsDisplay } from '@/components/ui/simple-whatsapp-icons';
import { getAvailableWhatsAppMethods } from '@/lib/whatsappDesktopManager';
import { isWhatsAppEnabled, sendTestMessage } from '@/lib/whatsappUtils';
import { ensureWhatsAppIsEnabled, getWhatsAppConfigWithAutoSetup } from '@/lib/whatsappAutoConfig';
import { checkWhatsAppAvailability, WhatsAppSessionStatus } from '@/lib/whatsappSessionManager';
import WhatsAppConnectionHelper from './WhatsAppConnectionHelper';
import WhatsAppInstallationHelper from './WhatsAppInstallationHelper';
import { useToast } from '@/hooks/use-toast';

const WhatsAppDiagnostic: React.FC = () => {
  const [isEnabled, setIsEnabled] = useState(false);
  const [config, setConfig] = useState<any>(null);
  const [testing, setTesting] = useState(false);
  const [sessionStatus, setSessionStatus] = useState<WhatsAppSessionStatus | null>(null);
  const [checkingSession, setCheckingSession] = useState(false);
  const [showConnectionHelper, setShowConnectionHelper] = useState(false);
  const [showInstallationHelper, setShowInstallationHelper] = useState(false);
  const [availableMethods, setAvailableMethods] = useState<any[]>([]);
  const { toast } = useToast();

  const checkStatus = async () => {
    const enabled = isWhatsAppEnabled();
    const whatsappConfig = getWhatsAppConfigWithAutoSetup();

    setIsEnabled(enabled);
    setConfig(whatsappConfig);

    // Verificar estado de sesión de WhatsApp Web
    if (enabled) {
      setCheckingSession(true);
      try {
        const status = await checkWhatsAppAvailability();
        setSessionStatus(status);

        // Obtener métodos disponibles
        const methods = await getAvailableWhatsAppMethods();
        setAvailableMethods(methods);
      } catch (error) {
        console.error('Error verificando sesión de WhatsApp:', error);
        setSessionStatus({
          isAvailable: false,
          isLoggedIn: false,
          lastCheck: Date.now(),
          error: 'Error verificando la sesión'
        });
      } finally {
        setCheckingSession(false);
      }
    }
  };

  useEffect(() => {
    checkStatus();
  }, []);

  const autoFix = () => {
    ensureWhatsAppIsEnabled();
    checkStatus();
    toast({
      title: "✅ WhatsApp Activado",
      description: "WhatsApp ha sido activado automáticamente con plantillas predeterminadas",
    });
  };

  const testWhatsApp = async () => {
    setTesting(true);

    try {
      const success = await sendTestMessage();

      if (success) {
        toast({
          title: "✅ Test enviado",
          description: "Se ha abierto WhatsApp con un mensaje de prueba",
        });
      } else {
        toast({
          title: "❌ Error en test",
          description: "No se pudo enviar el mensaje de prueba",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "❌ Error en test",
        description: "Error inesperado al enviar el mensaje de prueba",
        variant: "destructive",
      });
    } finally {
      setTimeout(() => setTesting(false), 2000);
    }
  };

  const getStatusBadge = (enabled: boolean) => {
    if (enabled) {
      return <Badge className="bg-green-100 text-green-800">✅ Activo</Badge>;
    }
    return <Badge className="bg-red-100 text-red-800">❌ Inactivo</Badge>;
  };

  const getSessionBadge = (status: WhatsAppSessionStatus | null) => {
    if (!status) {
      return <Badge className="bg-gray-100 text-gray-800">🔄 Verificando...</Badge>;
    }

    if (status.isAvailable && status.isLoggedIn) {
      return <Badge className="bg-green-100 text-green-800">✅ Conectado</Badge>;
    }

    if (status.error) {
      return <Badge className="bg-red-100 text-red-800">❌ Desconectado</Badge>;
    }

    return <Badge className="bg-yellow-100 text-yellow-800">⚠️ Incierto</Badge>;
  };

  const getTemplateStatus = (template: any) => {
    if (template?.enabled) {
      return <CheckCircle className="h-4 w-4 text-green-500" />;
    }
    return <XCircle className="h-4 w-4 text-red-500" />;
  };

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center gap-2">
            <SimpleWhatsAppIcon className="h-6 w-6" />
            Diagnóstico WhatsApp
          </span>
          <Button 
            onClick={checkStatus} 
            size="sm"
            variant="outline"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Verificar
          </Button>
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Estado General */}
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div className="flex items-center gap-3">
              <SimpleWhatsAppIcon className="h-8 w-8" />
              <div>
                <h4 className="font-medium">Estado General de WhatsApp</h4>
                <p className="text-sm text-gray-600">Sistema de mensajería automática</p>
              </div>
            </div>
            {getStatusBadge(isEnabled)}
          </div>

          {/* Estado de Sesión */}
          {isEnabled && (
            <div className="flex items-center justify-between p-4 border rounded-lg bg-blue-50">
              <div className="flex items-center gap-3">
                <div className={`h-8 w-8 rounded-full flex items-center justify-center ${
                  checkingSession ? 'bg-yellow-100' :
                  sessionStatus?.isAvailable ? 'bg-green-100' : 'bg-red-100'
                }`}>
                  {checkingSession ? (
                    <RefreshCw className="h-4 w-4 text-yellow-600 animate-spin" />
                  ) : sessionStatus?.isAvailable ? (
                    <CheckCircle className="h-4 w-4 text-green-600" />
                  ) : (
                    <XCircle className="h-4 w-4 text-red-600" />
                  )}
                </div>
                <div>
                  <h4 className="font-medium">Estado de WhatsApp Web</h4>
                  <p className="text-sm text-gray-600">
                    {checkingSession ? 'Verificando sesión...' :
                     sessionStatus?.isAvailable ? 'Sesión activa y disponible' :
                     sessionStatus?.error || 'Sesión no disponible'}
                  </p>
                </div>
              </div>
              {getSessionBadge(sessionStatus)}
            </div>
          )}
        </div>

        {/* Plantillas */}
        {config && (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">📋 Plantillas de Mensajes</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span className="text-sm">Nueva orden recibida</span>
                {getTemplateStatus(config.templates?.orderReceived)}
              </div>
              
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span className="text-sm">Orden en proceso</span>
                {getTemplateStatus(config.templates?.orderInProgress)}
              </div>
              
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span className="text-sm">Orden completada</span>
                {getTemplateStatus(config.templates?.orderCompleted)}
              </div>
              
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span className="text-sm">Orden entregada</span>
                {getTemplateStatus(config.templates?.orderDelivered)}
              </div>
              
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span className="text-sm">Factura creada</span>
                {getTemplateStatus(config.templates?.invoiceCreated)}
              </div>
              
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span className="text-sm">Recordatorio</span>
                {getTemplateStatus(config.templates?.reminder)}
              </div>
            </div>
          </div>
        )}

        {/* Métodos de Envío Disponibles */}
        {isEnabled && availableMethods.length > 0 && (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">🚀 Métodos de Envío</h3>
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="mb-3">
                <h4 className="font-medium text-blue-900">Prioridad de envío:</h4>
                <p className="text-sm text-blue-700">
                  El sistema intentará automáticamente en este orden hasta encontrar uno que funcione
                </p>
              </div>
              <WhatsAppMethodsDisplay methods={availableMethods} />
            </div>
          </div>
        )}

        {/* Acciones */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">🛠️ Acciones</h3>

          {!isEnabled && (
            <Alert className="border-yellow-200 bg-yellow-50">
              <AlertTriangle className="h-4 w-4 text-yellow-600" />
              <AlertDescription className="text-yellow-800">
                <strong>WhatsApp no está activado.</strong> Los mensajes automáticos no se enviarán.
              </AlertDescription>
            </Alert>
          )}

          {isEnabled && sessionStatus && !sessionStatus.isAvailable && (
            <Alert className="border-orange-200 bg-orange-50">
              <AlertTriangle className="h-4 w-4 text-orange-600" />
              <AlertDescription className="text-orange-800">
                <strong>⚠️ WhatsApp Web no está conectado.</strong><br/>
                <div className="mt-2 space-y-1">
                  <div className="flex items-center gap-2">
                    <Monitor className="h-3 w-3" />
                    <span className="text-sm">Instala WhatsApp Desktop para mejor rendimiento</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm">🌐</span>
                    <span className="text-sm">O conecta WhatsApp Web manualmente</span>
                  </div>
                  <div className="text-sm text-orange-700 mt-2">
                    ⚡ Los mensajes automáticos usarán WhatsApp móvil como respaldo
                  </div>
                </div>
              </AlertDescription>
            </Alert>
          )}

          <div className="flex flex-wrap gap-3">
            {!isEnabled && (
              <Button 
                onClick={autoFix}
                className="bg-green-600 hover:bg-green-700"
              >
                <Wrench className="h-4 w-4 mr-2" />
                Activar WhatsApp Automáticamente
              </Button>
            )}
            
            <Button
              onClick={testWhatsApp}
              disabled={testing}
              variant="outline"
            >
              <SimpleWhatsAppIcon className="h-4 w-4 mr-2" />
              {testing ? 'Enviando...' : 'Enviar Mensaje de Prueba'}
            </Button>

            {isEnabled && sessionStatus && !sessionStatus.isAvailable && (
              <>
                <Button
                  onClick={() => setShowConnectionHelper(true)}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <SimpleWhatsAppIcon className="h-4 w-4 mr-2" />
                  Conectar WhatsApp Web
                </Button>

                <Button
                  onClick={() => setShowInstallationHelper(true)}
                  className="bg-green-600 hover:bg-green-700"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Instalar WhatsApp Desktop
                </Button>
              </>
            )}
            
            <Button 
              onClick={() => window.location.hash = '#whatsapp'}
              variant="outline"
            >
              <Settings className="h-4 w-4 mr-2" />
              Configuración Avanzada
            </Button>
          </div>
        </div>

        {/* Estado Actual */}
        <div className="bg-blue-50 p-4 rounded-lg">
          <h4 className="font-medium mb-2">📊 Estado Actual</h4>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-gray-600">Sistema:</span>
              <span className="ml-2 font-medium">{isEnabled ? 'Activo' : 'Inactivo'}</span>
            </div>
            <div>
              <span className="text-gray-600">Plantillas:</span>
              <span className="ml-2 font-medium">
                {config?.templates ? Object.keys(config.templates).length : 0} disponibles
              </span>
            </div>
            {sessionStatus && (
              <div>
                <span className="text-gray-600">WhatsApp Web:</span>
                <span className="ml-2 font-medium">
                  {sessionStatus.isAvailable ? 'Conectado' : 'Desconectado'}
                </span>
              </div>
            )}
            {sessionStatus?.lastCheck && (
              <div>
                <span className="text-gray-600">Última verificación:</span>
                <span className="ml-2 font-medium">
                  {new Date(sessionStatus.lastCheck).toLocaleTimeString('es-ES')}
                </span>
              </div>
            )}
          </div>
        </div>

        {isEnabled && (
          <Alert className={`border-green-200 bg-green-50 ${
            sessionStatus && !sessionStatus.isAvailable ? 'border-orange-200 bg-orange-50' : ''
          }`}>
            <CheckCircle className={`h-4 w-4 ${
              sessionStatus && !sessionStatus.isAvailable ? 'text-orange-600' : 'text-green-600'
            }`} />
            <AlertDescription className={sessionStatus && !sessionStatus.isAvailable ? 'text-orange-800' : 'text-green-800'}>
              {sessionStatus && !sessionStatus.isAvailable ? (
                <>
                  <strong>⚠️ WhatsApp está activado pero Web no conectado.</strong><br/>
                  <div className="mt-2 flex items-center gap-2">
                    <WhatsAppBadge status="inactive">Respaldo móvil activo</WhatsAppBadge>
                    <span className="text-sm">Los mensajes se abrirán en WhatsApp móvil automáticamente.</span>
                  </div>
                </>
              ) : (
                <>
                  <strong>✅ WhatsApp está funcionando correctamente.</strong><br/>
                  <div className="mt-2 flex items-center gap-2">
                    <WhatsAppBadge status="active">Sistema activo</WhatsAppBadge>
                    <span className="text-sm">Los mensajes se enviarán automáticamente cuando cambies el estado de las órdenes.</span>
                  </div>
                </>
              )}
            </AlertDescription>
          </Alert>
        )}

        {/* Helper de conexión */}
        {showConnectionHelper && (
          <div className="mt-6">
            <WhatsAppConnectionHelper
              onConnected={() => {
                setShowConnectionHelper(false);
                checkStatus();
                toast({
                  title: "✅ WhatsApp conectado",
                  description: "WhatsApp Web se ha conectado correctamente",
                });
              }}
            />
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowConnectionHelper(false)}
              className="mt-4 w-full"
            >
              Cancelar
            </Button>
          </div>
        )}

        {/* Helper de instalación */}
        {showInstallationHelper && (
          <div className="mt-6">
            <WhatsAppInstallationHelper
              onInstallationComplete={() => {
                setShowInstallationHelper(false);
                checkStatus();
                toast({
                  title: "🚀 WhatsApp Desktop instalado",
                  description: "Reinicia la aplicación para aprovechar las mejoras",
                });
              }}
            />
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowInstallationHelper(false)}
              className="mt-4 w-full"
            >
              Cancelar
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default WhatsAppDiagnostic;
