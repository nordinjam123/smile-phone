-- Security Fix: Update RLS policies to prevent anonymous access and fix overly permissive policies

-- Fix profiles table policies - require authentication
DROP POLICY IF EXISTS "Users can view their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can insert their own profile" ON public.profiles;

-- Create new secure policies for profiles (authenticated users only)
CREATE POLICY "Authenticated users can view their own profile" 
ON public.profiles 
FOR SELECT 
TO authenticated
USING (auth.uid() = id);

CREATE POLICY "Authenticated users can update their own profile" 
ON public.profiles 
FOR UPDATE 
TO authenticated
USING (auth.uid() = id);

CREATE POLICY "Authenticated users can insert their own profile" 
ON public.profiles 
FOR INSERT 
TO authenticated
WITH CHECK (auth.uid() = id);

-- Fix subscribers table policies - require authentication and proper ownership
DROP POLICY IF EXISTS "select_own_subscription" ON public.subscribers;
DROP POLICY IF EXISTS "update_own_subscription" ON public.subscribers;
DROP POLICY IF EXISTS "insert_subscription" ON public.subscribers;

-- Create new secure policies for subscribers
CREATE POLICY "Authenticated users can view their own subscription" 
ON public.subscribers 
FOR SELECT 
TO authenticated
USING (user_id = auth.uid() OR email = auth.email());

-- Only service role can update subscriptions (for Stripe webhooks)
CREATE POLICY "Service role can update subscriptions" 
ON public.subscribers 
FOR UPDATE 
TO service_role
USING (true);

-- Authenticated users can only insert their own subscription
CREATE POLICY "Authenticated users can insert their own subscription" 
ON public.subscribers 
FOR INSERT 
TO authenticated
WITH CHECK (user_id = auth.uid() OR email = auth.email());

-- Edge functions can insert/update subscription data (for Stripe integration)
CREATE POLICY "Edge functions can manage subscriptions" 
ON public.subscribers 
FOR ALL 
TO authenticated
USING (auth.jwt() ->> 'role' = 'service_role')
WITH CHECK (auth.jwt() ->> 'role' = 'service_role');