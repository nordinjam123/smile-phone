import React from 'react';

interface BasicIconProps {
  className?: string;
  size?: number;
}

// Icono básico de WhatsApp - solo CSS, sin emojis
export const BasicWhatsAppIcon: React.FC<BasicIconProps> = ({ 
  className = "w-6 h-6", 
  size 
}) => (
  <div 
    className={`${className} flex items-center justify-center bg-green-500 text-white rounded-full font-bold text-xs border-2 border-green-600`}
    style={size ? { width: size, height: size, fontSize: Math.max(size * 0.4, 8) } : {}}
    title="WhatsApp"
  >
    WA
  </div>
);

// Badge de estado simple
export const BasicWhatsAppBadge: React.FC<{
  status: 'active' | 'inactive' | 'error' | 'connecting';
  children: React.ReactNode;
  className?: string;
}> = ({ status, children, className = "" }) => {
  const getStatusStyles = () => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800 border-green-300';
      case 'inactive':
        return 'bg-gray-100 text-gray-600 border-gray-300';
      case 'error':
        return 'bg-red-100 text-red-800 border-red-300';
      case 'connecting':
        return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      default:
        return 'bg-gray-100 text-gray-600 border-gray-300';
    }
  };

  const getStatusText = () => {
    switch (status) {
      case 'active': return '[ON]';
      case 'inactive': return '[OFF]';
      case 'error': return '[ERR]';
      case 'connecting': return '[...]';
      default: return '[?]';
    }
  };

  return (
    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded border text-xs font-mono ${getStatusStyles()} ${className}`}>
      <span className="font-bold">{getStatusText()}</span>
      {children}
    </span>
  );
};

// Indicador de estado simple
export const BasicStatusIndicator: React.FC<{
  status: 'connected' | 'disconnected' | 'connecting';
  className?: string;
}> = ({ status, className = "" }) => {
  const getStyles = () => {
    switch (status) {
      case 'connected':
        return 'bg-green-500 text-white';
      case 'disconnected':
        return 'bg-red-500 text-white';
      case 'connecting':
        return 'bg-yellow-500 text-black';
      default:
        return 'bg-gray-500 text-white';
    }
  };

  const getText = () => {
    switch (status) {
      case 'connected': return 'OK';
      case 'disconnected': return 'NO';
      case 'connecting': return '...';
      default: return '?';
    }
  };

  return (
    <div className={`inline-flex items-center justify-center w-8 h-8 rounded-full text-xs font-bold ${getStyles()} ${className}`}>
      {getText()}
    </div>
  );
};

// Método de envío simple
export const BasicMethodIndicator: React.FC<{
  method: 'desktop' | 'web' | 'mobile' | 'clipboard';
  available: boolean;
  className?: string;
}> = ({ method, available, className = "" }) => {
  const getMethodInfo = () => {
    switch (method) {
      case 'desktop':
        return { label: 'Desktop', icon: 'D', color: available ? 'bg-blue-500' : 'bg-gray-400' };
      case 'web':
        return { label: 'Web', icon: 'W', color: available ? 'bg-green-500' : 'bg-gray-400' };
      case 'mobile':
        return { label: 'Mobile', icon: 'M', color: available ? 'bg-purple-500' : 'bg-gray-400' };
      case 'clipboard':
        return { label: 'Copy', icon: 'C', color: available ? 'bg-orange-500' : 'bg-gray-400' };
      default:
        return { label: 'Unknown', icon: '?', color: 'bg-gray-400' };
    }
  };

  const info = getMethodInfo();

  return (
    <div className={`inline-flex items-center gap-2 ${className}`}>
      <div className={`w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-bold ${info.color}`}>
        {info.icon}
      </div>
      <span className={`text-sm ${available ? 'text-gray-900' : 'text-gray-400'}`}>
        {info.label}
      </span>
      <span className="text-xs text-gray-500">
        {available ? '[OK]' : '[NO]'}
      </span>
    </div>
  );
};

// Display de métodos disponibles
export const BasicMethodsDisplay: React.FC<{
  methods: Array<{
    type: 'desktop' | 'web' | 'mobile' | 'clipboard';
    available: boolean;
    name: string;
    priority: number;
  }>;
  className?: string;
}> = ({ methods, className = "" }) => {
  return (
    <div className={`space-y-2 ${className}`}>
      <h4 className="text-sm font-bold text-gray-700">Metodos Disponibles:</h4>
      <div className="space-y-1">
        {methods
          .sort((a, b) => a.priority - b.priority)
          .map((method, index) => (
            <div 
              key={method.type} 
              className={`flex items-center justify-between p-2 rounded border ${
                method.available ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200'
              }`}
            >
              <BasicMethodIndicator 
                method={method.type} 
                available={method.available} 
              />
              <div className="flex items-center gap-1">
                <span className="text-xs font-mono text-gray-500">#{method.priority}</span>
                <span className={`text-xs font-bold ${method.available ? 'text-green-600' : 'text-red-600'}`}>
                  {method.available ? 'SI' : 'NO'}
                </span>
              </div>
            </div>
          ))}
      </div>
    </div>
  );
};

// Botón de WhatsApp simple
export const BasicWhatsAppButton: React.FC<{
  onClick: () => void;
  disabled?: boolean;
  children: React.ReactNode;
  className?: string;
}> = ({ onClick, disabled = false, children, className = "" }) => (
  <button
    onClick={onClick}
    disabled={disabled}
    className={`inline-flex items-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white rounded-lg font-medium text-sm transition-colors ${className}`}
  >
    <BasicWhatsAppIcon className="w-4 h-4" />
    {children}
  </button>
);
