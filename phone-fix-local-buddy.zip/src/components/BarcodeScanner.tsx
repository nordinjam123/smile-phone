import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Camera, X, RotateCcw } from "lucide-react";

// Importar Quagga dinámicamente para evitar problemas de SSR
const loadQuagga = async () => {
  try {
    const Quagga = await import('quagga');
    return Quagga.default;
  } catch (error) {
    console.error('Error loading Quagga:', error);
    return null;
  }
};

interface BarcodeScannerProps {
  isOpen: boolean;
  onClose: () => void;
  onScan: (code: string) => void;
  title?: string;
}

export default function BarcodeScanner({ isOpen, onClose, onScan, title = "Escanear Código de Barras" }: BarcodeScannerProps) {
  const scannerRef = useRef<HTMLDivElement>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [error, setError] = useState<string>("");
  const { toast } = useToast();

  useEffect(() => {
    let Quagga: any = null;

    const initScanner = async () => {
      if (!isOpen || !scannerRef.current) return;

      try {
        Quagga = await loadQuagga();
        if (!Quagga) {
          setError("No se pudo cargar el escáner");
          return;
        }

        setIsScanning(true);
        setError("");

        Quagga.init({
          inputStream: {
            name: "Live",
            type: "LiveStream",
            target: scannerRef.current,
            constraints: {
              width: 640,
              height: 480,
              facingMode: "environment"
            }
          },
          locator: {
            patchSize: "medium",
            halfSample: true
          },
          numOfWorkers: 2,
          decoder: {
            readers: [
              "code_128_reader",
              "ean_reader",
              "ean_8_reader",
              "code_39_reader",
              "code_39_vin_reader",
              "codabar_reader",
              "upc_reader",
              "upc_e_reader",
              "i2of5_reader"
            ]
          },
          locate: true
        }, (err: any) => {
          if (err) {
            console.error('QuaggaJS init error:', err);
            setError("Error al inicializar el escáner: " + err.message);
            setIsScanning(false);
            return;
          }
          
          Quagga.start();
        });

        Quagga.onDetected((data: any) => {
          const code = data.codeResult.code;
          console.log("Barcode detected:", code);
          
          toast({
            title: "Código detectado",
            description: `Código: ${code}`,
            variant: "default"
          });
          
          onScan(code);
          stopScanner();
        });

      } catch (error: any) {
        console.error('Scanner initialization error:', error);
        setError("Error al acceder a la cámara: " + error.message);
        setIsScanning(false);
      }
    };

    const stopScanner = () => {
      if (Quagga) {
        Quagga.stop();
        Quagga.offDetected();
      }
      setIsScanning(false);
      onClose();
    };

    if (isOpen) {
      initScanner();
    }

    return () => {
      stopScanner();
    };
  }, [isOpen, onClose, onScan, toast]);

  const handleManualClose = () => {
    setIsScanning(false);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleManualClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Camera className="w-5 h-5" />
            {title}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {error ? (
            <div className="text-center p-8">
              <div className="text-red-600 mb-4">
                <Camera className="w-16 h-16 mx-auto mb-2 opacity-50" />
                <p className="font-medium">Error del escáner</p>
                <p className="text-sm">{error}</p>
              </div>
              <Button onClick={() => setError("")} variant="outline">
                <RotateCcw className="w-4 h-4 mr-2" />
                Reintentar
              </Button>
            </div>
          ) : (
            <div className="relative">
              <div 
                ref={scannerRef} 
                className="w-full h-80 bg-black rounded-lg overflow-hidden relative"
              >
                {!isScanning && (
                  <div className="absolute inset-0 flex items-center justify-center text-white">
                    <div className="text-center">
                      <Camera className="w-16 h-16 mx-auto mb-2 opacity-50" />
                      <p>Iniciando escáner...</p>
                    </div>
                  </div>
                )}
              </div>
              
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 pointer-events-none">
                <div className="w-64 h-32 border-2 border-red-500 border-dashed rounded-lg"></div>
              </div>
            </div>
          )}

          <div className="text-center space-y-2">
            <p className="text-sm text-gray-600">
              Coloca el código de barras dentro del marco rojo
            </p>
            <p className="text-xs text-gray-500">
              Soporta: EAN, UPC, Code 128, Code 39, Codabar y más
            </p>
          </div>

          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={handleManualClose}>
              <X className="w-4 h-4 mr-2" />
              Cancelar
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
