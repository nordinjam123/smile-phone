import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line
} from "recharts";
import { 
  Download,
  TrendingUp,
  DollarSign,
  Users,
  Wrench,
  Calendar,
  Package,
  AlertTriangle
} from "lucide-react";
import { format, subDays, parseISO } from "date-fns";
import { es } from "date-fns/locale";
import { useToast } from "@/hooks/use-toast";

const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];

export default function ReportesPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [ordenes, setOrdenes] = useState<any[]>([]);
  const [clientes, setClientes] = useState<any[]>([]);
  const [inventario, setInventario] = useState<any[]>([]);
  const [citas, setCitas] = useState<any[]>([]);
  const [facturas, setFacturas] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Cargar datos de Supabase y localStorage
  useEffect(() => {
    const cargarDatos = async () => {
      if (!user) return;

      try {
        // Cargar datos de Supabase
        const [clientesResult, inventarioResult, citasResult, facturasResult] = await Promise.all([
          supabase.from('clientes').select('*').eq('user_id', user.id),
          supabase.from('inventario').select('*').eq('user_id', user.id),
          supabase.from('citas').select('*').eq('user_id', user.id),
          supabase.from('facturas').select('*').eq('user_id', user.id)
        ]);

        if (clientesResult.error) throw clientesResult.error;
        if (inventarioResult.error) throw inventarioResult.error;
        if (citasResult.error) throw citasResult.error;
        if (facturasResult.error) throw facturasResult.error;

        setClientes(clientesResult.data || []);
        setInventario(inventarioResult.data || []);
        setCitas(citasResult.data || []);
        setFacturas(facturasResult.data || []);

        // Cargar órdenes de trabajo desde localStorage
        const ordenesLocalStorage = localStorage.getItem('ordenes');
        const ordenesData = ordenesLocalStorage ? JSON.parse(ordenesLocalStorage) : [];
        setOrdenes(ordenesData);

      } catch (error: any) {
        console.error('Error cargando datos:', error);
        toast({
          title: "Error",
          description: "Error cargando datos de reportes",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    cargarDatos();
  }, [user, toast]);

  if (loading) {
    return (
      <div className="p-6 flex justify-center items-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Cargando reportes...</p>
        </div>
      </div>
    );
  }

  // Datos para gráficos
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const date = subDays(new Date(), 6 - i);
    const dateStr = format(date, "yyyy-MM-dd");
    const ordenesDelDia = ordenes.filter((orden: any) => orden.fechaIngreso === dateStr);
    const citasDelDia = citas.filter((cita: any) => cita.fecha === dateStr);

    return {
      fecha: format(date, "dd/MM"),
      ordenes: ordenesDelDia.length,
      citas: citasDelDia.length,
      ingresos: ordenesDelDia
        .filter((orden: any) => orden.estado === "completado")
        .reduce((total: number, orden: any) => total + (orden.precio || 0), 0)
    };
  });

  const estadosOrdenes = [
    { name: "Pendiente", value: ordenes.filter((o: any) => o.estado === "pendiente").length },
    { name: "En Proceso", value: ordenes.filter((o: any) => o.estado === "en_proceso").length },
    { name: "Completado", value: ordenes.filter((o: any) => o.estado === "completado").length },
    { name: "Entregado", value: ordenes.filter((o: any) => o.estado === "entregado").length }
  ].filter(item => item.value > 0);

  const serviciosMasSolicitados = ordenes.reduce((acc: any, orden: any) => {
    const problema = orden.problema.toLowerCase();
    if (problema.includes("pantalla")) acc["Reparación de Pantalla"] = (acc["Reparación de Pantalla"] || 0) + 1;
    else if (problema.includes("batería") || problema.includes("bateria")) acc["Cambio de Batería"] = (acc["Cambio de Batería"] || 0) + 1;
    else if (problema.includes("carga")) acc["Puerto de Carga"] = (acc["Puerto de Carga"] || 0) + 1;
    else if (problema.includes("altavoz") || problema.includes("audio")) acc["Reparación de Audio"] = (acc["Reparación de Audio"] || 0) + 1;
    else acc["Otros"] = (acc["Otros"] || 0) + 1;
    return acc;
  }, {});

  const serviciosData = Object.entries(serviciosMasSolicitados).map(([name, value]) => ({ name, value }));

  // Métricas principales
  const ingresosOrdenes = ordenes
    .filter((orden: any) => orden.estado === "completado")
    .reduce((total: number, orden: any) => total + (orden.precio || 0), 0);

  const ingresosFacturas = facturas
    .filter((factura: any) => factura.estado === "pagada")
    .reduce((total: number, factura: any) => total + (factura.total || 0), 0);

  const totalIngresos = ingresosOrdenes + ingresosFacturas;

  const ingresosMesActualOrdenes = ordenes
    .filter((orden: any) => {
      if (orden.estado !== "completado" || !orden.fechaCompletado) return false;
      const fechaOrden = new Date(orden.fechaCompletado);
      const ahora = new Date();
      return fechaOrden.getMonth() === ahora.getMonth() && fechaOrden.getFullYear() === ahora.getFullYear();
    })
    .reduce((total: number, orden: any) => total + (orden.precio || 0), 0);

  const ingresosMesActualFacturas = facturas
    .filter((factura: any) => {
      if (factura.estado !== "pagada") return false;
      const fechaFactura = new Date(factura.fecha);
      const ahora = new Date();
      return fechaFactura.getMonth() === ahora.getMonth() && fechaFactura.getFullYear() === ahora.getFullYear();
    })
    .reduce((total: number, factura: any) => total + (factura.total || 0), 0);

  const ingresosMesActual = ingresosMesActualOrdenes + ingresosMesActualFacturas;

  const clientesOrdenes = ordenes.map((orden: any) => orden.clienteNombre);
  const clientesFacturas = facturas.map((factura: any) => factura.cliente_nombre);
  const clientesActivos = new Set([...clientesOrdenes, ...clientesFacturas]).size;
  const totalOperaciones = ordenes.length + facturas.length;
  const promedioReparaciones = totalOperaciones > 0 ? (totalIngresos / totalOperaciones) : 0;
  const productosStockBajo = inventario.filter((item: any) => item.stock <= item.stock_minimo).length;
  const citasPendientes = citas.filter((cita: any) => 
    cita.estado === "programada" || cita.estado === "confirmada"
  ).length;

  const exportarDatos = () => {
    const datos = {
      ordenes,
      facturas,
      clientes,
      inventario,
      citas,
      resumen: {
        totalIngresos,
        ingresosMesActual,
        clientesActivos,
        ordenesTotal: ordenes.length,
        facturasTotal: facturas.length,
        citasPendientes,
        productosStockBajo,
        fechaExportacion: new Date().toISOString()
      }
    };

    const dataStr = JSON.stringify(datos, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `techrepair-datos-${format(new Date(), "yyyy-MM-dd")}.json`;
    link.click();
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">Reportes y Analíticas</h1>
          <p className="text-slate-600">Análisis completo del rendimiento de tu negocio</p>
        </div>
        <Button onClick={exportarDatos} variant="outline">
          <Download className="w-4 h-4 mr-2" />
          Exportar Datos
        </Button>
      </div>

      {/* Métricas principales */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="border-l-4 border-l-green-500">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Ingresos Totales</p>
                <p className="text-2xl font-bold text-green-600">€{totalIngresos.toLocaleString()}</p>
              </div>
              <DollarSign className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Este Mes</p>
                <p className="text-2xl font-bold text-blue-600">€{ingresosMesActual.toLocaleString()}</p>
              </div>
              <TrendingUp className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-purple-500">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Clientes Activos</p>
                <p className="text-2xl font-bold text-purple-600">{clientesActivos}</p>
              </div>
              <Users className="w-8 h-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-yellow-500">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Promedio/Reparación</p>
                <p className="text-2xl font-bold text-yellow-600">€{promedioReparaciones.toFixed(0)}</p>
              </div>
              <Wrench className="w-8 h-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Alertas */}
      {(productosStockBajo > 0 || citasPendientes > 5) && (
        <Card className="border-orange-200 bg-orange-50">
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className="w-5 h-5 text-orange-600" />
              <h3 className="font-semibold text-orange-800">Alertas del Sistema</h3>
            </div>
            <div className="space-y-1 text-sm text-orange-700">
              {productosStockBajo > 0 && (
                <p>• {productosStockBajo} productos con stock bajo</p>
              )}
              {citasPendientes > 5 && (
                <p>• {citasPendientes} citas pendientes de atención</p>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Gráficos */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Actividad Últimos 7 Días */}
        <Card>
          <CardHeader>
            <CardTitle>Actividad Últimos 7 Días</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={last7Days}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="fecha" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="ordenes" fill="#3B82F6" name="Órdenes" />
                <Bar dataKey="citas" fill="#10B981" name="Citas" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Estado de Órdenes */}
        <Card>
          <CardHeader>
            <CardTitle>Estado de Órdenes</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={estadosOrdenes}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  dataKey="value"
                  label={({ name, value }) => `${name}: ${value}`}
                >
                  {estadosOrdenes.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Ingresos Últimos 7 Días */}
        <Card>
          <CardHeader>
            <CardTitle>Ingresos Últimos 7 Días</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={last7Days}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="fecha" />
                <YAxis />
                <Tooltip formatter={(value) => [`€${value}`, "Ingresos"]} />
                <Line type="monotone" dataKey="ingresos" stroke="#10B981" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Servicios Más Solicitados */}
        <Card>
          <CardHeader>
            <CardTitle>Servicios Más Solicitados</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={serviciosData} layout="horizontal">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" />
                <YAxis dataKey="name" type="category" width={100} />
                <Tooltip />
                <Bar dataKey="value" fill="#8B5CF6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Resumen detallado */}
      <Card>
        <CardHeader>
          <CardTitle>Resumen Detallado</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div>
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <Wrench className="w-4 h-4" />
                Órdenes de Trabajo
              </h4>
              <div className="space-y-1 text-sm">
                <p>Total: {ordenes.length}</p>
                <p>Pendientes: {ordenes.filter((o: any) => o.estado === "pendiente").length}</p>
                <p>En proceso: {ordenes.filter((o: any) => o.estado === "en_proceso").length}</p>
                <p>Completadas: {ordenes.filter((o: any) => o.estado === "completado").length}</p>
              </div>
            </div>

            <div>
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                Citas
              </h4>
              <div className="space-y-1 text-sm">
                <p>Total: {citas.length}</p>
                <p>Programadas: {citas.filter((c: any) => c.estado === "programada").length}</p>
                <p>Confirmadas: {citas.filter((c: any) => c.estado === "confirmada").length}</p>
                <p>Completadas: {citas.filter((c: any) => c.estado === "completada").length}</p>
              </div>
            </div>

            <div>
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <Package className="w-4 h-4" />
                Inventario
              </h4>
              <div className="space-y-1 text-sm">
                <p>Productos: {inventario.length}</p>
                <p>Stock bajo: {productosStockBajo}</p>
                <p>Valor total: €{inventario.reduce((total: number, item: any) => total + (item.precio * item.stock), 0).toLocaleString()}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
