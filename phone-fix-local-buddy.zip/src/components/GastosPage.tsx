import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import {
  Plus,
  Search,
  Edit,
  Trash2,
  Package,
  DollarSign,
  Calendar,
  Building,
  TrendingDown,
  ShoppingCart,
  ScanLine
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import BarcodeScanner from "./BarcodeScanner";

interface Gasto {
  id: string;
  tipo_producto: string;
  descripcion: string;
  proveedor: string;
  cantidad: number;
  precio_unitario: number;
  total: number;
  fecha: string;
  categoria: string;
  notas?: string;
  created_at: string;
  updated_at: string;
  user_id: string;
}

const categorias = [
  "Protectores y Cristales",
  "Audio y Auriculares",
  "Cargadores y Cables",
  "Fundas y Accesorios",
  "Repuestos de Pantalla",
  "Baterías",
  "Componentes Internos",
  "Herramientas",
  "Gastos de Alquiler",
  "Gastos de Mantenimiento",
  "Gastos de Impuestos",
  "Compra de Mercancía",
  "Gastos de Servicios Públicos",
  "Otros"
];

const tiposProducto = [
  "Cristal templado",
  "Auriculares",
  "Altavoces",
  "Funda",
  "Cargador",
  "Cable USB",
  "Pantalla",
  "Batería",
  "Tapa trasera",
  "Cámara",
  "Micrófono",
  "Altavoz interno",
  "Flex de carga",
  "Conector jack",
  "Herramientas reparación",
  "Alquiler local comercial",
  "Reparación equipos",
  "Limpieza",
  "Seguridad",
  "IVA",
  "Autónomos",
  "Impuesto municipal",
  "Stock mercancía general",
  "Productos para reventa",
  "Electricidad",
  "Agua",
  "Internet/Teléfono",
  "Gas",
  "Otro"
];

export default function GastosPage() {
  const [gastos, setGastos] = useState<Gasto[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCategoria, setFilterCategoria] = useState<string>("todas");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingGasto, setEditingGasto] = useState<Gasto | null>(null);
  const [loading, setLoading] = useState(true);
  const [isBarcodeSearchOpen, setIsBarcodeSearchOpen] = useState(false);
  const [isBarcodeAddOpen, setIsBarcodeAddOpen] = useState(false);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    tipo_producto: "",
    descripcion: "",
    proveedor: "",
    cantidad: "",
    precio_unitario: "",
    fecha: format(new Date(), "yyyy-MM-dd"),
    categoria: "",
    notas: ""
  });

  useEffect(() => {
    fetchGastos();
  }, []);

  const fetchGastos = async () => {
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) return;

      const { data, error } = await supabase
        .from('gastos_mercancia')
        .select('*')
        .eq('user_id', user.user.id)
        .order('created_at', { ascending: false });

      if (error) {
        // Si la tabla no existe, usar localStorage como fallback
        if (error.message.includes('relation "public.gastos_mercancia" does not exist') ||
            error.code === 'PGRST116' ||
            error.message.includes('does not exist')) {
          console.log('Tabla gastos_mercancia no existe, usando localStorage');
          const gastosLocal = localStorage.getItem('gastos_mercancia');
          setGastos(gastosLocal ? JSON.parse(gastosLocal) : []);
          return;
        }
        throw error;
      }
      setGastos(data || []);
    } catch (error: any) {
      console.error('Error fetching gastos:', error);
      const errorMessage = error?.message || error?.error_description || error?.details ||
                        (typeof error === 'string' ? error : JSON.stringify(error)) || 'Error desconocido';
      toast({
        title: "Error",
        description: `No se pudieron cargar los gastos: ${errorMessage}`,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const calcularTotal = () => {
    const cantidad = parseFloat(formData.cantidad) || 0;
    const precio = parseFloat(formData.precio_unitario) || 0;
    return cantidad * precio;
  };

  const añadirAlInventario = async (gastoData: any) => {
    try {
      // Calcular precio de venta (margen del 40% sobre el coste)
      const precioVenta = gastoData.precio_unitario * 1.4;

      const productoInventario = {
        id: Date.now().toString(),
        nombre: gastoData.tipo_producto,
        descripcion: gastoData.descripcion || gastoData.tipo_producto,
        categoria: gastoData.categoria,
        precio: precioVenta,
        stock: gastoData.cantidad,
        stock_minimo: 5,
        proveedor: gastoData.proveedor,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      // Añadir al inventario de mercancía (localStorage)
      const inventarioMercancia = JSON.parse(localStorage.getItem('inventario_mercancia') || '[]');

      // Verificar si ya existe el producto para actualizar stock
      const productoExistente = inventarioMercancia.find((p: any) =>
        p.nombre.toLowerCase() === gastoData.tipo_producto.toLowerCase() &&
        p.proveedor === gastoData.proveedor
      );

      if (productoExistente) {
        // Actualizar stock del producto existente
        productoExistente.stock += gastoData.cantidad;
        productoExistente.updated_at = new Date().toISOString();
      } else {
        // Añadir nuevo producto
        inventarioMercancia.push(productoInventario);
      }

      localStorage.setItem('inventario_mercancia', JSON.stringify(inventarioMercancia));

      toast({
        title: "Sincronizado con inventario",
        description: `${gastoData.tipo_producto} añadido al inventario de mercancía`,
        variant: "default"
      });
    } catch (error) {
      console.error('Error adding to inventory:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.tipo_producto || !formData.proveedor || !formData.cantidad || !formData.precio_unitario) {
      toast({
        title: "Error",
        description: "Por favor completa los campos obligatorios",
        variant: "destructive"
      });
      return;
    }

    // Validate numeric fields
    const cantidad = parseFloat(formData.cantidad.toString());
    const precioUnitario = parseFloat(formData.precio_unitario.toString());

    if (cantidad <= 0 || isNaN(cantidad)) {
      toast({
        title: "Error",
        description: "La cantidad debe ser un número mayor a 0",
        variant: "destructive"
      });
      return;
    }

    if (precioUnitario <= 0 || isNaN(precioUnitario)) {
      toast({
        title: "Error",
        description: "El precio unitario debe ser un número mayor a 0",
        variant: "destructive"
      });
      return;
    }

    const { data: user } = await supabase.auth.getUser();
    if (!user.user) {
      toast({
        title: "Error",
        description: "Usuario no autenticado",
        variant: "destructive"
      });
      return;
    }

    const gastoData = {
      tipo_producto: formData.tipo_producto,
      descripcion: formData.descripcion || '',
      proveedor: formData.proveedor,
      cantidad: cantidad,
      precio_unitario: precioUnitario,
      total: cantidad * precioUnitario,
      fecha: formData.fecha,
      categoria: formData.categoria || 'Otros',
      notas: formData.notas || '',
      user_id: user.user.id
    };

    console.log('Saving gasto with data:', gastoData);

    try {
      if (editingGasto) {
        // Try Supabase first, fallback to localStorage
        try {
          const { error } = await supabase
            .from('gastos_mercancia')
            .update(gastoData)
            .eq('id', editingGasto.id);

          if (error && !error.message.includes('does not exist') && error.code !== 'PGRST116') {
            throw error;
          }
        } catch (dbError) {
          console.log('Database update failed, using localStorage fallback');
          // Fallback to localStorage
          const gastosLocal = JSON.parse(localStorage.getItem('gastos_mercancia') || '[]');
          const updatedGastos = gastosLocal.map((g: any) =>
            g.id === editingGasto.id ? { ...gastoData, id: editingGasto.id } : g
          );
          localStorage.setItem('gastos_mercancia', JSON.stringify(updatedGastos));
        }

        toast({
          title: "Gasto actualizado",
          description: "El gasto ha sido actualizado exitosamente"
        });
      } else {
        const newGasto = { ...gastoData, id: Date.now().toString() };

        // Try Supabase first, fallback to localStorage
        try {
          const { error } = await supabase
            .from('gastos_mercancia')
            .insert(gastoData);

          if (error && !error.message.includes('does not exist') && error.code !== 'PGRST116') {
            throw error;
          }
        } catch (dbError) {
          console.log('Database insert failed, using localStorage fallback');
          // Fallback to localStorage
          const gastosLocal = JSON.parse(localStorage.getItem('gastos_mercancia') || '[]');
          gastosLocal.push(newGasto);
          localStorage.setItem('gastos_mercancia', JSON.stringify(gastosLocal));
        }

        toast({
          title: "Gasto registrado",
          description: "El gasto ha sido registrado exitosamente"
        });
      }

      // Añadir automáticamente al inventario
      await añadirAlInventario(gastoData);

      resetForm();
      setIsDialogOpen(false);
      fetchGastos();
    } catch (error: any) {
      console.error('Error saving gasto:', {
        error: error,
        message: error?.message || 'Unknown error',
        details: error?.details || 'No details',
        hint: error?.hint || 'No hint',
        code: error?.code || 'No code',
        operation: editingGasto ? 'update' : 'insert'
      });
      const errorMessage = error?.message || error?.error_description || error?.details ||
                        (typeof error === 'string' ? error : JSON.stringify(error)) || 'Error desconocido';
      toast({
        title: "Error",
        description: `No se pudo guardar el gasto: ${errorMessage}`,
        variant: "destructive"
      });
    }
  };

  const resetForm = () => {
    setFormData({
      tipo_producto: "",
      descripcion: "",
      proveedor: "",
      cantidad: "",
      precio_unitario: "",
      fecha: format(new Date(), "yyyy-MM-dd"),
      categoria: "",
      notas: ""
    });
    setEditingGasto(null);
  };

  const handleEdit = (gasto: Gasto) => {
    setEditingGasto(gasto);
    setFormData({
      tipo_producto: gasto.tipo_producto,
      descripcion: gasto.descripcion,
      proveedor: gasto.proveedor,
      cantidad: gasto.cantidad.toString(),
      precio_unitario: gasto.precio_unitario.toString(),
      fecha: gasto.fecha,
      categoria: gasto.categoria,
      notas: gasto.notas || ""
    });
    setIsDialogOpen(true);
  };

  const handleDelete = async (id: string) => {
    try {
      const { error } = await supabase
        .from('gastos_mercancia')
        .delete()
        .eq('id', id);

      if (error) {
        // Fallback a localStorage si hay error
        if (error.message.includes('does not exist') || error.code === 'PGRST116') {
          const gastosLocal = JSON.parse(localStorage.getItem('gastos_mercancia') || '[]');
          const filteredGastos = gastosLocal.filter((g: any) => g.id !== id);
          localStorage.setItem('gastos_mercancia', JSON.stringify(filteredGastos));
        } else {
          throw error;
        }
      }

      toast({
        title: "Gasto eliminado",
        description: "El gasto ha sido eliminado"
      });

      fetchGastos();
    } catch (error: any) {
      console.error('Error deleting gasto:', error);
      const errorMessage = error?.message || error?.error_description || error?.details ||
                        (typeof error === 'string' ? error : JSON.stringify(error)) || 'Error desconocido';
      toast({
        title: "Error",
        description: `No se pudo eliminar el gasto: ${errorMessage}`,
        variant: "destructive"
      });
    }
  };

  const handleBarcodeSearch = (code: string) => {
    console.log("Buscando gasto con código:", code);

    // Buscar gasto por tipo de producto o descripción
    const foundGasto = gastos.find(g =>
      g.tipo_producto.toLowerCase().includes(code.toLowerCase()) ||
      g.descripcion.toLowerCase().includes(code.toLowerCase()) ||
      g.proveedor.toLowerCase().includes(code.toLowerCase())
    );

    if (foundGasto) {
      setSearchTerm(code);
      toast({
        title: "Gasto encontrado",
        description: `${foundGasto.tipo_producto} - €${foundGasto.total}`,
        variant: "default"
      });
    } else {
      toast({
        title: "Gasto no encontrado",
        description: `No se encontró ningún gasto con el código: ${code}`,
        variant: "destructive"
      });
    }

    setIsBarcodeSearchOpen(false);
  };

  const handleBarcodeAdd = (code: string) => {
    // Usar el código para rellenar automáticamente el formulario
    setFormData({
      ...formData,
      tipo_producto: tiposProducto.find(tipo => tipo.toLowerCase().includes(code.toLowerCase())) || `Producto-${code}`,
      descripcion: `Código de barras: ${code}`
    });

    toast({
      title: "Código capturado",
      description: `Código ${code} añadido al formulario`,
      variant: "default"
    });

    setIsBarcodeAddOpen(false);
    setIsDialogOpen(true);
  };

  const filteredGastos = gastos.filter(gasto => {
    const matchesSearch = gasto.tipo_producto.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         gasto.proveedor.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         gasto.descripcion.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategoria = filterCategoria === "todas" || gasto.categoria === filterCategoria;
    return matchesSearch && matchesCategoria;
  });

  const totalGastos = gastos.reduce((total, gasto) => total + gasto.total, 0);
  const gastosMesActual = gastos.filter(gasto => {
    const fechaGasto = new Date(gasto.fecha);
    const ahora = new Date();
    return fechaGasto.getMonth() === ahora.getMonth() && fechaGasto.getFullYear() === ahora.getFullYear();
  }).reduce((total, gasto) => total + gasto.total, 0);

  if (loading) {
    return <div className="p-6">Cargando gastos...</div>;
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">Gestión de Gastos</h1>
          <p className="text-slate-600">Registra y controla todos los gastos del negocio: mercancía, alquiler, mantenimiento, impuestos y más</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={resetForm}>
              <Plus className="w-4 h-4 mr-2" />
              Nuevo Gasto
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingGasto ? "Editar Gasto" : "Registrar Nuevo Gasto"}
              </DialogTitle>
            </DialogHeader>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="tipo_producto">Tipo de Gasto *</Label>
                  <div className="flex gap-2">
                    <Select value={formData.tipo_producto} onValueChange={(value) => setFormData({...formData, tipo_producto: value})}>
                      <SelectTrigger className="flex-1">
                        <SelectValue placeholder="Selecciona un tipo" />
                      </SelectTrigger>
                      <SelectContent>
                        {tiposProducto.map(tipo => (
                          <SelectItem key={tipo} value={tipo}>{tipo}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setIsBarcodeAddOpen(true)}
                      className="px-3"
                    >
                      <ScanLine className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                <div>
                  <Label htmlFor="categoria">Categoría *</Label>
                  <Select value={formData.categoria} onValueChange={(value) => setFormData({...formData, categoria: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecciona una categoría" />
                    </SelectTrigger>
                    <SelectContent>
                      {categorias.map(categoria => (
                        <SelectItem key={categoria} value={categoria}>{categoria}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="descripcion">Descripción del Producto</Label>
                <Input
                  id="descripcion"
                  value={formData.descripcion}
                  onChange={(e) => setFormData({...formData, descripcion: e.target.value})}
                  placeholder="Ej: Cristal templado iPhone 14 Pro"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="proveedor">Proveedor *</Label>
                  <Input
                    id="proveedor"
                    value={formData.proveedor}
                    onChange={(e) => setFormData({...formData, proveedor: e.target.value})}
                    placeholder="Nombre del proveedor"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="fecha">Fecha de Compra *</Label>
                  <Input
                    id="fecha"
                    type="date"
                    value={formData.fecha}
                    onChange={(e) => setFormData({...formData, fecha: e.target.value})}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="cantidad">Cantidad *</Label>
                  <Input
                    id="cantidad"
                    type="number"
                    min="1"
                    step="1"
                    value={formData.cantidad}
                    onChange={(e) => setFormData({...formData, cantidad: e.target.value})}
                    placeholder="1"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="precio_unitario">Precio Unitario (€) *</Label>
                  <Input
                    id="precio_unitario"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.precio_unitario}
                    onChange={(e) => setFormData({...formData, precio_unitario: e.target.value})}
                    placeholder="0.00"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="total">Total</Label>
                  <Input
                    id="total"
                    type="number"
                    value={calcularTotal().toFixed(2)}
                    disabled
                    className="bg-gray-100"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="notas">Notas Adicionales</Label>
                <Input
                  id="notas"
                  value={formData.notas}
                  onChange={(e) => setFormData({...formData, notas: e.target.value})}
                  placeholder="Observaciones adicionales..."
                />
              </div>

              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit">
                  {editingGasto ? "Actualizar" : "Registrar"} Gasto
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Métricas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Gastos</p>
                <p className="text-2xl font-bold text-red-600">€{totalGastos.toLocaleString()}</p>
              </div>
              <TrendingDown className="h-8 w-8 text-red-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Este Mes</p>
                <p className="text-2xl font-bold text-orange-600">€{gastosMesActual.toLocaleString()}</p>
              </div>
              <Calendar className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Productos</p>
                <p className="text-2xl font-bold text-blue-600">{gastos.length}</p>
              </div>
              <Package className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Proveedores</p>
                <p className="text-2xl font-bold text-purple-600">
                  {new Set(gastos.map(g => g.proveedor)).size}
                </p>
              </div>
              <Building className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar por producto, proveedor o descripción..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Button
              variant="outline"
              onClick={() => setIsBarcodeSearchOpen(true)}
              className="flex items-center gap-2"
            >
              <ScanLine className="w-4 h-4" />
              Buscar por Código
            </Button>
            <Select value={filterCategoria} onValueChange={setFilterCategoria}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Filtrar por categoría" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todas">Todas las categorías</SelectItem>
                {categorias.map(categoria => (
                  <SelectItem key={categoria} value={categoria}>{categoria}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Gastos List */}
      <div className="grid gap-4">
        {filteredGastos.length === 0 ? (
          <Card>
            <CardContent className="pt-6 text-center">
              <ShoppingCart className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No hay gastos registrados</h3>
              <p className="text-muted-foreground">
                {searchTerm || filterCategoria !== "todas" 
                  ? "No se encontraron gastos con los filtros aplicados"
                  : "Registra tu primer gasto en mercancía para comenzar"
                }
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredGastos.map((gasto) => (
            <Card key={gasto.id} className="hover:shadow-md transition-shadow">
              <CardContent className="pt-6">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="text-lg font-semibold">{gasto.tipo_producto}</h3>
                      <Badge variant="outline">{gasto.categoria}</Badge>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Building className="w-4 h-4" />
                        {gasto.proveedor}
                      </div>
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {format(new Date(gasto.fecha), "dd/MM/yyyy")}
                      </div>
                      <div className="flex items-center gap-1">
                        <Package className="w-4 h-4" />
                        {gasto.cantidad} unidades
                      </div>
                      <div className="flex items-center gap-1">
                        <DollarSign className="w-4 h-4" />
                        €{gasto.total.toFixed(2)}
                      </div>
                    </div>
                    {gasto.descripcion && (
                      <p className="mt-2 text-sm">{gasto.descripcion}</p>
                    )}
                    {gasto.notas && (
                      <p className="mt-2 text-sm text-gray-600">{gasto.notas}</p>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEdit(gasto)}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleDelete(gasto.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Escáner para búsqueda */}
      <BarcodeScanner
        isOpen={isBarcodeSearchOpen}
        onClose={() => setIsBarcodeSearchOpen(false)}
        onScan={handleBarcodeSearch}
        title="Buscar Gasto por Código de Barras"
      />

      {/* Escáner para añadir producto */}
      <BarcodeScanner
        isOpen={isBarcodeAddOpen}
        onClose={() => setIsBarcodeAddOpen(false)}
        onScan={handleBarcodeAdd}
        title="Capturar Producto con Código de Barras"
      />
    </div>
  );
}
