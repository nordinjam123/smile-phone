import React, { createContext, useContext, useState, useEffect } from 'react';
import { es } from './translations/es';
import { en } from './translations/en';
import { fr } from './translations/fr';

type Language = 'es' | 'en' | 'fr';
type Translation = typeof es;

interface I18nContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: Translation;
  languages: { code: Language; name: string; flag: string }[];
}

const translations = {
  es,
  en,
  fr
};

const languages = [
  { code: 'es' as Language, name: 'Español', flag: '🇪🇸' },
  { code: 'en' as Language, name: 'English', flag: '🇬🇧' },
  { code: 'fr' as Language, name: 'Français', flag: '🇫🇷' }
];

const I18nContext = createContext<I18nContextType | undefined>(undefined);

interface I18nProviderProps {
  children: React.ReactNode;
}

export const I18nProvider: React.FC<I18nProviderProps> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>('es'); // Forzar español

  const setLanguage = (lang: Language) => {
    // Temporalmente deshabilitado - mantener español
    // setLanguageState(lang);
    // localStorage.setItem('language', lang);
  };

  const t = translations[language];

  const value: I18nContextType = {
    language,
    setLanguage,
    t,
    languages
  };

  return (
    <I18nContext.Provider value={value}>
      {children}
    </I18nContext.Provider>
  );
};

export const useTranslation = () => {
  const context = useContext(I18nContext);
  if (context === undefined) {
    throw new Error('useTranslation must be used within an I18nProvider');
  }
  return context;
};

// Hook para formatear strings con variables
export const useFormatMessage = () => {
  const { t } = useTranslation();

  const formatMessage = (template: string, variables: Record<string, any>) => {
    return template.replace(/{(\w+)}/g, (match, key) => {
      return variables[key] !== undefined ? String(variables[key]) : match;
    });
  };

  return { formatMessage, t };
};
