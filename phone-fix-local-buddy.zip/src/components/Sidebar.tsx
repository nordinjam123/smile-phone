import {
  Settings,
  Wrench,
  Users,
  Package,
  FileText,
  Smartphone,
  Calendar,
  DollarSign,
  Home,
  User,
  Crown,
  Lock,
  ShoppingCart,
  CreditCard,
  Building2,
  Youtube,

} from "lucide-react";
import { BasicWhatsAppIcon } from "@/components/ui/basic-whatsapp-icons";

interface SidebarProps {
  activeSection: string;
  setActiveSection: (section: string) => void;
  subscriptionData?: any;
}

const Sidebar: React.FC<SidebarProps> = ({ activeSection, setActiveSection, subscriptionData }) => {
  const hasAccess = subscriptionData?.subscribed ||
                   subscriptionData?.is_lifetime_free ||
                   subscriptionData?.has_access;

  const getIconColor = (itemId: string) => {
    const colors: { [key: string]: string } = {
      "dashboard": "text-blue-600 group-hover:text-blue-700",
      "tpv": "text-green-600 group-hover:text-green-700",
      "clientes": "text-purple-600 group-hover:text-purple-700",
      "inventario": "text-orange-600 group-hover:text-orange-700",
      "ordenes": "text-indigo-600 group-hover:text-indigo-700",
      "facturas": "text-yellow-600 group-hover:text-yellow-700",
      "gastos": "text-rose-600 group-hover:text-rose-700",
      "moviles": "text-slate-600 group-hover:text-slate-700",
      "citas": "text-teal-600 group-hover:text-teal-700",
      "balance": "text-lime-600 group-hover:text-lime-700",
      "youtube-repair": "text-red-600 group-hover:text-red-700",
      "configuracion": "text-gray-600 group-hover:text-gray-700",
      "empresa": "text-sky-600 group-hover:text-sky-700",
      "whatsapp": "text-green-600 group-hover:text-green-700",
      "suscripcion": "text-amber-600 group-hover:text-amber-700",
      "perfil": "text-violet-600 group-hover:text-violet-700",
    };
    return colors[itemId] || "text-gray-600 group-hover:text-gray-700";
  };
  
  const menuItems = [
    { id: "dashboard", label: "Dashboard", icon: Home, requiresSubscription: false, color: "from-blue-500 to-cyan-500", bgColor: "from-blue-50 to-cyan-50" },
    { id: "tpv", label: "TPV - Punto de Venta", icon: CreditCard, requiresSubscription: false, color: "from-green-500 to-emerald-500", bgColor: "from-green-50 to-emerald-50" },
    { id: "clientes", label: "Clientes", icon: Users, requiresSubscription: false, color: "from-purple-500 to-violet-500", bgColor: "from-purple-50 to-violet-50" },
    { id: "inventario", label: "Inventario", icon: Package, requiresSubscription: false, color: "from-orange-500 to-red-500", bgColor: "from-orange-50 to-red-50" },
    { id: "ordenes", label: "Órdenes de Trabajo", icon: FileText, requiresSubscription: false, color: "from-indigo-500 to-blue-500", bgColor: "from-indigo-50 to-blue-50" },
    { id: "facturas", label: "Facturas", icon: DollarSign, requiresSubscription: false, color: "from-yellow-500 to-amber-500", bgColor: "from-yellow-50 to-amber-50" },
    { id: "gastos", label: "Gastos Mercancía", icon: ShoppingCart, requiresSubscription: false, color: "from-rose-500 to-pink-500", bgColor: "from-rose-50 to-pink-50" },
    { id: "moviles", label: "Móviles", icon: Smartphone, requiresSubscription: false, color: "from-slate-500 to-gray-500", bgColor: "from-slate-50 to-gray-50" },
    { id: "citas", label: "Citas", icon: Calendar, requiresSubscription: false, color: "from-teal-500 to-cyan-500", bgColor: "from-teal-50 to-cyan-50" },
    { id: "balance", label: "Balance", icon: DollarSign, requiresSubscription: false, color: "from-lime-500 to-green-500", bgColor: "from-lime-50 to-green-50" },
    { id: "youtube-repair", label: "Videos de Reparación", icon: Youtube, requiresSubscription: false, color: "from-red-500 to-rose-500", bgColor: "from-red-50 to-rose-50" },


    { id: "empresa", label: "Datos de Empresa", icon: Building2, requiresSubscription: false, color: "from-sky-500 to-blue-500", bgColor: "from-sky-50 to-blue-50" },
    { id: "whatsapp", label: "WhatsApp", icon: BasicWhatsAppIcon, requiresSubscription: false, color: "from-green-600 to-green-500", bgColor: "from-green-50 to-green-100" },
    { id: "suscripcion", label: "Suscripción", icon: Crown, requiresSubscription: false, color: "from-amber-500 to-yellow-500", bgColor: "from-amber-50 to-yellow-50" },
    { id: "perfil", label: "Perfil", icon: User, requiresSubscription: false, color: "from-violet-500 to-purple-500", bgColor: "from-violet-50 to-purple-50" },
  ];

  return (
    <aside className="w-72 bg-gradient-to-b from-white/95 to-gray-50/95 backdrop-blur-lg border-r border-gray-200/50 h-[calc(100vh-60px)] flex flex-col shadow-xl">
      {/* Navigation */}
      <nav className="flex-1 px-4 py-6 space-y-2 overflow-y-auto overflow-x-hidden sidebar-scroll">
        <div className="mb-6">
          <h2 className="text-sm font-bold text-transparent bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text uppercase tracking-wider mb-2">
            Navegación Principal
          </h2>
          <div className="w-12 h-0.5 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full"></div>
        </div>
        
        {menuItems.map((item) => {
          const IconComponent = item.icon;
          const isActive = activeSection === item.id;
          const isAccessible = !item.requiresSubscription || hasAccess;
          
          return (
            <button
              key={item.id}
              onClick={() => setActiveSection(item.id)}
              disabled={!isAccessible}
              className={`w-full flex items-center px-3 py-3 text-left rounded-2xl transition-all duration-300 group relative overflow-hidden ${
                isActive
                  ? "bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white shadow-2xl shadow-blue-500/40 ring-1 ring-white/20 backdrop-blur-sm"
                  : isAccessible
                    ? "text-gray-700 hover:bg-gradient-to-r hover:from-white/80 hover:to-gray-50/80 hover:text-gray-800 hover:shadow-lg hover:ring-1 hover:ring-gray-200/50 hover:backdrop-blur-sm"
                    : "text-gray-400 cursor-not-allowed opacity-50"
              }`}
            >
              {/* Efecto de brillo en hover */}
              {isAccessible && !isActive && (
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent transform -skew-x-12 -translate-x-full group-hover:translate-x-full transition-transform duration-500"></div>
              )}

              {/* Contenedor del icono con diseño único */}
              <div className={`relative mr-3 transition-all duration-300 group-hover:scale-105 ${
                isActive ? "transform rotate-3" : ""
              }`}>
                {/* Fondo principal del icono */}
                <div className={`p-2.5 rounded-2xl transition-all duration-300 relative overflow-hidden ${
                  isActive
                    ? "bg-white/25 shadow-xl backdrop-blur-sm"
                    : isAccessible
                      ? `bg-gradient-to-br ${item.bgColor} group-hover:shadow-lg group-hover:${item.bgColor.replace('50', '100')}`
                      : "bg-gray-100"
                }`}>

                  {/* Efecto de cristal interno */}
                  <div className={`absolute inset-0 rounded-2xl ${
                    isActive
                      ? "bg-gradient-to-br from-white/20 to-transparent"
                      : "bg-gradient-to-br from-white/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  }`}></div>

                  {/* Borde brillante */}
                  <div className={`absolute inset-0 rounded-2xl transition-all duration-300 ${
                    isActive
                      ? "ring-2 ring-white/30 shadow-lg"
                      : isAccessible
                        ? "ring-1 ring-white/60 group-hover:ring-2 group-hover:ring-white/80"
                        : ""
                  }`}></div>

                  {/* Icono con colores sólidos */}
                  <IconComponent className={`h-4 w-4 transition-all duration-300 relative z-10 ${
                    isActive
                      ? "text-white drop-shadow-lg"
                      : isAccessible
                        ? getIconColor(item.id) + " group-hover:scale-110"
                        : "text-gray-400"
                  }`} />

                  {/* Punto de luz en la esquina */}
                  {isActive && (
                    <div className="absolute top-1 right-1 w-1.5 h-1.5 bg-white/60 rounded-full shadow-sm"></div>
                  )}

                  {/* Reflejo sutil */}
                  <div className="absolute top-1 left-1 right-1 h-1 bg-gradient-to-r from-white/20 to-transparent rounded-full"></div>
                </div>

                {/* Sombra de profundidad */}
                <div className={`absolute inset-0 rounded-2xl transition-all duration-300 -z-10 ${
                  isActive
                    ? "bg-gradient-to-br from-blue-500/20 to-purple-500/20 blur-md scale-110"
                    : isAccessible
                      ? `bg-gradient-to-br ${item.color.replace('500', '300')}/0 group-hover:${item.color.replace('500', '300')}/20 blur-sm scale-105 opacity-0 group-hover:opacity-100`
                      : ""
                }`}></div>
              </div>

              <span className={`font-semibold text-sm flex-1 transition-all duration-300 ${
                isActive ? "text-white" : "group-hover:font-bold"
              }`}>{item.label}</span>

              {!isAccessible && (
                <div className="ml-auto p-1 bg-gray-200 rounded-lg">
                  <Lock className="h-3 w-3 text-gray-500" />
                </div>
              )}

              {isActive && (
                <div className="flex items-center space-x-1 ml-auto">
                  <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                  <div className="w-1 h-1 bg-white/70 rounded-full"></div>
                </div>
              )}

              {/* Barra lateral activa */}
              {isActive && (
                <div className="absolute right-0 top-0 bottom-0 w-1 bg-white rounded-l-full shadow-lg"></div>
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-gradient-to-r from-blue-200/50 to-indigo-200/50 bg-gradient-to-r from-blue-50/50 to-indigo-50/50">
        <div className="text-xs font-semibold text-transparent bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-center">
          TechRepair Pro v2.0
        </div>
        <div className="flex justify-center mt-2">
          <div className="flex space-x-1">
            <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse"></div>
            <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-pulse" style={{animationDelay: '0.2s'}}></div>
            <div className="w-1.5 h-1.5 bg-purple-500 rounded-full animate-pulse" style={{animationDelay: '0.4s'}}></div>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
