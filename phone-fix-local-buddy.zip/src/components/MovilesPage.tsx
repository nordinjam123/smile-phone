import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import { useToast } from "@/hooks/use-toast";
import {
  Plus,
  Search,
  Edit,
  Trash2,
  Smartphone,
  ShoppingCart,
  TrendingUp,
  DollarSign,
  Eye,
  ScanLine
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import BarcodeScanner from "./BarcodeScanner";

interface Movil {
  id: string;
  marca: string;
  modelo: string;
  imei: string;
  estado: "nuevo" | "usado" | "reparado" | "defectuoso";
  almacenamiento: string;
  color: string;
  accesorios: string;
  precioCompra: number;
  precioVenta?: number;
  vendedorNombre: string;
  vendedorTelefono: string;
  compradorNombre?: string;
  compradorTelefono?: string;
  fechaCompra: string;
  fechaVenta?: string;
  vendido: boolean;
  notas: string;
}

const estadoColors = {
  nuevo: "bg-green-100 text-green-800 border-green-300",
  usado: "bg-blue-100 text-blue-800 border-blue-300", 
  reparado: "bg-orange-100 text-orange-800 border-orange-300",
  defectuoso: "bg-red-100 text-red-800 border-red-300"
};

const estadoLabels = {
  nuevo: "Nuevo",
  usado: "Usado",
  reparado: "Reparado",
  defectuoso: "Defectuoso"
};

export default function MovilesPage() {
  const [moviles, setMoviles] = useLocalStorage<Movil[]>("moviles", []);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterEstado, setFilterEstado] = useState<string>("todos");
  const [filterVendido, setFilterVendido] = useState<string>("todos");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingMovil, setEditingMovil] = useState<Movil | null>(null);
  const [activeTab, setActiveTab] = useState("compra");
  const [isBarcodeSearchOpen, setIsBarcodeSearchOpen] = useState(false);
  const [isBarcodeAddOpen, setIsBarcodeAddOpen] = useState(false);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    marca: "",
    modelo: "",
    imei: "",
    estado: "usado" as Movil["estado"],
    almacenamiento: "",
    color: "",
    accesorios: "",
    precioCompra: "",
    precioVenta: "",
    vendedorNombre: "",
    vendedorTelefono: "",
    compradorNombre: "",
    compradorTelefono: "",
    notas: ""
  });

  const resetForm = () => {
    setFormData({
      marca: "",
      modelo: "",
      imei: "",
      estado: "usado",
      almacenamiento: "",
      color: "",
      accesorios: "",
      precioCompra: "",
      precioVenta: "",
      vendedorNombre: "",
      vendedorTelefono: "",
      compradorNombre: "",
      compradorTelefono: "",
      notas: ""
    });
    setEditingMovil(null);
    setActiveTab("compra");
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.marca || !formData.modelo || !formData.imei) {
      toast({
        title: "Error",
        description: "Por favor completa los campos obligatorios",
        variant: "destructive"
      });
      return;
    }

    const nuevoMovil: Movil = {
      id: editingMovil?.id || Date.now().toString(),
      marca: formData.marca,
      modelo: formData.modelo,
      imei: formData.imei,
      estado: formData.estado,
      almacenamiento: formData.almacenamiento,
      color: formData.color,
      accesorios: formData.accesorios,
      precioCompra: parseFloat(formData.precioCompra) || 0,
      precioVenta: formData.precioVenta ? parseFloat(formData.precioVenta) : undefined,
      vendedorNombre: formData.vendedorNombre,
      vendedorTelefono: formData.vendedorTelefono,
      compradorNombre: formData.compradorNombre || undefined,
      compradorTelefono: formData.compradorTelefono || undefined,
      fechaCompra: editingMovil?.fechaCompra || new Date().toISOString().split('T')[0],
      fechaVenta: formData.compradorNombre ? new Date().toISOString().split('T')[0] : editingMovil?.fechaVenta,
      vendido: Boolean(formData.compradorNombre),
      notas: formData.notas
    };

    if (editingMovil) {
      setMoviles(moviles.map(movil => movil.id === editingMovil.id ? nuevoMovil : movil));
      toast({
        title: "Móvil actualizado",
        description: "Los datos del móvil han sido actualizados exitosamente"
      });
    } else {
      setMoviles([...moviles, nuevoMovil]);
      toast({
        title: "Móvil registrado",
        description: "El móvil ha sido registrado exitosamente"
      });
    }

    resetForm();
    setIsDialogOpen(false);
  };

  const handleEdit = (movil: Movil) => {
    setEditingMovil(movil);
    setFormData({
      marca: movil.marca,
      modelo: movil.modelo,
      imei: movil.imei,
      estado: movil.estado,
      almacenamiento: movil.almacenamiento,
      color: movil.color,
      accesorios: movil.accesorios,
      precioCompra: movil.precioCompra.toString(),
      precioVenta: movil.precioVenta?.toString() || "",
      vendedorNombre: movil.vendedorNombre,
      vendedorTelefono: movil.vendedorTelefono,
      compradorNombre: movil.compradorNombre || "",
      compradorTelefono: movil.compradorTelefono || "",
      notas: movil.notas
    });
    setActiveTab(movil.vendido ? "venta" : "compra");
    setIsDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    setMoviles(moviles.filter(movil => movil.id !== id));
    toast({
      title: "Móvil eliminado",
      description: "El móvil ha sido eliminado del inventario"
    });
  };

  const marcarComoVendido = (movil: Movil) => {
    setEditingMovil(movil);
    setFormData({
      marca: movil.marca,
      modelo: movil.modelo,
      imei: movil.imei,
      estado: movil.estado,
      almacenamiento: movil.almacenamiento,
      color: movil.color,
      accesorios: movil.accesorios,
      precioCompra: movil.precioCompra.toString(),
      precioVenta: "",
      vendedorNombre: movil.vendedorNombre,
      vendedorTelefono: movil.vendedorTelefono,
      compradorNombre: "",
      compradorTelefono: "",
      notas: movil.notas
    });
    setActiveTab("venta");
    setIsDialogOpen(true);
  };

  const handleBarcodeSearch = (code: string) => {
    console.log("Buscando móvil con código:", code);

    // Buscar móvil por IMEI o modelo
    const foundMovil = moviles.find(m =>
      m.imei.toLowerCase().includes(code.toLowerCase()) ||
      m.modelo.toLowerCase().includes(code.toLowerCase()) ||
      m.marca.toLowerCase().includes(code.toLowerCase())
    );

    if (foundMovil) {
      setSearchTerm(code);
      toast({
        title: "Móvil encontrado",
        description: `${foundMovil.marca} ${foundMovil.modelo} - ${foundMovil.vendido ? 'Vendido' : 'Disponible'}`,
        variant: "default"
      });
    } else {
      toast({
        title: "Móvil no encontrado",
        description: `No se encontró ningún móvil con el código: ${code}`,
        variant: "destructive"
      });
    }

    setIsBarcodeSearchOpen(false);
  };

  const handleBarcodeAdd = (code: string) => {
    // Usar el código para rellenar IMEI automáticamente
    setFormData({
      ...formData,
      imei: code,
      modelo: code.length > 10 ? `Modelo-${code.slice(-6)}` : `Modelo-${code}`
    });

    toast({
      title: "Código capturado",
      description: `IMEI ${code} añadido al formulario`,
      variant: "default"
    });

    setIsBarcodeAddOpen(false);
    setIsDialogOpen(true);
  };

  const filteredMoviles = moviles.filter(movil => {
    const matchesSearch = movil.marca.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         movil.modelo.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         movil.imei.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesEstado = filterEstado === "todos" || movil.estado === filterEstado;
    const matchesVendido = filterVendido === "todos" || 
                          (filterVendido === "vendidos" && movil.vendido) ||
                          (filterVendido === "disponibles" && !movil.vendido);
    return matchesSearch && matchesEstado && matchesVendido;
  });

  // Métricas
  const totalCompra = moviles.reduce((sum, movil) => sum + movil.precioCompra, 0);
  const totalVenta = moviles.filter(m => m.vendido).reduce((sum, movil) => sum + (movil.precioVenta || 0), 0);
  const totalBeneficio = totalVenta - moviles.filter(m => m.vendido).reduce((sum, movil) => sum + movil.precioCompra, 0);
  const movilesVendidos = moviles.filter(m => m.vendido).length;
  const movilesDisponibles = moviles.filter(m => !m.vendido).length;

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">Gestión de Móviles</h1>
          <p className="text-slate-600">Compra y venta de dispositivos móviles</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={resetForm}>
              <Plus className="w-4 h-4 mr-2" />
              Nuevo Móvil
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingMovil ? "Editar Móvil" : "Registrar Nuevo Móvil"}
              </DialogTitle>
            </DialogHeader>
            
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="compra">Datos de Compra</TabsTrigger>
                <TabsTrigger value="venta">Datos de Venta</TabsTrigger>
              </TabsList>

              <form onSubmit={handleSubmit} className="space-y-4">
                <TabsContent value="compra" className="space-y-4">

                  {/* Datos del dispositivo */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="marca">Marca *</Label>
                      <Input
                        id="marca"
                        value={formData.marca}
                        onChange={(e) => setFormData({...formData, marca: e.target.value})}
                        placeholder="Samsung, Apple, Xiaomi..."
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="modelo">Modelo *</Label>
                      <Input
                        id="modelo"
                        value={formData.modelo}
                        onChange={(e) => setFormData({...formData, modelo: e.target.value})}
                        placeholder="Galaxy S21, iPhone 12..."
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="imei">IMEI *</Label>
                      <div className="flex gap-2">
                        <Input
                          id="imei"
                          value={formData.imei}
                          onChange={(e) => setFormData({...formData, imei: e.target.value})}
                          placeholder="Número IMEI del dispositivo"
                          required
                          className="flex-1"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => setIsBarcodeAddOpen(true)}
                          className="px-3"
                        >
                          <ScanLine className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="estado">Estado</Label>
                      <Select value={formData.estado} onValueChange={(value: Movil["estado"]) => setFormData({...formData, estado: value})}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="nuevo">Nuevo</SelectItem>
                          <SelectItem value="usado">Usado</SelectItem>
                          <SelectItem value="reparado">Reparado</SelectItem>
                          <SelectItem value="defectuoso">Defectuoso</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="almacenamiento">Almacenamiento</Label>
                      <Input
                        id="almacenamiento"
                        value={formData.almacenamiento}
                        onChange={(e) => setFormData({...formData, almacenamiento: e.target.value})}
                        placeholder="64GB, 128GB, 256GB..."
                      />
                    </div>
                    <div>
                      <Label htmlFor="color">Color</Label>
                      <Input
                        id="color"
                        value={formData.color}
                        onChange={(e) => setFormData({...formData, color: e.target.value})}
                        placeholder="Negro, Blanco, Azul..."
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="accesorios">Accesorios Incluidos</Label>
                    <Input
                      id="accesorios"
                      value={formData.accesorios}
                      onChange={(e) => setFormData({...formData, accesorios: e.target.value})}
                      placeholder="Cargador, auriculares, funda..."
                    />
                  </div>

                  {/* Datos del vendedor */}
                  <div className="border-t pt-4">
                    <h3 className="text-lg font-semibold mb-3">Datos del Vendedor</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="vendedorNombre">Nombre del Vendedor</Label>
                        <Input
                          id="vendedorNombre"
                          value={formData.vendedorNombre}
                          onChange={(e) => setFormData({...formData, vendedorNombre: e.target.value})}
                          placeholder="Nombre completo"
                        />
                      </div>
                      <div>
                        <Label htmlFor="vendedorTelefono">Teléfono del Vendedor</Label>
                        <Input
                          id="vendedorTelefono"
                          value={formData.vendedorTelefono}
                          onChange={(e) => setFormData({...formData, vendedorTelefono: e.target.value})}
                          placeholder="Número de contacto"
                        />
                      </div>
                    </div>
                    <div className="mt-4">
                      <Label htmlFor="precioCompra">Precio de Compra</Label>
                      <Input
                        id="precioCompra"
                        type="number"
                        value={formData.precioCompra}
                        onChange={(e) => setFormData({...formData, precioCompra: e.target.value})}
                        placeholder="0.00"
                      />
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="venta" className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="compradorNombre">Nombre del Comprador</Label>
                      <Input
                        id="compradorNombre"
                        value={formData.compradorNombre}
                        onChange={(e) => setFormData({...formData, compradorNombre: e.target.value})}
                        placeholder="Nombre completo del comprador"
                      />
                    </div>
                    <div>
                      <Label htmlFor="compradorTelefono">Teléfono del Comprador</Label>
                      <Input
                        id="compradorTelefono"
                        value={formData.compradorTelefono}
                        onChange={(e) => setFormData({...formData, compradorTelefono: e.target.value})}
                        placeholder="Número de contacto"
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="precioVenta">Precio de Venta</Label>
                    <Input
                      id="precioVenta"
                      type="number"
                      value={formData.precioVenta}
                      onChange={(e) => setFormData({...formData, precioVenta: e.target.value})}
                      placeholder="0.00"
                    />
                  </div>
                </TabsContent>

                <div>
                  <Label htmlFor="notas">Notas</Label>
                  <Textarea
                    id="notas"
                    value={formData.notas}
                    onChange={(e) => setFormData({...formData, notas: e.target.value})}
                    placeholder="Observaciones adicionales..."
                  />
                </div>

                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancelar
                  </Button>
                  <Button type="submit">
                    {editingMovil ? "Actualizar" : "Registrar"} Móvil
                  </Button>
                </div>
              </form>
            </Tabs>
          </DialogContent>
        </Dialog>
      </div>

      {/* Métricas */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Invertido</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">€{totalCompra.toLocaleString()}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Vendido</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">€{totalVenta.toLocaleString()}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Beneficio</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">€{totalBeneficio.toLocaleString()}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Vendidos</CardTitle>
            <ShoppingCart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{movilesVendidos}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Disponibles</CardTitle>
            <Smartphone className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{movilesDisponibles}</div>
          </CardContent>
        </Card>
      </div>

      {/* Filtros */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar por marca, modelo o IMEI..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Button
              variant="outline"
              onClick={() => setIsBarcodeSearchOpen(true)}
              className="flex items-center gap-2"
            >
              <ScanLine className="w-4 h-4" />
              Buscar por Código
            </Button>
            <Select value={filterEstado} onValueChange={setFilterEstado}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Estado" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos</SelectItem>
                <SelectItem value="nuevo">Nuevo</SelectItem>
                <SelectItem value="usado">Usado</SelectItem>
                <SelectItem value="reparado">Reparado</SelectItem>
                <SelectItem value="defectuoso">Defectuoso</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterVendido} onValueChange={setFilterVendido}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Disponibilidad" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos</SelectItem>
                <SelectItem value="disponibles">Disponibles</SelectItem>
                <SelectItem value="vendidos">Vendidos</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Lista de móviles */}
      <div className="grid gap-4">
        {filteredMoviles.length === 0 ? (
          <Card>
            <CardContent className="pt-6 text-center">
              <Smartphone className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No hay móviles</h3>
              <p className="text-muted-foreground">
                {searchTerm || filterEstado !== "todos" || filterVendido !== "todos"
                  ? "No se encontraron móviles con los filtros aplicados"
                  : "Registra tu primer móvil para comenzar"
                }
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredMoviles.map((movil) => (
            <Card key={movil.id} className="hover:shadow-md transition-shadow">
              <CardContent className="pt-6">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="text-lg font-semibold">{movil.marca} {movil.modelo}</h3>
                      <Badge className={estadoColors[movil.estado]}>
                        {estadoLabels[movil.estado]}
                      </Badge>
                      {movil.vendido ? (
                        <Badge className="bg-green-100 text-green-800 border-green-300">
                          Vendido
                        </Badge>
                      ) : (
                        <Badge className="bg-blue-100 text-blue-800 border-blue-300">
                          Disponible
                        </Badge>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-2 text-sm text-muted-foreground mb-3">
                      <p><span className="font-medium">IMEI:</span> {movil.imei}</p>
                      <p><span className="font-medium">Almacenamiento:</span> {movil.almacenamiento || "N/A"}</p>
                      <p><span className="font-medium">Color:</span> {movil.color || "N/A"}</p>
                      <p><span className="font-medium">Compra:</span> {movil.fechaCompra}</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="font-medium">Vendedor: {movil.vendedorNombre}</p>
                        <p className="text-muted-foreground">Tel: {movil.vendedorTelefono}</p>
                      </div>
                      {movil.vendido && (
                        <div>
                          <p className="font-medium">Comprador: {movil.compradorNombre}</p>
                          <p className="text-muted-foreground">Tel: {movil.compradorTelefono}</p>
                        </div>
                      )}
                    </div>

                    <div className="mt-3 flex gap-4 text-sm">
                      <p className="text-red-600">Compra: €{movil.precioCompra.toLocaleString()}</p>
                      {movil.precioVenta && (
                        <p className="text-green-600">Venta: €{movil.precioVenta.toLocaleString()}</p>
                      )}
                      {movil.vendido && movil.precioVenta && (
                        <p className="font-bold text-blue-600">
                          Beneficio: €{(movil.precioVenta - movil.precioCompra).toLocaleString()}
                        </p>
                      )}
                    </div>

                    {movil.notas && (
                      <p className="mt-2 text-sm text-muted-foreground italic">{movil.notas}</p>
                    )}
                  </div>
                  
                  <div className="flex gap-2">
                    {!movil.vendido && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => marcarComoVendido(movil)}
                        className="text-green-600"
                      >
                        <ShoppingCart className="w-4 h-4" />
                      </Button>
                    )}
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEdit(movil)}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDelete(movil.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Escáner para búsqueda */}
      <BarcodeScanner
        isOpen={isBarcodeSearchOpen}
        onClose={() => setIsBarcodeSearchOpen(false)}
        onScan={handleBarcodeSearch}
        title="Buscar Móvil por Código de Barras"
      />

      {/* Escáner para añadir IMEI */}
      <BarcodeScanner
        isOpen={isBarcodeAddOpen}
        onClose={() => setIsBarcodeAddOpen(false)}
        onScan={handleBarcodeAdd}
        title="Capturar IMEI con Código de Barras"
      />
    </div>
  );
}
