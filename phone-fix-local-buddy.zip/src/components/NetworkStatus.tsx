import { useState, useEffect } from 'react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Wifi, WifiOff, AlertTriangle } from 'lucide-react';

export default function NetworkStatus() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [showOfflineAlert, setShowOfflineAlert] = useState(false);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setShowOfflineAlert(false);
    };

    const handleOffline = () => {
      setIsOnline(false);
      setShowOfflineAlert(true);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Auto-hide offline alert after 5 seconds
    if (!isOnline) {
      const timer = setTimeout(() => {
        setShowOfflineAlert(false);
      }, 5000);

      return () => {
        clearTimeout(timer);
        window.removeEventListener('online', handleOnline);
        window.removeEventListener('offline', handleOffline);
      };
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [isOnline]);

  return (
    <>
      {/* Badge de estado de red en la esquina */}
      <div className="fixed top-4 right-4 z-50">
        <Badge 
          variant={isOnline ? "default" : "destructive"} 
          className="flex items-center gap-1"
        >
          {isOnline ? (
            <>
              <Wifi className="w-3 h-3" />
              En línea
            </>
          ) : (
            <>
              <WifiOff className="w-3 h-3" />
              Sin conexión
            </>
          )}
        </Badge>
      </div>

      {/* Alert cuando se pierde la conexión */}
      {showOfflineAlert && (
        <div className="fixed top-16 right-4 z-50 max-w-sm">
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              Sin conexión a internet. La aplicación funcionará en modo offline con funcionalidad limitada.
            </AlertDescription>
          </Alert>
        </div>
      )}
    </>
  );
}
