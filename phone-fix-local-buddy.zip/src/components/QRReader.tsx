import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Camera, X, RotateCcw, QrCode } from "lucide-react";

interface QRReaderProps {
  isOpen: boolean;
  onClose: () => void;
  onScan: (data: any) => void;
  title?: string;
}

export default function QRReader({ isOpen, onClose, onScan, title = "Escanear Código QR" }: QRReaderProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [error, setError] = useState<string>("");
  const [scannedData, setScannedData] = useState<any>(null);
  const [qrScanner, setQrScanner] = useState<any>(null);
  const { toast } = useToast();

  useEffect(() => {
    let scanner: any = null;
    let isInitializing = false;

    const initScanner = async () => {
      if (!isOpen || !videoRef.current || isInitializing) return;
      
      isInitializing = true;
      console.log("Iniciando escáner QR...");

      try {
        // Importar qr-scanner dinámicamente
        const QrScannerModule = await import('qr-scanner');
        const QrScanner = QrScannerModule.default;

        if (!QrScanner) {
          setError("No se pudo cargar el escáner de QR");
          isInitializing = false;
          return;
        }

        setIsScanning(true);
        setError("");
        setScannedData(null);

        console.log("Creando scanner...");

        scanner = new QrScanner(
          videoRef.current,
          (result: any) => {
            console.log("QR Code detected:", result);
            const data = typeof result === 'string' ? result : result?.data || result;
            if (data) {
              handleScanResult(data);
            }
          },
          {
            returnDetailedScanResult: false,
            highlightScanRegion: true,
            highlightCodeOutline: true,
            preferredCamera: 'environment'
          }
        );

        setQrScanner(scanner);
        console.log("Iniciando cámara...");
        await scanner.start();
        console.log("QR Scanner iniciado correctamente");

      } catch (error: any) {
        console.error('Error iniciando scanner:', error);
        setError(`Error al acceder a la cámara: ${error.message || 'Error desconocido'}`);
        setIsScanning(false);
      } finally {
        isInitializing = false;
      }
    };

    const handleScanResult = (code: string) => {
      if (!code) return;
      
      console.log("Procesando resultado del escaneo:", code);
      
      try {
        // Intentar parsear como JSON (para códigos QR de nuestros tickets)
        const parsedData = JSON.parse(code);
        setScannedData(parsedData);
        
        toast({
          title: "Código QR detectado",
          description: `${parsedData.tipo || 'Datos'} encontrados`,
          variant: "default"
        });
        
        // NO cerrar automáticamente - dejar que el usuario vea el resultado
        onScan(parsedData);
        
      } catch (e) {
        // Si no es JSON, tratar como código de barras normal o texto
        const barcodeData = { code, tipo: 'BARCODE' };
        setScannedData(barcodeData);
        
        toast({
          title: "Código detectado",
          description: `Código: ${code}`,
          variant: "default"
        });
        
        // NO cerrar automáticamente - dejar que el usuario vea el resultado
        onScan(barcodeData);
      }
    };

    const stopScanner = () => {
      if (scanner) {
        try {
          scanner.stop();
          scanner.destroy();
          console.log("Scanner detenido correctamente");
        } catch (e) {
          console.warn("Error deteniendo scanner:", e);
        }
        scanner = null;
      }
      setIsScanning(false);
      setQrScanner(null);
    };

    if (isOpen) {
      // Añadir un pequeño delay para asegurar que el video está renderizado
      const timer = setTimeout(() => {
        initScanner();
      }, 300);
      
      return () => {
        clearTimeout(timer);
        stopScanner();
      };
    } else {
      stopScanner();
    }

    return () => {
      stopScanner();
    };
  }, [isOpen, onScan, toast]);

  const handleManualClose = () => {
    console.log("Cerrando scanner manualmente");
    if (qrScanner) {
      try {
        qrScanner.stop();
        qrScanner.destroy();
      } catch (e) {
        console.warn("Error cerrando scanner:", e);
      }
    }
    setIsScanning(false);
    setQrScanner(null);
    setScannedData(null);
    setError("");
    onClose();
  };

  const handleRetry = () => {
    console.log("Reintentando scanner");
    setError("");
    if (qrScanner) {
      try {
        qrScanner.stop();
        qrScanner.destroy();
      } catch (e) {
        console.warn("Error en retry:", e);
      }
      setQrScanner(null);
    }
    setIsScanning(false);
    setScannedData(null);
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleManualClose}>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <QrCode className="w-5 h-5" />
            {title}
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Escáner */}
          <div className="space-y-4">
            {error ? (
              <div className="text-center p-8">
                <div className="text-red-600 mb-4">
                  <Camera className="w-16 h-16 mx-auto mb-2 opacity-50" />
                  <p className="font-medium">Error del escáner</p>
                  <p className="text-sm">{error}</p>
                </div>
                <Button onClick={handleRetry} variant="outline">
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Reintentar
                </Button>
              </div>
            ) : (
              <div className="relative">
                <video 
                  ref={videoRef} 
                  className="w-full h-80 bg-black rounded-lg object-cover"
                  playsInline
                  muted
                  autoPlay
                />
                
                {/* Overlay de escaneado */}
                {!isScanning && (
                  <div className="absolute inset-0 flex items-center justify-center text-white bg-black bg-opacity-50 rounded-lg">
                    <div className="text-center">
                      <QrCode className="w-16 h-16 mx-auto mb-2 opacity-50" />
                      <p>Iniciando escáner...</p>
                    </div>
                  </div>
                )}
              </div>
            )}

            <div className="text-center space-y-2">
              <p className="text-sm text-gray-600">
                Coloca el código QR dentro del marco
              </p>
              <p className="text-xs text-gray-500">
                Soporta códigos QR y códigos de barras
              </p>
              {isScanning && (
                <div className="flex items-center justify-center gap-2 text-green-600">
                  <div className="w-2 h-2 bg-green-600 rounded-full animate-pulse"></div>
                  <span className="text-sm">Escaneando...</span>
                </div>
              )}
            </div>
          </div>

          {/* Información escaneada */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Información Escaneada</CardTitle>
              </CardHeader>
              <CardContent>
                {scannedData ? (
                  <div className="space-y-3">
                    <div className="bg-green-50 p-3 rounded-md">
                      <h4 className="font-semibold text-green-800 mb-2">
                        {scannedData.tipo || 'Datos encontrados'}
                      </h4>
                      <div className="space-y-1 text-sm">
                        {Object.entries(scannedData).map(([key, value]) => (
                          <div key={key} className="flex justify-between">
                            <span className="font-medium capitalize">{key}:</span>
                            <span className="text-right max-w-48 truncate">{String(value)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div className="text-center">
                      <Button onClick={handleManualClose} className="w-full">
                        <X className="w-4 h-4 mr-2" />
                        Cerrar y Usar Resultado
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <QrCode className="w-12 h-12 mx-auto mb-2 opacity-30" />
                    <p>Esperando código...</p>
                    <p className="text-xs">Los datos aparecerán aquí cuando se detecte un código</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={handleManualClose}>
            <X className="w-4 h-4 mr-2" />
            Cerrar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
