import { useCentralizedData } from '@/contexts/CentralizedDataContext';
import { useCentralizedAuth } from '@/hooks/useCentralizedAuth';

/**
 * Hook adaptador que simula la interfaz de localStorage/Supabase 
 * pero usando Firebase como backend
 */
export const useFirebaseAdapter = () => {
  const {
    clientes,
    inventario,
    ordenes,
    facturas,
    gastos,
    citas,
    addCliente,
    updateCliente,
    deleteCliente,
    addInventario,
    updateInventario,
    deleteInventario,
    addOrden,
    updateOrden,
    deleteOrden,
    addFactura,
    updateFactura,
    deleteFactura,
    addGasto,
    updateGasto,
    deleteGasto,
    addCita,
    updateCita,
    deleteCita,
    isOnline
  } = useCentralizedData();

  const { user, isAuthenticated } = useCentralizedAuth();

  // Simular localStorage para compatibilidad con componentes existentes
  const getItem = (key: string) => {
    switch (key) {
      case 'clientes':
        return JSON.stringify(clientes);
      case 'inventario':
        return JSON.stringify(inventario);
      case 'ordenes':
        return JSON.stringify(ordenes);
      case 'facturas':
        return JSON.stringify(facturas);
      case 'gastos_mercancia':
        return JSON.stringify(gastos);
      case 'citas':
        return JSON.stringify(citas);
      default:
        return localStorage.getItem(key);
    }
  };

  const setItem = async (key: string, value: string) => {
    try {
      const data = JSON.parse(value);
      
      switch (key) {
        case 'clientes':
          // Este método no es recomendado, mejor usar las funciones CRUD específicas
          console.warn('Usa addCliente/updateCliente en lugar de setItem para clientes');
          break;
        case 'inventario':
          console.warn('Usa addInventario/updateInventario en lugar de setItem para inventario');
          break;
        // ... otros casos
        default:
          localStorage.setItem(key, value);
      }
    } catch (error) {
      console.error('Error setting Firebase data:', error);
    }
  };

  // Funciones helper para componentes existentes
  const saveClientes = async (clientesList: any[]) => {
    // No recomendado, pero para compatibilidad
    console.warn('Método deprecated: usa addCliente/updateCliente individual');
  };

  const saveInventario = async (inventarioList: any[]) => {
    console.warn('Método deprecated: usa addInventario/updateInventario individual');
  };

  // Status del sistema
  const isFirebaseReady = isAuthenticated && isOnline;

  return {
    // Datos en tiempo real
    clientes,
    inventario,
    ordenes,
    facturas,
    gastos,
    citas,
    
    // Funciones CRUD (recomendadas)
    addCliente,
    updateCliente,
    deleteCliente,
    addInventario,
    updateInventario,
    deleteInventario,
    addOrden,
    updateOrden,
    deleteOrden,
    addFactura,
    updateFactura,
    deleteFactura,
    addGasto,
    updateGasto,
    deleteGasto,
    addCita,
    updateCita,
    deleteCita,
    
    // Compatibilidad localStorage (deprecated)
    getItem,
    setItem,
    saveClientes,
    saveInventario,
    
    // Estado
    user,
    isAuthenticated,
    isFirebaseReady,
    isOnline
  };
};
