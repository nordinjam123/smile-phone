import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { googleDriveService } from '@/lib/googleDriveService';

export const useGoogleAuth = () => {
  const [isGoogleConnected, setIsGoogleConnected] = useState(false);
  const [googleAccessToken, setGoogleAccessToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkGoogleConnection();
    
    // Listen for auth state changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (event === 'SIGNED_IN' && session?.provider_token) {
          setGoogleAccessToken(session.provider_token);
          setIsGoogleConnected(true);
          await googleDriveService.initializeGoogleDrive(session.provider_token);
        } else if (event === 'SIGNED_OUT') {
          setGoogleAccessToken(null);
          setIsGoogleConnected(false);
        }
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  const checkGoogleConnection = async () => {
    try {
      setLoading(true);
      const { data: { session } } = await supabase.auth.getSession();
      
      if (session?.provider_token) {
        setGoogleAccessToken(session.provider_token);
        setIsGoogleConnected(true);
        await googleDriveService.initializeGoogleDrive(session.provider_token);
      } else {
        setIsGoogleConnected(false);
        setGoogleAccessToken(null);
      }
    } catch (error) {
      console.error('Error checking Google connection:', error);
      setIsGoogleConnected(false);
      setGoogleAccessToken(null);
    } finally {
      setLoading(false);
    }
  };

  const connectGoogle = async (): Promise<{ success: boolean; error?: string }> => {
    try {
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          scopes: 'https://www.googleapis.com/auth/drive.file',
          redirectTo: `${window.location.origin}`,
          queryParams: {
            access_type: 'offline',
            prompt: 'consent',
          }
        }
      });

      if (error) throw error;
      return { success: true };
    } catch (error: any) {
      console.error('Error connecting to Google:', error);
      return { 
        success: false, 
        error: error.message || 'Error al conectar con Google Drive' 
      };
    }
  };

  const disconnectGoogle = async (): Promise<{ success: boolean; error?: string }> => {
    try {
      // Note: This will only sign out from Supabase, not revoke Google tokens
      // For full Google token revocation, additional API calls would be needed
      await supabase.auth.signOut();
      setIsGoogleConnected(false);
      setGoogleAccessToken(null);
      return { success: true };
    } catch (error: any) {
      console.error('Error disconnecting from Google:', error);
      return { 
        success: false, 
        error: error.message || 'Error al desconectar de Google Drive' 
      };
    }
  };

  return {
    isGoogleConnected,
    googleAccessToken,
    loading,
    connectGoogle,
    disconnectGoogle,
    checkGoogleConnection
  };
};
