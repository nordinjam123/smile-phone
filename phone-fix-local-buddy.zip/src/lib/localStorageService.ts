// 100% Local Storage Service - Sin dependencias externas
export interface LocalData {
  id: string;
  userId: string;
  createdAt: string;
  updatedAt: string;
  [key: string]: any;
}

class LocalStorageService {
  private generateId(): string {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  }

  private getUserKey(userId: string, collection: string): string {
    return `tallerpro_${userId}_${collection}`;
  }

  private getGlobalKey(collection: string): string {
    return `tallerpro_global_${collection}`;
  }

  // Create
  addDocument(collection: string, data: any, userId?: string): { id: string | null; error: string | null } {
    try {
      const id = this.generateId();
      const timestamp = new Date().toISOString();
      
      const document: LocalData = {
        ...data,
        id,
        userId: userId || 'anonymous',
        createdAt: timestamp,
        updatedAt: timestamp
      };

      const key = userId ? this.getUserKey(userId, collection) : this.getGlobalKey(collection);
      const existing = this.getCollection(key);
      
      existing.push(document);
      localStorage.setItem(key, JSON.stringify(existing));
      
      return { id, error: null };
    } catch (error: any) {
      return { id: null, error: error.message || 'Error guardando documento' };
    }
  }

  // Read
  getDocument(collection: string, docId: string, userId?: string): LocalData | null {
    try {
      const key = userId ? this.getUserKey(userId, collection) : this.getGlobalKey(collection);
      const documents = this.getCollection(key);
      
      return documents.find(doc => doc.id === docId) || null;
    } catch (error) {
      console.error('Error obteniendo documento:', error);
      return null;
    }
  }

  // Read all user documents
  getUserDocuments(collection: string, userId: string): LocalData[] {
    try {
      const key = this.getUserKey(userId, collection);
      const documents = this.getCollection(key);
      
      return documents.sort((a, b) => 
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
    } catch (error) {
      console.error('Error obteniendo documentos del usuario:', error);
      return [];
    }
  }

  // Update
  updateDocument(collection: string, docId: string, data: any, userId?: string): { success: boolean; error: string | null } {
    try {
      const key = userId ? this.getUserKey(userId, collection) : this.getGlobalKey(collection);
      const documents = this.getCollection(key);
      
      const index = documents.findIndex(doc => doc.id === docId);
      if (index === -1) {
        return { success: false, error: 'Documento no encontrado' };
      }

      documents[index] = {
        ...documents[index],
        ...data,
        updatedAt: new Date().toISOString()
      };

      localStorage.setItem(key, JSON.stringify(documents));
      return { success: true, error: null };
    } catch (error: any) {
      return { success: false, error: error.message || 'Error actualizando documento' };
    }
  }

  // Delete
  deleteDocument(collection: string, docId: string, userId?: string): { success: boolean; error: string | null } {
    try {
      const key = userId ? this.getUserKey(userId, collection) : this.getGlobalKey(collection);
      const documents = this.getCollection(key);
      
      const filteredDocuments = documents.filter(doc => doc.id !== docId);
      
      if (filteredDocuments.length === documents.length) {
        return { success: false, error: 'Documento no encontrado' };
      }

      localStorage.setItem(key, JSON.stringify(filteredDocuments));
      return { success: true, error: null };
    } catch (error: any) {
      return { success: false, error: error.message || 'Error eliminando documento' };
    }
  }

  // Subscribe to changes (simulated real-time)
  subscribeToUserDocuments(collection: string, userId: string, callback: (documents: LocalData[]) => void): () => void {
    // Initial call
    const documents = this.getUserDocuments(collection, userId);
    callback(documents);

    // Listen for storage changes
    const handleStorageChange = (event: StorageEvent) => {
      if (event.key === this.getUserKey(userId, collection)) {
        const updatedDocuments = this.getUserDocuments(collection, userId);
        callback(updatedDocuments);
      }
    };

    window.addEventListener('storage', handleStorageChange);

    // Return unsubscribe function
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }

  // Helper to get collection from storage
  private getCollection(key: string): LocalData[] {
    try {
      const stored = localStorage.getItem(key);
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('Error parsing stored data:', error);
      return [];
    }
  }

  // Migration from old storage format
  migrateFromOldStorage(): { success: boolean; migrated: number; errors: string[] } {
    const errors: string[] = [];
    let migrated = 0;

    const collectionMappings = {
      'clientes': 'clientes',
      'inventario': 'inventario',
      'ordenes': 'ordenes_trabajo',
      'facturas': 'facturas',
      'gastos_mercancia': 'gastos_mercancia',
      'citas': 'citas'
    };

    try {
      const userId = 'legacy_user'; // For old data without user association

      for (const [oldKey, newCollection] of Object.entries(collectionMappings)) {
        const oldData = localStorage.getItem(oldKey);
        if (oldData) {
          try {
            const items = JSON.parse(oldData);
            if (Array.isArray(items)) {
              for (const item of items) {
                const result = this.addDocument(newCollection, item, userId);
                if (result.error) {
                  errors.push(`Error migrando ${oldKey}: ${result.error}`);
                } else {
                  migrated++;
                }
              }
              // Remove old data after successful migration
              localStorage.removeItem(oldKey);
            }
          } catch (error: any) {
            errors.push(`Error procesando ${oldKey}: ${error.message}`);
          }
        }
      }

      return { success: errors.length === 0, migrated, errors };
    } catch (error: any) {
      return { success: false, migrated, errors: [error.message] };
    }
  }

  // Statistics
  getStorageStats(): { collections: number; totalDocuments: number; storageUsed: string } {
    let totalDocuments = 0;
    let collections = 0;
    let storageUsed = 0;

    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key?.startsWith('tallerpro_')) {
        collections++;
        const data = localStorage.getItem(key);
        if (data) {
          storageUsed += data.length;
          try {
            const parsed = JSON.parse(data);
            if (Array.isArray(parsed)) {
              totalDocuments += parsed.length;
            }
          } catch (error) {
            // Ignore parsing errors for stats
          }
        }
      }
    }

    return {
      collections,
      totalDocuments,
      storageUsed: (storageUsed / 1024).toFixed(2) + ' KB'
    };
  }

  // Clear all user data
  clearUserData(userId: string): void {
    const keysToRemove: string[] = [];
    
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key?.includes(`tallerpro_${userId}_`)) {
        keysToRemove.push(key);
      }
    }

    keysToRemove.forEach(key => localStorage.removeItem(key));
  }

  // Export data
  exportUserData(userId: string): { [collection: string]: LocalData[] } {
    const exportData: { [collection: string]: LocalData[] } = {};
    
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key?.includes(`tallerpro_${userId}_`)) {
        const collection = key.split('_')[2];
        const data = localStorage.getItem(key);
        if (data) {
          try {
            exportData[collection] = JSON.parse(data);
          } catch (error) {
            console.error(`Error exporting ${collection}:`, error);
          }
        }
      }
    }

    return exportData;
  }

  // Import data
  importUserData(userId: string, data: { [collection: string]: LocalData[] }): { success: boolean; errors: string[] } {
    const errors: string[] = [];

    try {
      for (const [collection, documents] of Object.entries(data)) {
        const key = this.getUserKey(userId, collection);
        localStorage.setItem(key, JSON.stringify(documents));
      }

      return { success: true, errors: [] };
    } catch (error: any) {
      errors.push(error.message || 'Error importando datos');
      return { success: false, errors };
    }
  }
}

export const localStorageService = new LocalStorageService();
