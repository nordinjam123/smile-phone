// Auto-configuración para WhatsApp Web
export interface WhatsAppAutoConfig {
  enabled: boolean;
  templates: {
    orderReceived: {
      enabled: boolean;
      message: string;
    };
    orderCompleted: {
      enabled: boolean;
      message: string;
    };
    orderInProgress: {
      enabled: boolean;
      message: string;
    };
    orderDelivered: {
      enabled: boolean;
      message: string;
    };
    invoiceCreated: {
      enabled: boolean;
      message: string;
    };
    reminder: {
      enabled: boolean;
      message: string;
    };
  };
}

const DEFAULT_TEMPLATES = {
  orderReceived: `🔧 *{{empresa}}* - Nueva Orden Recibida

Hola {{cliente}}, 👋

✅ Hemos recibido tu {{dispositivo}} {{marca}} {{modelo}}

📋 *Detalles:*
• Orden: #{{ordenId}}
• Problema: {{problema}}
• Fecha: {{fecha}}

⏰ Te mantendremos informado del progreso de la reparación.

📞 Contacto: {{telefono_empresa}}
📍 {{direccion}}

¡Gracias por confiar en nosotros! 🛠️`,

  orderCompleted: `✅ *{{empresa}}* - Reparación Completada

¡Hola {{cliente}}! 🎉

✅ Tu {{dispositivo}} {{marca}} {{modelo}} está LISTO para recoger!

📋 *Detalles:*
• Orden: #{{ordenId}}
• Precio: {{precio}}€
• Fecha: {{fecha}}

🏪 *Pasa a recogerlo cuando puedas:*
📍 {{direccion}}
📞 {{telefono_empresa}}

¡Muchas gracias! 😊`,

  orderInProgress: `🔧 *{{empresa}}* - Reparación en Proceso

Hola {{cliente}}, 👋

🔄 Tu {{dispositivo}} {{marca}} {{modelo}} está siendo reparado.

📋 *Estado actual:*
• Orden: #{{ordenId}}
• Estado: En proceso
• Fecha: {{fecha}}

⏰ Te avisaremos cuando esté listo.

📞 Contacto: {{telefono_empresa}}`,

  orderDelivered: `📦 *{{empresa}}* - Entrega Confirmada

¡Hola {{cliente}}! ✅

📦 Tu {{dispositivo}} {{marca}} {{modelo}} ha sido entregado correctamente.

📋 *Resumen:*
• Orden: #{{ordenId}}
• Entregado: {{fecha}}

😊 ¡Esperamos que disfrutes tu dispositivo reparado!

⭐ *¿Te gustó nuestro servicio?*
Nos ayudarías mucho con una reseña positiva.

🔧 *{{empresa}}*
📞 {{telefono_empresa}}
📍 {{direccion}}

¡Hasta la próxima! 👋`,

  invoiceCreated: `🧾 *{{empresa}}* - Nueva Factura

Hola {{cliente}}, 👋

📄 Hemos generado tu factura:

📋 *Detalles:*
• Número: {{numeroFactura}}
• Total: {{total}}€
• Fecha: {{fecha}}
• Estado: {{estado}}

📞 Contacto: {{telefono_empresa}}

¡Gracias por tu confianza! 😊`,

  reminder: `⏰ *{{empresa}}* - Recordatorio de Recogida

Hola {{cliente}}, 👋

🔔 Recordatorio amigable: Tu {{dispositivo}} está listo para recoger desde hace {{dias}} días.

📋 *Detalles:*
• Orden: #{{ordenId}}

🏪 *Horario de recogida:*
📍 {{direccion}}
📞 {{telefono_empresa}}

¡Te esperamos! 😊`
};

// Función para auto-configurar WhatsApp si no está configurado
export function autoConfigureWhatsApp(): boolean {
  try {
    const savedConfig = localStorage.getItem('whatsapp_web_config');
    
    // Si ya está configurado, no hacer nada
    if (savedConfig) {
      const config = JSON.parse(savedConfig);
      // Si está habilitado, ya está bien
      if (config.enabled) {
        return true;
      }
    }

    // Auto-configurar con plantillas predeterminadas
    const autoConfig: WhatsAppAutoConfig = {
      enabled: true, // ✅ Activar automáticamente
      templates: {
        orderReceived: {
          enabled: true,
          message: DEFAULT_TEMPLATES.orderReceived
        },
        orderCompleted: {
          enabled: true,
          message: DEFAULT_TEMPLATES.orderCompleted
        },
        orderInProgress: {
          enabled: true,
          message: DEFAULT_TEMPLATES.orderInProgress
        },
        orderDelivered: {
          enabled: true,
          message: DEFAULT_TEMPLATES.orderDelivered
        },
        invoiceCreated: {
          enabled: true,
          message: DEFAULT_TEMPLATES.invoiceCreated
        },
        reminder: {
          enabled: true,
          message: DEFAULT_TEMPLATES.reminder
        }
      }
    };

    // Guardar configuración automática
    localStorage.setItem('whatsapp_web_config', JSON.stringify(autoConfig));
    
    console.log('✅ WhatsApp auto-configurado correctamente');
    return true;
  } catch (error) {
    console.error('❌ Error en auto-configuración de WhatsApp:', error);
    return false;
  }
}

// Función para verificar y activar WhatsApp si es necesario
export function ensureWhatsAppIsEnabled(): boolean {
  try {
    const savedConfig = localStorage.getItem('whatsapp_web_config');
    
    if (!savedConfig) {
      // No hay configuración, auto-configurar
      return autoConfigureWhatsApp();
    }

    const config = JSON.parse(savedConfig);
    
    // Si no está habilitado, habilitarlo
    if (!config.enabled) {
      config.enabled = true;
      localStorage.setItem('whatsapp_web_config', JSON.stringify(config));
      console.log('✅ WhatsApp habilitado automáticamente');
      return true;
    }

    return true;
  } catch (error) {
    console.error('❌ Error verificando WhatsApp:', error);
    return false;
  }
}

// Función para obtener configuración con auto-configuración
export function getWhatsAppConfigWithAutoSetup(): WhatsAppAutoConfig {
  ensureWhatsAppIsEnabled();
  
  try {
    const savedConfig = localStorage.getItem('whatsapp_web_config');
    if (savedConfig) {
      return JSON.parse(savedConfig);
    }
  } catch (error) {
    console.error('Error loading WhatsApp config:', error);
  }

  // Si falla, usar configuración por defecto activada
  return {
    enabled: true,
    templates: {
      orderReceived: { enabled: true, message: DEFAULT_TEMPLATES.orderReceived },
      orderCompleted: { enabled: true, message: DEFAULT_TEMPLATES.orderCompleted },
      orderInProgress: { enabled: true, message: DEFAULT_TEMPLATES.orderInProgress },
      orderDelivered: { enabled: true, message: DEFAULT_TEMPLATES.orderDelivered },
      invoiceCreated: { enabled: true, message: DEFAULT_TEMPLATES.invoiceCreated },
      reminder: { enabled: true, message: DEFAULT_TEMPLATES.reminder }
    }
  };
}
