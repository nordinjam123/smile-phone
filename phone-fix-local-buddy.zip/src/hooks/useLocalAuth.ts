import { useState, useEffect } from 'react';
import { localAuthService, LocalUser } from '@/lib/localAuthService';

interface UseLocalAuthReturn {
  user: LocalUser | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  signIn: (email: string, password: string) => Promise<{ user: LocalUser | null; error: string | null }>;
  signUp: (email: string, password: string, additionalData?: any) => Promise<{ user: LocalUser | null; error: string | null }>;
  signOut: () => Promise<{ success: boolean; error: string | null }>;
}

export const useLocalAuth = (): UseLocalAuthReturn => {
  const [user, setUser] = useState<LocalUser | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Set initial user
    const currentUser = localAuthService.getCurrentUser();
    setUser(currentUser);
    setIsAuthenticated(!!currentUser);
    setIsLoading(false);

    // Listen for auth changes
    const unsubscribe = localAuthService.onAuthStateChanged((newUser) => {
      setUser(newUser);
      setIsAuthenticated(!!newUser);
      setIsLoading(false);
    });

    return unsubscribe;
  }, []);

  const signIn = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      const result = await localAuthService.signInWithEmail(email, password);
      return result;
    } finally {
      setIsLoading(false);
    }
  };

  const signUp = async (email: string, password: string, additionalData?: any) => {
    setIsLoading(true);
    try {
      const result = await localAuthService.signUpWithEmail(email, password, additionalData);
      return result;
    } finally {
      setIsLoading(false);
    }
  };

  const signOut = async () => {
    setIsLoading(true);
    try {
      const result = await localAuthService.signOut();
      return result;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    user,
    isAuthenticated,
    isLoading,
    signIn,
    signUp,
    signOut
  };
};
