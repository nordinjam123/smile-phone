import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  CheckCircle, 
  Circle, 
  ArrowRight, 
  ExternalLink,
  Copy,
  DollarSign,
  Database,
  Shield,
  Zap,
  Users,
  BarChart3,
  Cloud
} from 'lucide-react';

const GoogleCloudSetupGuide: React.FC = () => {
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);
  const [currentStep, setCurrentStep] = useState(1);

  const steps = [
    {
      id: 1,
      title: "Verificar Créditos Google Cloud",
      description: "Confirmar que tienes los 300€ disponibles",
      url: "https://console.cloud.google.com",
      details: [
        "Ir a Google Cloud Console",
        "Verificar créditos en esquina superior derecha",
        "Anotar nombre de la cuenta de facturación"
      ]
    },
    {
      id: 2, 
      title: "Crear Proyecto Firebase",
      description: "Configurar proyecto optimizado para TallerPro",
      url: "https://console.firebase.google.com",
      details: [
        "Nombre: tallerpro-admin-2024",
        "Habilitar Google Analytics",
        "Región: europe-west1 (Bélgica)",
        "Conectar cuenta de facturación"
      ]
    },
    {
      id: 3,
      title: "Configurar Authentication", 
      description: "Habilitar login con Google y email",
      details: [
        "Ir a Authentication → Get started",
        "Habilitar Email/Password",
        "Habilitar Google OAuth",
        "Configurar email de soporte"
      ]
    },
    {
      id: 4,
      title: "Crear Firestore Database",
      description: "Base de datos en tiempo real con reglas de seguridad",
      details: [
        "Crear database en modo test",
        "Ubicación: europe-west1", 
        "Configurar reglas de aislamiento",
        "Publicar reglas de seguridad"
      ]
    },
    {
      id: 5,
      title: "Configurar App Web",
      description: "Obtener credenciales para TallerPro",
      details: [
        "Agregar app web '<>'",
        "Nombre: TallerPro Admin Web",
        "Copiar configuración firebaseConfig",
        "Guardar credenciales seguras"
      ]
    },
    {
      id: 6,
      title: "Conectar TallerPro",
      description: "Actualizar código con tu configuración",
      details: [
        "Editar centralizedFirebaseService.ts",
        "Reemplazar CENTRALIZED_FIREBASE_CONFIG",
        "Guardar y refresh página",
        "Verificar logs: '🔥 Firebase inicializado'"
      ]
    },
    {
      id: 7,
      title: "Probar Sistema",
      description: "Verificar que todo funcione correctamente",
      details: [
        "Login con Google en TallerPro",
        "Crear cliente de prueba",
        "Verificar datos en Firebase Console",
        "Test multi-usuario en ventana incógnita"
      ]
    },
    {
      id: 8,
      title: "Configurar Monitoreo",
      description: "Alertas y seguimiento de gastos",
      details: [
        "Configurar presupuesto $20/mes",
        "Alertas al 50%, 90%, 100%",
        "Revisar métricas Firebase",
        "Activar funciones premium opcionales"
      ]
    }
  ];

  const toggleStep = (stepId: number) => {
    if (completedSteps.includes(stepId)) {
      setCompletedSteps(completedSteps.filter(id => id !== stepId));
    } else {
      setCompletedSteps([...completedSteps, stepId]);
    }
  };

  const copyConfig = () => {
    const configTemplate = `// REEMPLAZA en src/lib/centralizedFirebaseService.ts
const CENTRALIZED_FIREBASE_CONFIG = {
  apiKey: "TU_API_KEY_AQUI",
  authDomain: "tallerpro-admin-2024.firebaseapp.com",
  projectId: "tallerpro-admin-2024",
  storageBucket: "tallerpro-admin-2024.appspot.com", 
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:abc123def456789"
};`;
    navigator.clipboard.writeText(configTemplate);
  };

  const copyRules = () => {
    const rules = `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{collection}/{document} {
      allow read, write: if request.auth != null && 
        (resource == null || resource.data.workspaceId == request.auth.uid);
    }
    
    match /users/{userId} {
      allow read, write: if request.auth != null && 
        request.auth.uid == userId;
    }
    
    match /test/{document} {
      allow read: if request.auth != null;
    }
  }
}`;
    navigator.clipboard.writeText(rules);
  };

  const progress = (completedSteps.length / steps.length) * 100;

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-3 mb-4">
          <div className="p-3 bg-gradient-to-br from-green-500 to-blue-500 rounded-xl">
            <DollarSign className="h-8 w-8 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              Configurar Firebase con tus 300€ de Google Cloud
            </h1>
            <p className="text-lg text-gray-600">
              Guía paso a paso para aprovechar tus créditos gratuitos
            </p>
          </div>
        </div>

        <div className="bg-gradient-to-r from-green-50 to-blue-50 p-6 rounded-xl border border-green-200">
          <h3 className="font-semibold text-green-900 mb-3">💰 Con 300€ podrás servir:</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div className="bg-white p-3 rounded-lg">
              <Users className="h-6 w-6 mx-auto mb-1 text-blue-500" />
              <div className="text-sm font-medium">100+ talleres</div>
              <div className="text-xs text-gray-500">6+ meses</div>
            </div>
            <div className="bg-white p-3 rounded-lg">
              <Database className="h-6 w-6 mx-auto mb-1 text-green-500" />
              <div className="text-sm font-medium">Ilimitado</div>
              <div className="text-xs text-gray-500">Datos</div>
            </div>
            <div className="bg-white p-3 rounded-lg">
              <Shield className="h-6 w-6 mx-auto mb-1 text-purple-500" />
              <div className="text-sm font-medium">Enterprise</div>
              <div className="text-xs text-gray-500">Seguridad</div>
            </div>
            <div className="bg-white p-3 rounded-lg">
              <BarChart3 className="h-6 w-6 mx-auto mb-1 text-orange-500" />
              <div className="text-sm font-medium">Analytics</div>
              <div className="text-xs text-gray-500">Incluido</div>
            </div>
          </div>
        </div>

        {/* Progress */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>Progreso de configuración</span>
            <span>{completedSteps.length}/{steps.length} completados</span>
          </div>
          <Progress value={progress} className="h-3" />
        </div>
      </div>

      {/* Steps */}
      <div className="space-y-4">
        {steps.map((step, index) => (
          <Card 
            key={step.id}
            className={`transition-all duration-200 ${
              completedSteps.includes(step.id) 
                ? 'border-green-200 bg-green-50' 
                : currentStep === step.id
                  ? 'border-blue-200 bg-blue-50'
                  : 'border-gray-200'
            }`}
          >
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => toggleStep(step.id)}
                    className="p-0 h-auto"
                  >
                    {completedSteps.includes(step.id) ? (
                      <CheckCircle className="h-6 w-6 text-green-600" />
                    ) : (
                      <Circle className="h-6 w-6 text-gray-400" />
                    )}
                  </Button>
                  <div>
                    <CardTitle className="text-lg">
                      Paso {step.id}: {step.title}
                    </CardTitle>
                    <CardDescription>{step.description}</CardDescription>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  {step.url && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => window.open(step.url, '_blank')}
                    >
                      <ExternalLink className="h-4 w-4 mr-1" />
                      Abrir
                    </Button>
                  )}
                  {!completedSteps.includes(step.id) && (
                    <Badge variant="outline">Pendiente</Badge>
                  )}
                  {completedSteps.includes(step.id) && (
                    <Badge className="bg-green-100 text-green-800">Completado</Badge>
                  )}
                </div>
              </div>
            </CardHeader>
            
            <CardContent>
              <div className="space-y-3">
                <ul className="space-y-2">
                  {step.details.map((detail, idx) => (
                    <li key={idx} className="flex items-center gap-2 text-sm">
                      <ArrowRight className="h-3 w-3 text-blue-500 flex-shrink-0" />
                      <span>{detail}</span>
                    </li>
                  ))}
                </ul>
                
                {/* Helpers específicos */}
                {step.id === 4 && (
                  <Alert>
                    <Shield className="h-4 w-4" />
                    <AlertDescription>
                      <div className="flex items-center justify-between">
                        <span>Reglas de seguridad para copiar en Firestore:</span>
                        <Button variant="outline" size="sm" onClick={copyRules}>
                          <Copy className="h-4 w-4 mr-1" />
                          Copiar Reglas
                        </Button>
                      </div>
                    </AlertDescription>
                  </Alert>
                )}
                
                {step.id === 6 && (
                  <Alert>
                    <Database className="h-4 w-4" />
                    <AlertDescription>
                      <div className="flex items-center justify-between">
                        <span>Plantilla de configuración para TallerPro:</span>
                        <Button variant="outline" size="sm" onClick={copyConfig}>
                          <Copy className="h-4 w-4 mr-1" />
                          Copiar Config
                        </Button>
                      </div>
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Final Success */}
      {completedSteps.length === steps.length && (
        <Card className="border-green-200 bg-gradient-to-r from-green-50 to-blue-50">
          <CardContent className="pt-6">
            <div className="text-center space-y-4">
              <div className="flex justify-center">
                <div className="p-4 bg-green-100 rounded-full">
                  <CheckCircle className="h-12 w-12 text-green-600" />
                </div>
              </div>
              <div>
                <h3 className="text-2xl font-bold text-green-900 mb-2">
                  🎉 ¡Configuración Completa!
                </h3>
                <p className="text-green-700 mb-4">
                  TallerPro está conectado a tu Firebase con créditos de Google Cloud
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                  <div className="bg-white p-4 rounded-lg border border-green-200">
                    <Cloud className="h-8 w-8 text-blue-500 mx-auto mb-2" />
                    <h4 className="font-medium mb-1">Infraestructura Lista</h4>
                    <p className="text-sm text-gray-600">Firebase enterprise configurado</p>
                  </div>
                  <div className="bg-white p-4 rounded-lg border border-green-200">
                    <Zap className="h-8 w-8 text-yellow-500 mx-auto mb-2" />
                    <h4 className="font-medium mb-1">Créditos Activos</h4>
                    <p className="text-sm text-gray-600">300€ para meses de operación</p>
                  </div>
                  <div className="bg-white p-4 rounded-lg border border-green-200">
                    <Users className="h-8 w-8 text-green-500 mx-auto mb-2" />
                    <h4 className="font-medium mb-1">Listo para Clientes</h4>
                    <p className="text-sm text-gray-600">Sin configuración adicional</p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Help Section */}
      <Card className="border-blue-200 bg-blue-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-blue-600" />
            ¿Necesitas ayuda?
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="font-medium mb-2">📖 Documentación detallada:</h4>
              <p className="text-sm text-gray-700 mb-2">
                Revisa GOOGLE_CLOUD_300_EUROS_SETUP.md para guía completa
              </p>
            </div>
            <div>
              <h4 className="font-medium mb-2">🛠️ Troubleshooting:</h4>
              <p className="text-sm text-gray-700">
                Si algo falla, revisa la consola del navegador (F12) para errores específicos
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default GoogleCloudSetupGuide;
