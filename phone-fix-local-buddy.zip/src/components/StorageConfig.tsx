import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { 
  Cloud, 
  HardDrive, 
  Wifi, 
  WifiOff, 
  RefreshCw, 
  Settings, 
  CheckCircle, 
  AlertCircle,
  Clock,
  Database
} from 'lucide-react';

type StorageMode = 'local' | 'cloud' | 'hybrid';

interface StorageConfig {
  mode: StorageMode;
  autoSync: boolean;
  syncInterval: number;
  compression: boolean;
  backupFrequency: 'daily' | 'weekly' | 'monthly';
}

interface StorageStats {
  localSize: number;
  cloudSize: number;
  lastSync: Date | null;
  pendingChanges: number;
}

export default function StorageConfig() {
  const [config, setConfig] = useState<StorageConfig>({
    mode: 'hybrid',
    autoSync: true,
    syncInterval: 30,
    compression: true,
    backupFrequency: 'weekly'
  });

  const [stats, setStats] = useState<StorageStats>({
    localSize: 0,
    cloudSize: 0,
    lastSync: null,
    pendingChanges: 0
  });

  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [syncing, setSyncing] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    // Cargar configuración guardada
    const savedConfig = localStorage.getItem('storageConfig');
    if (savedConfig) {
      setConfig(JSON.parse(savedConfig));
    }

    // Calcular estadísticas de almacenamiento
    calculateStorageStats();

    // Detectar estado de conexión
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const calculateStorageStats = () => {
    let totalSize = 0;
    let pendingCount = 0;

    // Calcular tamaño del localStorage
    for (let key in localStorage) {
      if (localStorage.hasOwnProperty(key)) {
        const value = localStorage.getItem(key);
        if (value) {
          totalSize += value.length;
          
          // Verificar si hay cambios pendientes
          if (key.includes('_pending') || key.includes('_dirty')) {
            pendingCount++;
          }
        }
      }
    }

    const lastSyncStr = localStorage.getItem('lastCloudSync');
    const lastSync = lastSyncStr ? new Date(lastSyncStr) : null;

    setStats({
      localSize: totalSize,
      cloudSize: totalSize * 0.8, // Estimación
      lastSync,
      pendingChanges: pendingCount
    });
  };

  const saveConfig = () => {
    localStorage.setItem('storageConfig', JSON.stringify(config));
    toast({
      title: "Configuración guardada",
      description: "Las preferencias de almacenamiento se han actualizado",
      variant: "default"
    });
  };

  const handleSync = async () => {
    setSyncing(true);
    try {
      // Simular sincronización (aquí integrarías con tu hook useHybridStorage)
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      localStorage.setItem('lastCloudSync', new Date().toISOString());
      calculateStorageStats();
      
      toast({
        title: "Sincronización completa",
        description: "Todos los datos están actualizados",
        variant: "default"
      });
    } catch (error) {
      toast({
        title: "Error de sincronización",
        description: "No se pudo completar la sincronización",
        variant: "destructive"
      });
    } finally {
      setSyncing(false);
    }
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getModeIcon = (mode: StorageMode) => {
    switch (mode) {
      case 'local': return <HardDrive className="w-4 h-4" />;
      case 'cloud': return <Cloud className="w-4 h-4" />;
      case 'hybrid': return <Database className="w-4 h-4" />;
    }
  };

  const getModeDescription = (mode: StorageMode) => {
    switch (mode) {
      case 'local': return 'Datos guardados solo en tu dispositivo. Sin sincronización.';
      case 'cloud': return 'Datos guardados en la nube. Requiere conexión a internet.';
      case 'hybrid': return 'Datos locales + nube. Funciona offline y sincroniza automáticamente.';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header con estado de conexión */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Settings className="w-5 h-5" />
              Configuración de Almacenamiento
            </div>
            <div className="flex items-center gap-2">
              {isOnline ? (
                <Badge variant="default" className="bg-green-100 text-green-800">
                  <Wifi className="w-3 h-3 mr-1" />
                  Online
                </Badge>
              ) : (
                <Badge variant="destructive">
                  <WifiOff className="w-3 h-3 mr-1" />
                  Offline
                </Badge>
              )}
            </div>
          </CardTitle>
        </CardHeader>
      </Card>

      {/* Estadísticas de almacenamiento */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Almacenamiento Local</p>
                <p className="text-2xl font-bold">{formatBytes(stats.localSize)}</p>
              </div>
              <HardDrive className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Almacenamiento Nube</p>
                <p className="text-2xl font-bold">{formatBytes(stats.cloudSize)}</p>
              </div>
              <Cloud className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Cambios Pendientes</p>
                <p className="text-2xl font-bold text-orange-600">{stats.pendingChanges}</p>
              </div>
              <Clock className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Configuración principal */}
      <Card>
        <CardHeader>
          <CardTitle>Modo de Almacenamiento</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Selector de modo */}
          <div className="space-y-3">
            <Label>Tipo de Almacenamiento</Label>
            <Select value={config.mode} onValueChange={(value: StorageMode) => setConfig({...config, mode: value})}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="local">
                  <div className="flex items-center gap-2">
                    <HardDrive className="w-4 h-4" />
                    Solo Local
                  </div>
                </SelectItem>
                <SelectItem value="cloud">
                  <div className="flex items-center gap-2">
                    <Cloud className="w-4 h-4" />
                    Solo Nube
                  </div>
                </SelectItem>
                <SelectItem value="hybrid">
                  <div className="flex items-center gap-2">
                    <Database className="w-4 h-4" />
                    Híbrido (Recomendado)
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
            <p className="text-sm text-muted-foreground">
              {getModeDescription(config.mode)}
            </p>
          </div>

          {/* Configuración de sincronización */}
          {(config.mode === 'cloud' || config.mode === 'hybrid') && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="autoSync">Sincronización Automática</Label>
                  <p className="text-sm text-muted-foreground">
                    Sincronizar cambios automáticamente con la nube
                  </p>
                </div>
                <Switch
                  id="autoSync"
                  checked={config.autoSync}
                  onCheckedChange={(checked) => setConfig({...config, autoSync: checked})}
                />
              </div>

              {config.autoSync && (
                <div className="space-y-2">
                  <Label>Intervalo de Sincronización</Label>
                  <Select 
                    value={config.syncInterval.toString()} 
                    onValueChange={(value) => setConfig({...config, syncInterval: parseInt(value)})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="5">Cada 5 minutos</SelectItem>
                      <SelectItem value="15">Cada 15 minutos</SelectItem>
                      <SelectItem value="30">Cada 30 minutos</SelectItem>
                      <SelectItem value="60">Cada hora</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
          )}

          {/* Configuración avanzada */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="compression">Compresión de Datos</Label>
                <p className="text-sm text-muted-foreground">
                  Reducir el tamaño de los datos almacenados
                </p>
              </div>
              <Switch
                id="compression"
                checked={config.compression}
                onCheckedChange={(checked) => setConfig({...config, compression: checked})}
              />
            </div>

            <div className="space-y-2">
              <Label>Frecuencia de Backup</Label>
              <Select 
                value={config.backupFrequency} 
                onValueChange={(value: 'daily' | 'weekly' | 'monthly') => setConfig({...config, backupFrequency: value})}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Diario</SelectItem>
                  <SelectItem value="weekly">Semanal</SelectItem>
                  <SelectItem value="monthly">Mensual</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Estado de sincronización */}
          {stats.lastSync && (
            <div className="bg-muted p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span className="text-sm font-medium">Última sincronización</span>
              </div>
              <p className="text-sm text-muted-foreground">
                {stats.lastSync.toLocaleString('es-ES')}
              </p>
            </div>
          )}

          {/* Botones de acción */}
          <div className="flex gap-2">
            <Button onClick={saveConfig}>
              Guardar Configuración
            </Button>
            
            {(config.mode === 'cloud' || config.mode === 'hybrid') && isOnline && (
              <Button 
                variant="outline" 
                onClick={handleSync}
                disabled={syncing}
              >
                {syncing ? (
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <RefreshCw className="w-4 h-4 mr-2" />
                )}
                Sincronizar Ahora
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Advertencias y recomendaciones */}
      {!isOnline && config.mode === 'cloud' && (
        <Card className="border-orange-200 bg-orange-50">
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-orange-600" />
              <div>
                <p className="font-medium text-orange-800">Sin conexión</p>
                <p className="text-sm text-orange-700">
                  El modo "Solo Nube" requiere conexión a internet. Considera cambiar a modo "Híbrido" para trabajar offline.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
