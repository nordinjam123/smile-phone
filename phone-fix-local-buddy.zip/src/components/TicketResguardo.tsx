import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Printer, Settings, Plus, Trash2 } from "lucide-react";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import QRCode from "qrcode";
import { useEmpresaConfig } from "@/hooks/useEmpresaConfig";

interface TicketResguardoProps {
  orden: {
    id: string;
    cliente: string;
    telefono: string;
    email?: string;
    dispositivo: string;
    marca: string;
    modelo: string;
    descripcionProblema: string;
    fechaRecepcion: string;
    imei?: string;
    precio?: number;
  };
}

export const TicketResguardo: React.FC<TicketResguardoProps> = ({ orden }) => {
  const { config: configuracion } = useEmpresaConfig();

  const [camposPersonalizados, setCamposPersonalizados] = useLocalStorage("camposTicket", [] as Array<{id: string, etiqueta: string, valor: string}>);
  const [tempCampos, setTempCampos] = useState(camposPersonalizados);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [qrCodeUrl, setQrCodeUrl] = useState<string>("");
  const [qrMovilUrl, setQrMovilUrl] = useState<string>("");

  useEffect(() => {
    const generateQRs = async () => {
      try {
        // QR para la orden completa
        const ordenData = {
          id: orden.id,
          tipo: 'ORDEN_TRABAJO',
          cliente: orden.cliente,
          dispositivo: orden.dispositivo,
          marca: orden.marca,
          modelo: orden.modelo,
          fecha: orden.fechaRecepcion,
          precio: orden.precio,
          empresa: {
            nombre: configuracion.nombreEmpresa || 'TECHREPAIR PRO',
            telefono: configuracion.telefono || '',
            email: configuracion.email || ''
          }
        };

        const qrDataString = JSON.stringify(ordenData);
        const qrCodeDataURL = await QRCode.toDataURL(qrDataString, {
          width: 128,
          margin: 2,
          color: {
            dark: '#000000',
            light: '#FFFFFF'
          },
          errorCorrectionLevel: 'M'
        });

        setQrCodeUrl(qrCodeDataURL);

        // QR específico para identificación del móvil
        const movilData = {
          cliente: orden.cliente,
          telefono: orden.telefono,
          dispositivo: orden.dispositivo,
          marca: orden.marca,
          modelo: orden.modelo,
          imei: orden.imei || '',
          orden_id: orden.id,
          tipo: 'IDENTIFICACION_MOVIL',
          empresa: configuracion.nombreEmpresa || 'TECHREPAIR PRO',
          empresa_telefono: configuracion.telefono || ''
        };

        const qrMovilString = JSON.stringify(movilData);
        const qrMovilDataURL = await QRCode.toDataURL(qrMovilString, {
          width: 96,
          margin: 1,
          color: {
            dark: '#000000',
            light: '#FFFFFF'
          },
          errorCorrectionLevel: 'H'
        });

        setQrMovilUrl(qrMovilDataURL);

      } catch (error) {
        console.error('Error generando códigos QR:', error);
        // Mantener los QR vacíos si hay error
        setQrCodeUrl("");
        setQrMovilUrl("");
      }
    };

    generateQRs();
  }, [orden]);

  const handleSaveConfig = () => {
    // La configuración de empresa ahora se maneja centralizadamente
    // Solo guardamos los campos personalizados
    setCamposPersonalizados(tempCampos);
    setIsDialogOpen(false);
  };

  const handleAddCampo = () => {
    const newCampo = {
      id: Date.now().toString(),
      etiqueta: "",
      valor: ""
    };
    setTempCampos([...tempCampos, newCampo]);
  };

  const handleDeleteCampo = (id: string) => {
    setTempCampos(tempCampos.filter(campo => campo.id !== id));
  };

  const handleUpdateCampo = (id: string, field: 'etiqueta' | 'valor', value: string) => {
    setTempCampos(tempCampos.map(campo => 
      campo.id === id ? { ...campo, [field]: value } : campo
    ));
  };

  const handleImprimir = async (tipoImpresion: 'termica' | 'papel') => {
    const jsPDF = (await import('jspdf')).default;

    // Calcular altura dinámica basada en contenido
    const baseHeight = 200;
    const extraHeight = camposPersonalizados.length * 10 + (orden.imei ? 10 : 0);
    const dynamicHeight = Math.max(baseHeight, baseHeight + extraHeight);

    const doc = new jsPDF({
      format: [80, dynamicHeight],
      unit: 'mm'
    });

    let y = 10;
    const margen = 5;
    const anchoUtil = 70;

    // Header con datos de la empresa
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text(configuracion.nombreEmpresa || "TECHREPAIR PRO", 40, y, { align: 'center' });
    y += 8;

    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    if (configuracion.telefono && configuracion.telefono.trim()) {
      doc.text(`Tel: ${configuracion.telefono}`, 40, y, { align: 'center' });
      y += 5;
    }
    if (configuracion.direccion && configuracion.direccion.trim()) {
      doc.text(`${configuracion.direccion}`, 40, y, { align: 'center' });
      y += 5;
    }
    if (configuracion.email && configuracion.email.trim()) {
      doc.text(`Email: ${configuracion.email}`, 40, y, { align: 'center' });
      y += 5;
    }
    if (configuracion.cif && configuracion.cif.trim()) {
      doc.text(`${configuracion.tipoDocumento || 'CIF'}: ${configuracion.cif}`, 40, y, { align: 'center' });
      y += 5;
    }

    // Línea separadora
    y += 3;
    doc.setLineWidth(0.5);
    doc.line(margen, y, anchoUtil, y);
    y += 7;

    // Título
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text('ORDEN DE REPARACIÓN', 40, y, { align: 'center' });
    y += 8;

    // Información de la orden
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text(`Nº Orden: ${orden.id}`, margen, y);
    y += 5;
    doc.text(`Fecha: ${new Date(orden.fechaRecepcion).toLocaleDateString('es-ES')}`, margen, y);
    y += 8;

    // Datos del cliente
    doc.setFont('helvetica', 'bold');
    doc.text('DATOS DEL CLIENTE', margen, y);
    y += 5;
    doc.setFont('helvetica', 'normal');
    doc.text(`Cliente: ${orden.cliente}`, margen, y);
    y += 4;
    doc.text(`Teléfono: ${orden.telefono}`, margen, y);
    y += 4;
    if (orden.email) {
      doc.text(`Email: ${orden.email}`, margen, y);
      y += 4;
    }
    y += 4;

    // Datos del dispositivo
    doc.setFont('helvetica', 'bold');
    doc.text('DATOS DEL DISPOSITIVO', margen, y);
    y += 5;
    doc.setFont('helvetica', 'normal');
    doc.text(`Tipo: ${orden.dispositivo}`, margen, y);
    y += 4;
    doc.text(`Marca: ${orden.marca}`, margen, y);
    y += 4;
    doc.text(`Modelo: ${orden.modelo}`, margen, y);
    y += 4;
    if (orden.imei) {
      doc.text(`IMEI: ${orden.imei}`, margen, y);
      y += 4;
    }
    y += 4;

    // Problema reportado
    doc.setFont('helvetica', 'bold');
    doc.text('PROBLEMA REPORTADO', margen, y);
    y += 5;
    doc.setFont('helvetica', 'normal');

    // Dividir descripción en líneas
    const palabras = orden.descripcionProblema.split(' ');
    let lineaActual = '';
    palabras.forEach(palabra => {
      const lineaTemporal = lineaActual + (lineaActual ? ' ' : '') + palabra;
      if (lineaTemporal.length > 35) {
        if (lineaActual) {
          doc.text(lineaActual, margen, y);
          y += 4;
        }
        lineaActual = palabra;
      } else {
        lineaActual = lineaTemporal;
      }
    });
    if (lineaActual) {
      doc.text(lineaActual, margen, y);
      y += 4;
    }
    y += 4;

    // Precio si existe
    if (orden.precio && orden.precio > 0) {
      doc.setFont('helvetica', 'bold');
      doc.text('PRECIO DE REPARACIÓN', margen, y);
      y += 5;
      doc.setFontSize(12);
      doc.text(`TOTAL: €${orden.precio.toFixed(2)}`, margen, y);
      y += 8;
      doc.setFontSize(8);
    }

    // Campos personalizados
    if (camposPersonalizados.length > 0) {
      doc.setFont('helvetica', 'bold');
      doc.text('INFORMACIÓN ADICIONAL', margen, y);
      y += 5;
      doc.setFont('helvetica', 'normal');
      camposPersonalizados.forEach(campo => {
        if (campo.etiqueta && campo.valor) {
          doc.text(`${campo.etiqueta}: ${campo.valor}`, margen, y);
          y += 4;
        }
      });
      y += 4;
    }

    // Código QR principal
    if (qrCodeUrl) {
      y += 5;
      try {
        doc.addImage(qrCodeUrl, 'PNG', 25, y, 30, 30);
        y += 35;
      } catch (error) {
        console.error('Error añadiendo QR principal:', error);
      }
    }

    // Términos y condiciones (después del primer QR)
    y += 5;
    doc.setLineWidth(0.5);
    doc.setDrawColor(0, 0, 0);
    doc.line(margen, y, anchoUtil, y);
    y += 5;

    doc.setFontSize(7);
    doc.setFont('helvetica', 'bold');
    doc.text('TÉRMINOS Y CONDICIONES:', margen, y);
    y += 5;

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(6);
    const terminos = configuracion.terminosTicket || "• El presupuesto es válido por 15 días.\n• Los dispositivos no retirados en 30 días quedan en depósito.\n• No nos hacemos responsables de la pérdida de datos.\n• Se recomienda realizar copia de seguridad antes de la reparación.";

    terminos.split('\n').forEach(termino => {
      if (termino.trim()) {
        doc.text(termino.trim(), margen, y);
        y += 3;
      }
    });

    y += 5;
    doc.setFont('helvetica', 'bold');
    doc.text(`¡Gracias por confiar en ${configuracion.nombreEmpresa || 'nuestro servicio'}!`, 40, y, { align: 'center' });

    // Línea de corte para etiqueta móvil
    if (qrMovilUrl) {
      y += 8;
      doc.setLineWidth(0.5);
      doc.setDrawColor(150, 150, 150);
      for (let i = margen; i < anchoUtil; i += 3) {
        doc.line(i, y, i + 1.5, y);
      }
      doc.setFontSize(6);
      doc.text('✂️ RECORTAR ✂️', 40, y - 1, { align: 'center' });
      y += 5;

      // Etiqueta del móvil (sin título)
      doc.setDrawColor(0, 0, 0);
      doc.setLineWidth(1);
      for (let i = 0; i < anchoUtil; i += 3) {
        doc.line(margen + i, y, margen + i + 1.5, y);
        doc.line(margen + i, y + 20, margen + i + 1.5, y + 20);
      }
      for (let i = 0; i < 20; i += 3) {
        doc.line(margen, y + i, margen, y + i + 1.5);
        doc.line(anchoUtil, y + i, anchoUtil, y + i + 1.5);
      }

      // Contenido de la etiqueta (sin título)
      doc.setFontSize(6);
      doc.setFont('helvetica', 'normal');
      doc.text(`${orden.cliente.substring(0, 15)}`, margen + 2, y + 5);
      doc.text(`${orden.telefono}`, margen + 2, y + 8);
      doc.text(`${orden.marca} ${orden.modelo}`, margen + 2, y + 11);
      doc.text(`#${orden.id}`, margen + 2, y + 14);

      // QR pequeño
      if (qrMovilUrl) {
        try {
          doc.addImage(qrMovilUrl, 'PNG', 52, y + 5, 12, 12);
        } catch (error) {
          console.error('Error añadiendo QR móvil:', error);
        }
      }

      y += 25;

      // Línea de corte inferior
      for (let i = margen; i < anchoUtil; i += 3) {
        doc.line(i, y, i + 1.5, y);
      }
    }

    // Abrir en nueva ventana
    window.open(doc.output('bloburl'), '_blank');
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Ticket de Resguardo</h3>
        <div className="flex gap-2">
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm" onClick={() => setTempCampos(camposPersonalizados)}>
                <Settings className="w-4 h-4 mr-2" />
                Campos Personalizados
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Campos Personalizados del Ticket</DialogTitle>
              </DialogHeader>
              <div className="space-y-6">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-sm text-blue-800">
                    💡 <strong>Tip:</strong> Los datos de empresa se configuran centralizadamente en
                    <strong> "Datos de Empresa"</strong> en el menú principal.
                  </p>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-lg font-semibold">Campos Personalizados</h4>
                    <Button onClick={handleAddCampo} size="sm">
                      <Plus className="w-4 h-4 mr-2" />
                      Agregar Campo
                    </Button>
                  </div>
                  <div className="space-y-3">
                    {tempCampos.map((campo) => (
                      <div key={campo.id} className="flex gap-2 items-end">
                        <div className="flex-1">
                          <Label htmlFor={`etiqueta-${campo.id}`}>Etiqueta</Label>
                          <Input
                            id={`etiqueta-${campo.id}`}
                            value={campo.etiqueta}
                            onChange={(e) => handleUpdateCampo(campo.id, 'etiqueta', e.target.value)}
                            placeholder="Nombre del campo"
                          />
                        </div>
                        <div className="flex-1">
                          <Label htmlFor={`valor-${campo.id}`}>Valor</Label>
                          <Input
                            id={`valor-${campo.id}`}
                            value={campo.valor}
                            onChange={(e) => handleUpdateCampo(campo.id, 'valor', e.target.value)}
                            placeholder="Valor del campo"
                          />
                        </div>
                        <Button
                          onClick={() => handleDeleteCampo(campo.id)}
                          variant="destructive"
                          size="icon"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancelar
                  </Button>
                  <Button onClick={handleSaveConfig}>
                    Guardar Configuración
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
          <div className="flex gap-1">
            <Button onClick={() => handleImprimir('termica')} variant="outline" size="sm">
              <Printer className="w-4 h-4 mr-1" />
              Ver/Imprimir Ticket
            </Button>
          </div>
        </div>
      </div>

      <Card className="max-w-md mx-auto">
        <CardContent className="p-4">
          <div id="ticket-resguardo">
            {/* Header con datos de la empresa */}
            <div className="header text-center border-b-2 border-black pb-3 mb-4">
              <div className="empresa text-xl font-bold">{configuracion.nombreEmpresa || 'TECHREPAIR PRO'}</div>
              <div className="contacto text-sm mt-2 space-y-1">
                {configuracion.telefono && <div>📞 {configuracion.telefono}</div>}
                {configuracion.direccion && <div>📍 {configuracion.direccion}</div>}
                {configuracion.email && <div>📧 {configuracion.email}</div>}
                {configuracion.cif && <div>🏢 {configuracion.tipoDocumento || 'CIF'}: {configuracion.cif}</div>}
              </div>
            </div>

            {/* Número de orden y fecha */}
            <div className="seccion mb-4">
              <div className="titulo-seccion font-semibold border-b border-gray-300 pb-1 mb-2">
                ORDEN DE REPARACIÓN
              </div>
              <div className="fila flex justify-between">
                <span className="etiqueta font-semibold">Nº Orden:</span>
                <span>{orden.id}</span>
              </div>
              <div className="fila flex justify-between">
                <span className="etiqueta font-semibold">Fecha:</span>
                <span>{new Date(orden.fechaRecepcion).toLocaleDateString('es-ES')}</span>
              </div>
            </div>

            {/* Datos del cliente */}
            <div className="seccion mb-4">
              <div className="titulo-seccion font-semibold border-b border-gray-300 pb-1 mb-2">
                DATOS DEL CLIENTE
              </div>
              <div className="fila flex justify-between">
                <span className="etiqueta font-semibold">Nombre:</span>
                <span>{orden.cliente}</span>
              </div>
              <div className="fila flex justify-between">
                <span className="etiqueta font-semibold">Teléfono:</span>
                <span>{orden.telefono}</span>
              </div>
              {orden.email && (
                <div className="fila flex justify-between">
                  <span className="etiqueta font-semibold">Email:</span>
                  <span className="text-xs">{orden.email}</span>
                </div>
              )}
            </div>

            {/* Datos del dispositivo */}
            <div className="seccion mb-4">
              <div className="titulo-seccion font-semibold border-b border-gray-300 pb-1 mb-2">
                DATOS DEL DISPOSITIVO
              </div>
              <div className="fila flex justify-between">
                <span className="etiqueta font-semibold">Tipo:</span>
                <span>{orden.dispositivo}</span>
              </div>
              <div className="fila flex justify-between">
                <span className="etiqueta font-semibold">Marca:</span>
                <span>{orden.marca}</span>
              </div>
              <div className="fila flex justify-between">
                <span className="etiqueta font-semibold">Modelo:</span>
                <span>{orden.modelo}</span>
              </div>
              {orden.imei && (
                <div className="fila flex justify-between">
                  <span className="etiqueta font-semibold">IMEI:</span>
                  <span className="text-xs">{orden.imei}</span>
                </div>
              )}
            </div>

            {/* Problema reportado */}
            <div className="seccion mb-4">
              <div className="titulo-seccion font-semibold border-b border-gray-300 pb-1 mb-2">
                PROBLEMA REPORTADO
              </div>
              <div className="text-sm">
                {orden.descripcionProblema}
              </div>
            </div>

            {/* Precio de reparación */}
            {orden.precio && orden.precio > 0 && (
              <div className="seccion mb-4">
                <div className="titulo-seccion font-semibold border-b border-gray-300 pb-1 mb-2">
                  PRECIO DE REPARACIÓN
                </div>
                <div className="fila flex justify-between">
                  <span className="etiqueta font-semibold">Total:</span>
                  <span className="font-bold text-lg">€{orden.precio.toFixed(2)}</span>
                </div>
              </div>
            )}

            {/* Campos personalizados */}
            {camposPersonalizados.length > 0 && (
              <div className="seccion mb-4">
                <div className="titulo-seccion font-semibold border-b border-gray-300 pb-1 mb-2">
                  INFORMACIÓN ADICIONAL
                </div>
                {camposPersonalizados.map((campo) => (
                  campo.etiqueta && campo.valor && (
                    <div key={campo.id} className="fila flex justify-between">
                      <span className="etiqueta font-semibold">{campo.etiqueta}:</span>
                      <span className="text-sm">{campo.valor}</span>
                    </div>
                  )
                ))}
              </div>
            )}

            {/* Código QR */}
            {qrCodeUrl && (
              <div className="seccion mb-4 text-center">
                <div className="titulo-seccion font-semibold border-b border-gray-300 pb-1 mb-2">
                  CÓDIGO QR - ORDEN
                </div>
                <img src={qrCodeUrl} alt="QR Code" className="mx-auto" style={{width: '80px', height: '80px'}} />
              </div>
            )}

            {/* Etiqueta de identificación del móvil - Para recortar */}
            {qrMovilUrl && (
              <div className="mt-6 mb-4">
                {/* Línea de corte superior con tijeras */}
                <div className="cut-line">
                  <div className="cut-text">
                    ✂️ RECORTAR AQUÍ - ETIQUETA PARA MÓVIL ✂️
                  </div>
                </div>

                {/* Contenido de la etiqueta */}
                <div className="mobile-tag">
                  <div className="mobile-tag-header">
                    📱 ETIQUETA DE IDENTIFICACIÓN 📱
                  </div>

                  <div className="fila flex justify-between mobile-info mb-1">
                    <span className="etiqueta">Cliente:</span>
                    <span>{orden.cliente.length > 12 ? orden.cliente.substring(0, 12) + '...' : orden.cliente}</span>
                  </div>
                  <div className="fila flex justify-between mobile-info mb-1">
                    <span className="etiqueta">Tel:</span>
                    <span>{orden.telefono}</span>
                  </div>
                  <div className="fila flex justify-between mobile-info mb-1">
                    <span className="etiqueta">Dispositivo:</span>
                    <span>{(orden.marca + ' ' + orden.modelo).length > 15 ?
                      (orden.marca + ' ' + orden.modelo).substring(0, 15) + '...' :
                      orden.marca + ' ' + orden.modelo}</span>
                  </div>
                  <div className="fila flex justify-between mobile-info mb-2">
                    <span className="etiqueta">Orden:</span>
                    <span>#{orden.id}</span>
                  </div>

                  {/* QR pequeño para identificación */}
                  <div className="text-center mb-2">
                    <img src={qrMovilUrl} alt="QR Móvil" className="mx-auto" style={{width: '45px', height: '45px'}} />
                  </div>

                  {orden.imei && (
                    <div className="mobile-info text-center mb-1">
                      <span className="etiqueta">IMEI:</span> {orden.imei.length > 15 ? orden.imei.substring(0, 15) + '...' : orden.imei}
                    </div>
                  )}

                  <div className="mobile-info text-center" style={{fontSize: '7px', color: '#666', fontWeight: 'bold'}}>
                    🏷️ PEGAR EN EL DISPOSITIVO 🏷️
                  </div>
                </div>

                {/* Línea de corte inferior */}
                <div className="cut-line">
                  <div className="cut-text">
                    ✂️ RECORTAR AQUÍ ✂️
                  </div>
                </div>
              </div>
            )}

            {/* Información específica de móviles */}
            {configuracion.configuracionMoviles?.mostrarEnTicket && (
              <div className="seccion-especifica border-t border-gray-300 pt-3 mt-4 text-xs">
                {configuracion.configuracionMoviles.textoPersonalizado && (
                  <div className="texto-personalizado font-semibold text-center mb-2">
                    {configuracion.configuracionMoviles.textoPersonalizado}
                  </div>
                )}
                {configuracion.configuracionMoviles.informacionAdicional && (
                  <div className="info-adicional text-center mb-2 text-gray-600">
                    {configuracion.configuracionMoviles.informacionAdicional}
                  </div>
                )}
                {configuracion.configuracionMoviles.terminos && (
                  <div className="terminos-especificos mb-2">
                    <div className="font-semibold mb-1">Términos específicos:</div>
                    <div className="space-y-1">
                      {configuracion.configuracionMoviles.terminos.split('\n').map((termino, index) => (
                        <div key={index}>{termino}</div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Términos y condiciones generales */}
            <div className="footer border-t border-black pt-3 mt-5 text-xs">
              <div className="mb-2">
                <strong>TÉRMINOS Y CONDICIONES:</strong>
              </div>
              <div className="space-y-1">
                {(configuracion.terminosTicket || "• El presupuesto es válido por 15 días.\n• Los dispositivos no retirados en 30 días quedan en depósito.\n• No nos hacemos responsables de la pérdida de datos.\n• Se recomienda realizar copia de seguridad antes de la reparación.").split('\n').map((termino, index) => (
                  <div key={index}>{termino}</div>
                ))}
              </div>
              <div className="mt-3 text-center">
                <div>¡Gracias por confiar en {configuracion.nombreEmpresa}!</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
