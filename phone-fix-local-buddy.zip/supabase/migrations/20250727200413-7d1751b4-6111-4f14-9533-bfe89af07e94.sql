-- Grant lifetime access to the specified email
SELECT public.grant_lifetime_access('nordin_jamae@hotmail.com');