import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Database, 
  Shield, 
  Zap, 
  Cloud,
  Chrome,
  Key,
  Loader2,
  Settings
} from 'lucide-react';
import AuthPage from './AuthPage';
import FirebaseAuthPage from './FirebaseAuthPage';
import { firebaseService } from '@/lib/firebaseService';
import { customStorageService } from '@/lib/customStorageService';

interface AuthSelectorProps {
  onAuthSuccess: (user: any) => void;
}

const AuthSelector: React.FC<AuthSelectorProps> = ({ onAuthSuccess }) => {
  const [authMode, setAuthMode] = useState<'select' | 'supabase' | 'firebase'>('select');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkExistingConfiguration();
  }, []);

  const checkExistingConfiguration = async () => {
    try {
      // Check if Firebase is already configured
      const firebaseReady = await firebaseService.loadSavedConfig();
      
      // Check if custom storage (Firebase) is configured
      const customConfig = await customStorageService.loadStorageConfig();
      const hasFirebaseConfig = customConfig?.provider === 'firebase' && customConfig.isActive;

      if (firebaseReady || hasFirebaseConfig) {
        setAuthMode('firebase');
      } else {
        // Default to Supabase for existing users
        setAuthMode('supabase');
      }
    } catch (error) {
      console.error('Error checking configuration:', error);
      // Default to selection mode if there's an error
      setAuthMode('select');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Cargando configuración...</p>
        </div>
      </div>
    );
  }

  if (authMode === 'supabase') {
    return <AuthPage onAuthSuccess={onAuthSuccess} />;
  }

  if (authMode === 'firebase') {
    return <FirebaseAuthPage onAuthSuccess={onAuthSuccess} />;
  }

  // Selection mode
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 p-4">
      <div className="w-full max-w-4xl">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Bienvenido a TallerPro</h1>
          <p className="text-xl text-gray-600">Elige cómo quieres gestionar tu taller</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Supabase Option */}
          <Card className="cursor-pointer transition-all duration-300 hover:shadow-lg hover:scale-[1.02] border-2 border-gray-200 hover:border-blue-400">
            <CardHeader className="text-center pb-4">
              <div className="mx-auto mb-4 p-4 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl w-fit">
                <Database className="h-10 w-10 text-white" />
              </div>
              <CardTitle className="text-2xl font-bold text-gray-900">
                Modo Estándar
              </CardTitle>
              <CardDescription className="text-base">
                Gestión tradicional con Supabase
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                  <Shield className="h-5 w-5 text-blue-600" />
                  <span className="text-sm">Autenticación segura por email</span>
                </div>
                <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                  <Cloud className="h-5 w-5 text-green-600" />
                  <span className="text-sm">Base de datos PostgreSQL</span>
                </div>
                <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                  <Zap className="h-5 w-5 text-purple-600" />
                  <span className="text-sm">Configuración rápida</span>
                </div>
              </div>
              
              <div className="border-t pt-4">
                <Badge variant="outline" className="mb-3">Recomendado para mayoría de usuarios</Badge>
                <Button 
                  onClick={() => setAuthMode('supabase')}
                  className="w-full h-12 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                >
                  Usar Modo Estándar
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Firebase Option */}
          <Card className="cursor-pointer transition-all duration-300 hover:shadow-lg hover:scale-[1.02] border-2 border-gray-200 hover:border-orange-400">
            <CardHeader className="text-center pb-4">
              <div className="mx-auto mb-4 p-4 bg-gradient-to-br from-orange-500 to-red-600 rounded-xl w-fit">
                <Chrome className="h-10 w-10 text-white" />
              </div>
              <CardTitle className="text-2xl font-bold text-gray-900">
                Modo Google Cloud
              </CardTitle>
              <CardDescription className="text-base">
                Integración completa con Firebase
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-3 bg-orange-50 rounded-lg">
                  <Chrome className="h-5 w-5 text-orange-600" />
                  <span className="text-sm">Autenticación Google nativa</span>
                </div>
                <div className="flex items-center gap-3 p-3 bg-red-50 rounded-lg">
                  <Database className="h-5 w-5 text-red-600" />
                  <span className="text-sm">Firestore en tiempo real</span>
                </div>
                <div className="flex items-center gap-3 p-3 bg-yellow-50 rounded-lg">
                  <Key className="h-5 w-5 text-yellow-600" />
                  <span className="text-sm">Tu propia infraestructura</span>
                </div>
              </div>
              
              <div className="border-t pt-4">
                <Badge variant="outline" className="mb-3">Requiere configuración Firebase</Badge>
                <Button 
                  onClick={() => setAuthMode('firebase')}
                  className="w-full h-12 bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700"
                >
                  Usar Google Cloud
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="mt-8 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gray-100 rounded-lg">
            <Settings className="h-4 w-4 text-gray-600" />
            <span className="text-sm text-gray-600">
              Puedes cambiar el modo más tarde en configuración
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthSelector;
