import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import { useToast } from "@/hooks/use-toast";
import { 
  Save,
  Building,
  DollarSign,
  Bell,
  Database,
  Download,
  Upload,
  Trash2,
  RefreshCw
} from "lucide-react";

interface ConfiguracionEmpresa {
  nombreEmpresa: string;
  direccion: string;
  telefono: string;
  email: string;
  website: string;
  impuestos: number;
  moneda: string;
  diasGarantia: number;
  terminosTicket: string;
}

interface ConfiguracionNotificaciones {
  stockBajo: boolean;
  citasProximas: boolean;
  facturasVencidas: boolean;
  ordenesCompletadas: boolean;
}

export default function ConfiguracionPage() {
  const [configuracion, setConfiguracion] = useLocalStorage<ConfiguracionEmpresa>("configuracion", {
    nombreEmpresa: "",
    direccion: "",
    telefono: "",
    email: "",
    website: "",
    impuestos: 21,
    moneda: "EUR",
    diasGarantia: 30,
    terminosTicket: "• El presupuesto es válido por 15 días.\n• Los dispositivos no retirados en 30 días quedan en depósito.\n• No nos hacemos responsables de la pérdida de datos.\n• Se recomienda realizar copia de seguridad antes de la reparación."
  });

  const [notificaciones, setNotificaciones] = useLocalStorage<ConfiguracionNotificaciones>("notificaciones", {
    stockBajo: true,
    citasProximas: true,
    facturasVencidas: true,
    ordenesCompletadas: false
  });

  const [ordenes] = useLocalStorage("ordenes", []);
  const [clientes] = useLocalStorage("clientes", []);
  const [inventario] = useLocalStorage("inventario", []);
  const [citas] = useLocalStorage("citas", []);
  const [facturas] = useLocalStorage("facturas", []);

  const { toast } = useToast();

  const [formEmpresa, setFormEmpresa] = useState(configuracion);
  const [formNotificaciones, setFormNotificaciones] = useState(notificaciones);

  const guardarConfiguracion = () => {
    setConfiguracion(formEmpresa);
    setNotificaciones(formNotificaciones);
    toast({
      title: "Configuración guardada",
      description: "Los cambios han sido guardados exitosamente"
    });
  };

  const exportarDatos = () => {
    const datos = {
      configuracion: formEmpresa,
      notificaciones: formNotificaciones,
      ordenes,
      clientes,
      inventario,
      citas,
      facturas,
      fechaExportacion: new Date().toISOString(),
      version: "1.0"
    };

    const dataStr = JSON.stringify(datos, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `techrepair-backup-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    toast({
      title: "Datos exportados",
      description: "El archivo de respaldo ha sido descargado"
    });
  };

  const importarDatos = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const datos = JSON.parse(e.target?.result as string);
        
        if (datos.configuracion) setConfiguracion(datos.configuracion);
        if (datos.notificaciones) setNotificaciones(datos.notificaciones);
        
        // Actualizar localStorage con todos los datos
        if (datos.ordenes) localStorage.setItem("ordenes", JSON.stringify(datos.ordenes));
        if (datos.clientes) localStorage.setItem("clientes", JSON.stringify(datos.clientes));
        if (datos.inventario) localStorage.setItem("inventario", JSON.stringify(datos.inventario));
        if (datos.citas) localStorage.setItem("citas", JSON.stringify(datos.citas));
        if (datos.facturas) localStorage.setItem("facturas", JSON.stringify(datos.facturas));

        toast({
          title: "Datos importados",
          description: "Los datos han sido restaurados exitosamente. Recarga la página para ver los cambios."
        });
      } catch (error) {
        toast({
          title: "Error al importar",
          description: "El archivo no tiene el formato correcto",
          variant: "destructive"
        });
      }
    };
    reader.readAsText(file);
  };

  const limpiarDatos = () => {
    if (confirm("¿Estás seguro de que quieres eliminar todos los datos? Esta acción no se puede deshacer.")) {
      localStorage.removeItem("ordenes");
      localStorage.removeItem("clientes");
      localStorage.removeItem("inventario");
      localStorage.removeItem("citas");
      localStorage.removeItem("facturas");
      
      toast({
        title: "Datos eliminados",
        description: "Todos los datos han sido eliminados. Recarga la página."
      });
    }
  };

  const estadisticasStorage = () => {
    const stats = {
      ordenes: ordenes.length,
      clientes: clientes.length,
      inventario: inventario.length,
      citas: citas.length,
      facturas: facturas.length,
      totalRegistros: ordenes.length + clientes.length + inventario.length + citas.length + facturas.length
    };
    return stats;
  };

  const stats = estadisticasStorage();

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">Configuración</h1>
          <p className="text-slate-600">Configura tu negocio y preferencias del sistema</p>
        </div>
        <Button onClick={guardarConfiguracion}>
          <Save className="w-4 h-4 mr-2" />
          Guardar Cambios
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Configuración de la Empresa */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building className="w-5 h-5" />
              Información de la Empresa
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="nombreEmpresa">Nombre de la Empresa</Label>
              <Input
                id="nombreEmpresa"
                value={formEmpresa.nombreEmpresa}
                onChange={(e) => setFormEmpresa({...formEmpresa, nombreEmpresa: e.target.value})}
                placeholder="Nombre de tu empresa"
              />
            </div>

            <div>
              <Label htmlFor="direccion">Dirección</Label>
              <Textarea
                id="direccion"
                value={formEmpresa.direccion}
                onChange={(e) => setFormEmpresa({...formEmpresa, direccion: e.target.value})}
                placeholder="Dirección completa"
                rows={2}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="telefono">Teléfono</Label>
                <Input
                  id="telefono"
                  value={formEmpresa.telefono}
                  onChange={(e) => setFormEmpresa({...formEmpresa, telefono: e.target.value})}
                  placeholder="+1234567890"
                />
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formEmpresa.email}
                  onChange={(e) => setFormEmpresa({...formEmpresa, email: e.target.value})}
                  placeholder="contacto@empresa.com"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="website">Sitio Web</Label>
              <Input
                id="website"
                value={formEmpresa.website}
                onChange={(e) => setFormEmpresa({...formEmpresa, website: e.target.value})}
                placeholder="www.tuempresa.com"
              />
            </div>
          </CardContent>
        </Card>

        {/* Configuración Financiera */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="w-5 h-5" />
              Configuración Financiera
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="impuestos">Porcentaje de Impuestos (%)</Label>
                <Input
                  id="impuestos"
                  type="number"
                  min="0"
                  max="100"
                  step="0.1"
                  value={formEmpresa.impuestos}
                  onChange={(e) => setFormEmpresa({...formEmpresa, impuestos: parseFloat(e.target.value) || 0})}
                />
              </div>
              <div>
                <Label htmlFor="moneda">Moneda</Label>
                <Input
                  id="moneda"
                  value={formEmpresa.moneda}
                  onChange={(e) => setFormEmpresa({...formEmpresa, moneda: e.target.value})}
                  placeholder="EUR"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="diasGarantia">Días de Garantía</Label>
              <Input
                id="diasGarantia"
                type="number"
                min="0"
                value={formEmpresa.diasGarantia}
                onChange={(e) => setFormEmpresa({...formEmpresa, diasGarantia: parseInt(e.target.value) || 0})}
              />
              <p className="text-sm text-muted-foreground mt-1">
                Días de garantía por defecto para las reparaciones
              </p>
            </div>

            <div>
              <Label htmlFor="terminosTicket">Términos y Condiciones del Ticket</Label>
              <Textarea
                id="terminosTicket"
                value={formEmpresa.terminosTicket}
                onChange={(e) => setFormEmpresa({...formEmpresa, terminosTicket: e.target.value})}
                placeholder="Escribe los términos y condiciones que aparecerán en el ticket..."
                rows={4}
              />
              <p className="text-sm text-muted-foreground mt-1">
                Términos que aparecerán en el ticket de resguardo
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Notificaciones */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="w-5 h-5" />
              Notificaciones
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="stockBajo">Alertas de Stock Bajo</Label>
                  <p className="text-sm text-muted-foreground">
                    Notificar cuando los productos tengan stock bajo
                  </p>
                </div>
                <Switch
                  id="stockBajo"
                  checked={formNotificaciones.stockBajo}
                  onCheckedChange={(checked) => 
                    setFormNotificaciones({...formNotificaciones, stockBajo: checked})
                  }
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="citasProximas">Citas Próximas</Label>
                  <p className="text-sm text-muted-foreground">
                    Recordatorio de citas programadas
                  </p>
                </div>
                <Switch
                  id="citasProximas"
                  checked={formNotificaciones.citasProximas}
                  onCheckedChange={(checked) => 
                    setFormNotificaciones({...formNotificaciones, citasProximas: checked})
                  }
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="facturasVencidas">Facturas Vencidas</Label>
                  <p className="text-sm text-muted-foreground">
                    Alertas de facturas por cobrar vencidas
                  </p>
                </div>
                <Switch
                  id="facturasVencidas"
                  checked={formNotificaciones.facturasVencidas}
                  onCheckedChange={(checked) => 
                    setFormNotificaciones({...formNotificaciones, facturasVencidas: checked})
                  }
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="ordenesCompletadas">Órdenes Completadas</Label>
                  <p className="text-sm text-muted-foreground">
                    Notificar cuando se complete una reparación
                  </p>
                </div>
                <Switch
                  id="ordenesCompletadas"
                  checked={formNotificaciones.ordenesCompletadas}
                  onCheckedChange={(checked) => 
                    setFormNotificaciones({...formNotificaciones, ordenesCompletadas: checked})
                  }
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Gestión de Datos */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="w-5 h-5" />
              Gestión de Datos
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Estadísticas */}
            <div className="grid grid-cols-2 gap-4 p-4 bg-muted rounded-lg">
              <div className="text-center">
                <p className="text-2xl font-bold text-blue-600">{stats.ordenes}</p>
                <p className="text-sm text-muted-foreground">Órdenes</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-green-600">{stats.clientes}</p>
                <p className="text-sm text-muted-foreground">Clientes</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-purple-600">{stats.inventario}</p>
                <p className="text-sm text-muted-foreground">Productos</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-orange-600">{stats.citas}</p>
                <p className="text-sm text-muted-foreground">Citas</p>
              </div>
            </div>

            {/* Acciones */}
            <div className="space-y-3">
              <Button onClick={exportarDatos} variant="outline" className="w-full">
                <Download className="w-4 h-4 mr-2" />
                Exportar Datos (Respaldo)
              </Button>

              <div>
                <input
                  type="file"
                  accept=".json"
                  onChange={importarDatos}
                  style={{ display: 'none' }}
                  id="file-input"
                />
                <Button 
                  onClick={() => document.getElementById('file-input')?.click()}
                  variant="outline" 
                  className="w-full"
                >
                  <Upload className="w-4 h-4 mr-2" />
                  Importar Datos (Restaurar)
                </Button>
              </div>

              <Button 
                onClick={limpiarDatos} 
                variant="destructive" 
                className="w-full"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Limpiar Todos los Datos
              </Button>
            </div>

            <div className="text-xs text-muted-foreground">
              <p>Total de registros: {stats.totalRegistros}</p>
              <p>Los datos se almacenan localmente en tu navegador</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Información del Sistema */}
      <Card>
        <CardHeader>
          <CardTitle>Información del Sistema</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div>
              <p className="font-semibold">Versión:</p>
              <p>TechRepair v1.0</p>
            </div>
            <div>
              <p className="font-semibold">Almacenamiento:</p>
              <p>Local (Navegador)</p>
            </div>
            <div>
              <p className="font-semibold">Última actualización:</p>
              <p>{new Date().toLocaleDateString()}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}