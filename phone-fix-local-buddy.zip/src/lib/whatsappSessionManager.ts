// Gestor de sesión de WhatsApp Web
export interface WhatsAppSessionStatus {
  isAvailable: boolean;
  isLoggedIn: boolean;
  lastCheck: number;
  error?: string;
}

class WhatsAppSessionManager {
  private status: WhatsAppSessionStatus = {
    isAvailable: false,
    isLoggedIn: false,
    lastCheck: 0
  };

  private CACHE_DURATION = 30000; // 30 segundos

  /**
   * Verifica si WhatsApp Web está disponible y logueado
   */
  async checkWhatsAppStatus(): Promise<WhatsAppSessionStatus> {
    const now = Date.now();
    
    // Si la verificación es reciente, usar cache
    if (now - this.status.lastCheck < this.CACHE_DURATION) {
      return this.status;
    }

    try {
      // Verificar si podemos acceder a WhatsApp Web
      const available = await this.checkWhatsAppAvailability();
      
      this.status = {
        isAvailable: available,
        isLoggedIn: available, // Si está disponible, asumimos que está logueado
        lastCheck: now,
        error: available ? undefined : 'WhatsApp Web no está disponible o no está logueado'
      };
    } catch (error) {
      this.status = {
        isAvailable: false,
        isLoggedIn: false,
        lastCheck: now,
        error: error instanceof Error ? error.message : 'Error desconocido'
      };
    }

    return this.status;
  }

  /**
   * Verifica la disponibilidad de WhatsApp Web
   */
  private async checkWhatsAppAvailability(): Promise<boolean> {
    return new Promise((resolve) => {
      // Crear una ventana temporal para verificar el estado
      const testWindow = window.open(
        'https://web.whatsapp.com',
        '_blank',
        'width=1,height=1,left=-1000,top=-1000'
      );

      if (!testWindow) {
        resolve(false);
        return;
      }

      // Timer para cerrar la ventana de test
      const timeout = setTimeout(() => {
        try {
          testWindow.close();
        } catch (e) {
          // Ignorar errores al cerrar
        }
        resolve(false);
      }, 5000);

      // Verificar cuando la página cargue
      const checkInterval = setInterval(() => {
        try {
          // Si la ventana está cerrada o no responde, WhatsApp no está disponible
          if (testWindow.closed) {
            clearInterval(checkInterval);
            clearTimeout(timeout);
            resolve(false);
            return;
          }

          // Verificar si la URL cambió (indicando que WhatsApp está funcionando)
          const currentUrl = testWindow.location.href;
          if (currentUrl && currentUrl.includes('web.whatsapp.com')) {
            clearInterval(checkInterval);
            clearTimeout(timeout);
            testWindow.close();
            resolve(true);
          }
        } catch (error) {
          // Error de CORS es esperado - significa que WhatsApp está funcionando
          clearInterval(checkInterval);
          clearTimeout(timeout);
          testWindow.close();
          resolve(true);
        }
      }, 1000);
    });
  }

  /**
   * Abre WhatsApp Web con verificación previa
   */
  async openWhatsAppSafely(phoneNumber: string, message: string): Promise<{
    success: boolean;
    method: 'whatsapp_web' | 'mobile_fallback' | 'copy_text';
    error?: string;
  }> {
    try {
      const status = await this.checkWhatsAppStatus();
      const formattedPhone = this.formatPhoneNumber(phoneNumber);
      const encodedMessage = encodeURIComponent(message);

      // Si WhatsApp Web está disponible, usarlo
      if (status.isAvailable) {
        const whatsappUrl = `https://web.whatsapp.com/send?phone=${formattedPhone}&text=${encodedMessage}`;
        
        const whatsappWindow = window.open(
          whatsappUrl, 
          '_blank', 
          'width=1200,height=800,scrollbars=yes,resizable=yes'
        );

        if (whatsappWindow) {
          // Verificar si la ventana se abre correctamente
          setTimeout(() => {
            if (whatsappWindow.closed) {
              console.warn('WhatsApp Web se cerró inesperadamente');
            }
          }, 2000);

          return {
            success: true,
            method: 'whatsapp_web'
          };
        }
      }

      // Fallback: Intentar abrir WhatsApp móvil
      const mobileUrl = `https://wa.me/${formattedPhone}?text=${encodedMessage}`;
      const mobileWindow = window.open(mobileUrl, '_blank');

      if (mobileWindow) {
        return {
          success: true,
          method: 'mobile_fallback'
        };
      }

      // Último recurso: Copiar al portapapeles
      return this.copyToClipboardFallback(phoneNumber, message);

    } catch (error) {
      console.error('Error abriendo WhatsApp:', error);
      return this.copyToClipboardFallback(phoneNumber, message);
    }
  }

  /**
   * Fallback para copiar texto al portapapeles
   */
  private async copyToClipboardFallback(phoneNumber: string, message: string): Promise<{
    success: boolean;
    method: 'copy_text';
    error?: string;
  }> {
    try {
      const textToCopy = `WhatsApp para: ${phoneNumber}\n\nMensaje:\n${message}`;
      
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(textToCopy);
      } else {
        // Fallback para navegadores sin clipboard API
        const textArea = document.createElement('textarea');
        textArea.value = textToCopy;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
      }

      return {
        success: true,
        method: 'copy_text'
      };
    } catch (error) {
      return {
        success: false,
        method: 'copy_text',
        error: error instanceof Error ? error.message : 'Error copiando al portapapeles'
      };
    }
  }

  /**
   * Formatea el número de tel��fono
   */
  private formatPhoneNumber(phone: string): string {
    let cleaned = phone.replace(/\D/g, '');
    
    if (!cleaned.startsWith('34') && cleaned.length === 9) {
      cleaned = '34' + cleaned;
    }
    
    return cleaned;
  }

  /**
   * Obtiene el estado actual sin verificación
   */
  getCurrentStatus(): WhatsAppSessionStatus {
    return { ...this.status };
  }

  /**
   * Invalida el cache para forzar una nueva verificación
   */
  invalidateCache(): void {
    this.status.lastCheck = 0;
  }
}

// Instancia singleton
export const whatsappSessionManager = new WhatsAppSessionManager();

// Funciones de utilidad
export async function checkWhatsAppAvailability(): Promise<WhatsAppSessionStatus> {
  return whatsappSessionManager.checkWhatsAppStatus();
}

export async function sendWhatsAppMessageSafely(
  phoneNumber: string, 
  message: string
): Promise<{
  success: boolean;
  method: 'whatsapp_web' | 'mobile_fallback' | 'copy_text';
  error?: string;
}> {
  return whatsappSessionManager.openWhatsAppSafely(phoneNumber, message);
}
