const express = require('express');
const cors = require('cors');
const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');

const app = express();
const PORT = process.env.PORT || 3001;

// Configurar middleware
app.use(cors());
app.use(express.json());

// Variables globales
let client = null;
let isReady = false;
let qrString = '';
let clientInfo = null;

// Inicializar cliente de WhatsApp
function initializeWhatsApp() {
  client = new Client({
    authStrategy: new LocalAuth({
      clientId: "whatsapp-web-client"
    }),
    puppeteer: {
      headless: true,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-accelerated-2d-canvas',
        '--no-first-run',
        '--no-zygote',
        '--single-process',
        '--disable-gpu'
      ]
    }
  });

  // Evento QR Code
  client.on('qr', (qr) => {
    console.log('QR Code recibido');
    qrString = qr;
    qrcode.generate(qr, { small: true });
    isReady = false;
  });

  // Evento cliente listo
  client.on('ready', async () => {
    console.log('Cliente de WhatsApp Web está listo!');
    isReady = true;
    qrString = '';
    
    // Obtener información del cliente
    try {
      const info = client.info;
      clientInfo = {
        number: info.wid.user,
        pushname: info.pushname,
        platform: info.platform
      };
      console.log('Cliente conectado:', clientInfo);
    } catch (error) {
      console.error('Error obteniendo info del cliente:', error);
    }
  });

  // Evento desconexión
  client.on('disconnected', (reason) => {
    console.log('Cliente desconectado:', reason);
    isReady = false;
    qrString = '';
    clientInfo = null;
  });

  // Evento mensaje recibido (opcional - para logs)
  client.on('message_create', (message) => {
    if (message.from === 'status@broadcast') return;
    console.log('Mensaje:', message.body);
  });

  // Manejar errores
  client.on('auth_failure', (message) => {
    console.error('Error de autenticación:', message);
    isReady = false;
  });

  // Inicializar cliente
  client.initialize();
}

// Rutas de la API

// Obtener estado de conexión
app.get('/api/whatsapp/status', (req, res) => {
  try {
    let status = 'disconnected';
    
    if (isReady && client) {
      status = 'connected';
    } else if (qrString && !isReady) {
      status = 'qr_pending';
    }
    
    res.json({
      status: status,
      qr: qrString,
      info: clientInfo
    });
  } catch (error) {
    console.error('Error obteniendo estado:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
});

// Conectar WhatsApp
app.post('/api/whatsapp/connect', (req, res) => {
  try {
    if (!client) {
      initializeWhatsApp();
    }
    
    res.json({
      message: 'Iniciando conexión con WhatsApp Web',
      status: isReady ? 'connected' : qrString ? 'qr_pending' : 'connecting',
      qr: qrString,
      info: clientInfo
    });
  } catch (error) {
    console.error('Error conectando WhatsApp:', error);
    res.status(500).json({ error: 'Error conectando WhatsApp Web' });
  }
});

// Desconectar WhatsApp
app.post('/api/whatsapp/disconnect', async (req, res) => {
  try {
    if (client) {
      await client.logout();
      await client.destroy();
      client = null;
    }
    
    isReady = false;
    qrString = '';
    clientInfo = null;
    
    res.json({ message: 'WhatsApp Web desconectado correctamente' });
  } catch (error) {
    console.error('Error desconectando WhatsApp:', error);
    res.status(500).json({ error: 'Error desconectando WhatsApp Web' });
  }
});

// Enviar mensaje
app.post('/api/whatsapp/send', async (req, res) => {
  try {
    const { to, message } = req.body;
    
    if (!client || !isReady) {
      return res.status(400).json({ 
        error: 'WhatsApp Web no está conectado',
        fallback: true,
        whatsappUrl: `https://web.whatsapp.com/send?phone=${to.replace('@c.us', '')}&text=${encodeURIComponent(message)}`
      });
    }
    
    if (!to || !message) {
      return res.status(400).json({ error: 'Número de teléfono y mensaje requeridos' });
    }
    
    // Enviar mensaje
    await client.sendMessage(to, message);
    
    console.log(`Mensaje enviado a ${to}: ${message.substring(0, 50)}...`);
    res.json({ 
      success: true, 
      message: 'Mensaje enviado correctamente',
      to: to
    });
    
  } catch (error) {
    console.error('Error enviando mensaje:', error);
    
    // En caso de error, devolver URL de fallback
    const { to, message } = req.body;
    const cleanPhone = to ? to.replace('@c.us', '').replace(/\D/g, '') : '';
    
    res.status(500).json({ 
      error: 'Error enviando mensaje',
      fallback: true,
      whatsappUrl: `https://web.whatsapp.com/send?phone=${cleanPhone}&text=${encodeURIComponent(message || '')}`
    });
  }
});

// Obtener chats (opcional)
app.get('/api/whatsapp/chats', async (req, res) => {
  try {
    if (!client || !isReady) {
      return res.status(400).json({ error: 'WhatsApp Web no está conectado' });
    }
    
    const chats = await client.getChats();
    const simplifiedChats = chats.slice(0, 10).map(chat => ({
      id: chat.id._serialized,
      name: chat.name,
      isGroup: chat.isGroup,
      lastMessage: chat.lastMessage?.body || 'Sin mensajes'
    }));
    
    res.json({ chats: simplifiedChats });
  } catch (error) {
    console.error('Error obteniendo chats:', error);
    res.status(500).json({ error: 'Error obteniendo chats' });
  }
});

// Ruta de prueba
app.get('/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    whatsapp: isReady ? 'connected' : 'disconnected',
    timestamp: new Date().toISOString()
  });
});

// Manejar cierre del servidor
process.on('SIGINT', async () => {
  console.log('Cerrando servidor...');
  
  if (client) {
    try {
      await client.destroy();
    } catch (error) {
      console.error('Error cerrando cliente:', error);
    }
  }
  
  process.exit(0);
});

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`🚀 Servidor WhatsApp Web ejecutándose en puerto ${PORT}`);
  console.log(`📱 Health check: http://localhost:${PORT}/health`);
  
  // Inicializar WhatsApp automáticamente
  initializeWhatsApp();
});

module.exports = app;
