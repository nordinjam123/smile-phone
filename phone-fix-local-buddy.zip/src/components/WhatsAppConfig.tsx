import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { 
  MessageCircle, 
  Save, 
  TestTube, 
  AlertCircle, 
  CheckCircle, 
  Settings,
  Send,
  Smartphone,
  QrCode,
  Wifi,
  WifiOff,
  ExternalLink
} from 'lucide-react';

interface WhatsAppConfig {
  enabled: boolean;
  // Plantillas de mensajes
  templates: {
    orderReceived: {
      enabled: boolean;
      message: string;
    };
    orderCompleted: {
      enabled: boolean;
      message: string;
    };
    invoiceCreated: {
      enabled: boolean;
      message: string;
    };
    reminder: {
      enabled: boolean;
      message: string;
    };
  };
}

const defaultConfig: WhatsAppConfig = {
  enabled: false,
  templates: {
    orderReceived: {
      enabled: true,
      message: `¡Hola {{cliente}}! 📱\n\nHemos recibido tu {{dispositivo}} {{marca}} {{modelo}} para reparación.\n\n🔧 Orden: #{{ordenId}}\n📅 Fecha: {{fecha}}\n⚠️ Problema: {{problema}}\n\nTe mantendremos informado del progreso.\n\n{{empresa}} - {{telefono}}`
    },
    orderCompleted: {
      enabled: true,
      message: `¡Buenas noticias {{cliente}}! ✅\n\nTu {{dispositivo}} {{marca}} {{modelo}} está listo para recoger.\n\n🔧 Orden: #{{ordenId}}\n💰 Total: €{{precio}}\n📍 Dirección: {{direccion}}\n\nHorario: Lunes a Viernes 9:00-18:00\n\n{{empresa}} - {{telefono}}`
    },
    invoiceCreated: {
      enabled: true,
      message: `Hola {{cliente}} 📄\n\nTu factura #{{numeroFactura}} está lista:\n\n💰 Total: €{{total}}\n📅 Fecha: {{fecha}}\n💳 Estado: {{estado}}\n\nGracias por confiar en nosotros.\n\n{{empresa}} - {{telefono}}`
    },
    reminder: {
      enabled: true,
      message: `Hola {{cliente}} 🔔\n\nRecordatorio: Tu {{dispositivo}} está listo para recoger desde hace {{dias}} días.\n\n🔧 Orden: #{{ordenId}}\n📍 {{direccion}}\n⏰ Horario: L-V 9:00-18:00\n\nPor favor, pasa a recogerlo pronto.\n\n{{empresa}} - {{telefono}}`
    }
  }
};

export default function WhatsAppConfig() {
  const [config, setConfig] = useState<WhatsAppConfig>(defaultConfig);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'unknown' | 'connected' | 'disconnected'>('disconnected');
  const [isActivated, setIsActivated] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadConfig();
  }, []);

  const loadConfig = () => {
    try {
      const savedConfig = localStorage.getItem('whatsapp_web_config');
      if (savedConfig) {
        const parsedConfig = JSON.parse(savedConfig);
        setConfig({ ...defaultConfig, ...parsedConfig });
        setIsActivated(parsedConfig.enabled || false);
      }
    } catch (error) {
      console.error('Error loading WhatsApp config:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveConfig = async () => {
    setSaving(true);
    try {
      localStorage.setItem('whatsapp_web_config', JSON.stringify(config));
      toast({
        title: "✅ Configuración guardada",
        description: "La configuración de WhatsApp Web se ha guardado correctamente",
        variant: "default"
      });
    } catch (error) {
      console.error('Error saving WhatsApp config:', error);
      toast({
        title: "Error",
        description: "No se pudo guardar la configuración",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const activateWhatsApp = () => {
    setIsActivated(true);
    setConnectionStatus('connected');
    setConfig(prev => ({ ...prev, enabled: true }));
    
    toast({
      title: "🎉 WhatsApp Web Activado",
      description: "Los mensajes se abrirán automáticamente en WhatsApp Web cuando sea necesario",
      variant: "default"
    });
  };

  const deactivateWhatsApp = () => {
    setIsActivated(false);
    setConnectionStatus('disconnected');
    setConfig(prev => ({ ...prev, enabled: false }));
    
    toast({
      title: "🔌 WhatsApp Web Desactivado",
      description: "Los mensajes automáticos han sido desactivados",
      variant: "default"
    });
  };

  const sendTestMessage = () => {
    if (!isActivated) {
      toast({
        title: "WhatsApp no activado",
        description: "Primero activa WhatsApp Web",
        variant: "destructive"
      });
      return;
    }

    const testMessage = `🧪 Mensaje de prueba desde WhatsApp Web\n\n✅ La integración está funcionando correctamente.\n\nFecha: ${new Date().toLocaleString('es-ES')}`;
    const whatsappUrl = `https://web.whatsapp.com/send?text=${encodeURIComponent(testMessage)}`;
    
    window.open(whatsappUrl, '_blank', 'width=800,height=600');
    
    toast({
      title: "✅ WhatsApp Web abierto",
      description: "Se ha abierto WhatsApp Web con el mensaje de prueba",
      variant: "default"
    });
  };

  const updateTemplate = (template: keyof typeof config.templates, field: string, value: any) => {
    setConfig(prev => ({
      ...prev,
      templates: {
        ...prev.templates,
        [template]: {
          ...prev.templates[template],
          [field]: value
        }
      }
    }));
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-slate-800 flex items-center gap-2">
            <MessageCircle className="w-8 h-8 text-green-600" />
            Configuración de WhatsApp Web
          </h1>
          <p className="text-slate-600 mt-2">
            Sistema de mensajería automática 100% GRATUITO - Sin APIs
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant={isActivated ? "default" : "secondary"}>
            {isActivated ? <CheckCircle className="w-4 h-4 mr-1" /> : <Settings className="w-4 h-4 mr-1" />}
            {isActivated ? 'Activo' : 'Inactivo'}
          </Badge>
        </div>
      </div>

      {/* Configuración principal */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Wifi className="w-5 h-5" />
            Activación de WhatsApp Web
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {!isActivated ? (
            // Estado desactivado
            <div className="text-center py-8">
              <div className="mb-6">
                <Smartphone className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-800 mb-2">WhatsApp Web Desactivado</h3>
                <p className="text-gray-600 mb-6">
                  Activa WhatsApp Web para enviar mensajes automáticos a tus clientes de forma gratuita
                </p>
              </div>
              
              <Button 
                onClick={activateWhatsApp}
                size="lg"
                className="bg-green-600 hover:bg-green-700 text-white px-8 py-3"
              >
                <MessageCircle className="w-5 h-5 mr-2" />
                Activar WhatsApp Web
              </Button>
            </div>
          ) : (
            // Estado activado
            <div className="space-y-4">
              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold text-green-800">✅ WhatsApp Web Activado</h4>
                    <p className="text-sm text-green-700">
                      Los mensajes se abrirán automáticamente en WhatsApp Web cuando sea necesario
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={sendTestMessage}
                      className="border-green-600 text-green-600 hover:bg-green-50"
                    >
                      <Send className="w-4 h-4 mr-1" />
                      Enviar Prueba
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={deactivateWhatsApp}
                    >
                      Desactivar
                    </Button>
                  </div>
                </div>
              </div>

              {/* Información del sistema */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg text-center">
                  <MessageCircle className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                  <h4 className="font-semibold text-blue-800">100% Gratuito</h4>
                  <p className="text-sm text-blue-600">No pagas APIs</p>
                </div>
                <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg text-center">
                  <ExternalLink className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                  <h4 className="font-semibold text-purple-800">Automático</h4>
                  <p className="text-sm text-purple-600">Abre WhatsApp Web solo</p>
                </div>
                <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg text-center">
                  <Settings className="w-8 h-8 text-orange-600 mx-auto mb-2" />
                  <h4 className="font-semibold text-orange-800">Personalizable</h4>
                  <p className="text-sm text-orange-600">Edita plantillas</p>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Plantillas de mensajes */}
      {isActivated && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageCircle className="w-5 h-5" />
              Plantillas de Mensajes
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {Object.entries(config.templates).map(([key, template]) => (
              <TemplateEditor
                key={key}
                title={getTemplateTitle(key)}
                description={getTemplateDescription(key)}
                template={template}
                onUpdate={(field, value) => updateTemplate(key as keyof typeof config.templates, field, value)}
              />
            ))}
          </CardContent>
        </Card>
      )}

      {/* Variables disponibles */}
      {isActivated && (
        <Card>
          <CardHeader>
            <CardTitle>Variables Disponibles</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div>
                <h4 className="font-semibold mb-2">Cliente</h4>
                <ul className="space-y-1 text-gray-600">
                  <li>{'{{cliente}}'}</li>
                  <li>{'{{telefono}}'}</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Orden</h4>
                <ul className="space-y-1 text-gray-600">
                  <li>{'{{ordenId}}'}</li>
                  <li>{'{{dispositivo}}'}</li>
                  <li>{'{{marca}}'}</li>
                  <li>{'{{modelo}}'}</li>
                  <li>{'{{problema}}'}</li>
                  <li>{'{{precio}}'}</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Factura</h4>
                <ul className="space-y-1 text-gray-600">
                  <li>{'{{numeroFactura}}'}</li>
                  <li>{'{{total}}'}</li>
                  <li>{'{{estado}}'}</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Empresa</h4>
                <ul className="space-y-1 text-gray-600">
                  <li>{'{{empresa}}'}</li>
                  <li>{'{{direccion}}'}</li>
                  <li>{'{{telefono}}'}</li>
                  <li>{'{{fecha}}'}</li>
                  <li>{'{{dias}}'}</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Información sobre el funcionamiento */}
      {isActivated && (
        <Card>
          <CardHeader>
            <CardTitle>💡 Cómo Funciona</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-sm text-gray-700">
              <p><strong>1. Automático:</strong> Cuando se crea una orden, factura o recordatorio, se abre WhatsApp Web automáticamente</p>
              <p><strong>2. Pre-escrito:</strong> El mensaje ya está escrito con todos los datos del cliente</p>
              <p><strong>3. Un clic:</strong> Solo necesitas hacer clic en "Enviar" en WhatsApp Web</p>
              <p><strong>4. Sin costos:</strong> Usa tu WhatsApp normal, no pagas APIs ni servicios externos</p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Guardar configuración */}
      {isActivated && (
        <div className="flex justify-end">
          <Button onClick={saveConfig} disabled={saving} className="min-w-32">
            {saving ? (
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Guardando...
              </div>
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" />
                Guardar Configuración
              </>
            )}
          </Button>
        </div>
      )}
    </div>
  );
}

// Componente para editar plantillas
function TemplateEditor({ 
  title, 
  description, 
  template, 
  onUpdate 
}: {
  title: string;
  description: string;
  template: { enabled: boolean; message: string };
  onUpdate: (field: string, value: any) => void;
}) {
  return (
    <div className="p-4 border rounded-lg">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h4 className="font-semibold">{title}</h4>
          <p className="text-sm text-gray-600">{description}</p>
        </div>
        <Switch
          checked={template.enabled}
          onCheckedChange={(enabled) => onUpdate('enabled', enabled)}
        />
      </div>
      
      {template.enabled && (
        <div>
          <Label htmlFor={`template-${title}`}>Mensaje</Label>
          <Textarea
            id={`template-${title}`}
            value={template.message}
            onChange={(e) => onUpdate('message', e.target.value)}
            rows={4}
            className="mt-1"
            placeholder="Escribe tu mensaje aquí..."
          />
        </div>
      )}
    </div>
  );
}

// Funciones auxiliares
function getTemplateTitle(key: string): string {
  const titles = {
    orderReceived: 'Orden Recibida',
    orderCompleted: 'Orden Completada',
    invoiceCreated: 'Factura Creada',
    reminder: 'Recordatorio de Recogida'
  };
  return titles[key as keyof typeof titles] || key;
}

function getTemplateDescription(key: string): string {
  const descriptions = {
    orderReceived: 'Enviado cuando se recibe una nueva orden',
    orderCompleted: 'Enviado cuando una reparación está lista',
    invoiceCreated: 'Enviado cuando se genera una factura',
    reminder: 'Recordatorio para recoger dispositivo'
  };
  return descriptions[key as keyof typeof descriptions] || '';
}

// Función para obtener configuración
export function getWhatsAppConfig(): WhatsAppConfig {
  try {
    const savedConfig = localStorage.getItem('whatsapp_web_config');
    if (savedConfig) {
      return { ...defaultConfig, ...JSON.parse(savedConfig) };
    }
  } catch (error) {
    console.error('Error loading WhatsApp config:', error);
  }
  return defaultConfig;
}
