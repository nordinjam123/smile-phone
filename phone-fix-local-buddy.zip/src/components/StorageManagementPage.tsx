import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Database, 
  Settings, 
  Info, 
  BarChart3, 
  Shield,
  Cloud,
  Server
} from 'lucide-react';
import CustomStorageConfigComponent from './CustomStorageConfig';
import StorageProviderInfo from './StorageProviderInfo';
import { useAuth } from '@/hooks/useAuth';

const StorageManagementPage: React.FC = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('info');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Gestión de Almacenamiento</h1>
          <p className="text-gray-600 mt-2">
            Configura tu propia infraestructura de almacenamiento y paga directamente al proveedor
          </p>
        </div>
        <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-300">
          <Database className="h-3 w-3 mr-1" />
          Almacenamiento Personalizable
        </Badge>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Cloud className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Almacenamiento Actual</p>
                <p className="font-semibold">Centralizado</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <BarChart3 className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Ahorro Potencial</p>
                <p className="font-semibold text-green-600">€10-50/mes</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-purple-100 rounded-lg">
                <Shield className="h-5 w-5 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Control de Datos</p>
                <p className="font-semibold">100% Privado</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-orange-100 rounded-lg">
                <Server className="h-5 w-5 text-orange-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Proveedores</p>
                <p className="font-semibold">5+ Opciones</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Configuración de Almacenamiento
          </CardTitle>
          <CardDescription>
            Elige y configura tu propia solución de almacenamiento
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="info" className="flex items-center gap-2">
                <Info className="h-4 w-4" />
                Información
              </TabsTrigger>
              <TabsTrigger value="configure" className="flex items-center gap-2">
                <Settings className="h-4 w-4" />
                Configurar
              </TabsTrigger>
              <TabsTrigger value="manage" className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4" />
                Gestionar
              </TabsTrigger>
            </TabsList>

            <TabsContent value="info" className="mt-6">
              <StorageProviderInfo />
            </TabsContent>

            <TabsContent value="configure" className="mt-6">
              {user ? (
                <CustomStorageConfigComponent />
              ) : (
                <Card className="border-orange-200 bg-orange-50">
                  <CardContent className="p-6 text-center">
                    <div className="text-orange-700">
                      <Shield className="h-12 w-12 mx-auto mb-4" />
                      <h3 className="text-lg font-medium mb-2">Autenticación Requerida</h3>
                      <p className="mb-4">
                        Debes iniciar sesión para configurar tu almacenamiento personalizado
                      </p>
                      <Button onClick={() => window.location.reload()}>
                        Iniciar Sesión
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="manage" className="mt-6">
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Estado del Almacenamiento</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div>
                          <h4 className="font-medium">Configuración Actual</h4>
                          <p className="text-sm text-gray-600">Usando almacenamiento centralizado</p>
                        </div>
                        <Badge variant="outline">Activo</Badge>
                      </div>
                      
                      <div className="flex items-center justify-between p-4 border-2 border-dashed border-gray-300 rounded-lg">
                        <div>
                          <h4 className="font-medium text-gray-400">Almacenamiento Personalizado</h4>
                          <p className="text-sm text-gray-400">No configurado</p>
                        </div>
                        <Button 
                          variant="outline" 
                          onClick={() => setActiveTab('configure')}
                        >
                          Configurar
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Herramientas de Migración</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Button variant="outline" className="h-auto p-4 justify-start" disabled>
                        <div className="text-left">
                          <div className="font-medium">Exportar Datos</div>
                          <div className="text-xs text-gray-500">Descargar backup completo</div>
                        </div>
                      </Button>
                      
                      <Button variant="outline" className="h-auto p-4 justify-start" disabled>
                        <div className="text-left">
                          <div className="font-medium">Importar Datos</div>
                          <div className="text-xs text-gray-500">Cargar desde backup</div>
                        </div>
                      </Button>
                    </div>
                    
                    <p className="text-sm text-gray-500 mt-4">
                      Las herramientas de migración estarán disponibles una vez configures tu almacenamiento personalizado.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Call to Action */}
      <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-bold mb-2">¿Listo para tomar control de tus datos?</h3>
              <p className="text-blue-100">
                Configura tu propia infraestructura y ahorra en costes de almacenamiento
              </p>
            </div>
            <Button 
              variant="secondary" 
              onClick={() => setActiveTab('configure')}
              className="bg-white text-blue-600 hover:bg-gray-100"
            >
              Comenzar Configuración
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default StorageManagementPage;
