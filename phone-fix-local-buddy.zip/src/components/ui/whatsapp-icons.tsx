import React from 'react';

interface IconProps {
  className?: string;
  size?: number;
}

// Icono principal de WhatsApp
export const WhatsAppIcon: React.FC<IconProps> = ({ 
  className = "w-6 h-6", 
  size 
}) => (
  <svg 
    viewBox="0 0 24 24" 
    className={className}
    width={size}
    height={size}
    fill="currentColor"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.890-5.335 11.893-11.893A11.821 11.821 0 0020.525 3.687"/>
  </svg>
);

// Icono de mensaje de WhatsApp
export const WhatsAppMessageIcon: React.FC<IconProps> = ({ 
  className = "w-5 h-5", 
  size 
}) => (
  <svg 
    viewBox="0 0 24 24" 
    className={className}
    width={size}
    height={size}
    fill="currentColor"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path d="M12.017 2C6.502 2 2.018 6.484 2.018 12s4.484 10 10 10c1.664 0 3.252-.401 4.64-1.112L22 22l-1.112-5.36C21.599 15.252 22 13.664 22 12c0-5.516-4.484-10-10-10v.017zM12 18.5c-3.584 0-6.5-2.916-6.5-6.5s2.916-6.5 6.5-6.5 6.5 2.916 6.5 6.5-2.916 6.5-6.5 6.5z"/>
    <path d="M8.5 13.5l2 2 5-5"/>
  </svg>
);

// Icono de estado de WhatsApp
export const WhatsAppStatusIcon: React.FC<IconProps & { status: 'connected' | 'disconnected' | 'connecting' }> = ({ 
  className = "w-4 h-4", 
  size,
  status 
}) => {
  const getColor = () => {
    switch (status) {
      case 'connected': return 'text-green-600';
      case 'disconnected': return 'text-red-600';
      case 'connecting': return 'text-yellow-600';
      default: return 'text-gray-600';
    }
  };

  return (
    <div className={`inline-flex items-center gap-1 ${getColor()}`}>
      <svg 
        viewBox="0 0 24 24" 
        className={`${className} ${getColor()}`}
        width={size}
        height={size}
        fill="currentColor"
        xmlns="http://www.w3.org/2000/svg"
      >
        <circle cx="12" cy="12" r="10" fill="currentColor" opacity="0.2"/>
        <circle cx="12" cy="12" r="3" fill="currentColor"/>
        {status === 'connecting' && (
          <animateTransform
            attributeName="transform"
            attributeType="XML"
            type="rotate"
            from="0 12 12"
            to="360 12 12"
            dur="1s"
            repeatCount="indefinite"
          />
        )}
      </svg>
      <span className="text-xs font-medium">
        {status === 'connected' && 'Conectado'}
        {status === 'disconnected' && 'Desconectado'}
        {status === 'connecting' && 'Conectando...'}
      </span>
    </div>
  );
};

// Icono de chat/conversación
export const WhatsAppChatIcon: React.FC<IconProps> = ({ 
  className = "w-5 h-5", 
  size 
}) => (
  <svg 
    viewBox="0 0 24 24" 
    className={className}
    width={size}
    height={size}
    fill="currentColor"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path d="M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM6 9h12v2H6V9zm8 5H6v-2h8v2zm4-6H6V6h12v2z"/>
  </svg>
);

// Icono de teléfono con WhatsApp
export const WhatsAppPhoneIcon: React.FC<IconProps> = ({ 
  className = "w-5 h-5", 
  size 
}) => (
  <svg 
    viewBox="0 0 24 24" 
    className={className}
    width={size}
    height={size}
    fill="currentColor"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/>
    <circle cx="18" cy="6" r="3" fill="#25D366"/>
    <path d="M18 4.5c-.83 0-1.5.67-1.5 1.5s.67 1.5 1.5 1.5 1.5-.67 1.5-1.5-.67-1.5-1.5-1.5z" fill="white"/>
  </svg>
);

// Icono de notificación de WhatsApp
export const WhatsAppNotificationIcon: React.FC<IconProps & { hasNotification?: boolean }> = ({ 
  className = "w-5 h-5", 
  size,
  hasNotification = false 
}) => (
  <div className="relative inline-block">
    <WhatsAppIcon className={className} size={size} />
    {hasNotification && (
      <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full flex items-center justify-center">
        <span className="text-white text-xs font-bold">!</span>
      </div>
    )}
  </div>
);

// Badge de estado mejorado
export const WhatsAppBadge: React.FC<{
  status: 'active' | 'inactive' | 'error' | 'connecting';
  children: React.ReactNode;
  className?: string;
}> = ({ status, children, className = "" }) => {
  const getStatusStyles = () => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'inactive':
        return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'error':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'connecting':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getIcon = () => {
    switch (status) {
      case 'active':
        return <WhatsAppIcon className="w-3 h-3" />;
      case 'inactive':
        return <WhatsAppIcon className="w-3 h-3 opacity-50" />;
      case 'error':
        return <WhatsAppIcon className="w-3 h-3 text-red-600" />;
      case 'connecting':
        return <WhatsAppIcon className="w-3 h-3 animate-pulse" />;
      default:
        return <WhatsAppIcon className="w-3 h-3" />;
    }
  };

  return (
    <div className={`inline-flex items-center gap-1 px-2 py-1 rounded-full border text-xs font-medium ${getStatusStyles()} ${className}`}>
      {getIcon()}
      {children}
    </div>
  );
};

// Componente de ayuda visual para problemas de iconos
export const WhatsAppIconFallback: React.FC<{ text?: string; className?: string }> = ({ 
  text = "WA", 
  className = "w-6 h-6" 
}) => (
  <div className={`${className} bg-green-500 text-white rounded-full flex items-center justify-center text-xs font-bold`}>
    {text}
  </div>
);
