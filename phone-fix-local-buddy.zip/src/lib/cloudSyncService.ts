import { supabase } from '@/integrations/supabase/client';

export interface SyncStatus {
  isOnline: boolean;
  lastSync: string | null;
  syncing: boolean;
  pendingChanges: number;
}

interface LocalToCloudMapping {
  [key: string]: {
    table: string;
    transform?: (data: any) => any;
    userField?: string;
  };
}

// Mapeo de datos locales a tablas de Supabase
const DATA_MAPPINGS: LocalToCloudMapping = {
  'ordenes': {
    table: 'ordenes_trabajo',
    userField: 'user_id',
    transform: (data) => {
      // Create a clean object without undefined values
      const result: any = {};

      result.cliente_nombre = data.clienteNombre || data.cliente || 'Cliente sin nombre';
      result.dispositivo = data.dispositivo || `${data.marca || ''} ${data.modelo || ''}`.trim() || 'Dispositivo móvil';
      result.problema = data.problema || data.descripcion || 'Sin especificar';
      result.numero_orden = data.numeroOrden || data.id || `ORD-${Date.now()}`;

      // Optional fields - only add if they have values
      if (data.clienteTelefono || data.telefono) {
        result.cliente_telefono = data.clienteTelefono || data.telefono;
      }
      if (data.clienteEmail || data.email) {
        result.cliente_email = data.clienteEmail || data.email;
      }
      if (data.diagnostico || data.solucion) {
        result.solucion = data.diagnostico || data.solucion;
      }
      if (data.notas) {
        result.notas = data.notas;
      }

      // Set defaults for required fields
      result.estado = data.estado || 'pendiente';
      result.prioridad = data.prioridad || 'normal';
      result.fecha_ingreso = data.fechaIngreso || data.fecha || new Date().toISOString().split('T')[0];

      // Optional dates
      if (data.fechaEstimada) {
        result.fecha_estimada = data.fechaEstimada;
      }
      if (data.fechaCompletado) {
        result.fecha_completado = data.fechaCompletado;
      }

      // Price - convert to number if it's a string
      if (data.precio || data.coste) {
        const price = data.precio || data.coste;
        result.precio = typeof price === 'string' ? parseFloat(price) : price;
      }

      return result;
    }
  },
  'clientes': {
    table: 'clientes',
    userField: 'user_id'
  },
  'inventario': {
    table: 'inventario',
    userField: 'user_id'
  },
  'inventario_piezas': {
    table: 'inventario',
    userField: 'user_id'
  },
  'inventario_mercancia': {
    table: 'gastos_mercancia',
    userField: 'user_id',
    transform: (data) => {
      const precio = data.precio || data.precioVenta || data.precioCoste || 0;
      const cantidad = data.stock || data.cantidad || 1;
      return {
        categoria: data.categoria || 'inventario',
        tipo_producto: data.tipo || data.nombre || 'producto',
        proveedor: data.proveedor || 'Sin especificar',
        precio_unitario: typeof precio === 'string' ? parseFloat(precio) : precio,
        cantidad: typeof cantidad === 'string' ? parseInt(cantidad) : cantidad,
        total: (typeof precio === 'string' ? parseFloat(precio) : precio) * (typeof cantidad === 'string' ? parseInt(cantidad) : cantidad),
        fecha: data.fecha || new Date().toISOString().split('T')[0],
        descripcion: data.descripcion || data.nombre || null,
        notas: data.notas || null
      };
    }
  },
  'productos_mercancia': {
    table: 'gastos_mercancia',
    userField: 'user_id',
    transform: (data) => {
      const precio = data.precio || data.precioVenta || data.precioCoste || 0;
      const cantidad = data.stock || data.cantidad || 1;
      return {
        categoria: data.categoria || 'productos',
        tipo_producto: data.tipo || data.nombre || 'producto',
        proveedor: data.proveedor || 'Sin especificar',
        precio_unitario: typeof precio === 'string' ? parseFloat(precio) : precio,
        cantidad: typeof cantidad === 'string' ? parseInt(cantidad) : cantidad,
        total: (typeof precio === 'string' ? parseFloat(precio) : precio) * (typeof cantidad === 'string' ? parseInt(cantidad) : cantidad),
        fecha: data.fecha || new Date().toISOString().split('T')[0],
        descripcion: data.descripcion || data.nombre || null,
        notas: data.notas || null
      };
    }
  },
  'gastos_mercancia': {
    table: 'gastos_mercancia',
    userField: 'user_id'
  },
  'ventas_tpv': {
    table: 'facturas',
    userField: 'user_id',
    transform: (data) => {
      const total = data.total || data.totalVenta || 0;
      const subtotal = total / 1.21; // Assuming 21% IVA
      const iva = total - subtotal;

      return {
        cliente_nombre: data.nombreCliente || data.cliente || 'Cliente TPV',
        numero: data.numero || data.id || `TPV-${Date.now()}`,
        fecha: data.fecha || new Date().toISOString().split('T')[0],
        total: typeof total === 'string' ? parseFloat(total) : total,
        subtotal: Math.round(subtotal * 100) / 100,
        iva: Math.round(iva * 100) / 100,
        tipo: 'venta_tpv',
        estado: 'pagada',
        conceptos: data.productos || data.items || [],
        cliente_telefono: data.telefono || null,
        cliente_email: data.email || null,
        notas: data.notas || null
      };
    }
  },
  'citas': {
    table: 'citas',
    userField: 'user_id'
  },
  'facturas': {
    table: 'facturas',
    userField: 'user_id'
  }
};

class CloudSyncService {
  private syncStatus: SyncStatus = {
    isOnline: navigator.onLine,
    lastSync: localStorage.getItem('lastCloudSync'),
    syncing: false,
    pendingChanges: 0
  };

  private statusCallbacks: ((status: SyncStatus) => void)[] = [];

  constructor() {
    // Monitor online status
    window.addEventListener('online', () => {
      this.updateStatus({ isOnline: true });
      this.autoSync();
    });

    window.addEventListener('offline', () => {
      this.updateStatus({ isOnline: false });
    });

    // Auto sync every 5 minutes when online
    setInterval(() => {
      if (this.syncStatus.isOnline && !this.syncStatus.syncing) {
        this.autoSync();
      }
    }, 5 * 60 * 1000);
  }

  private updateStatus(updates: Partial<SyncStatus>) {
    this.syncStatus = { ...this.syncStatus, ...updates };
    this.statusCallbacks.forEach(callback => callback(this.syncStatus));
  }

  onStatusChange(callback: (status: SyncStatus) => void) {
    this.statusCallbacks.push(callback);
    return () => {
      const index = this.statusCallbacks.indexOf(callback);
      if (index > -1) this.statusCallbacks.splice(index, 1);
    };
  }

  async getUserId(): Promise<string | null> {
    const { data: { user } } = await supabase.auth.getUser();
    return user?.id || null;
  }

  async migrateAllLocalDataToCloud(): Promise<{ success: boolean; migrated: number; errors: string[] }> {
    const userId = await this.getUserId();
    if (!userId) {
      return { success: false, migrated: 0, errors: ['Usuario no autenticado'] };
    }

    this.updateStatus({ syncing: true });
    
    let migratedCount = 0;
    const errors: string[] = [];

    try {
      for (const [localKey, mapping] of Object.entries(DATA_MAPPINGS)) {
        try {
          const localDataStr = localStorage.getItem(localKey);
          if (!localDataStr) {
            console.log(`⏭️ Skipping ${localKey}: no data found`);
            continue;
          }

          const localData = JSON.parse(localDataStr);
          if (!Array.isArray(localData) || localData.length === 0) {
            console.log(`⏭️ Skipping ${localKey}: empty array`);
            continue;
          }

          console.log(`📤 Processing ${localKey}: ${localData.length} items`);

          // Transform data if needed
          const dataToUpload = localData.map((item, index) => {
            try {
              const transformed = mapping.transform ? mapping.transform(item) : item;
              const result = {
                ...transformed,
                [mapping.userField || 'user_id']: userId
              };

              // Only keep existing ID if it's valid
              if (item.id && typeof item.id === 'string' && item.id.length > 0) {
                result.id = item.id;
              }

              // Validate required fields based on table
              if (mapping.table === 'ordenes_trabajo') {
                if (!result.cliente_nombre) {
                  console.warn(`Item ${index} missing cliente_nombre, using default`);
                  result.cliente_nombre = 'Cliente sin nombre';
                }
                if (!result.dispositivo) {
                  console.warn(`Item ${index} missing dispositivo, using default`);
                  result.dispositivo = 'Dispositivo';
                }
                if (!result.problema) {
                  console.warn(`Item ${index} missing problema, using default`);
                  result.problema = 'Sin especificar';
                }
                if (!result.numero_orden) {
                  result.numero_orden = `ORD-${Date.now()}-${index}`;
                }
              } else if (mapping.table === 'gastos_mercancia') {
                if (!result.categoria) result.categoria = 'general';
                if (!result.tipo_producto) result.tipo_producto = 'producto';
                if (!result.proveedor) result.proveedor = 'Sin especificar';
                if (typeof result.precio_unitario !== 'number') {
                  result.precio_unitario = 0;
                }
                if (typeof result.cantidad !== 'number') {
                  result.cantidad = 1;
                }
                if (typeof result.total !== 'number') {
                  result.total = result.precio_unitario * result.cantidad;
                }
                if (!result.fecha) {
                  result.fecha = new Date().toISOString().split('T')[0];
                }
              } else if (mapping.table === 'facturas') {
                if (!result.cliente_nombre) {
                  result.cliente_nombre = 'Cliente sin nombre';
                }
                if (!result.numero) {
                  result.numero = `FACT-${Date.now()}-${index}`;
                }
                if (!result.fecha) {
                  result.fecha = new Date().toISOString().split('T')[0];
                }
                if (typeof result.total !== 'number') {
                  result.total = 0;
                }
                if (typeof result.subtotal !== 'number') {
                  result.subtotal = result.total / 1.21;
                }
                if (typeof result.iva !== 'number') {
                  result.iva = result.total - result.subtotal;
                }
                if (!result.estado) {
                  result.estado = 'borrador';
                }
                if (!result.tipo) {
                  result.tipo = 'factura';
                }
              }

              return result;
            } catch (transformError) {
              console.error(`Error transforming item ${index} in ${localKey}:`, transformError);
              throw new Error(`Transform error at item ${index}: ${transformError.message}`);
            }
          });

          console.log(`📋 Uploading ${dataToUpload.length} items to ${mapping.table}`);
          console.log('Sample transformed data:', dataToUpload[0]);

          // Validate data before upload
          if (dataToUpload.length === 0) {
            console.warn(`No data to upload for ${localKey}`);
            continue;
          }

          // Upload to Supabase
          const { error, data } = await supabase
            .from(mapping.table)
            .upsert(dataToUpload);

          if (error) {
            console.error(`Error migrating ${localKey}:`, error);
            let errorMessage = 'Unknown error';

            if (typeof error === 'string') {
              errorMessage = error;
            } else if (error.message) {
              errorMessage = error.message;
            } else if (error.details) {
              errorMessage = error.details;
            } else if (error.hint) {
              errorMessage = error.hint;
            } else if (error.code) {
              errorMessage = `Error code: ${error.code}`;
            } else {
              errorMessage = JSON.stringify(error);
            }

            errors.push(`${localKey}: ${errorMessage}`);
          } else {
            migratedCount += dataToUpload.length;
            console.log(`✅ Migrated ${dataToUpload.length} items from ${localKey} to ${mapping.table}`);
          }
        } catch (error: any) {
          console.error(`Error processing ${localKey}:`, error);
          let errorMessage = 'Unknown processing error';

          if (typeof error === 'string') {
            errorMessage = error;
          } else if (error.message) {
            errorMessage = error.message;
          } else if (error.stack) {
            errorMessage = error.stack.split('\n')[0];
          } else {
            errorMessage = JSON.stringify(error);
          }

          errors.push(`${localKey}: ${errorMessage}`);
        }
      }

      // Update last sync time
      const now = new Date().toISOString();
      localStorage.setItem('lastCloudSync', now);
      this.updateStatus({ lastSync: now });

      return { 
        success: errors.length === 0, 
        migrated: migratedCount, 
        errors 
      };
    } finally {
      this.updateStatus({ syncing: false });
    }
  }

  async loadDataFromCloud(dataType: string): Promise<any[]> {
    const userId = await this.getUserId();
    if (!userId) return [];

    const mapping = DATA_MAPPINGS[dataType];
    if (!mapping) return [];

    try {
      const { data, error } = await supabase
        .from(mapping.table)
        .select('*')
        .eq(mapping.userField || 'user_id', userId);

      if (error) throw error;

      // Update localStorage with cloud data
      if (data) {
        localStorage.setItem(dataType, JSON.stringify(data));
        return data;
      }
    } catch (error) {
      console.error(`Error loading ${dataType} from cloud:`, error);
    }

    return [];
  }

  async saveToCloud(dataType: string, data: any[]): Promise<boolean> {
    const userId = await this.getUserId();
    if (!userId) return false;

    const mapping = DATA_MAPPINGS[dataType];
    if (!mapping) return false;

    try {
      // Transform data if needed
      const dataToSave = data.map(item => {
        const transformed = mapping.transform ? mapping.transform(item) : item;
        return {
          ...transformed,
          [mapping.userField || 'user_id']: userId
        };
      });

      const { error } = await supabase
        .from(mapping.table)
        .upsert(dataToSave);

      if (error) throw error;

      // Update localStorage
      localStorage.setItem(dataType, JSON.stringify(data));
      
      return true;
    } catch (error) {
      console.error(`Error saving ${dataType} to cloud:`, error);
      return false;
    }
  }

  async autoSync(): Promise<boolean> {
    if (this.syncStatus.syncing || !this.syncStatus.isOnline) return false;

    const userId = await this.getUserId();
    if (!userId) return false;

    this.updateStatus({ syncing: true });

    try {
      // Load all data from cloud and update localStorage
      for (const dataType of Object.keys(DATA_MAPPINGS)) {
        await this.loadDataFromCloud(dataType);
      }

      const now = new Date().toISOString();
      localStorage.setItem('lastCloudSync', now);
      this.updateStatus({ lastSync: now });

      return true;
    } catch (error) {
      console.error('Auto sync failed:', error);
      return false;
    } finally {
      this.updateStatus({ syncing: false });
    }
  }

  async clearLocalData(): Promise<void> {
    Object.keys(DATA_MAPPINGS).forEach(key => {
      localStorage.removeItem(key);
    });
    localStorage.removeItem('lastCloudSync');
    this.updateStatus({ lastSync: null });
  }

  getStatus(): SyncStatus {
    return { ...this.syncStatus };
  }
}

export const cloudSyncService = new CloudSyncService();
