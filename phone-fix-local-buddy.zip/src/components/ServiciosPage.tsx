import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Smartphone, Laptop, Tablet, Headphones, Watch, Check, Star, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const servicios = [
  {
    id: "pantalla-movil",
    title: "Reparación de Pantalla Móvil",
    description: "Reparación profesional de pantallas rotas o dañadas",
    icon: Smartphone,
    price: 89,
    duration: "1-2 horas",
    features: ["Garantía 6 meses", "Piezas originales", "Diagnóstico gratuito"],
    popular: true
  },
  {
    id: "bateria-movil",
    title: "Cambio de Batería",
    description: "Sustitución de batería deteriorada por una nueva",
    icon: Smartphone,
    price: 45,
    duration: "30 minutos",
    features: ["Batería de alta calidad", "Garantía 3 meses", "Instalación rápida"],
    popular: false
  },
  {
    id: "reparacion-laptop",
    title: "Reparación de Laptop",
    description: "Diagnóstico y reparación completa de ordenadores portátiles",
    icon: Laptop,
    price: 120,
    duration: "1-3 días",
    features: ["Diagnóstico completo", "Limpieza interna", "Garantía 1 año"],
    popular: false
  },
  {
    id: "pantalla-tablet",
    title: "Reparación Tablet",
    description: "Reparación de pantallas y componentes de tablets",
    icon: Tablet,
    price: 95,
    duration: "2-4 horas",
    features: ["Todas las marcas", "Garantía 6 meses", "Presupuesto sin compromiso"],
    popular: false
  },
  {
    id: "auriculares",
    title: "Reparación Auriculares",
    description: "Reparación de auriculares y dispositivos de audio",
    icon: Headphones,
    price: 35,
    duration: "1 hora",
    features: ["Reparación cables", "Sustitución drivers", "Prueba de calidad"],
    popular: false
  },
  {
    id: "smartwatch",
    title: "Reparación Smartwatch",
    description: "Reparación de relojes inteligentes y wearables",
    icon: Watch,
    price: 75,
    duration: "1-2 días",
    features: ["Apple Watch y Android", "Pantallas y correas", "Sincronización"],
    popular: false
  }
];

export default function ServiciosPage() {
  const { toast } = useToast();
  const [selectedService, setSelectedService] = useState<any>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    deviceBrand: "",
    deviceModel: "",
    problemDescription: "",
    urgency: "normal",
    contactPreference: "phone"
  });

  const handleServiceRequest = (service: any) => {
    setSelectedService(service);
    setIsDialogOpen(true);
  };

  const handleSubmitRequest = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Aquí conectarías con Supabase para guardar la solicitud
    toast({
      title: "¡Solicitud enviada!",
      description: `Hemos recibido tu solicitud para ${selectedService?.title}. Te contactaremos pronto.`,
    });
    
    setIsDialogOpen(false);
    setFormData({
      deviceBrand: "",
      deviceModel: "",
      problemDescription: "",
      urgency: "normal",
      contactPreference: "phone"
    });
  };

  return (
    <div className="p-6 space-y-8">
      <div className="text-center max-w-3xl mx-auto">
        <h1 className="text-4xl font-bold text-foreground mb-4">
          Nuestros Servicios de Reparación
        </h1>
        <p className="text-xl text-muted-foreground mb-8">
          Servicios profesionales de reparación con garantía y atención personalizada
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {servicios.map((service) => {
          const Icon = service.icon;
          return (
            <Card key={service.id} className="relative hover:shadow-lg transition-shadow">
              {service.popular && (
                <Badge className="absolute -top-2 left-4 bg-primary text-primary-foreground">
                  Más Popular
                </Badge>
              )}
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">{service.title}</CardTitle>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Clock className="w-4 h-4" />
                      {service.duration}
                    </div>
                  </div>
                </div>
                <CardDescription className="mt-2">
                  {service.description}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-3xl font-bold text-primary">
                  €{service.price}
                  <span className="text-base font-normal text-muted-foreground ml-2">
                    desde
                  </span>
                </div>
                
                <ul className="space-y-2">
                  {service.features.map((feature, index) => (
                    <li key={index} className="flex items-center gap-2 text-sm">
                      <Check className="w-4 h-4 text-success" />
                      {feature}
                    </li>
                  ))}
                </ul>

                <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                  <DialogTrigger asChild>
                    <Button 
                      className="w-full" 
                      onClick={() => handleServiceRequest(service)}
                    >
                      Solicitar Servicio
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                      <DialogTitle>Solicitar: {selectedService?.title}</DialogTitle>
                      <DialogDescription>
                        Completa los detalles para que podamos ayudarte mejor
                      </DialogDescription>
                    </DialogHeader>
                    <form onSubmit={handleSubmitRequest} className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="brand">Marca del dispositivo</Label>
                          <Input
                            id="brand"
                            placeholder="Samsung, Apple, etc."
                            value={formData.deviceBrand}
                            onChange={(e) => setFormData({ ...formData, deviceBrand: e.target.value })}
                            required
                          />
                        </div>
                        <div>
                          <Label htmlFor="model">Modelo</Label>
                          <Input
                            id="model"
                            placeholder="iPhone 13, Galaxy S21, etc."
                            value={formData.deviceModel}
                            onChange={(e) => setFormData({ ...formData, deviceModel: e.target.value })}
                            required
                          />
                        </div>
                      </div>
                      
                      <div>
                        <Label htmlFor="description">Descripción del problema</Label>
                        <Textarea
                          id="description"
                          placeholder="Describe qué le ocurre a tu dispositivo..."
                          value={formData.problemDescription}
                          onChange={(e) => setFormData({ ...formData, problemDescription: e.target.value })}
                          required
                        />
                      </div>

                      <div>
                        <Label htmlFor="urgency">Urgencia</Label>
                        <Select 
                          value={formData.urgency} 
                          onValueChange={(value) => setFormData({ ...formData, urgency: value })}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="low">Baja - Puedo esperar</SelectItem>
                            <SelectItem value="normal">Normal - En unos días</SelectItem>
                            <SelectItem value="high">Alta - Lo antes posible</SelectItem>
                            <SelectItem value="urgent">Urgente - Hoy mismo</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label htmlFor="contact">Preferencia de contacto</Label>
                        <Select 
                          value={formData.contactPreference} 
                          onValueChange={(value) => setFormData({ ...formData, contactPreference: value })}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="phone">Teléfono</SelectItem>
                            <SelectItem value="email">Email</SelectItem>
                            <SelectItem value="whatsapp">WhatsApp</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="flex gap-2">
                        <Button type="submit" className="flex-1">
                          Enviar Solicitud
                        </Button>
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={() => setIsDialogOpen(false)}
                        >
                          Cancelar
                        </Button>
                      </div>
                    </form>
                  </DialogContent>
                </Dialog>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="bg-muted/50 rounded-lg p-8 text-center">
        <h2 className="text-2xl font-bold mb-4">¿No encuentras lo que buscas?</h2>
        <p className="text-muted-foreground mb-6">
          Contáctanos para servicios personalizados y presupuestos especiales
        </p>
        <div className="flex items-center justify-center gap-4">
          <Button variant="outline">
            📞 Llamar ahora
          </Button>
          <Button>
            📧 Enviar mensaje
          </Button>
        </div>
      </div>
    </div>
  );
}