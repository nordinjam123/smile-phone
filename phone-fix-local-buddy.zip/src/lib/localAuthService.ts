import { supabase } from '@/integrations/supabase/client';
import type { User } from '@supabase/supabase-js';

export interface LocalUser {
  id: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
  workshopName?: string;
  contactPerson?: string;
}

class LocalAuthService {
  private currentUser: LocalUser | null = null;
  private authListeners: ((user: LocalUser | null) => void)[] = [];

  constructor() {
    this.initializeAuth();
  }

  private async initializeAuth() {
    // Get current session from Supabase
    const { data: { session } } = await supabase.auth.getSession();
    
    if (session?.user) {
      this.currentUser = this.mapSupabaseUser(session.user);
      this.notifyListeners();
    }

    // Listen for auth changes
    supabase.auth.onAuthStateChange((event, session) => {
      if (session?.user) {
        this.currentUser = this.mapSupabaseUser(session.user);
      } else {
        this.currentUser = null;
      }
      this.notifyListeners();
    });
  }

  private mapSupabaseUser(user: User): LocalUser {
    return {
      id: user.id,
      email: user.email || null,
      displayName: user.user_metadata?.full_name || user.email || null,
      photoURL: user.user_metadata?.avatar_url || null,
      workshopName: user.user_metadata?.workshop_name,
      contactPerson: user.user_metadata?.contact_person
    };
  }

  private notifyListeners() {
    this.authListeners.forEach(listener => listener(this.currentUser));
  }

  // Authentication methods
  async signInWithEmail(email: string, password: string): Promise<{ user: LocalUser | null; error: string | null }> {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (error) {
        return { user: null, error: this.getErrorMessage(error) };
      }

      if (data.user) {
        const user = this.mapSupabaseUser(data.user);
        this.currentUser = user;
        return { user, error: null };
      }

      return { user: null, error: 'Error desconocido' };
    } catch (error: any) {
      return { user: null, error: error.message || 'Error de conexión' };
    }
  }

  async signUpWithEmail(
    email: string, 
    password: string, 
    additionalData?: { workshopName?: string; contactPerson?: string }
  ): Promise<{ user: LocalUser | null; error: string | null }> {
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: additionalData?.contactPerson || email,
            workshop_name: additionalData?.workshopName,
            contact_person: additionalData?.contactPerson
          }
        }
      });

      if (error) {
        return { user: null, error: this.getErrorMessage(error) };
      }

      if (data.user) {
        const user = this.mapSupabaseUser(data.user);
        this.currentUser = user;
        return { user, error: null };
      }

      return { user: null, error: 'Error en el registro' };
    } catch (error: any) {
      return { user: null, error: error.message || 'Error de registro' };
    }
  }



  async signOut(): Promise<{ success: boolean; error: string | null }> {
    try {
      const { error } = await supabase.auth.signOut();
      
      if (error) {
        return { success: false, error: this.getErrorMessage(error) };
      }

      this.currentUser = null;
      return { success: true, error: null };
    } catch (error: any) {
      return { success: false, error: error.message || 'Error al cerrar sesión' };
    }
  }

  onAuthStateChanged(callback: (user: LocalUser | null) => void): () => void {
    this.authListeners.push(callback);
    
    // Call immediately with current user
    callback(this.currentUser);
    
    // Return unsubscribe function
    return () => {
      const index = this.authListeners.indexOf(callback);
      if (index > -1) {
        this.authListeners.splice(index, 1);
      }
    };
  }

  getCurrentUser(): LocalUser | null {
    return this.currentUser;
  }

  isAuthenticated(): boolean {
    return this.currentUser !== null;
  }

  private getErrorMessage(error: any): string {
    switch (error.message) {
      case 'Invalid login credentials':
        return 'Credenciales inválidas';
      case 'Email not confirmed':
        return 'Email no confirmado. Revisa tu bandeja de entrada.';
      case 'User already registered':
        return 'El usuario ya está registrado';
      case 'Weak password':
        return 'La contraseña es muy débil';
      case 'Invalid email':
        return 'Email inválido';
      default:
        return error.message || 'Error desconocido';
    }
  }
}

export const localAuthService = new LocalAuthService();
